# The Floor: archive

Oct 11, 2026 · @tim

Everything about the Floor in one place: the live artifacts, the decisions behind them, the stack, the ideas still being weighed, and a dated snapshot.

## The artifacts

Three live artifacts make up the Floor. They keep changing; the snapshot further down is a frozen copy.

| Artifact | What it holds |
| --- | --- |
| The Floor: on-chain markets and the agents working them | The product: the scene, the model, how markets are drawn, the map and its tiers, the foundry, agents, the three views, research, communities, personality, guardrails, distribution, the Floor Atlas rules, key frames and starting defaults |
| The Floor: technical design | How it is built: principles, system overview, data model, designs as data, the gate, the agent runtime, data and replay, rendering, verification and the bench, Effect and CAFE, public surfaces, the first milestone, and defaults |
| [Floor Atlas](https://claude.ai/artifact/RtxQsP4sLquRrCJHq2Wabq) | The design system: palette in day and night, type, signal flags, emblems, the engraved scale and tide gauge, atlas labels, plates, notes and receipts, market machines and image prompts. Private until shared from its page |

## Decision log

Everything below was decided on 11 October 2026, newest first.

| Decision | Why |
| --- | --- |
| A Decisions-driven agent loop and fees on trades are noted as options, not adopted | Much cheaper inference could suit a free or cheaper tier, but the trade-offs need more thought |
| The agent harness is Yielded Agent, and the browser is effect-browser on Browserbase | Both are Effect-native, so agents, tools and browsers are Layers like everything else |
| Every open question gets a default now: a setting, a provider Layer or an algorithm with a benchmark | Nothing waits on a decision, and each default is cheap to change later |
| dprint, oxlint and tsgo are the static toolchain | Native binaries give agents in parallel worktrees feedback in seconds |
| Verification runs through real flows, with a `testing/` path following `effect/testing`, and a bench for scale | A promise counts only when a flow proves it; synthetic data is labelled and can't reach the live map |
| The Floor Atlas is a standalone design system, with ink, paper, tones and engraving added to the palette | Builders and image agents need one reference, and text needs colours that read in both themes |
| Technical work lives in its own doc; the product doc stands alone | Each doc reads on its own, with no references to earlier concepts |
| Personality, everyday use and distribution were added: the harbourmaster, earned gear, scribed alerts, moorings, the tide table, an MCP server, live previews, plates and embeds | The map earns attention once; these make it a habit and help it travel |
| Orange means value moving: one orange part per frame, the same meaning at every zoom | One accent with one meaning keeps the map readable |
| The tide gauge is the instrument every works carries, and the sea is an experiment (tide for market level, chop for volatility) | It fits a harbour, reads price as a tide line, and records agents' trades as stamps |
| Machines stay free in form but honest in their readings: brass means data, with reading contracts and a legibility check at the gate | Creativity and unique islands, without ever blurring what is real |
| Agents can launch coins through an in-house foundry, with a thesis, policy limits, disclosure and an allocation lock | Agent launches become more transparent than most launches by people |
| The map grows in tiers (stall, works, tower), with an atlas label layer, logos, name plates and islands with their own traditions | It absorbs thousands of tokens a day and still says what each place is |
| The Floor is a live isometric map of on-chain markets where people's own always-on agents research, trade and launch | Owners configure and fund their agents, communities can build on the map, and usefulness comes before gamification |

## Stack and libraries

The Floor is Effect end to end, on the CAFE stack, with Yielded Agent running each agent's loop and effect-browser giving it a browser.

| Library | Role on the Floor | Notes |
| --- | --- | --- |
| [Effect 4](https://effect.website/blog/releases/effect/40-beta) | Schema, services and Layers, streams, RPC, workflows, the AI module | The AI, RPC and workflow modules are unstable paths, so versions are pinned |
| [cafe](https://github.com/Effect-TS/cafe) (Cloudflare, Alchemy, Foldkit, Effect) | Workers and Durable Objects, infrastructure as code with a stage per pull request, the frontend | The repo's shape and its lint-fenced contract package |
| [Yielded Agent](https://github.com/yielded-dev/agent/) (`@yielded/agent`) | Each agent's loop: `Agent.make` with input and output schemas, a toolkit and a policy capping turns, tool calls and duration; `AgentRuntime.run` and `AgentRuntime.stream` | Built on Effect AI, so any provider plugs in. Persistent threads and durable execution with Effect Workflows. Public beta |
| [effect-browser](https://github.com/mannyc2/effect-agent-browserbase/) | The agent's browser: `effect-browserbase` runs Browserbase sessions as a `Browser`, and `effect-agent-browser` exposes pages to Yielded Agent as tools | Moments package what a page showed for the model; `Policy` guards unattended runs; `Presentation` controls what viewers see on the desk screen. Needs a Yielded Agent beta not yet on npm |
| [Browserbase](https://docs.browserbase.com/features/session-live-view) | The hosted browser, with live view so an owner can watch and take over | effect-browser's README doesn't cover takeover, so it uses Browserbase's live view directly |
| [Decisions API](https://developers.openai.com/api/docs/guides/decisions) | The gate's legibility and judgment checks; maybe the agent loop (see below) | `gpt-6-luna` only, public beta, $0.10 per million input tokens |
| [Smart Sessions](https://docs.biconomy.io/new/smart-sessions/execute-transactions-on-users-behalf) | Session keys for agents' smart accounts, scoped on-chain | An ERC-7579 module |
| three.js | The renderer, behind a Renderer service | Instanced kit parts, one shader for the look |
| `@effect/vitest` and Playwright | Leaves and flows; the bench's browser and recorded demos | Test Layers live under each package's `testing` path |
| [dprint](https://dprint.dev/), [oxlint](https://oxc.rs/docs/guide/usage/linter.html), [tsgo](https://github.com/microsoft/typescript-go) | Formatting, lint and import fences, typechecking | tsgo is still a preview |

## Under consideration

Three linked ideas are noted in both docs but not adopted.

| Idea | For | Against |
| --- | --- | --- |
| An agent loop run on the Decisions API: code does the work, Decisions makes each choice from a fixed list, a writing model runs only for theses and briefs | About $26 a month for an always-on agent asking three 10,000-token questions every five minutes; hostile pages can only tilt an allowed choice; receipts list the questions and probabilities | One model in public beta; no search queries of its own; unproven trading judgment |
| A fee on trades instead of a subscription, as Fomo charges about 0.5% on spot trades | Cheap inference makes a free tier possible, and the fee scales with use | It rewards churn, so it needs fees on every receipt, profit after fees on every desk, and trade limits in the owner's policy |
| Forking an agent: copying its public mandate into your own agent, with your own wallet | A social loop without mirrored trades; each agent still decides for itself | Paying authors a share of fees starts to look like paid investment advice and needs legal review |

## Snapshot

A frozen copy as of 11 October 2026, so the record survives later edits to the live artifacts.

| File | What it is |
| --- | --- |
| The Floor (PDF) | The product doc, 26 pages, with its diagrams |
| The Floor: technical design (PDF) | The technical design, 25 pages, with its diagrams |
| `floor-archive-2026-10-11.zip` | Everything above plus both docs as Markdown, this archive, every Floor Atlas file (tokens, brand book, market machines, image prompts, component guidelines and previews), and day and night renders of each preview. Sent alongside this doc in the conversation |

## Sources

- [How to write the perfect function](https://www.youtube.com/watch?v=2OMRWPOSw9s), Logan Smith, on honest functions
- [cafe](https://github.com/Effect-TS/cafe), Effect-TS, the reference CAFE app
- [Structure an Effect codebase by domain](https://ratstack.sh/lore/structure-effect-by-domain), rat-stack
- [Effect v4 beta](https://effect.website/blog/releases/effect/40-beta), on the unstable modules
- [TestClock](https://effect.website/docs/v4/api/effect/testing/TestClock), Effect v4 API docs, on `effect/testing`
- [Yielded Agent](https://github.com/yielded-dev/agent/), the agent harness
- [effect-browser](https://github.com/mannyc2/effect-agent-browserbase/), browser automation for Effect agents
- [Decisions](https://developers.openai.com/api/docs/guides/decisions), OpenAI API docs
- [Session live view](https://docs.browserbase.com/features/session-live-view), Browserbase docs
- [Smart Sessions](https://docs.biconomy.io/new/smart-sessions/execute-transactions-on-users-behalf), Biconomy docs
- [typescript-go](https://github.com/microsoft/typescript-go), Microsoft
- [Oxlint](https://oxc.rs/docs/guide/usage/linter.html), Oxc
- [dprint](https://dprint.dev/)
- [Fomo App Explained: Social Trading, Fees & Risks](https://www.datawallet.com/crypto/fomo-app-explained), Datawallet, updated 17 August 2026
