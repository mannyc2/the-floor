# The Floor: technical design

Oct 11, 2026 · @tim

This is how Doc gets built. The product doc says what people see; this doc says what has to be true underneath for it to stay honest, fast and open to contributions. Everything here was chosen so the expensive decisions are made once, early, and everything else can be added later without migrations.

## Principles

### The order of work

The contracts are the decisions that get more expensive every day they wait. Every design, agent and receipt is written against them, so changing one later means migrating all of them. A machine's look is local by comparison: an ugly design gets redrawn and nothing else notices. That sets the order.

1. **Contracts.** The Schema types, the reading contract per kind of market, the submission format, the mandate and policy, and the receipt.
2. **The gate.** The checks that let a design, a build or a launch be accepted without a person reading it.
3. **The shared runtime.** Camera, renderer, atlas layer, data pipeline and agent runtime, built once for everything.
4. **Content and polish.** Machine designs, island traditions, sound, the sea. All of it is additive.

The contracts are designed first but proved continuously against a real slice of the map, because every rule so far has come from a concrete case breaking an abstract one.

### One honesty rule

Nothing on the Floor may change because of something you can't trace. That one rule shows up in three places:

- **Machines** read only the chain data their market's reading contract declares. A design chooses the form, never the inputs.
- **Agents** act only through the signing service and its policy, and every action leaves a receipt linking sources, thesis, policy check and transaction.
- **Community builds** read only their own token's numbers, through drivers that can't see anything else.

### Nothing simulated

The chain is the simulation. The Floor renders real state and records its own events (agents' actions, notes, approvals), stamped with the block they happened at. That makes replay exact and cheap, and it means the server never runs a model of the market, only an index of it.

### Additive, always

Signatures and schemas grow; they never break. A new kind of market adds a reading contract. A new instrument adds a kit part. A new chain adds an island. Nothing that already exists has to change for any of these.

### Proved by real flows

A claim about the Floor counts only when a flow proves it: the real components, run end to end, with only the edges recorded. Each product promise (every trade has a receipt, a hostile page can't move money, replay matches live) is a named flow that runs on every pull request, locally and against that pull request's preview stage. Unit tests prove the leaves; flows prove the product.

### Defaults over open questions

Nothing waits on an undecided question. Each one gets a sane default now, held where it is cheap to change: a setting, a swappable Layer, or an algorithm judged by a benchmark. Defaults, and how they change, near the end, lists them.

## System overview

The Floor has two sources of truth, the chains and its own agents, and one trusted path for anything that moves money.

&#91;embedded content: architecture · market data down the left, money through the signing service on the right\]

The signing service is the only box that can reach a chain with a transaction, and nothing in it calls a model.

- **Market data** flows one way. Indexers read each chain and normalise it into readings (reserves, prices, trades, liquidity bands, utilization). They write the readings to a history store and stream them to district objects. A district object aggregates its markets, assigns tiers and streams updates to the viewers looking at it.
- **Agents** live in their own objects. Each runs its loop against a cloud browser, an inference service and the chain readings. When it wants to trade or launch, it sends a proposal to the signing service, the only component that can sign anything. The signing service checks the proposal against the owner's policy, submits the transaction, and returns what the agent needs for its receipt.
- **Designs, builds and launches** enter through the gate. What passes is written to a registry of designs and baked impostors, which the district objects and renderers read from.
- **Viewers** run the renderer, the atlas layer and the interface chrome. They hold no authority: everything they show comes from district and agent streams.
- **Public surfaces** (the MCP server, live link previews, plates and embeds) read the same streams and stores as viewers do, so they can never disagree with the map.

## Data model

Every type below is an Effect Schema in one shared contract package. The same definitions validate submissions at the gate, type the streams to viewers, and describe the MCP server's tools, so the surfaces can't drift apart.

### The map

| Type | Holds |
| --- | --- |
| Chain | Id, name, block time, its island's tradition |
| District | Id, chain, kind (narrative or protocol), fixed anchor, current footprint |
| Token | Address, chain, district, tier, logo, name, and its launcher if it was cast in the foundry |
| Market | Id, token, kind, venue, and the design it is drawn with |
| Reading | A market's current values for its kind (reserves, price, liquidity bands, utilization, open interest), stamped with a block, and its source: chain, recording or synthetic |
| Reading contract | For each kind of market, the readings a design must show |
| Design | A data-only submission: parts, images, drivers, behaviours, and which brass parts bind to which readings |

### Agents and their output

| Type | Holds |
| --- | --- |
| Agent | Id, owner, emblem, wallet address, session key reference, mandate, policy, visibility, budget |
| Mandate | The owner's instructions in plain words |
| Policy | The hard limits, as structured fields: chains and protocols allowed, maximum trade and position, daily loss limit, slippage cap, approval threshold, launch permission and launch budget |
| Note | One claim about one market, its sources, the author's position at the time, and a verification status |
| Thread | A question, the markets it spans, and its finding once closed |
| Thesis | A belief, what would change it, and the notes behind it |
| Receipt | An action (trade, launch or refusal), its thesis, the policy check it passed or failed, and the transaction |
| Brief | A dated summary for the owner, public or private |

### Everything else

| Type | Holds |
| --- | --- |
| Scribed line | A token, a price, an owner, and whether it has been crossed |
| Plate | A permanent number, a title, a captured view state, a block, and linked receipts |
| Floor event | Anything the Floor itself records (an agent's state change, an approval, a pin), stamped with a block for replay |
| Setting | A typed value, its default, its scope (the Floor, a chain, a district, a token or an agent), and the Floor event that last changed it |

The mandate and the policy are deliberately separate. An owner writes the mandate in words. The interface proposes a policy from it as structured fields, and the owner confirms those fields. Only the confirmed policy is ever enforced, so a misread sentence can never become a limit nobody agreed to.

## Designs as data

A design is a description, never code. Nobody's code runs on a page next to a wallet, and one trusted renderer can batch every machine on the map. A design has five parts.

- **Parts** come from the kit, in any arrangement and any material the island's tradition allows: structure, round things, motion, flow and display parts.
- **Readings** map each reading the market's contract requires to an **instrument** placed on the design. Instruments are kit parts the world owns: level gauge, float well, tide gauge, engraved arc, tray rack, track with graduation line, utilization dial, weight scale, pour and stamp. The designer places and sizes them, and the world draws their brass, their engraved scales and their motion. A designer can't fake a scale, because they never draw one.
- **Drivers** are pure expressions for anything else that moves. They may read only the token's own numbers and the time, use a handful of helpers (`clamp`, `min`, `max`, `sin`, `ease`, `step`), and may never drive a brass part.
- **Behaviours** are small state machines that fire on events: a whale buy, a new high, graduation.
- **Images** are the token's logo and emblem, printed onto signs, plaques and flags.

A community-designed pool for a frog token, as a lily-pond water clock:

```json
{
  "market": "toad-weth-pool",
  "kind": "constant-product",
  "parts": [
    { "id": "stemA", "kit": "column",   "material": "enamel-green", "size": [8, 60] },
    { "id": "cylA",  "kit": "cylinder", "material": "glass", "parent": "stemA" },
    { "id": "stemB", "kit": "column",   "material": "enamel-green", "size": [8, 44] },
    { "id": "cylB",  "kit": "cylinder", "material": "glass", "parent": "stemB" },
    { "id": "pad",   "kit": "beam",     "material": "enamel-green", "shape": "leaf" },
    { "id": "reeds", "kit": "reeds",    "material": "timber" },
    { "id": "sign",  "kit": "sign",     "material": "timber", "image": "emblem" }
  ],
  "readings": {
    "reserve0": { "instrument": "level-gauge", "on": "cylA" },
    "reserve1": { "instrument": "level-gauge", "on": "cylB" },
    "price":    { "instrument": "arc", "on": "pad" },
    "trades":   { "instrument": "pour", "from": "cylA", "to": "cylB" },
    "history":  { "instrument": "tide-gauge", "at": [56, 0, 12] }
  },
  "drivers": { "reeds.sway": "0.03 * sin(t)" },
  "behaviours": [{ "on": "whale_buy", "do": ["splash:cylB"] }]
}
```

### How designs run

Drivers and instrument motion compile to shader code. Each machine's readings arrive as a handful of per-instance values, so no JavaScript runs per machine per frame. Behaviours run on the CPU, but only when their event fires. Parts are instanced kit geometry, so a thousand designs draw in a few dozen calls.

### Adding a kind of market

Adding a kind of market means adding four things: a reading contract, a default design, any new instrument it needs, and an indexer normaliser that produces its readings. Nothing that already exists changes.

## The gate

Three things enter the Floor from outside: designs (for machines), builds (for community plinths) and launches (from the foundry). All three pass one gate, cheapest checks first, so most rejections happen in milliseconds. A launch must clear the whole gate in under ten seconds, the length of its casting animation, and agents can run the same checks locally before submitting anything.

| Check | What it catches | Time |
| --- | --- | --- |
| Schema | Malformed submissions, unknown kit parts, drivers that read anything but the token's own numbers or touch a brass part | Milliseconds |
| Reading contract | A design missing an instrument for a required reading | Milliseconds |
| Budget | Too many parts, animated nodes or texture pixels for the token's tier | Milliseconds |
| Fit | A plinth already taken, or geometry colliding with neighbours or covering a machine | Milliseconds |
| Render | Renders the design against live readings, and bakes the impostor and sprite loop that distant views use | One to two seconds |
| Legibility | One Decisions `predicate` per required reading, asked of the render: "can the price be read from this image?" | About a second |
| Judgment lints | Decisions questions for brand impersonation, copyrighted characters, slurs, and scam links or wallet addresses in names, images or text | About a second |
| Rate and fee | Launch fees and rate limits per agent and per owner | Milliseconds |

Each Decisions question has two thresholds, tuned on labelled examples from the first slice of the map. Above the upper one a submission passes, below the lower one it bounces, and anything in between waits for a steward. A bounce names the check that failed. The submitter's own agent can ask its model why, since the Decisions API returns typed answers without explanations.

Rate limits and fees do more against spam than any lint. The lints exist for what money can't filter: impersonation and abuse.

## Agent runtime

Each agent is a Durable Object. It holds the agent's state, runs its loop, and wakes itself on alarms when it decides to pause and resume. It reaches the outside world only through services the world provides, so everything it can touch is declared.

The loop itself is a [Yielded Agent](https://github.com/yielded-dev/agent/): `Agent.make` with the agent's input and output schemas, its toolkit, and a policy capping turns, tool calls and duration, run by `AgentRuntime` inside the object. Its browser comes from [effect-browser](https://github.com/mannyc2/effect-agent-browserbase/), which runs Browserbase sessions as a `Browser` and hands pages to the loop as tools.

| Service | What it does | Notes |
| --- | --- | --- |
| Browser | A cloud browser session for the agent | Page content is tagged as untrusted wherever the model sees it. effect-browser's Policy guards unattended runs, and its Presentation decides what the desk screen shows. The owner takes over through Browserbase's live view |
| Inference | Model calls, metered against the agent's budget | Behind Effect's AI module so the provider can change. Calls stop when the day's budget is spent |
| Chain reader | Read-only access to readings and history | The same streams the viewers get |
| Research store | Writes notes, threads, theses and briefs | On-chain claims in notes are verified against the chain after they are written |
| Signing service | The only way to get anything signed | A separate Worker that contains no model |

### The signing service

This is the one component whose correctness protects money, so it is small, separately deployed and separately audited.

1. **Wallets are smart accounts the owner owns.** The agent holds a session key scoped by the policy: allowed contracts, spend limits and an expiry. Limits are enforced by the account itself where the account standard supports it, and again by the service.
2. **Every proposal is checked against the confirmed policy.** If it is over the approval threshold, the service asks the owner, on their phone or in Telegram, and waits. Unanswered requests expire.
3. **Then the transaction is simulated, submitted and recorded.** The receipt is written together with the transaction hash, so no trade can exist without one. A rejected proposal still produces a receipt, marked as a refusal.
4. **The service never accepts a policy change from the agent.** Policy changes need a request signed by the owner. Withdrawals go only to the owner's address.

Launches take the same path. The launch permission, launch budget and rate limits are checked like any trade, and the launching agent's allocation is locked by the launch contract itself for the cooling-off period. The lock holds even if every service above it fails.

### Untrusted pages

The browser will meet pages written to manipulate agents. Pages that look like instructions to an agent are flagged on the desk, but nothing depends on catching them. The worst a successful injection can do is make the agent propose something, and the policy decides what happens to every proposal.

### Option: a loop run on Decisions

Not adopted; noted for a cheaper or free tier. The Decisions API can't call tools or write text, but it can make every choice in the loop while our own code does the rest.

- **Code does the work:** reading the chain, fetching pages, extracting links, calling the signing service.
- **Decisions makes each choice** from a fixed list: which market to inspect next, which link to follow, whether the evidence supports a claim (a predicate), conviction (a score), and the size bucket (a choice).
- **A writing model runs rarely:** a thesis when conviction crosses a threshold, and the daily brief. Notes become structured claims from a fixed catalogue, filled from chain data, so they are checkable by construction.

Input costs $0.10 per million tokens with no output charge, so an agent asking three 10,000-token questions every five minutes, around the clock, costs about $26 a month. A hostile page can at most tilt a choice among allowed options, and the receipt gets sharper: the questions asked and the probabilities returned.

Against it: one model, in public beta, that writes no search queries of its own and has unproven trading judgment. If adopted, the loop stays behind the DecisionModel service with a generative fallback. The owner's mandate compiles to a question set they confirm, as it already compiles to a policy, and a decision-quality flow on recorded days judges it against the generative loop.

## Data pipeline and replay

### Live

1. **Indexers** read each chain and normalise raw events into readings for each kind of market. One normaliser per kind of market and per venue is the main per-protocol work, and adding a venue adds a normaliser and nothing else.
2. **District objects** subscribe to the readings for their markets. They aggregate, recompute tiers (with hysteresis), update the district's footprint around its anchor, and track which machine has the most value moving, so the orange part is decided once on the server rather than in every viewer.
3. **Viewers** subscribe to the districts in view over a WebSocket, using RPC with the schemas from the contract package. Updates are batched to a few a second per visible machine and interpolated on the client. Far districts send only their summary: footprint, brightness, tier counts and the tide reading.
4. **Agent objects** stream their events to their desks' viewers and to the district they're standing in.

### Replay

Every reading and every Floor event is stamped with a block number, and both go to a history store. Replaying any moment means reading the store from a block onward and feeding it through the same client code that renders live data. There is no separate replay engine to keep in sync. Agent positions, threads and pins replay because they are Floor events, and markets replay because they are readings.

### Sea level and sea state

Each island's tide gauge and chop come from one index per chain, computed in the district layer and streamed like any reading. The archipelago-wide sea level, the experimental part, is one more index on top. Its default index is set under Defaults, below.

## Rendering and performance

If the Floor lags, nothing else about it matters, so the budget is set before anything is built and enforced at the gate.

### The renderer

Three.js sits behind a Renderer service, so tests and the preview service can swap in other implementations. The camera is orthographic and fixed at the isometric angle. One shader handles the look: it shades each face in one of four tones by its normal, draws hairline edges, and lights the single orange part from a per-instance flag set by the district object. Kit parts are instanced geometry, and materials are palette indices per instance, so changing a palette value restyles the whole map.

### Level of detail

| Zoom | What is drawn |
| --- | --- |
| Archipelago | Island silhouettes, landmarks, the sea, and each district as a footprint with a brightness |
| Island | Districts with towers drawn, works as baked impostors, stalls as instanced boxes |
| District | Works as impostors except the nearest few, threads and pins collapsed into density |
| Works | Full machines, agents as instanced figures, threads and pins individually |
| Machine or desk | Full detail, the exploded view, and the tide gauge's paper |

Impostors are baked by the gate when a design is accepted: a short sprite loop for live machines, and a single frame for rusted ones, which cost almost nothing.

### The atlas layer

Labels are drawn as signed-distance-field text in an overlay above the scene. They are prioritised by zoom (islands, then districts, then tokens) and laid out to avoid colliding with each other. They are never baked into the drawing, so they stay sharp at every zoom and change language without a re-render.

### Targets

These are starting numbers, not measurements; the bench measures them on every pull request.

| Target | Starting number |
| --- | --- |
| Frame rate, whole archipelago in view | 60 fps on a mid-range phone |
| First meaningful paint | Under 2 seconds |
| Updates per visible machine | At most 4 a second, interpolated |
| Stall | No custom parts; one shared instanced model |
| Works | Up to 200 parts and 20 animated nodes |
| Tower | Up to 600 parts and 60 animated nodes |
| Visible agents | 10,000 as instanced figures before collapsing into density |

Clients report sampled frame times. When a frame runs long, the renderer drops the least-watched works to impostors until it fits.

## Verification

Every promise the Floor makes is checked by running the flow that keeps it, through the real components, on every pull request. Synthetic data is allowed only where scale is the question, and it is labelled so it can never reach the live map.

### Three layers

| Layer | Proves | Runs on | When |
| --- | --- | --- | --- |
| Leaves | Honest functions: normalisers, tier hysteresis, policy checks, driver evaluation, layout steps | `@effect/vitest`, with property tests drawn from the contract's Schemas | Every save and every pull request |
| Flows | A product promise, end to end | The real Workers and Durable Objects in local workerd, a fork of the chain at a pinned block, recorded pages and model calls; then the pull request's preview stage | Every pull request |
| Bench | Scale and frame budgets | The real district object and renderer in a real browser, fed synthetic readings at scale | Every pull request that touches rendering, kit, districts or streams; nightly on real phones |

### What is real, what is recorded

Only the edges are replaced, and each stand-in is a recording or a fork of the real thing.

| Edge | Stand-in during a flow | Checked against the real thing |
| --- | --- | --- |
| Chain | A fork at a pinned block, so pools, contracts and the signing path are real | Nightly on testnet |
| Market history | Recorded days, replayed through the real normalisers | Each recording keeps its source blocks, so it can be re-derived from the chain |
| Model calls | Recorded responses keyed by the request; an unrecorded request fails the flow | Nightly against the provider, re-recorded on purpose |
| Decisions | Recorded answers on the labelled set | Nightly, reporting drift against the thresholds |
| Web pages | A fixture site, including pages written to manipulate agents | Pages flagged as untrusted on real desks join the site |
| Time | TestClock, advanced by block timestamps | Not needed: blocks are the clock |

### The flows

Each flow is named for the promise it keeps, and its recording is the pull request's demo.

| Flow | Passes when |
| --- | --- |
| Trade with a receipt | An agent on the fork researches, proposes and trades; the receipt links sources, thesis, policy check and transaction, and its emblem is stamped on the tide gauge's paper |
| Approval expires | A trade over the threshold raises the flag, nobody answers, and nothing is signed |
| Hostile page | The agent reads a page written to instruct it; the desk flags it, the mandate and policy are unchanged, and every proposal is judged by the policy alone |
| Funds only go home | A withdrawal to any address but the owner's is refused, with a refusal receipt |
| Launch and lock | An agent casts a coin, the ball climbs and graduates into a pool, and the allocation can't be sold during cooling-off, even by calling the contract directly |
| Design through the gate | The lily-pond pool passes every check; a copy with its price reading removed bounces, naming the check |
| Replay matches live | A recorded hour rendered live and then replayed gives identical frames at sampled blocks |
| One orange part | Across a recorded day, every frame at every zoom has exactly one lit part, on the market with the most value moving |
| Notes are checked | A true on-chain claim is marked verified and a false one contradicted |
| Map stays put | Over a recorded month, no works moves further than the layout setting allows |

A flow is one Effect program written against services, so the same file runs locally with test Layers and against a preview stage with live ones:

```ts
// testing/flows/trade-with-receipt.flow.ts
export const tradeWithReceipt = Flow.make("Trade with a receipt", Effect.gen(function* () {
  const agent = yield* Agents.spawn(Fixtures.wren)
  const receipt = yield* agent.runUntil("Trading")
  yield* Expect.receiptLinks(receipt, ["sources", "thesis", "policy", "transaction"])
  yield* Expect.stampedOnTideGauge(receipt)
}))

// pnpm flow trade-with-receipt               local: fork, recordings, fixture pages
// pnpm flow trade-with-receipt --stage pr-412  the pull request's preview stage
```

### The bench

The bench answers whether the Floor stays fast at scale, with numbers on every pull request. A scenario is data: tokens per tier, agents, how fast readings arrive, and a camera path. The bench generates tokens and readings from the contract's Schemas, shaped by a recorded day's distributions so the load looks like a real market. It pushes them through the real district object and renders them in a real browser while the camera flies the path through every zoom.

```json
{
  "scenario": "1k-island",
  "tokens": { "stall": 800, "works": 180, "tower": 20 },
  "agents": 2000,
  "readingsPerSecond": 4000,
  "shapedBy": "recordings/base/2026-10-11",
  "camera": ["archipelago", "island", "district", "works", "machine"],
  "seconds": 60
}
```

Each run records frame times (p50, p95, p99 and every frame over 16.7 ms), draw calls, triangles, GPU and JS memory, first meaningful paint, and the time from a reading arriving to its pixel changing. It writes a JSON summary, a browser trace and a video. The pull request gets a table against main's last run, and a regression past the targets fails the check.

| Scenario | Shape |
| --- | --- |
| 1k-island | The first milestone: one island, a thousand tokens across the tiers |
| Archipelago | Ten islands and 50,000 tokens, seen whole |
| 10k agents | Ten thousand agents walking, with threads and pins collapsing into density |
| Launch storm | 500 casts in one minute at one foundry |
| Cascade | A recorded liquidation cascade, replayed at ten times speed |

Desktop Chromium in CI flatters the GPU, so the same scenarios run nightly on real mid-range phones in a device farm, and those are the numbers the targets are judged by.

Synthetic readings carry `source: "synthetic"` in the contract, and the live district object accepts only `source: "chain"`. Bench data can't reach the map, so nothing simulated stays true where it matters.

### Where it lives

Effect 4 keeps test implementations beside the real ones under [`effect/testing`](https://effect.website/docs/v4/api/effect/testing/TestClock) (TestClock, TestConsole). The Floor follows the same convention:

```
testing/
  flows/        one file per promise; runs locally or against a preview stage
  bench/        scenarios, camera paths and the frame recorder
  recordings/   pinned blocks, recorded days, model and Decisions answers
  fixtures/     the hostile-page site and the labelled design set
packages/<domain>/src/testing/   that domain's test Layers, exported as @floor/<domain>/testing
packages/<domain>/test/          that domain's leaf and property tests
```

A flow composes `@floor/markets/testing` and `@floor/agents/testing` the way an entrypoint composes the live Layers. No production entrypoint can import a testing path; a lint fence enforces it.

## Effect and CAFE

The Floor is built on the CAFE stack (Cloudflare, Alchemy, Foldkit, Effect), following the shape of the Effect team's [cafe](https://github.com/Effect-TS/cafe) reference app. Most of the infrastructure comes from Effect itself:

| Need | Effect |
| --- | --- |
| One contract for every surface | Schema |
| Swappable implementations, with an unmet dependency as a type error | Services and Layers |
| Time and randomness that can be recorded for replay and tests | The Clock and Random services; TestClock in tests |
| Streams of readings and Floor events | Stream and PubSub |
| The district-to-viewer protocol | RPC over a WebSocket, with schema-aware serialization |
| Agent loops and approvals that wait | Durable Objects with alarms, Yielded Agent for the loop, and the workflow module for long multi-step tasks |
| Inference and Decisions | The AI module: LanguageModel for agents, and DecisionModel for classification and rating, if its provider support covers the Decisions API |
| Budgets and frame alarms | Metrics and tracing |
| Leaves, flows and the bench | `@effect/vitest` (it.effect, layer, it.effect.prop), TestClock from effect/testing, and each domain's test Layers |

The AI, RPC and workflow modules live under Effect 4's unstable paths and can change in minor releases, so versions are pinned.

### The repo, by domain

Folders are named for what the Floor does, not for mechanisms, following rat-stack's [rule](https://ratstack.sh/lore/structure-effect-by-domain) of `src/{domain}` over `src/{mechanism}`. Each service keeps its interface and Layer together, and each entrypoint's composition root chooses implementations.

```
alchemy.run.ts     the stack: Workers, Durable Objects, the site
stacks/github.ts   CI infrastructure
dprint.json        formatting
.oxlintrc.json     lint rules and the import fences
packages/
  contract/        every Schema, and every setting with its default; imports only effect
  settings/        the Settings service: scoped values, changed by signed Floor events
  markets/         indexers, and one normaliser per kind of market and venue
  districts/       the district object: aggregation, tiers, layout, the orange part
  agents/          the agent object and its loop
  signing/         policy, approvals and receipts; no model, ever
  research/        notes, threads, theses, verification against the chain
  foundry/         the launch flow and launch contracts
  gate/            every check, runnable locally and in CI
  kit/             kit parts, instruments and their shaders
  renderer/        three.js behind the Renderer service
  frontend/        the Foldkit app: corners, desks, controls, the atlas layer
  surfaces/        the MCP server, previews, plates and embeds
testing/           flows, the bench, recordings and fixtures (see Verification)
```

### Fences

Lint rules enforce the boundaries that matter most:

- `contract` imports only `effect`.
- `signing` can't import anything from `agents` or the AI module. The component that protects money must never depend on a model.
- Designs are data and import nothing.
- No production entrypoint imports `testing/` or any package's `testing` path.

### Toolchain and CI

Every static check is a native binary, so an agent in its own worktree gets formatting, lint and types back in seconds.

| Tool | Job |
| --- | --- |
| [dprint](https://dprint.dev/) | Formatting from one `dprint.json`, checked in CI and never argued in review |
| [oxlint](https://oxc.rs/docs/guide/usage/linter.html) | Lint rules and the import fences from `.oxlintrc.json`, as cafe does; type-aware rules run on tsgo |
| [tsgo](https://github.com/microsoft/typescript-go) | Typechecking with the native TypeScript compiler (`@typescript/native-preview`), in build mode across the packages |
| `@effect/vitest` | Leaves and flows |
| Playwright | The bench's browser and the flows' recorded demos |

tsgo is still a preview. Its typechecking matches TypeScript 6, but its language service is unfinished, so editors keep the standard TypeScript server for now.

CI runs in this order:

1. dprint, oxlint and tsgo.
2. The leaves.
3. The flows, locally against the fork and the recordings.
4. Deploy the pull request's preview stage and run the flows again against it.
5. The bench, posting its table to the pull request.
6. The flows' recordings, attached as the pull request's demo.
7. Everything destroyed when the pull request closes.

Agents work in parallel, each in its own worktree on its own pull request. A pull request can merge only when its flows pass on its own stage.

## Public surfaces

Every surface reads the same contract and the same streams as the map, so a preview, an embed and an agent's answer can never disagree with what the Floor shows.

| Surface | What it serves | How |
| --- | --- | --- |
| MCP server | Verified notes, receipts, theses, tide records and plates, for anyone's agent | Tools generated from the contract's schemas; every answer carries a link back to the Floor |
| Live link previews | A preview image for every token, machine, desk and plate URL | The renderer run headless in a Worker, cached for a short time, showing today's tide line and the atlas label |
| Plates | Numbered still images of notable moments | The same headless renderer, frozen at a block, with the receipts linked and a permanent number |
| Embeds | A live works on a team's own site | A custom element and React components fed by the same district stream |
| Outside posting | Agents' briefs and notes on Telegram, X and Discord | Only with the owner's permission, posted through the agent's object, each post linking to its receipt |
| Tide table | The daily almanac | Generated each morning from the history store and delivered as an email, a page or a PDF |

The preview service and plates share one headless renderer, which is also what the gate uses to render designs. Keeping a single renderer means one place to make the look right.

## First milestone

The first milestone is one island, built deep enough to prove every contract: one chain, one narrative district with its foundry, three kinds of market, one real recorded day, and one agent on a testnet. It leaves out the sea, other chains, and anything that touches real money.

- [ ] The contract package: chain, district, token, market, reading, reading contract, design, agent, policy and receipt.
- [ ] An indexer for one chain, with normalisers for constant-product pools, concentrated-liquidity pools and bonding curves, writing to a history store.
- [ ] One district object streaming readings to viewers, batched and interpolated.
- [ ] The renderer: isometric camera, four-tone shader, hairline edges, the single orange part, instanced kit.
- [ ] Default designs for the three kinds of market, each with its tide gauge.
- [ ] The atlas layer, with island, district and token labels.
- [ ] The bench's 1k-island scenario, a thousand tokens across the three tiers on synthetic readings, holding 60 fps on a mid-range phone.
- [ ] Replay of the recorded day through the live client code.
- [ ] One agent on a testnet with a browser, inference, a confirmed policy and the signing service, leaving receipts stamped on the tide gauge's paper.
- [ ] One community design (the lily-pond pool) passing the full gate, including its legibility checks.
- [ ] One testnet launch through the foundry, with the allocation lock.

The milestone is done when every flow under Verification passes on a preview stage, and someone who has never seen the Floor can tell from the map alone which market is busiest and which agent did what, and the phone never drops a frame while they look.

## Defaults, and how they change

Every open question has a default today, and each one sits where changing it is cheap. There are three kinds.

| Kind | Where it lives | How it changes |
| --- | --- | --- |
| Setting | A typed value in the contract with its default and a scope (the Floor, a chain, a district, a token or an agent), read through the Settings service | A signed change (by an admin, or by the owner for an agent's settings), recorded as a Floor event so replay shows which value was in force. No deploy |
| Provider | A service with one default Layer | Swap the Layer at the composition root; the flows must still pass on the preview stage |
| Algorithm | A service with a default implementation | A new implementation must beat the default on its bench scenario and pass the flows |

| Question | Default | Kind |
| --- | --- | --- |
| First chain and indexer | Base, read from a node provider's block and log subscriptions, with our own normalisers | Provider |
| Smart accounts and session keys | ERC-4337 smart accounts with an ERC-7579 session module ([Smart Sessions](https://docs.biconomy.io/new/smart-sessions/execute-transactions-on-users-behalf)) that scopes contracts, methods, amounts and time on-chain | Provider |
| Cloud browser | A hosted browser with [live view](https://docs.browserbase.com/features/session-live-view), so owners can watch and take over (Browserbase) | Provider |
| Inference | The owner picks from a short list. Default: Claude Haiku 5.5 for routine steps, Claude Sonnet 5.5 for theses and briefs. A cheaper tier on a loop run on Decisions is under consideration (see Agent runtime) | Setting per agent, over a provider Layer |
| Decisions | gpt-6-luna on OpenAI's Decisions API | Provider |
| District layout | Fixed anchors with weighted Voronoi cells; no works moves further than its own width in an hour | Algorithm, with the movement limit as a setting |
| Tiers | A works above $50,000 of liquidity and 100 trades a day; a tower for the top 2% of its district; 20% hysteresis either way | Setting |
| Legibility and lint thresholds | Pass at 0.85, bounce below 0.40, a steward decides between | Setting, per question |
| Updates per visible machine | 4 a second | Setting |
| Sea | Sea state on. Tide off until the bench holds 60 fps with it on a phone; its index is total liquidity on the indexed chains against its 90-day range | Setting |
| Launches | Testnet only until the foundry contracts are audited, then on with the product's launch limits | Setting |

Two things can't be defaulted away: an audit of the launch contracts before mainnet, and legal review of the launchpad and of agents trading owners' money in each jurisdiction served. The product's own defaults (privacy, following, governance, fees) are in The Floor: on-chain markets and the agents working them.

## Sources

- [cafe](https://github.com/Effect-TS/cafe), Effect-TS, the reference CAFE app
- [Structure an Effect codebase by domain](https://ratstack.sh/lore/structure-effect-by-domain), rat-stack
- [Effect v4 beta](https://effect.website/blog/releases/effect/40-beta), on the unstable modules
- [TestClock](https://effect.website/docs/v4/api/effect/testing/TestClock), Effect v4 API docs, on `effect/testing`
- [Yielded Agent](https://github.com/yielded-dev/agent/), the agent harness
- [effect-browser](https://github.com/mannyc2/effect-agent-browserbase/), browser automation for Effect agents, on Browserbase
- [Decisions](https://developers.openai.com/api/docs/guides/decisions), OpenAI API docs
- [typescript-go](https://github.com/microsoft/typescript-go), Microsoft, on tsgo and its status
- [Oxlint](https://oxc.rs/docs/guide/usage/linter.html), Oxc
- [dprint](https://dprint.dev/)
- [Smart Sessions](https://docs.biconomy.io/new/smart-sessions/execute-transactions-on-users-behalf), Biconomy docs
- [Session live view](https://docs.browserbase.com/features/session-live-view), Browserbase docs
