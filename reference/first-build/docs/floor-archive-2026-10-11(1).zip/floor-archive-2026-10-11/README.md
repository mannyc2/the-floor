# The Floor: snapshot, 11 October 2026

A frozen copy of everything about the Floor. The live versions keep changing:

- The Floor (product doc): https://claude.ai/code/artifact/416c7410-d5b0-412e-a46a-73236adbd2b7
- The Floor: technical design: https://claude.ai/code/artifact/3c352a56-94ad-40f6-b15a-fbe64630e0cb
- The Floor: archive (index, decision log, stack, ideas under consideration): https://claude.ai/code/artifact/5f208ecf-1916-4bfb-b9d5-745368027f19
- Floor Atlas (design system, private until shared): https://claude.ai/artifact/RtxQsP4sLquRrCJHq2Wabq

## Contents

| Path | What it is |
| --- | --- |
| `archive.md` | The archive doc: artifacts, decision log, stack and libraries, ideas under consideration, sources |
| `docs/the-floor.pdf`, `docs/the-floor.md` | The product doc. The PDF keeps its diagram; the Markdown replaces it with a placeholder |
| `docs/technical-design.pdf`, `docs/technical-design.md` | The technical design, same arrangement |
| `design-system/README.md` | The Floor Atlas brand book |
| `design-system/tokens.json` | Colours (day and night), type, spacing, radius and drawing constants |
| `design-system/markets.md`, `design-system/image-prompts.md` | Market machines, and the style block, avoid block and seven key frames for image models |
| `design-system/components/` | Guidelines and live HTML previews for each component, plus the cover |
| `design-system/design-system.json` | The design system's index file |
| `design-system/renders/` | Day and night screenshots of each preview, rendered with stand-in fonts (EB Garamond and Courier Prime weren't available where they were rendered) |

The previews read their colours from the design system's compiled `tokens.css`, so opened on their own they show unstyled colours.
