The Floor Atlas is the look of the Floor: a live map of on-chain markets drawn as an engraved atlas of working machines. Every market is a machine, every chain an island, and the agents working them are small figures moving between them. It should read like a plate in an engineering atlas: calm, legible and serious, with enough character that people leave it open in a tab.

There are two layers, and they never mix. **The drawing** is the isometric world: wordless, hairline, four-tone, and honest about what it shows. **The interface** sits above it: the atlas layer of labels, the panels, notes, receipts and readouts. Words and numbers belong to the interface; the drawing carries none except logos and name plates.

## Two laws

Everything else in this system is tunable. These two are not.

- **Brass means data.** Paint a part `brass` only when it is bound to live data: a level, a needle, a float, a tide-gauge pen. Give every brass part an engraved scale. Nothing else may be brass: not housings, not trim, not landmarks, not a community's statue. Anyone should be able to tell at a glance which parts are readings and which are decoration.
- **Orange means value moving.** Each frame has exactly one `accent` part, and it always means value moving right now, or waiting on you to move it. Never use `accent` for a landmark, an agent, a tide gauge's float, a button, a link or a brand moment.

| Where you are | What is `accent` |
| --- | --- |
| The map | The market with the most value moving |
| A district or a works | The machine with the most value moving |
| A machine | The trade in progress: the pour between tanks, the tray being drained, the weight being added |
| The foundry | The cast being poured |
| An agent's desk | The trade waiting for its owner's approval, under the flag; with nothing waiting, nothing is orange |

## Content fundamentals

The Floor's voice is the harbourmaster's: dry, exact, a little weathered, and never hyped. It describes what the market did and leaves the excitement to the market.

- Write in sentence case everywhere except atlas labels, which are small caps. "Approval needed", not "Approval Needed".
- Address the owner as "you". Refer to agents by name and as "it": "Wren is writing a thesis", "its desk".
- Lead with the fact, then the source. A note is one claim about one machine: "The liquidity was added by a single wallet two hours ago." Its sources go underneath, never inline.
- Say what you know and how you know it. On-chain claims are marked verified or contradicted; claims about the web are only ever marked sourced.
- Show the author's position on every public note: "Position when written: 1.2% of supply", or "Position when written: none".
- Title plates in the form *Plate 214: the draining of a pool*, with the date written 11 October 2026.
- Questions to the harbourmaster are plain words, and so are its answers: "Where did the money go overnight?"
- Keep numbers in readouts, in `readout`, with units: `4.21M WETH/h`, `block 21,904,377`. Shorten addresses in the middle: `0x9f3c…a41e`.
- No emoji and no exclamation marks. Keep hype words out of the Floor's own voice; agents may quote them, in `note`. The drawing never shows casino imagery, coins or dollar signs.

## Visual foundations

### The drawing

| Foundation | Rule |
| --- | --- |
| Camera | Orthographic isometric from one corner, `camera-pitch` (30°) down. No perspective, no vanishing points, no depth of field |
| Line | One `hairline` weight in `line`, on every edge. Every line ends on a face, another line or a dot |
| Shading | Four tones by face direction: `tone-3` on tops, `tone-2` and `tone-1` on the two sides, `tone-0` on faces turned furthest away. No gradients, no glow, no photographic light |
| Brass | `brass` on data-bound parts only, each with an engraved scale |
| Orange | One `accent` part per frame, as above |
| Scales | One tick system on every engraved scale, cut in `engraving`: a major mark every `tick-major-every` (fifth) tick, minor marks between, and no numbers |
| Paper | One `paper` material for drums, notes, receipts, tide tables and plates |
| Materials | Steel, glass, stone, brick, timber, enamel and paint, chosen by each island's tradition. `steel` is the default only where the island doesn't say otherwise |
| Words | None in the drawing except logos and name plates; labels live in the atlas layer |

Liquidity is always `water`. Proposed, unbuilt or still-cooling things are drawn in `blueprint` linework. A market that has died goes `frost`, then `rust`, then drops back to a stall. Islands are not alike: give each its own tradition and its own landmark, and never let them share one vocabulary of brass and tanks.

Logos are printed onto surfaces in the drawing (a painted sign, an enamel plaque, a flag), foreshortened with the surface they sit on. Never float a logo flat over the drawing.

### Day and night

`day` is the first theme and the default, because people will use the Floor during working hours. Treat it as seriously as `night`. Every token is defined in both; never hard-code a value from one theme. At night `line` drops to 70% so the linework stays fine on the dark `ground`.

### Colour in the interface

- Set text in `ink` on `ground`, `paper` or any tone. Set secondary text in `ink-muted` on `ground` or `paper` only.
- Never set text in `brass`, `accent`, `steel`, `water`, `frost` or `rust`.
- Put notes, receipts, tide tables and plates on `paper` with a `hairline` edge in `line`; `paper` barely lifts off `ground` on its own.
- Use `blueprint` only for proposed or unbuilt things (a design under review, a stall cooling in the foundry), and only as linework.
- `accent` appears in the interface in one place only: the approval flag, while a trade or launch waits on its owner.

### Type

- **Atlas labels** in the `atlas` family (EB Garamond), letterspaced small caps: `atlas-island` from the farthest zoom, `atlas-district` in the middle distance, `atlas-token` up close. Apply `font-variant-caps: all-small-caps`. Plate titles in `plate-title`, italic, sentence case.
- **Readouts and receipts** in `mono`, the system monospace: `readout-lg` for a view's live readout, `readout` for receipts, ledgers and dates, `readout-sm` for sources.
- **Agents' words** in `notes` (Courier Prime): `note` for notes, theses and briefs, `note-sm` for a thesis quoted on a receipt. Nothing the Floor itself writes is set in this face.
- **Interface text** in `ui` (Inter): `ui-title`, `ui-body`, `ui-label`.

All four are hosted Google Fonts; load EB Garamond (400, 500, italic 400), Courier Prime (400, 700) and Inter (400, 500, 600).

### Layout

- Every view keeps the four corners of an engraved plate: the place top-left (`atlas-island` or `atlas-district`), the path of scales top-right (Floor › island › district, in `ui-label`), a hint bottom-left (`ui-label` in `ink-muted`) and the live readout bottom-right (`readout-lg`). Inset them by `space-4`.
- Keep the centre of every view for the drawing. Panels slide in from an edge; they never cover the orange part.
- Space the interface on the 4px scale: `space-3` inside notes and receipts, `space-4` for panel padding, `space-6` between sections.
- Keep everything square (`radius-none`). Only stamps and pins are round (`radius-round`); text inputs take `radius-hair`.
- No shadows. Separate surfaces with a `hairline` rule in `line`, the way an engraving would.

### Focus and states

- Show keyboard focus as a solid 2px `ink` outline, offset 2px. It holds well over 3:1 on every surface in both themes.
- Hover underlines a label and never changes a colour, since every colour here carries a meaning. Selection draws a second `hairline` outline 2px outside the first.
- Disabled controls drop to `ink-muted` and lose their outline.

### Motion and sound

| Kind of change | Motion | Sound |
| --- | --- | --- |
| Continuous: tides, levels, threads | Slow easing that never jumps | Soft and ambient: water, wind |
| Discrete: trades, stamps, flags, casts | A quick settle: stamps snap, flags snap up, pours start and stop cleanly | Short and crisp: a stamp, a click, a pour |
| Rare: big liquidations, graduations | A held beat before and after | One distinct sound each: a foghorn, a bell |

Sound is off by default and is never needed to understand anything. Respect reduced motion: continuous changes step instead of easing, and rare beats are skipped.

### Plates

Any view can be captured as a numbered plate, with a title in `plate-title`, the date and the plate number in a corner in `readout`, and its receipts linked. Plate numbers are permanent, so plates can be cited. A plate is the drawing on `paper` with a `space-8` margin and a single `hairline` frame.

## Iconography

The Floor has no icon font and uses no emoji. Its iconography is two sets of geometric marks, drawn as SVG from simple shapes, in the palette:

- **Signal flags** for system states: Approval needed, Alert, Verified, Contradicted, Paused and Untrusted page. Each is a two-colour geometric pattern, inspired by maritime signal flags without borrowing their meanings. Always set the flag's name beside it in `ui-label`, so no state is told apart by colour or pattern alone. Only the approval flag may be `accent`. See the SignalFlag component.
- **Emblems** for agents: circle, triangle, square, diamond, hexagon, cross, crescent and star, with one optional modifier (a bar, a dot or a ring). The same emblem appears on an agent's chest, its desk banner and every stamp it leaves on a tide gauge's paper. Within a district no two active agents share one. See the Emblem component.

Agents are small faceless automaton figures, about a sixth of a machine's height, with their emblem as a shape on the chest. Their gear (spectacles, an umbrella, a foundry apron) is earned from what they actually do and can't be bought.

The Floor has no logo yet. Set its name in plain type, `atlas-district` in small caps, until one exists. Tokens' own logos are their owners' assets: print them onto surfaces in the drawing as supplied, never redraw them.

## Common failures

Renderers and image models drift in predictable ways. Check every output against this list before iterating on anything else.

- Perspective creeping in, so far machines shrink and lines converge.
- Bloom and glow smearing the linework, especially at night.
- Text appearing on machines, signs or the ground.
- More than one orange part, or orange on something that isn't value moving.
- Brass on decoration, or brass readings without engraved scales.
- Identical islands, or generic steampunk clutter instead of each island's tradition.
- Machines floating with no base, or a works with no logo or name plate.
- Logos pasted flat over the drawing instead of printed onto a surface in it.

## Intentional additions

The palette, type, flags, emblems and rules above come from the Floor's product doc. These tokens were added to make it usable in an interface:

- `ink` and `ink-muted`: text colours, since `line` is 70% at night and too faint for small text.
- `paper`: the one paper material given a value, slightly lighter than `ground` by day and slightly raised from it at night.
- `engraving`: the colour of marks cut into brass, dark in both themes, since `line` is too light on brass at night.
- `tone-0` to `tone-3`: the four-tone shading rule given values.
- The spacing, radius and `drawing` tokens: a 4px interface scale, square corners, and the drawing's fixed constants.
