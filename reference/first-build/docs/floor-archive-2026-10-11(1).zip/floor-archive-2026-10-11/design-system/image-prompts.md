# Image prompts

For image models and anyone briefing one. Prepend the style block to every frame and append the avoid block, then check the result against the common failures in the brand book before iterating on anything else.

Every frame prompt does four things:

- It names its island's tradition.
- It puts blank name plates and simple invented emblems on signs; the interface adds real names and logos.
- It engraves a scale on every brass reading.
- It states the single orange part.

Agents are small faceless automaton figures, about a sixth of a machine's height, each with its emblem as a shape on its chest. Day frames matter as much as night ones.

## Style block

Prepend to every frame:

```
Isometric technical illustration, orthographic camera from one corner looking down 30 degrees, no perspective. Hairline even-weight linework on every edge. Flat four-tone shading by face direction, top faces lightest. Warm paper background for day scenes, dark navy-charcoal for night. Only parts that show live data are brass, and each carries fine engraved scale marks; every other material follows the scene's architectural tradition. Exactly one part highlighted in vivid orange: the place where value is moving right now. Engineering-drawing precision with dense, purposeful detail. Calm, legible and serious, like a plate in an engineering atlas.
```

## Avoid block

Append to every frame:

```
Avoid: perspective, vanishing points, depth of field, photographic lighting, soft gradients, bloom, neon, holograms, casino imagery, coins and dollar signs, text, letters, numbers, arrows, callouts, motion lines, watermarks, real brand logos, faces on robots, identical islands, generic steampunk clutter, decorative gears, brass on decorative parts, more than one orange highlight.
```

## 1. The archipelago in daylight

```
Three islands seen whole in daylight on warm paper, each built in a clearly different tradition: a terraced harbour city of glass and riveted steel with a clockwork lighthouse at its centre; a stone canal town of brick mills and arched bridges with a slow beam engine at its centre; a timber shipyard under construction, covered in scaffolding, with a crane at its centre. Each island has a district gate with a plain banner, a covered market hall of many tiny stalls, a few larger compounds with blank name plates and simple painted emblem signs, and one tall tower. Steel bridges with freight carts join the islands, and each island's harbour has a large tide gauge on its quay. Tiny faceless automaton figures walk between buildings. The busiest compound's main machine on the harbour island, mid-trade, is the orange part.
```

## 2. A tuned constant-product pool

```
A single market machine in the harbour city's glass-and-steel tradition, centred with wide margins: two glass tanks joined by a pipe, standing on a balance beam. Each tank has a brass level gauge with fine engraved scale marks, and an engraved brass arc sits under the beam's pivot. Liquid is pouring from one tank into the other mid-trade, with a small emblem stamped beside the pour. A tide gauge stands beside it, a brass float in an engraved stilling well linked to a pen on a turning paper drum, and a blank name plate and a simple painted emblem sign are fixed to the base. The pour is the orange part.
```

## 3. The same readings, designed by a community

```
The same kind of market machine designed as a lily-pond water clock: two tall green-enamel lily stems holding glass cylinders of water, a lily-pad balance between them, wooden decking and reeds around the base. Only the readings are brass: a level gauge with engraved marks on each cylinder, an engraved arc under the balance, and a tide gauge with its float and paper drum. A painted frog emblem on a wooden sign and a blank name plate. Water is pouring from one cylinder into the other mid-trade, and the pour is the orange part.
```

## 4. The depth rack

```
A tall steel rack of shallow trays in the canal town's tradition on a brick plinth, the lower trays full of liquid and the upper trays nearly empty, with a brass float riding through the middle tray along a brass rail with engraved price marks. Beside it, a tide gauge: a brass float in a stilling well driving two pens across a paper drum, with small emblems stamped along the line. Four paper notes with simple shapes pinned to the frame, and two faceless automaton figures, one holding a clipboard. The tray being drained by the latest trade is the orange part.
```

## 5. The foundry

```
The foundry at the edge of the timber shipyard island: a brick casting floor with a crucible pouring molten brass into a mould, and a newly cast small stall cooling beside it with a curved brass track and a ball at its foot, an engraved graduation line near the top of the track. Further along, two older stalls with their balls high on their tracks, and a cart carrying a stall out across a bridge toward the districts. A faceless automaton figure watches the pour holding a notebook. The pouring brass is the orange part.
```

## 6. A district in tiers

```
One narrative district on the canal town island seen from above: an arched gate with a plain banner, a covered market hall packed with dozens of tiny stalls each with a miniature tide gauge, a ring of mid-sized compounds with blank name plates and emblem signs, community plinths with a painted lighthouse and a statue, and one tall tower at the centre. Thin threads are strung between several compounds. The compound with the most trading, its main machine mid-pour, is the orange part.
```

## 7. An agent's desk

```
A small wooden desk in a community hall, seen close. On it: a small screen showing an abstract web page, a corkboard with pinned cards and threads between them, an open notebook, a ledger book with receipts tucked into it, a brass gauge with engraved marks like a fuel meter, and a small raised flag. A faceless automaton figure with a diamond emblem on its chest sits writing in the notebook. The raised flag is the orange part.
```
