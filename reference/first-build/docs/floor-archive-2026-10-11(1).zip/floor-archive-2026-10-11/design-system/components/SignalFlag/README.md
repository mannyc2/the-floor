# SignalFlag

A maritime-style flag that marks a system state on a desk, a note, a receipt or your harbour.

Each flag is a 48×32 two-colour geometric pattern with a `hairline` edge in `line`, inspired by real signal flags without borrowing their meanings.

| Flag | Pattern | Raised when |
| --- | --- | --- |
| Approval needed | `ground` with an `accent` triangle | A trade or launch is waiting for its owner |
| Alert | `ink` and `ground` quartered | A scribed line has been crossed |
| Verified | A `ground` panel in an `ink` field | An on-chain claim in a note checked out |
| Contradicted | An `ink` saltire on `ground` | An on-chain claim in a note failed its check |
| Paused | `steel`, `ground`, `steel` bands | The owner has paused the agent |
| Untrusted page | `ink` diagonal stripes on `ground` | The browser met a page that tried to instruct the agent |

**Provide** the state, and the word that goes with it.

- Always set the flag's name beside it in `ui-label`; a flag never stands alone.
- Draw flags at 48×32 in legends and 18×12 inline in notes and receipts. Keep the 3:2 ratio.
- Only Approval needed may be orange, because it marks value waiting on you to move it. It is the desk's one `accent` part; clear it the moment the trade is approved, declined or expires.
- In the drawing, flags snap up on a short staff over the desk or harbour. On your phone, the same flag leads the notification.
- Don't invent new flags for one-off states, and don't recolour a flag to make it louder.
