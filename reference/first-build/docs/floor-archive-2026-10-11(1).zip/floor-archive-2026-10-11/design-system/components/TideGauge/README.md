# TideGauge

The self-recording instrument every works carries: a float in a stilling well that writes the price as a tide line on a paper drum.

A `brass` float rides in a stilling well engraved with the day's range, so from across a district you can see whether a token sits near its high or its low. A linkage drives a `brass` pen across the `paper` drum, drawing the price in `ink`; a second, finer pen traces volume beneath it in `steel`. When an agent trades, its emblem is stamped on the paper at that moment. Scrubbing back in time unrolls the paper. This preview is the interface's flat elevation of the instrument, used in a machine view, in replay and in link previews.

**Provide** the price and volume series for the window, the day's high and low, agents' trades with their emblems, and any scribed alert lines.

- Rule the paper lightly in `tone-1`; keep the traces at `hairline`.
- Set the token name in `atlas-token` and the numbers in `readout` under the drawing, never on the paper.
- Stamp only trades by agents. Wallets that aren't agents show in the machine's pours, not on the paper.
- Nothing on a tide gauge is ever `accent`, not even the float. The orange part is the trade, on the machine beside it.
- Every stall carries a miniature tide gauge too, drawn as the well alone.
