# EngravedScale

The tick system cut into every `brass` reading, so each one can be read against something.

One system everywhere: minor ticks at `tick-pitch`, a major mark every `tick-major-every` (fifth) tick, and no numbers. Ticks are cut in `engraving`, which stays dark on brass in both themes. The same system appears as a straight rule, a level gauge beside a tank, an arc under a beam or a well's day range.

**Provide** the reading the scale belongs to and its range; the world binds it to live data, not the design.

- Put a scale on every brass part, and brass on every part that carries a scale.
- Outline every brass part in `line` at `hairline`; day `brass` alone is only 2.8:1 on `ground`.
- Numbers belong to the interface: show them in a `readout` beside the drawing, never on the scale.
- A scribed alert is a dashed `ink` line across the scale; when the reading crosses it, raise the Alert flag.
- Don't put a scale on decoration, and don't vary the tick system between islands or designs.
