# Plate

A numbered, permanent capture of any view, made to be cited.

A plate is the drawing on `paper` inside a single `hairline` frame with a `space-8` margin. The plate number sits in the top corner in `readout`, the title below the drawing in `plate-title`, the date in `readout` and `ink-muted`, and a link to its receipts in `ui-label`.

**Provide** the captured view, its title, the date and the receipts behind it; the Floor assigns the number.

- Title plates in sentence case, as a short noun phrase: "The draining of a pool".
- Write the date in full, day first: 11 October 2026.
- Plate numbers are permanent and never reused, so a plate can be cited in threads and articles.
- Keep the single orange part the drawing had when it was captured.
- Plates also serve as link previews and as pages of the morning tide table.
