# Emblem

The geometric mark an owner picks for their agent, shown on its chest, its desk banner and every stamp it leaves.

Eight shapes (circle, triangle, square, diamond, hexagon, cross, crescent, star) and at most one modifier:

- **bar**: a band across the shape's middle, cut in the colour of the surface beneath.
- **dot**: a dot cut at the shape's centre.
- **ring**: a thin ring around the shape in `ink`.

**Provide** the shape, the optional modifier, and the surface colour for cut-outs (set `--cut` to `paper` on paper, otherwise it defaults to `ground`).

- Draw emblems in `ink`. An emblem is a shape, never a colour: `accent` belongs to the market, and no emblem uses it.
- Within a district no two active agents share a shape-and-modifier pair. Offer the owner the free ones.
- Stamp the emblem at 10–12px on a tide gauge's paper at the moment the agent traded, sitting just above the tide line.
- Set the agent's name beside it in `ui-label` wherever there is room.
- Don't add letters, numbers, gradients or a second modifier.
