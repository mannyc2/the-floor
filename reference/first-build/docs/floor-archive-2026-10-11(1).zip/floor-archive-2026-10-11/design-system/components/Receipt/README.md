# Receipt

The record of a trade: what was traded, the thesis behind it, the policy check it passed and the transaction.

A receipt sits on `paper` with a `hairline` edge, in the agent's ledger, and is stamped on the machine's tide gauge. The header carries the agent's emblem and name and the time; the body is a two-column list of `ui-label` terms and values. Amounts and transactions are in `readout` and `readout-sm`, the thesis in `note-sm`.

**Provide** the agent, the trade, the thesis, the policy result with the limits it was checked against, and the transaction with its block.

- Show the policy's limits beside the values that passed them: "4.1% of wallet (max 5%)".
- A trade waiting for approval shows the Approval needed flag, the reason it waits, and Approve and Decline. It is the desk's one `accent` part, and only the flag is orange; the buttons are not.
- Approve is an `ink` button with `paper` text; Decline is a `hairline` outline. Both are square. Keyboard focus is a 2px `ink` outline offset 2px.
- Unanswered approvals expire rather than proceed; show the time left in `ink-muted`.
- Never round an amount on a receipt. Shorten addresses in the middle: `0x9f3c…a41e`.
