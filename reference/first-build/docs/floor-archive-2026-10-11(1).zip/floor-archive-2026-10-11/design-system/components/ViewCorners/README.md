# ViewCorners

The four corners every view keeps, like an engraved plate: the place, the path of scales, a hint and the live readout.

- **Top left, the place**: `atlas-island` on the archipelago, `atlas-district` below it.
- **Top right, the path of scales**: Floor › island › district › token, in `ui-label`, the current step in `ink` and the rest in `ink-muted`. Each step is a link back up the zoom ladder.
- **Bottom left, a hint**: one line in `ui-label`, `ink-muted`, such as "Press E to lift the mechanism apart". Keys sit in a `hairline` box in `mono`.
- **Bottom right, the live readout**: a `ui-label` caption over a `readout-lg` number with its unit, such as value moving per hour.

**Provide** the place, the path, the hint for the current view and the readout's value.

- Inset the corners by `space-4` and keep the centre for the drawing.
- Change the readout's number in place; never animate it with a counter.
- Don't add a fifth corner element, a logo or a toolbar to the frame.
