# AtlasLabel

The names the atlas layer floats above the drawing, set like an old chart and scaled by zoom.

Island names in `atlas-island` from the farthest zoom, district names in `atlas-district` in the middle distance, token names in `atlas-token` up close. All three are the `atlas` family in letterspaced small caps (`font-variant-caps: all-small-caps`), in `ink`.

**Provide** the name and the zoom level; the renderer places the label.

- Labels live in an overlay above the drawing. The drawing itself carries no words except logos and name plates.
- Show one level of label at a time, by zoom: island names fade out as district names fade in.
- Place labels in clear ground, beside what they name, without leader lines. Never cover the orange part.
- Keep the token's own spelling, set in small caps; drop the `$` ticker prefix in the label.
- Wrecks on the low-tide flats carry their token's name and the date they went under, in `atlas-token`.
