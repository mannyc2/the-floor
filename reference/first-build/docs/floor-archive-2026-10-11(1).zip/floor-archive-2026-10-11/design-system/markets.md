# Market machines

Every market on the Floor is drawn as a machine. The defaults below are a starting vocabulary, not a standard: a token's community, a protocol's team or an island's tradition may give a machine any form, as long as it shows everything in its row and obeys the brass rule. A lily-pond water clock is a fine constant-product pool if its levels, price and trades can be read off brass scales.

## Default forms

| Market | Default form | Must show | Tuning |
| --- | --- | --- | --- |
| Constant-product pool | Two tanks joined by a pipe on a balance beam | Both reserves, the price, each trade | An engraved level scale on each tank and a price arc under the beam; each trade as a visible pour stamped with its maker |
| Concentrated-liquidity pool | A rack of trays, one per price band, with a brass float | Liquidity per band, the current price | Already reads well. Engrave price marks beside the trays |
| Bonding-curve launch | A ball climbing a curved track | Progress toward graduation | An engraved graduation line, and a faint trail of the ball's recent path |
| Lending market | A reservoir with an outflow valve and a utilization gauge | Deposits, borrows, utilization, liquidations | The rate kink and the liquidation line marked on the gauge; liquidations as trapdoors |
| Perpetuals | A beam with longs and shorts as weights, and a funding pump | Open interest on each side, funding | Weights sized against an engraved scale; the pump's stroke shows which way funding flows |
| Prediction market | A two-pan scale | The odds | A 0–100 arc behind the pans, so the tilt reads as a percentage |
| Bridge | A bridge between islands | Value crossing, queue length | Freight sized by value |
| Large wallet | A vault on its home island | Holdings, movements | Freight leaving when it moves |
| Chain | A landmark at the island's centre that beats once per block | Block time, fees | Every island's landmark is its own |

## Rules for every machine

- Paint the readings `brass` and engrave a scale on each. Paint nothing else brass.
- Make the trade in progress the one `accent` part, and only while value is moving.
- Fill liquidity with `water`. Draw everything else in the island's materials, with `steel` as the fallback.
- Give every works its token's logo, printed on a sign, plaque or flag, and a blank name plate for the interface to fill.
- Stand every machine on a base. Nothing floats.
- Give every works a tide gauge.

## The tide gauge

Every works carries one instrument in common: a self-recording tide gauge. A `brass` float rides in a stilling well engraved with the day's range, so from across a district you can see whether a token sits near its high or its low. A linkage from the float drives a `brass` pen across a turning `paper` drum, recording the price as a tide line in `ink`, while a second, finer pen traces volume beneath it in `steel`. When an agent trades, its emblem is stamped on the paper at that moment. Scrubbing back in time unrolls the paper.

Water is liquidity, the float is price, and brass is data. A price alert is a mark scribed on the stilling well; when the float crosses it, the Alert flag goes up.

## Tiers

| Tier | Which tokens | Drawn as |
| --- | --- | --- |
| Stall | Every token, however small | A small stand in its district's market hall with a miniature tide gauge |
| Works | Tokens with real liquidity and activity | A compound: its machines, logo and name plate, its community's plinths, and room for agents' desks |
| Tower | The few that dominate their district | A works grown upward, visible from across the island |

## Agents in the drawing

| State | What you see |
| --- | --- |
| Researching | At its desk with the screen lit, threads running from it to the machines it is reading about |
| Inspecting | Standing at a machine with a loupe |
| Deciding | Writing in its notebook |
| Waiting for its owner | A small flag raised over its desk; the waiting trade is the `accent` part |
| Trading | Carrying its wallet to a machine; the trade pours in stamped with its emblem |
| Asleep | Desk lamp off |
| Launching | At the foundry, watching its coin pour, with its thesis pinned beside the mould |

Threads string between machines an agent is comparing, in `line`. Pins are its conclusions, fixed to a machine, drawn as small `paper` cards with a round head. At a distance, threads and pins collapse into a soft density over the district.
