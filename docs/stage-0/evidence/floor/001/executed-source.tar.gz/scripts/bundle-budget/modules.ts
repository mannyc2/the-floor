import { BunRuntime, BunServices } from "@effect/platform-bun";
import { Array, Crypto, Effect, FileSystem, HashSet, Path, Result, Schema } from "effect";
import { Command, Flag } from "effect/cli";
import * as Hex from "effect/encoding/Hex";
import { generatedModuleSha256 } from "./generated";
import { BundleBudgetError, inspectSources, SourceMap, type Target } from "./model";

const inspectMap = Effect.fn("BundleModules.inspectMap")(function*(target: Target, file: string, code: string) {
  const fs = yield* FileSystem.FileSystem;
  const path = yield* Path.Path;
  const mapFile = `${file}.map`;
  if (!(yield* fs.exists(mapFile))) {
    const crypto = yield* Crypto.Crypto;
    const digest = Hex.encode(yield* crypto.digest("SHA-256", new TextEncoder().encode(code)));
    if (!generatedModuleSha256.has(digest)) {
      return yield* new BundleBudgetError({ reason: "MissingSourceMap", detail: file });
    }
    return 0;
  }
  const map = yield* fs.readFileString(mapFile).pipe(
    Effect.flatMap(Schema.decodeUnknownEffect(Schema.fromJsonString(SourceMap))),
  );
  if (map.sources.length === 0) return yield* new BundleBudgetError({ reason: "MissingSourceMap", detail: file });
  const sources = map.sources.map(source =>
    path.relative(path.resolve("."), path.resolve(path.dirname(mapFile), source))
  );
  const result = inspectSources(target, sources);
  if (Result.isFailure(result)) return yield* result.failure;
  return sources.length;
});

const command = Command.make(
  "bundle-modules",
  {
    target: Flag.Literals("target", ["web", "floor", "signer"]),
    directory: Flag.String("directory"),
    entry: Flag.String("entry").pipe(Flag.atLeast(1)),
  },
  Effect.fn("BundleModules.check")(function*({ target, directory, entry }) {
    const fs = yield* FileSystem.FileSystem;
    const path = yield* Path.Path;
    const root = path.resolve(directory);
    // Bun's parser follows static, dynamic, CommonJS and re-export dependency edges
    // in emitted JavaScript. Recursive directory scans would include stale chunks.
    const parser = new Bun.Transpiler({ loader: "js" });
    let pending = entry.map(file => path.resolve(root, file));
    let visited = HashSet.empty<string>();
    let mappedSources = 0;
    while (Array.isArrayNonEmpty(pending)) {
      const [file, ...remaining] = pending;
      pending = remaining;
      if (HashSet.has(visited, file)) continue;
      visited = HashSet.add(visited, file);
      const relative = path.relative(root, file);
      if (relative === ".." || relative.startsWith("../") || path.isAbsolute(relative)) {
        return yield* new BundleBudgetError({ reason: "UnsafePath", detail: file });
      }
      if (!(yield* fs.exists(file))) return yield* new BundleBudgetError({ reason: "MissingEntry", detail: file });
      const code = yield* fs.readFileString(file);
      const imports = yield* Effect.try({
        try: () => parser.scanImports(code),
        catch: cause => new BundleBudgetError({ reason: "InvalidModule", detail: file, cause }),
      });
      for (const dependency of imports) {
        if (dependency.path.startsWith(".")) pending.push(path.resolve(path.dirname(file), dependency.path));
        else if (!dependency.path.startsWith("node:") && dependency.path !== "cloudflare:workers") {
          return yield* new BundleBudgetError({
            reason: "InvalidModule",
            detail: `Unbundled dependency ${dependency.path}`,
          });
        }
      }
      mappedSources += yield* inspectMap(target, file, code);
    }
    yield* Effect.logInfo(
      `${target}: ${HashSet.size(visited)} emitted modules, ${mappedSources} mapped sources inspected`,
    );
    return void 0;
  }),
);

command.pipe(
  Command.run({ version: "1.0.0" }),
  // oxlint-disable-next-line effecttsgo/strict-effect-provide -- The artifact-inspection executable owns its filesystem and cryptographic digest services.
  Effect.provide(BunServices.layer),
  BunRuntime.runMain,
);
