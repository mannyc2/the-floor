# Local launch-construction probe

This isolated spike package builds an Alchemy Worker using Kit 8.4.0, a narrow Codama-generated Meteora client, native `bigint` arithmetic and Doppler's `/evm` entry. It contains controlled test inputs. It is not a production chain package or a signer.

From this directory, run `bun install --frozen-lockfile`, `bun run format:check`, `bun run typecheck`, `bun run lint`, `bun run test`, then `bun run build`. Build uses Alchemy's supported `Test.make({ dev: true, sidecar: false })` harness: it bundles the Worker, executes the local assertions and destroys the local resource. It creates no hosted stage. The host transport preload rejects non-loopback fetches and telemetry is disabled. The test-owned Worker listens on port 19735 while the test runs.

The pinned Alchemy beta.80 package carries Yielded PR 557's patch. The Worker uses compatibility date 2026-08-18 with the default flags. The evidence records the resolved workerd version and actual Node compatibility behavior. Every active consumer uses Effect 4.0.3, including the separately packaged native Alchemy-agent probe.

## What runs

- `/launch` constructs the same fixed unsigned config-plus-pool transaction twice. Three public identities, a zero blockhash and a synthetic quote-mint owner are explicit inputs. An Effect `HttpClient` request to the same local Worker's `/rpc` endpoint supplies the owner, decoded by Schema. Only the declared request shape is accepted. There is no live chain checkpoint or signing key.
- `/evm` builds fixed Doppler Airlock multicurve calldata twice through `viem`. A rejecting transport counts the negative control and proves that construction itself makes no RPC request.
- `/crypto` checks SHA-256 empty/abc vectors, 32 sampled UUIDv4 values and typed rejection of negative random-byte size through the browser crypto layer.
- `/math` checks representative fee and curve-delta arithmetic and typed invalid-input behavior. The four pure computations are also compared with the official Meteora SDK as a development oracle. They are not a complete pool quote or curve-construction implementation.
- `/privy` checks native P-256 and PKCS8 import, then executes the bounded Privy client through the actual Worker's `FetchHttpClient` and a guarded loopback fixture. The fixture counts requests and returns a deliberately synthetic message-signing response. Its request count and results are written to `work/privy-result.json`.

The construction test requires the known full serialized digests, expected lengths, no attached signatures, repeated equality, the EVM transport counts, a successful math probe and rejection of an undeclared RPC. Results from the real local Worker are retained in the evidence directory, with exact source and dependency hashes.

Kit's unconstrained generic `RpcTransport` promises a caller-selected response type from unknown JSON. This bounded example instead places Schema decoding directly at the Effect HTTP edge and uses Kit for addresses, PDAs, codecs and transaction serialization. It avoids a type assertion at that trust boundary. A generalized Kit RPC adapter remains future work.

## Regeneration and limits

Meteora-derived IDL and arithmetic retain the upstream MIT terms in `METEORA-LICENSE`. `source.json` pins the Meteora Anchor IDL's upstream commit and SHA-256. `bun run generate` runs Codama and then `bounded-client.py`. That script retains twelve binary codec modules and derives only the two required instruction builders from the IDL. It emits direct codec imports to avoid barrel cycles. Full generic Codama output stays in ignored `client/`; the selected output has no casts, non-null assertions or `any`. Run formatting and all checks after regeneration. `config.ts` is a labelled fixed oracle fixture, not a live quote or a port of the SDK's entire configuration builder.

The SDK and its web3.js/Anchor/BN dependencies are not dependencies of this package. The bundle audit also checks that Doppler's unused Kit 6 dependency does not enter the reachable Worker graph. Oracle output and driver provenance are retained separately as development evidence.

Nineteen reasoned lint suppression lines cover twenty-four rule occurrences. The original nine lines cover Alchemy's module filename and lifecycle hooks, Layer entry points, Viem's required rejected-Promise callback and the host transport guard. Ten additional lines cover JCS primitive serialization, native asymmetric crypto, an ephemeral test-key export, test Layer entry points, the fake Fetch Promise boundary and the guarded loopback Fetch adapter. Two compiler annotations apply only to the native-fetch boundaries. Strict compiler options, all 91 Effect diagnostics and the remaining lint rules stay enabled. The test driver additionally reviews the external `effect/FileSystem` module family; there is no internal unstable-API exception.

## Bounded Privy edge

`src/privy` implements four documented POST operations through Effect `HttpClient`: create a key quorum, create an Ethereum message policy, create its quorum-owned wallet, and `personal_sign` a UTF-8 message. Policy support is deliberately limited to one exact-message rule. Wallet creation requires an owner quorum and at least one policy. Quorum creation accepts public authorization keys, optional user IDs and an explicit threshold; nested quorums and user-key retrieval are outside this probe.

Authorization follows Privy's [direct signing guide](https://docs.privy.io/controls/authorization-keys/using-owners/sign/direct-implementation): a [RFC 8785](https://www.rfc-editor.org/rfc/rfc8785) payload, native Web Crypto P-256/SHA-256, PKCS8 private-key import and DER/base64 signatures. The serializer preserves UTF-16 property order and rejects invalid Unicode and non-finite numbers. It accepts constructed JSON values, not raw text with potentially duplicated keys. The client fixes the API origin, signs the body and idempotency header, bounds request time and never automatically retries mutations. Foreign failures retain their causes; a Base64 error that contains a malformed private key is retained behind `Redacted`.

Co-signatures use the documented [comma-delimited quorum header](https://docs.privy.io/controls/key-quorum/sign). Tests independently decode both DER signatures and verify that they cover the same request; neither signer is registered with Privy. The documented [user/server 2-of-2 arrangement](https://docs.privy.io/recipes/wallets/two-of-two-server-in-the-loop) still requires the owner's chosen sandbox app, user and server authorization keys. The HTTP tests use fake responses or the loopback fixture. They do not establish service acceptance, real wallet signatures, quorum membership, policy enforcement or refusal behavior at Privy.

The request and response subsets were checked against the official [wallet](https://docs.privy.io/api-reference/wallets/create), [policy](https://docs.privy.io/api-reference/policies/create), [quorum](https://docs.privy.io/api-reference/key-quorums/create), [personal-sign](https://docs.privy.io/api-reference/wallets/ethereum/personal-sign) and [authentication](https://docs.privy.io/basics/rest-api/setup) references. No Privy SDK or runtime dependency was added. No credentials were inspected, no Privy request was made and no broadcast endpoint exists in the client. Live sandbox work needs account selection and a separately authorized provider budget.

No result proves sandbox co-signing, simulation, broadcast, graduation, migration, vesting, allocations, hosted compatibility or Stage 0 readiness.
