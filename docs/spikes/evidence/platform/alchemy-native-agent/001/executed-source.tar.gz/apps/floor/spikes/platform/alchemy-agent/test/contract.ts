import { Schema } from "effect";

export const CallbackStatus = Schema.Struct({ acceptedAt: Schema.Finite, completedAt: Schema.Finite });
export const Record = Schema.Struct({
  sequence: Schema.Natural,
  kind: Schema.String,
  createdAt: Schema.Finite,
  settlement: Schema.String,
  output: Schema.Json,
});
export const Snapshot = Schema.Struct({ callback: CallbackStatus, records: Schema.Array(Record) });
export const AdmissionReport = Schema.Struct({
  ...Snapshot.fields,
  quietStartedAt: Schema.Finite,
  observedAt: Schema.Finite,
  localUrl: Schema.String,
  threadName: Schema.String,
});
export const RestartReport = Schema.Struct({
  threadName: Schema.String,
  afterRestart: Snapshot,
  afterDuplicate: Snapshot,
  quietStartedAt: Schema.Finite,
  observedAt: Schema.Finite,
});
