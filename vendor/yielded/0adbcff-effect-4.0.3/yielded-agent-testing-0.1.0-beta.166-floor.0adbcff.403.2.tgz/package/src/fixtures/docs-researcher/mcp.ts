import {
  McpConnectionRequest,
  McpConnector,
  McpServerIdentity,
  McpToolkitMismatch,
  type McpConnection,
} from "@yielded/agent/mcp";
import type { JsonSchema } from "effect";
import { Effect, JsonPointer, Layer, Schema } from "effect";
import { Tool } from "effect/ai";
import * as McpSchema from "effect/ai/McpSchema";

import { DocContentToolkit, FetchDocument } from "./definition.ts";

// ---------------------------------------------------------------------------
// Scripted MCP fixture: a deterministic `McpConnector` adapter that serves the
// doc-summarizer's content tool. Discovery entries are DERIVED from the
// authored Tool (`Tool.getJsonSchema`), so `validateMcpDiscovery` digesting
// both sides is a real check, not a tautology; the mismatch and over-limit
// connectors below serve deliberately wrong contracts so tests can pin the
// fail-closed paths (CAP-009, SEC-013).
// ---------------------------------------------------------------------------

/** Framework-side hard bounds one docs-researcher assembly requests. */
export const docsMcpRequest = McpConnectionRequest.make({
  serverId: "docs-content-mcp",
  maxToolCount: 4,
  maxToolDescriptionBytes: 256,
  maxDiscoveryBytes: 16_384,
  connectTimeoutMillis: 1_000,
});

export const docsMcpIdentity = McpServerIdentity.make({
  serverId: docsMcpRequest.serverId,
  implementation: McpSchema.Implementation.make({
    name: "docs-researcher-content-fixture",
    version: "1.0.0",
  }),
});

/**
 * `Tool.getJsonSchema` produces a `$ref`/`$defs`-shaped schema for
 * `FetchDocument`'s named, refined parameters type, but `McpSchema.Tool`'s
 * `inputSchema` requires a flat `{ type: "object", ... }` root — the shape a
 * real MCP server advertises on the wire. This inlines the single top-level
 * `$ref` so the derivation described above still holds byte-for-byte.
 */
const JsonSchemaDefinitions = Schema.Record(
  Schema.String,
  Schema.Record(Schema.String, Schema.Unknown),
);

const decodeJsonSchemaDefinitions = Schema.decodeUnknownSync(JsonSchemaDefinitions);
const decodeToolJson = Schema.decodeUnknownSync(McpSchema.ToolJson);

const flattenTopLevelRef = (schema: JsonSchema.JsonSchema): McpSchema.ToolJson => {
  const ref = schema["$ref"];

  if (typeof ref !== "string") {
    return decodeToolJson(schema);
  }

  const defs = decodeJsonSchemaDefinitions(schema["$defs"]);

  const key = ref.startsWith("#/$defs/")
    ? JsonPointer.unescapeToken(ref.slice("#/$defs/".length))
    : undefined;

  const resolved = key !== undefined && Object.hasOwn(defs, key) ? defs[key] : undefined;

  return decodeToolJson(resolved ?? schema);
};

const fetchDocumentOutputSchema = flattenTopLevelRef(
  Tool.getJsonSchemaFromSchema(FetchDocument.successSchema),
);

const discoveredFetchDocument = McpSchema.Tool.make({
  name: FetchDocument.name,
  description: "Fetch one bounded research document by its identifier.",
  inputSchema: flattenTopLevelRef(Tool.getJsonSchema(FetchDocument)),
  // `validateMcpDiscovery` only compares an `outputSchema` derived down to an
  // object type; mirror that so this fixture stays a real round-trip check.
  ...(fetchDocumentOutputSchema.type === "object"
    ? { outputSchema: fetchDocumentOutputSchema }
    : {}),
});

const scriptedConnector = (tools: ReadonlyArray<McpSchema.Tool>): Layer.Layer<McpConnector> =>
  Layer.succeed(McpConnector)({
    connect: () =>
      Effect.acquireRelease(
        Effect.succeed({
          identity: docsMcpIdentity,
          capabilities: McpSchema.ServerCapabilities.make({}),
          tools,
          toolkit: DocContentToolkit,
        }),
        () => Effect.void,
      ),
  });

/** The well-behaved scripted content server. */
export const docsMcpConnectorLayer: Layer.Layer<McpConnector> = scriptedConnector([
  discoveredFetchDocument,
]);

/** Serves a tool description exceeding `maxToolDescriptionBytes` (SEC-013 bound). */
export const docsMcpOversizedConnectorLayer: Layer.Layer<McpConnector> = scriptedConnector([
  McpSchema.Tool.make({
    name: discoveredFetchDocument.name,
    description: "x".repeat(1_024),
    inputSchema: discoveredFetchDocument.inputSchema,
  }),
]);

/** Serves a discovery schema that disagrees with the authored toolkit (drift fails closed). */
export const docsMcpMismatchedConnectorLayer: Layer.Layer<McpConnector> = scriptedConnector([
  McpSchema.Tool.make({
    name: discoveredFetchDocument.name,
    description: discoveredFetchDocument.description,
    inputSchema: { type: "object", properties: { url: { type: "string" } } },
  }),
]);

const isJsonEqual = (left: unknown, right: unknown): boolean =>
  JSON.stringify(left) === JSON.stringify(right);

/**
 * Bind DISCOVERY to AUTHORING: `validateMcpDiscovery` (inside `connectMcp`)
 * already proved the served discovery matches the connection's own Toolkit;
 * this check additionally proves that Toolkit is the exact toolkit the
 * doc-summarizer was AUTHORED against — same tool names, same derived JSON
 * schemas — so a connector cannot substitute a look-alike toolkit. The
 * docs-researcher harness runs it before any worker Binding registration and
 * fails closed on any drift.
 */
export const assertDiscoveryMatchesAuthoredToolkit = Effect.fn(
  "DocsResearcher.assertDiscoveryMatchesAuthoredToolkit",
)(function* (connection: McpConnection): Effect.fn.Return<void, McpToolkitMismatch> {
  const authored = Object.values(DocContentToolkit.tools)
    .map((tool) => ({ name: tool.name, inputSchema: Tool.getJsonSchema(tool) }))
    .sort((left, right) => (left.name < right.name ? -1 : left.name > right.name ? 1 : 0));

  const discovered = Object.values(connection.toolkit.tools)
    .map((tool) => ({ name: tool.name, inputSchema: Tool.getJsonSchema(tool) }))
    .sort((left, right) => (left.name < right.name ? -1 : left.name > right.name ? 1 : 0));

  const matches =
    authored.length === discovered.length &&
    authored.every(
      (tool, index) =>
        tool.name === discovered[index]?.name &&
        isJsonEqual(tool.inputSchema, discovered[index]?.inputSchema),
    );

  if (!matches) {
    return yield* McpToolkitMismatch.make({
      serverId: connection.discovery.identity.serverId,
      message:
        "The MCP-discovered toolkit does not match the doc-summarizer's authored content toolkit",
    });
  }
});

/** Round-trip guard for encoded discovery values persisted as fixture evidence. */
export const DocsMcpDiscoveryEvidence = Schema.Struct({
  serverId: Schema.NonEmptyString,
  toolCount: Schema.Natural,
  encodedBytes: Schema.Natural,
  toolkitSchemaDigest: Schema.String,
});
