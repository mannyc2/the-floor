import {
  type DoMemoryStorageLimits,
  defaultDoMemoryStorageLimits,
  doMemoryStoreLayerWithFailpoints,
} from "@yielded/agent-storage-cloudflare/do-memory-store";
import {
  type MemoryOwnerAuthorizer,
  decodeMemoryWire,
  defaultMemoryRpcLimits,
  encodeMemoryWire,
  handleMemoryOwnerRequest,
  MemoryOwnerIdentity,
  MemoryOwnerRequest,
  MemoryOwnerResponse,
  MemoryRpcError,
  MemoryRpcLimits,
} from "@yielded/agent-storage-cloudflare/memory-protocol";
import * as Memory from "@yielded/agent/memory";
import * as MemoryNamespace from "@yielded/agent/memory-namespace";
import { MemoryNamespaceAddress } from "@yielded/agent/memory-namespace";
import { type MemoryLookup, MemoryRecallLimits } from "@yielded/agent/memory-reference";
import { MemoryAccess } from "@yielded/agent/memory-revalidation";
import {
  type MemoryReader,
  type MemoryWrite,
  MemoryKey,
  MemoryDocument,
  MemoryMutationFailpoint,
  MemoryStorageError,
  MemoryWriter,
} from "@yielded/agent/memory-store";
import {
  type MemoryIndexSearch,
  type SemanticMemoryProfile,
} from "@yielded/agent/semantic-memory-index";
import { type SemanticCandidateLimits } from "@yielded/agent/semantic-memory-revalidation";
import { Principal } from "@yielded/agent/submission-ledger";
import { Clock, Context, Effect, Layer, Schema } from "effect";

import { DurableObjectContext } from "./CloudflareHostBindings.ts";
import { RpcStrategy } from "./CloudflareRpc.ts";

export interface MemoryObjectRpc extends Rpc.DurableObjectBranded {
  memory(encoded: string): Promise<string>;
}

export class MemoryObjectNamespace extends Context.Service<
  MemoryObjectNamespace,
  {
    readonly namespace: DurableObjectNamespace<MemoryObjectRpc>;
  }
>()("@effect-agent/platform-cloudflare/MemoryObjectNamespace") {}

/** Namespace version and identity are already canonicalized by MemoryNamespace. */
export const memoryObjectName = (namespace: MemoryNamespace.Any): string => namespace.address;

/**
 * Effect-native, host-bound memory client. Recall revalidates the entire admitted lookup
 * in one RPC and renders it locally. No retries or per-source splitting occur here.
 * Interrupted callers stop waiting; the owner has its own deadline. A timed-out write
 * may have committed: reconcile by sending the identical operation ID and command.
 */
const makeMemoryClient = Effect.fn("CloudflareMemoryClient.make")(function* <
  Namespace extends MemoryNamespace.Any,
>(
  access: MemoryAccess<Namespace>,
  principal: Principal,
  rpcLimits: MemoryRpcLimits = defaultMemoryRpcLimits,
) {
  const validated = yield* Schema.decodeEffect(MemoryRpcLimits)(rpcLimits).pipe(
    Effect.mapError(() => MemoryRpcError.make({ reason: "protocol" })),
  );

  const bound = yield* Schema.decodeUnknownEffect(MemoryAccess.Wire)(access).pipe(
    Effect.mapError(() => MemoryRpcError.make({ reason: "protocol" })),
  );

  principal = yield* Schema.decodeEffect(Principal)(principal).pipe(
    Effect.mapError(() => MemoryRpcError.make({ reason: "protocol" })),
  );
  const { namespace } = yield* MemoryObjectNamespace;
  const rpcStrategy = yield* RpcStrategy;

  const call = Effect.fn("CloudflareMemoryClient.call")(function* (request: MemoryOwnerRequest) {
    const decoded = yield* Schema.decodeEffect(MemoryOwnerRequest)(request).pipe(
      Effect.mapError(() => MemoryRpcError.make({ reason: "protocol" })),
    );

    const encoded = yield* encodeMemoryWire(MemoryOwnerRequest, decoded, validated.maxRequestBytes);

    const unavailable = (cause: unknown) => {
      const error = MemoryRpcError.make({ reason: "unavailable" });

      error.cause = cause;

      return error;
    };

    const address = memoryObjectName(bound.namespace);

    const target = yield* rpcStrategy
      .get(namespace, address, () => namespace.get(namespace.idFromName(address)))
      .pipe(Effect.mapError(unavailable));

    const raw = yield* Effect.tryPromise({
      try: () => target.memory(encoded),
      catch: unavailable,
    }).pipe(Effect.tapCause(() => rpcStrategy.invalidate(target)));

    const response = yield* decodeMemoryWire(MemoryOwnerResponse, raw, validated.maxResponseBytes);

    if (response._tag === "Failed") return yield* response.failure;
    if (
      !MemoryNamespace.equals(response.access.namespace, bound.namespace) ||
      response.access.scope !== bound.scope
    )
      return yield* MemoryRpcError.make({ reason: "protocol" });

    return response;
  });

  const withinDeadline = <A, E, R>(effect: Effect.Effect<A, E, R>, timeoutMillis: number) =>
    effect.pipe(
      Effect.timeoutOrElse({
        duration: timeoutMillis,
        orElse: () => Effect.fail(MemoryRpcError.make({ reason: "timeout" })),
      }),
    );

  const revalidate = Effect.fn("CloudflareMemoryClient.revalidate")(function* (
    lookup: MemoryLookup,
    limits: MemoryRecallLimits,
  ) {
    limits = yield* Schema.decodeEffect(MemoryRecallLimits)(limits).pipe(
      Effect.mapError(() => MemoryRpcError.make({ reason: "protocol" })),
    );
    const timeoutMillis = Math.min(validated.timeoutMillis, limits.timeoutMillis);

    return yield* Effect.gen(function* () {
      const response = yield* call({
        _tag: "Revalidate",
        version: 1,
        access: bound,
        principal,
        lookup,
        limits,
        deadlineMillis: (yield* Clock.currentTimeMillis) + timeoutMillis,
      });

      if (response._tag !== "Lookup") return yield* MemoryRpcError.make({ reason: "protocol" });

      return response.lookup;
    }).pipe((effect) => withinDeadline(effect, timeoutMillis));
  });

  const change = Effect.fn("CloudflareMemoryClient.change")(function* (
    write: MemoryWrite<Namespace>,
  ) {
    if (!MemoryNamespace.equals(write.key.namespace, bound.namespace))
      return yield* MemoryRpcError.make({ reason: "denied" });

    return yield* Effect.gen(function* () {
      const response = yield* call({
        _tag: "Change",
        version: 1,
        access: bound,
        principal,
        write,
        deadlineMillis: (yield* Clock.currentTimeMillis) + validated.timeoutMillis,
      });

      if (response._tag !== "Changed" || response.document.key.id !== write.key.id)
        return yield* MemoryRpcError.make({ reason: "protocol" });

      return yield* MemoryDocument.restore(access.namespace, response.document);
    }).pipe((effect) => withinDeadline(effect, validated.timeoutMillis));
  });

  /**
   * Read one exact current document in one owner RPC. Null means absent; withdrawals return
   * tombstones. Denial, unavailable storage and deadlines fail typed, never become absence.
   * Reads begun after an acknowledged write observe it or a later revision. The owner checks
   * exact-key authority and active document scopes; source-dependent provenance policy remains
   * application-owned. No extraction, job draining, embedding, discovery or rendering occurs.
   */
  const get = Effect.fn("CloudflareMemoryClient.get")(function* (key: MemoryKey<Namespace>) {
    const decodedKey = yield* Schema.decodeUnknownEffect(MemoryKey.Wire)(key).pipe(
      Effect.mapError(() => MemoryRpcError.make({ reason: "protocol" })),
    );

    if (!MemoryNamespace.equals(decodedKey.namespace, bound.namespace))
      return yield* MemoryRpcError.make({ reason: "denied" });

    return yield* Effect.gen(function* () {
      const response = yield* call({
        _tag: "Get",
        version: 1,
        access: bound,
        principal,
        key: decodedKey,
        deadlineMillis: (yield* Clock.currentTimeMillis) + validated.timeoutMillis,
      });

      if (
        response._tag !== "Document" ||
        !MemoryNamespace.equals(response.key.namespace, bound.namespace) ||
        response.key.id !== decodedKey.id
      )
        return yield* MemoryRpcError.make({ reason: "protocol" });
      if (response.document === null) return null;
      if (
        response.document.key.id !== decodedKey.id ||
        response.document.source.id !== decodedKey.id ||
        (response.document._tag === "ActiveMemoryDocument" &&
          !response.document.scopes.includes(bound.scope))
      )
        return yield* MemoryRpcError.make({ reason: "protocol" });

      yield* encodeMemoryWire(MemoryDocument.Wire, response.document, validated.maxSourceBytes);

      return yield* MemoryDocument.restore(access.namespace, response.document);
    }).pipe((effect) => withinDeadline(effect, validated.timeoutMillis));
  });

  const revalidateSemantic = Effect.fn("CloudflareMemoryClient.revalidateSemantic")(function* (
    found: MemoryIndexSearch<Namespace>,
    profile: SemanticMemoryProfile,
    limits: SemanticCandidateLimits,
  ) {
    return yield* Effect.gen(function* () {
      const response = yield* call({
        _tag: "RevalidateSemantic",
        version: 1,
        access: bound,
        principal,
        found,
        profile,
        limits,
        deadlineMillis: (yield* Clock.currentTimeMillis) + validated.timeoutMillis,
      });

      if (response._tag !== "Semantic") return yield* MemoryRpcError.make({ reason: "protocol" });

      return response.result;
    }).pipe((effect) => withinDeadline(effect, validated.timeoutMillis));
  });

  /**
   * Revalidate in one owner RPC, then render whole passages within the caller's budget.
   * The bound source is essential: unavailable/stale results and matches that cannot fit
   * fail instead of silently producing empty context. No-match remains successful.
   * The single outcome has sourceId "memory". No embedding or candidate search is performed.
   * Use revalidate with Memory.recall for multiple readers sharing one output budget.
   */
  const recall = Effect.fn("CloudflareMemoryClient.recall")(function* (
    lookup: MemoryLookup,
    limits: MemoryRecallLimits,
    estimateTokens?: (text: string) => number,
  ) {
    return yield* Memory.recall(
      [{ id: "memory", essential: true, read: revalidate(lookup, limits) }],
      limits,
      estimateTokens,
    );
  });

  return { get, recall, revalidate, revalidateSemantic, change };
});

export const CloudflareMemoryClient = {
  /** Bind access and principal using the MemoryObjectNamespace supplied by the application. */
  make: makeMemoryClient,
  /** Use a resolved Worker or Durable Object binding without manual service provisioning. */
  fromBinding: Effect.fn("CloudflareMemoryClient.fromBinding")(function* <
    Namespace extends MemoryNamespace.Any,
  >(
    binding: DurableObjectNamespace<MemoryObjectRpc>,
    options: {
      readonly access: MemoryAccess<Namespace>;
      readonly principal: Principal;
      readonly rpcLimits?: MemoryRpcLimits;
    },
  ) {
    return yield* makeMemoryClient(options.access, options.principal, options.rpcLimits).pipe(
      Effect.provideService(MemoryObjectNamespace, { namespace: binding }),
    );
  }),
};

/**
 * Optional activity-processor destination. Keeps domain write errors intact; transport,
 * authorization and deadline failures become the existing MemoryStorageError contract.
 * Receipts remain authoritative, including after caller interruption or lost replies.
 */
export const cloudflareMemoryWriterLayer = (
  access: MemoryAccess,
  principal: Principal,
  limits: MemoryRpcLimits = defaultMemoryRpcLimits,
) =>
  Layer.effect(
    MemoryWriter,
    Effect.gen(function* () {
      const client = yield* CloudflareMemoryClient.make(access, principal, limits);

      return MemoryWriter.fromAdapter({
        change: (write) =>
          client.change(write).pipe(
            Effect.catchTag("MemoryRpcError", (error) =>
              Effect.fail(
                MemoryStorageError.make({
                  operation: `memory RPC ${error.reason}`,
                  reason:
                    error.reason === "unavailable" || error.reason === "timeout"
                      ? "unavailable"
                      : "invalid-input",
                }),
              ),
            ),
            Effect.catchTag(["MemoryRecallError", "MemoryIndexError", "SemanticMemoryError"], () =>
              Effect.fail(
                MemoryStorageError.make({ operation: "memory RPC response", reason: "corrupt" }),
              ),
            ),
          ),
      });
    }),
  );

export type Services = MemoryReader | MemoryWriter | MemoryOwnerAuthorizer | MemoryOwnerIdentity;

/** Build once per native object incarnation; the host gates acquisition before storage I/O. */
export const makeRuntime = <E, R, FR = never>(
  host: Layer.Layer<MemoryOwnerAuthorizer, E, R>,
  options: {
    readonly storageLimits?: DoMemoryStorageLimits;
    readonly rpcLimits?: MemoryRpcLimits;
    readonly failpoints?: Layer.Layer<MemoryMutationFailpoint, never, FR>;
  } = {},
) => {
  const identity = Layer.effect(
    MemoryOwnerIdentity,
    Effect.gen(function* () {
      const state = yield* DurableObjectContext;

      const address = yield* Schema.decodeUnknownEffect(MemoryNamespaceAddress)(
        state.ctx.id.name,
      ).pipe(Effect.mapError(() => MemoryRpcError.make({ reason: "denied" })));

      return { namespace: MemoryNamespace.Any.make({ address }) };
    }),
  );

  const store = Layer.unwrap(
    Effect.map(DurableObjectContext, (state) =>
      doMemoryStoreLayerWithFailpoints(
        state.ctx.storage,
        options.storageLimits ?? defaultDoMemoryStorageLimits,
      ),
    ),
  ).pipe(Layer.provide(options.failpoints ?? MemoryMutationFailpoint.layer));

  const application = Layer.merge(store, host).pipe(Layer.provideMerge(identity));

  return application.pipe(
    Layer.provide(
      Layer.effectDiscard(
        Schema.decodeEffect(MemoryRpcLimits)(options.rpcLimits ?? defaultMemoryRpcLimits).pipe(
          Effect.mapError(() => MemoryRpcError.make({ reason: "protocol" })),
        ),
      ),
    ),
  );
};

export const rpc = (limits: MemoryRpcLimits = defaultMemoryRpcLimits) => ({
  memory: (encoded: string) => handleMemoryOwnerRequest(encoded, limits),
});
