import * as Prompt from "effect/ai/Prompt";
import * as Tool from "effect/ai/Tool";
import * as Schema from "effect/Schema";

import type * as Agent from "../../core/Agent.ts";

const outputFormatAnnotation = "@effect-agent/engine/Output/format";

/**
 * Declare ordinary assistant text as an Agent's final-output wire format. Apply this to the
 * complete output Schema after composing transformations. Its encoded type must be string;
 * decoding, checks, transformations, and service requirements remain owned by that Schema.
 * Text is preserved verbatim, including whitespace, quotes, and an empty reply when allowed.
 * Required completion Tools still take precedence. Unmarked Schemas use JSON final output.
 *
 * @example
 * ```ts
 * output: Output.text(Schema.String.check(Schema.isMaxLength(20_000)))
 * ```
 */
export const textOutput = <S extends Schema.Top & { readonly Encoded: string }>(
  schema: S,
): S["Rebuild"] => schema.annotate({ [outputFormatAnnotation]: "text" });

export const isTextOutput = (schema: Schema.Top): boolean =>
  Schema.resolveAnnotations(schema)?.[outputFormatAnnotation] === "text";

/**
 * Model-visible final-output contract (RUN-028).
 *
 * For ordinary text completion, the interpreter's only output-conformance
 * point is `decodeFinalOutput`, which validates the final text after the
 * model has already finished. This module renders that Schema's wire contract
 * with the same Effect AI derivation the providers use for Tool parameters
 * and states it as one framework-owned system message on every model request.
 * A required completion Tool instead gets a native-tool directive: its Tool
 * parameter Schema is already carried by the provider request, and ordinary
 * final text is not an allowed completion path.
 *
 * The contract is a per-request projection of the immutable definition —
 * exactly like the Tool schemas the request already carries. It is inserted
 * at model-request materialization (after context preparation) and never
 * into official history, so canonical records, run events, and the committed
 * DN/DC golden are unchanged.
 *
 */

/** Rendering outcome for one definition's output Schema. */
type OutputContract =
  | {
      readonly _tag: "rendered";
      /** The complete system-message text: directive plus the derived JSON Schema. */
      readonly message: string;
      readonly part: Prompt.SystemMessage;
    }
  | {
      readonly _tag: "unrenderable";
      /** Why Effect AI's JSON-Schema derivation rejected the output Schema. */
      readonly reason: string;
    };

const contractDirective = (definition: Agent.AnyDefinition): string =>
  definition.completion === undefined
    ? "Final output contract: when the task is complete, the final assistant message must be only " +
      "JSON that is valid against this JSON Schema — no prose, no Markdown code fences, nothing " +
      "before or after the JSON."
    : `Final output contract: when the task is complete without calling the "${definition.completion.tool}" completion Tool, the final assistant message must be only ` +
      "JSON that is valid against this JSON Schema — no prose, no Markdown code fences, nothing " +
      `before or after the JSON. When calling the "${definition.completion.tool}" completion Tool, never place this private Agent output JSON in any Tool argument; follow the Tool's parameter schema instead. Call it as the sole application Tool Call, after receiving any other needed application Tool results. Completed provider Tool results may accompany it. The engine projects the successful completion Tool result into the Agent output.`;

const requiredCompletionDirective = (tool: string, hasAlternatives: boolean): string =>
  `Final output contract: ${hasAlternatives ? "otherwise complete" : "complete only"} by calling the required completion Tool ${JSON.stringify(tool)} ` +
  "as the sole application Tool Call in its batch. Completed provider Tool results may accompany it. Do not emit an ordinary final assistant text answer. " +
  "The Tool's canonical parameters and successful result are projected and validated as the Agent output.";

/**
 * Render the model-visible final-output contract for one definition. The
 * derivation and message identity are stable for an immutable definition.
 * An output Schema the Effect AI derivation cannot represent is reported as
 * `unrenderable`; the caller falls back to the prior behavior — the contract
 * is guidance, and a Schema that decodes but does not render must not become
 * a new failure mode.
 */
const rendered = (message: string): OutputContract => ({
  _tag: "rendered",
  message,
  part: Prompt.makeMessage("system", { content: message }),
});

const renderOutputSchemaContract = (definition: Agent.AnyDefinition): OutputContract => {
  if (definition.completion?.required === true) {
    return rendered(
      requiredCompletionDirective(
        definition.completion.tool,
        (definition.completionFromTools?.length ?? 0) > 0,
      ),
    );
  }
  if (isTextOutput(definition.output)) {
    return rendered(
      "Final output contract: write the final reply as ordinary assistant text, without JSON wrapping. " +
        "An empty reply is valid only when allowed by the output Schema and the task instructions." +
        (definition.completion === undefined
          ? ""
          : ` When calling the "${definition.completion.tool}" completion Tool, follow its parameter schema instead and call it as the sole application Tool Call, after receiving any other needed application Tool results; completed provider Tool results may accompany it; the engine projects its successful result into the Agent output.`),
    );
  }
  try {
    const jsonSchema = Tool.getJsonSchemaFromSchema(definition.output);

    return rendered(
      `${contractDirective(definition)}\n\n${JSON.stringify(jsonSchema, undefined, 2)}`,
    );
  } catch (cause) {
    return {
      _tag: "unrenderable",
      reason: cause instanceof Error ? cause.message : String(cause),
    };
  }
};

// Native incremental-response tracking recognizes message objects, not rendered text.
// Weak keys retain neither discarded definitions nor their Schema graphs.
const outputContracts = new WeakMap<Agent.AnyDefinition, OutputContract>();

export const outputSchemaContract = (definition: Agent.AnyDefinition): OutputContract => {
  const cached = outputContracts.get(definition);

  if (cached !== undefined) return cached;
  const base = renderOutputSchemaContract(definition);
  const alternatives = definition.completionFromTools ?? [];

  const contract =
    base._tag === "rendered" && alternatives.length > 0
      ? rendered(
          `The following action Tools may complete the Run from their successful canonical result: ${alternatives.map((declaration) => JSON.stringify(declaration.tool)).join(", ")}. ` +
            "Call such a Tool as the sole application Tool Call, following its parameter schema. Completed provider Tool results may accompany it. It may complete the Run only when it satisfies the whole request. " +
            "An incomplete or pending result continues the Run. These actions are unavailable during finalization after budget exhaustion.\n\n" +
            base.message,
        )
      : base;

  outputContracts.set(definition, contract);

  return contract;
};

const sameSystemMessage = Schema.toEquivalence(Prompt.SystemMessage);

/**
 * Keep supported system instructions in conversation order so changing late guidance
 * cannot invalidate the preceding user/tool cache prefix. Omit an exact repeat
 * only when no distinct system instruction intervened; returning to an earlier
 * instruction after a different one must preserve the new directive's precedence.
 * Anchor the immutable output contract after the initial system block.
 * Restore leading static instructions for caller-supplied conversation-only history.
 *
 * This runs after preparation and compaction. Canonical messages, protected
 * instruction/input spans and compaction coverage retain their original positions.
 * Adapters without this capability retain the grouped-system projection: keep the
 * last equivalent instruction with its native options, then the contract and
 * conversation. This prevents older Anthropic adapters from discarding system groups.
 */
export const prepareModelPrompt = (
  prompt: Prompt.Prompt,
  contract: Prompt.SystemMessage | undefined,
  systemMessagesInHistory: boolean,
  staticInstructions: Prompt.RawInput | undefined,
): Prompt.Prompt => {
  if (systemMessagesInHistory) {
    const content: Array<Prompt.Message> = [];
    let lastSystem: Prompt.SystemMessage | undefined;
    let ordered = prompt.content;

    if (staticInstructions !== undefined) {
      const firstConversation = prompt.content.findIndex((message) => message.role !== "system");

      const leading = prompt.content.slice(
        0,
        firstConversation === -1 ? prompt.content.length : firstConversation,
      );

      const restored: Array<Prompt.Message> = [];

      const instructions =
        typeof staticInstructions === "string"
          ? [Prompt.systemMessage({ content: staticInstructions })]
          : Prompt.make(staticInstructions).content;

      for (const message of instructions) {
        if (message.role !== "system") break;
        if (
          leading.some(
            (candidate) => candidate.role === "system" && sameSystemMessage(candidate, message),
          )
        )
          break;

        const original = prompt.content.find(
          (candidate) => candidate.role === "system" && sameSystemMessage(candidate, message),
        );

        if (original === undefined) break;
        restored.push(original);
      }
      if (restored.length > 0)
        ordered = [...leading, ...restored, ...prompt.content.slice(leading.length)];
    }

    for (const message of ordered) {
      if (message.role === "system") {
        if (lastSystem !== undefined && sameSystemMessage(lastSystem, message)) continue;
        lastSystem = message;
      }
      content.push(message);
    }
    if (contract !== undefined) {
      const firstConversation = content.findIndex((message) => message.role !== "system");

      content.splice(firstConversation === -1 ? content.length : firstConversation, 0, contract);
    }

    return Prompt.fromMessages(content);
  }

  const systems: Array<Prompt.SystemMessage> = [];
  const conversation: Array<Prompt.Message> = [];
  const seen = new Map<string, Array<Prompt.SystemMessage>>();

  for (let index = prompt.content.length - 1; index >= 0; index -= 1) {
    const message = prompt.content[index];

    if (message === undefined) continue;
    if (message.role !== "system") {
      conversation.push(message);
      continue;
    }
    const variants = seen.get(message.content);

    if (variants?.some((previous) => sameSystemMessage(previous, message))) continue;
    if (variants === undefined) seen.set(message.content, [message]);
    else variants.push(message);
    systems.push(message);
  }

  return Prompt.fromMessages([
    ...systems.reverse(),
    ...(contract === undefined ? [] : [contract]),
    ...conversation.reverse(),
  ]);
};
