import type { Prompt } from "effect/ai";
import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import * as Schema from "effect/Schema";

import { ThreadId, type RunId } from "../core/Identifiers.ts";
import { type RunCompleted } from "../core/RunEvent.ts";
import {
  Store as ConversationStore,
  layerMemory,
  toPrompt,
  type ThreadError,
} from "../core/Thread.ts";

/** A history adapter rejected a read, staged value, or completed Run commit. */
export class ThreadHistoryError extends Schema.TaggedError<ThreadHistoryError>()(
  "ThreadHistoryError",
  {
    threadId: ThreadId,
    reason: Schema.Literals([
      "not-found",
      "conflict",
      "fenced",
      "incompatible",
      "limit",
      "encoding",
      "storage",
    ]),
    message: Schema.String,
    cause: Schema.optionalKey(Schema.Defect()),
  },
) {}

/**
 * One Run's history owner. Incremental adapters retain each stageHistory update; on-success
 * adapters stage privately until commit. Before commit, the interpreter
 * finishes run-owned work and closes resources acquired for that Run, then validates the result
 * for run/start.await. Shared model, provider, and client services supplied by an enclosing
 * application Layer remain owned by that application's Scope and may outlive multiple Runs.
 * Commit must succeed before RunCompleted becomes observable. Schema-encoded input is opaque
 * here; the adapter owns its persistence boundary. A failed commit may have reached storage;
 * callers must inspect history before retrying external execution.
 */
export interface ThreadHistoryRun {
  readonly prompt: Prompt.Prompt;
  readonly stageInput: (input: unknown) => Effect.Effect<void, ThreadHistoryError>;
  readonly stageHistory: (history: Prompt.Prompt) => Effect.Effect<void, ThreadHistoryError>;
  readonly commit: (completed: RunCompleted) => Effect.Effect<void, ThreadHistoryError>;
}

/**
 * History shared by Runs with the same Thread ID. The default layer retains native messages
 * incrementally in memory for its application Scope, including completed updates before a failure.
 * PersistentHistory.layer from @yielded/agent/persistent-history instead commits successful
 * Runs to an explicit ThreadStore. Durable hosts retain history through their journal hooks.
 * No implementation may retry model or Tool execution or claim interrupted-work recovery.
 */
export class ThreadHistory extends Context.Service<
  ThreadHistory,
  {
    readonly retention: "incremental" | "on-success";
    /** Present only for the in-memory adapter; identifies its exact Store ownership view. */
    readonly memoryStore?: ConversationStore["Service"];
    readonly open: (request: {
      readonly threadId: ThreadId;
      readonly runId: RunId;
    }) => Effect.Effect<ThreadHistoryRun, ThreadHistoryError>;
    readonly load: (threadId: ThreadId) => Effect.Effect<Prompt.Prompt, ThreadHistoryError>;
  }
>()("@effect-agent/engine/ThreadHistory") {
  /** Bind incremental history to the supplied Thread.Store, including scoped ownership views. */
  static readonly layerFromStore = Layer.effect(
    ThreadHistory,
    Effect.gen(function* () {
      const threads = yield* ConversationStore;

      const historyError = (cause: ThreadError): ThreadHistoryError =>
        ThreadHistoryError.make({
          threadId: cause.threadId,
          reason:
            cause._tag === "ThreadNotFound"
              ? "not-found"
              : cause._tag === "ThreadLimitExceeded"
                ? "limit"
                : cause._tag === "ThreadHistoryDiverged"
                  ? "conflict"
                  : cause._tag === "ThreadOwnershipError"
                    ? cause.reason === "closed"
                      ? "fenced"
                      : "conflict"
                    : "encoding",
          message:
            cause._tag === "ThreadNotFound"
              ? "Thread history is not present in this application Scope"
              : cause._tag === "ThreadLimitExceeded"
                ? `In-memory history exceeds the ${cause.limit} limit of ${cause.limitValue}`
                : cause.message,
          cause,
        });

      return ThreadHistory.of({
        retention: "incremental",
        memoryStore: threads,
        load: (threadId) =>
          threads.snapshot(threadId).pipe(Effect.map(toPrompt), Effect.mapError(historyError)),
        open: Effect.fn("ThreadHistory.open")(function* ({ threadId, runId }) {
          const snapshot = yield* threads.create(threadId).pipe(Effect.mapError(historyError));

          return {
            prompt: toPrompt(snapshot),
            stageInput: () => Effect.void,
            stageHistory: (history: Prompt.Prompt) =>
              threads
                .recordHistory(threadId, runId, history)
                .pipe(Effect.asVoid, Effect.mapError(historyError)),
            commit: () =>
              threads.snapshot(threadId).pipe(Effect.asVoid, Effect.mapError(historyError)),
          };
        }),
      });
    }),
  );

  /** Retain bounded history for the application Scope. Separate Layer builds own separate stores. */
  static readonly layer = ThreadHistory.layerFromStore.pipe(Layer.provideMerge(layerMemory));
}

/** Retain in-memory conversation history for the application Scope. */
export const layer = ThreadHistory.layer;
