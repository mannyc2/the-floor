import { Context, Effect } from "effect";

import * as FailureDiagnostic from "../core/FailureDiagnostic.ts";
import type { Receipt } from "./DurableAgentRuntime.ts";
import { type ScheduledInputFailure, ScheduleStorageError } from "./Schedule.ts";
import type { SubmissionStatus } from "./SubmissionStatus.ts";
import type { PreparedInput } from "./Subscription.ts";

/** Host admission shared by event deliveries and scheduling adapters. */
export class PreparedInputAdmission extends Context.Service<
  PreparedInputAdmission,
  {
    /** Required when retention is configured; reports canonical settlement without releasing group ownership itself. */
    readonly submissionStatus?: (
      receipt: Receipt,
    ) => Effect.Effect<SubmissionStatus, ScheduledInputFailure>;
    readonly submit: (envelope: PreparedInput) => Effect.Effect<Receipt, ScheduledInputFailure>;
  }
>()("@effect-agent/thread/PreparedInputAdmission") {}

/**
 * Reduce one bounded admission attempt. The caller owns concurrency, durable retry state,
 * and completion fencing. Interruption and defects propagate without claiming a refusal.
 */
export const admitPreparedInput = Effect.fn("Thread.admitPreparedInput")(
  <R>(submit: Effect.Effect<Receipt, ScheduledInputFailure, R>, timeoutMillis: number) =>
    submit.pipe(
      Effect.timeout(timeoutMillis),
      Effect.map((receipt) => ({ _tag: "Receipt" as const, receipt })),
      Effect.catchTag("ScheduledInputRefused", (error) =>
        Effect.succeed({ _tag: "Refused" as const, error }),
      ),
      Effect.catchTag("ScheduledInputRetryable", (error) =>
        Effect.succeed({
          _tag: "Retry" as const,
          reason: error.reason,
          diagnostic: FailureDiagnostic.capture(error),
        }),
      ),
      Effect.catchTag("TimeoutError", (error) =>
        Effect.succeed({
          _tag: "Retry" as const,
          reason: "timeout" as const,
          diagnostic: FailureDiagnostic.capture(error),
        }),
      ),
      Effect.catchTag("ScheduleStorageError", (error) =>
        error.reason === "unavailable"
          ? Effect.succeed({
              _tag: "Retry" as const,
              reason: "storage" as const,
              diagnostic: FailureDiagnostic.capture(error),
            })
          : Effect.fail(ScheduleStorageError.make(error)),
      ),
    ),
);
