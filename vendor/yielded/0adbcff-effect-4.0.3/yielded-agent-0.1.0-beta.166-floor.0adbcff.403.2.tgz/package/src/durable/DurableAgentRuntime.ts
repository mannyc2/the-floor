import type { Scope } from "effect";
import {
  Cause,
  Clock,
  Context,
  Crypto,
  DateTime,
  Deferred,
  Duration,
  Effect,
  Equal,
  Exit,
  Layer,
  Option,
  Ref,
  Result,
  Schedule,
  Schema,
  Semaphore,
  Stream,
} from "effect";
import { Prompt, type Tool } from "effect/ai";

import {
  type InputMessage,
  MessageAdmission,
  type MessagingError,
} from "../capabilities/Messaging.ts";
import type * as Agent from "../core/Agent.ts";
import { type RunDispositionDeclaration, type InputPromptSource } from "../core/Agent.ts";
import {
  AgentApprovalDenied,
  AgentApprovalPending,
  AgentInputError,
  AgentToolAuthorizationDenied,
  type AgentToolAuthorizationCheckError,
  PolicyLimit,
} from "../core/AgentError.ts";
import { AgentPolicy } from "../core/AgentPolicy.ts";
import { UpdateError } from "../core/AgentUpdates.ts";
import * as FailureDiagnostic from "../core/FailureDiagnostic.ts";
import {
  type ReceiptId,
  ThreadId,
  SubmissionId,
  ToolCallId,
  type AgentId,
  type AttemptId,
  type RunId,
  type TurnId,
} from "../core/Identifiers.ts";
import { IdGenerator } from "../core/IdGenerator.ts";
import { Receipt } from "../core/Receipt.ts";
import { type ExhaustedLimit, type RunEvent } from "../core/RunEvent.ts";
import { RunPolicyUsage } from "../core/RunPolicyUsage.ts";
import {
  SubagentBudgetReservation,
  SubagentReservationAmounts,
  SubagentGrant,
  DelegationDepth,
  getToolExecutionKind,
  SubagentParentLink,
} from "../core/SubagentContract.ts";
import { Selection, Snapshot } from "../core/ToolExposure.ts";
import type { ToolParameterRejection } from "../core/ToolResult.ts";
import {
  type ModelCallUsage,
  InputTokenUsage,
  ModelUsageGroup,
  RunUsageSummary,
  ChildRunUsage,
  RunUsageReport,
  emptyRunTotals,
  unknownRunTotals,
  runTotalsFromSummary,
  sumRunTotals,
  summarizeModelUsage,
  OutputTokenUsage,
} from "../core/Usage.ts";
import { FrameworkMessage } from "../core/Worker.ts";
import type { WorkerError } from "../core/Worker.ts";
import * as AgentRuntime from "../engine/AgentRuntime.ts";
import {
  AgentChildPending,
  renderInputPrompt,
  type AgentRuntimeRequirements,
  type AgentCompletionProjectionRequirements,
  type RuntimeBinding,
} from "../engine/AgentRuntime.ts";
import { ContextCompactor, CompactionError } from "../engine/ContextCompactor.ts";
import { ContextRolloverTool } from "../engine/ContextWindow.ts";
import { getToolExecutionClass } from "../engine/DurableStep.ts";
import { MessagingHost } from "../engine/MessagingHost.ts";
import {
  CurrentToolFailureObserver,
  AgentUpdateAcceptance,
  ModelUsageAccounting,
  RunContextPreparation,
  RunToolAuthorization,
  RunToolScheduling,
  RunContextPreparationPassthrough,
  type RunContextPreparationError,
  type ChildEstablishStatus,
  type RunApprovalHook,
  type RunContextHook,
  type RunCostEstimator,
  type RunDurabilityHook,
  type RunInputCommand,
  type RunInputHook,
  type RunOptions,
  type RunSubagentEstablishRequest,
  type RunSubagentHook,
  type RunSubagentJoinRequest,
  type RunToolAuthorizationHook,
  type RunToolAuthorizationRequest,
} from "../engine/RunOptions.ts";
import { SubagentHost } from "../engine/SubagentHost.ts";
import { ThreadHistory } from "../engine/ThreadHistory.ts";
import { RunToolVisibility } from "../engine/ToolExposure.ts";
import {
  type RetryCommand,
  ExplainedEvidence,
  ExplainedSubmission,
  ExplainedUnknownCall,
  IntegrityCheck,
  IntegrityReport,
  ObligationEntry,
  ObligationReport,
  RecoveryExplanation,
  RetryRefused,
  obligationSeverityOf,
  predictRecoveryDisposition,
  recoveryDecisionMeaning,
  type ObligationBlockedOn,
  type ObligationThresholds,
} from "./Admin.ts";
import { digestJson, type DigestError } from "./Digest.ts";
import {
  DurableRuntimeFailpoint,
  type DurableRuntimeFailpointError,
  type DurableRuntimeFailpointLocation,
} from "./DurableFailpoint.ts";
import {
  BindingUnavailable,
  compileRegistrations,
  definitionDigestsEqual,
  toolReplayContracts,
  type AgentRegistration,
  type DurableBindingFailure,
  makeLegacyWorkerBinding,
  type ResolvedBinding,
  resolveDefinitionBinding,
  resolveWorkerBinding,
  CurrentBindingSelection,
} from "./internal/agent-registration.ts";
import { makeAgentUpdateRuntime } from "./internal/agent-updates.ts";
import { inspectForeignDiagnostic, safeUnknownString } from "./internal/foreign-diagnostic.ts";
import {
  JournalCheckpointSeed,
  RecoveryCheckpointState,
  RecoveryCheckpointContents,
  ThreadContextCheckpoint,
  RECOVERY_ENGINE_VERSION,
  checkpointSuffixCompatible,
  makeThreadContextCertificate,
} from "./internal/journal-checkpoint.ts";
import { makeJournalMetadata, type JournalMetadata } from "./internal/journal-metadata.ts";
import { makeMessagingRuntime } from "./internal/messaging-host.ts";
import * as ThreadInitialization from "./internal/thread-initialization.ts";
import { makeWorkerRuntime, WorkerInputControl } from "./internal/worker-host.ts";
import { WorkerRuntime } from "./internal/worker-runtime.ts";
import { MessageDeliveryStore } from "./MessageDelivery.ts";
import {
  OperationAuthorizationRequest,
  OperationAuthorizer,
  OperationDenied,
} from "./OperationAuthorizer.ts";
import {
  type CanonicalRecordEnvelope,
  type CanonicalRecordPayload,
  type DeploymentId,
  type Digest,
  type ProducerId,
  AbortRequested,
  BatchId,
  CanonicalBatch,
  CanonicalSequence,
  CompactionCreated,
  DefinitionDigests,
  ModelResponseInterrupted,
  ModelCallAborted,
  PersistedJson,
  ProducerEpoch,
  RecordEnvelope,
  RecordId,
  RepairAnnotated,
  RunStartedRecord,
  RunDurationExhausted,
  SettlementFailureDiagnostic,
  SubagentJoined,
  SubagentLineageRecorded,
  SubtreeBudgetReserved,
  SubagentRequested,
  SubagentStarted,
  SubmissionSettled,
  SubmissionSettledRecord,
  ToolApprovalDecided,
  ToolApprovalRequested,
  ToolCallPrepared,
  ToolOperation,
  ToolUnavailable,
  RunPolicyUsageReserved,
  ToolCallResolved,
  ToolCallSettled,
  ToolCallUnknown,
  ToolStepSettled,
  UserInputRecorded,
  WorkerAdmission,
  type ApprovalDecision,
  type SettlementOutcome,
  type ToolCallResolution,
} from "./Records.ts";
import {
  classifyRecovery,
  DeclaredPendingBatchEvidence,
  OpenDelegationCallEvidence,
  OpenToolCallEvidence,
  PendingApprovalEvidence,
  RecoveryDecision,
  RecoveryEvidence,
  type DelegationAdmissionEvidence,
  type MarkUnknown as MarkUnknownDecision,
  type SettleAborted as SettleAbortedDecision,
} from "./Recovery.ts";
import {
  RunJournalError,
  approvalDecisionBatchId,
  childThreadIdFor,
  childIdempotencyKeyFor,
  compactionBatchId,
  compactionRecordId,
  markUnknownBatchId,
  modelResponseInterruptedBatchId,
  modelResponseInterruptedRecordId,
  modelResponseRecordId,
  projectRunJournalStream,
  type JournalBoundary,
  type RunJournalProjection,
  runCompletedRecordId,
  runCompletionDigest,
  runIdForSubmission,
  runStartedBatchId,
  runStartedRecordId,
  runDurationRecordId,
  runDurationBatchId,
  subagentJoinBatchId,
  subagentJoinedRecordId,
  subagentLineageBatchId,
  subagentLineageRecordId,
  subagentRequestedBatchId,
  subagentRequestedRecordId,
  subagentStartedBatchId,
  subagentStartedRecordId,
  toolApprovalDecisionRecordId,
  toolApprovalRequestRecordId,
  toolCallPreparedRecordId,
  toolCallResolutionBatchId,
  toolCallResolvedRecordId,
  toolCallResultBatchId,
  toolCallSettledRecordId,
  toolCallUnknownRecordId,
  toolStepSettledBatchId,
  toolStepSettledRecordId,
  turnApprovalsBatchId,
  turnCanonicalBatch,
  turnIdForRun,
  turnPreparedBatchId,
  turnResponseBatch,
  turnResultsBatch,
} from "./RunJournal.ts";
import {
  type AdmissionFence,
  AdmissionPolicyError,
  type AbortIntent,
  AbortIntentRequest,
  type AdmissionConflict,
  type Claim,
  type JoinedToHost,
  type OwnershipLost,
  type RecoverySnapshot,
  type SettlementConflict,
  type SubmissionSnapshot,
  AbortCommand,
  AdmissionRequest,
  ApprovalDecisionCommand,
  ApprovalPendingSuspension,
  AttachChildToReservationRequest,
  BeginChildBudgetReleaseRequest,
  ChildBudgetReservationRequest,
  ChildReservationId,
  ChildSettledNotification,
  ClaimHandoff,
  SubmissionScheduling,
  ClaimJoiningRequest,
  type JoiningClaim,
  ClaimRequest,
  IdempotencyKey,
  LedgerError,
  MarkInputAppliedRequest,
  MarkJoinedRequest,
  MarkReadyRequest,
  MarkUnknownRequest,
  OwnershipToken,
  ParentLinkage,
  Principal,
  RecoverySnapshotRequest,
  ReleaseChildBudgetRequest,
  ReleaseOwnershipRequest,
  RenewOwnershipRequest,
  RevertJoiningRequest,
  SettlementFinalization,
  SettlementReservation,
  Settlement,
  SubmissionLedger,
  SubmissionLookupById,
  SubmissionLookupByKey,
  SuspendRequest,
  UnknownResolutionCommand,
  WaitingChild,
  WaitingForChildSuspension,
  submissionAbortBatchId,
  submissionAbortRecordId,
  submissionInputBatchId,
  submissionInputRecordId,
  submissionSettlementBatchId,
  submissionSettlementId,
  submissionSettlementRecordId,
  type AdmissionResult,
  type ApprovalConflict,
  type ApprovalDecisionIntent,
  type ChildBudgetReservationSnapshot,
  type JoinSnapshot,
  type UnknownResolutionConflict,
  type UnknownResolutionIntent,
} from "./SubmissionLedger.ts";
import { PendingSubmission, SettledSubmission, type SubmissionStatus } from "./SubmissionStatus.ts";
import { verifyThreadInvariants } from "./ThreadInvariants.ts";
import {
  type AppendConflict,
  type ThreadNotMaterialized,
  type FenceRejected,
  ThreadExportRequest,
  ThreadMaterialization,
  ThreadObservation,
  ThreadRead,
  ThreadStore,
  ThreadStoreDiagnostic,
  ThreadStoreError,
  ThreadTailRequest,
  FencedAppendRequest,
  LoadCheckpointRequest,
  ThreadCheckpoint,
  SaveRecoveryCheckpointRequest,
  getRecord,
  getRunInput,
} from "./ThreadStore.ts";
import { PreparedToolCallEvidence, ToolReconciler } from "./ToolReconciler.ts";
import { WakeScheduler } from "./WakeScheduler.ts";
import { WorkerAdmissionPort, WorkerAdmissionRequest } from "./WorkerAdmission.ts";

// Capture the tracing call site once; each application still creates a fresh Attempt span.
const withThreadHeadSpan = Effect.withSpan("DurableAgentRuntime.processThreadHead");

/**
 * Instruction failure/requirement derivation mirroring the engine's `RuntimeBinding` defaults:
 * declaring them as generic DEFAULTS (instead of independent inference sites) keeps a plain
 * string-returning instruction function from widening both parameters to `unknown`.
 */
type InstructionResultOf<Instructions, Input> = Instructions extends (input: Input) => infer Result
  ? Result
  : Instructions;

type InstructionErrorOf<Instructions, Input> =
  InstructionResultOf<Instructions, Input> extends Effect.Effect<
    infer _Success,
    infer Error,
    infer _Requirements
  >
    ? Error
    : never;

type InstructionRequirementsOf<Instructions, Input> =
  InstructionResultOf<Instructions, Input> extends Effect.Effect<
    infer _Success,
    infer _Error,
    infer Requirements
  >
    ? Requirements
    : never;

const decodeBatchId = Schema.decodeSync(BatchId);
const decodeCanonicalSequence = Schema.decodeSync(CanonicalSequence);
const decodeRecordId = Schema.decodeSync(RecordId);
const decodeToolCallIdUnknown = Schema.decodeUnknownEffect(ToolCallId);
const ZERO_EPOCH = Schema.decodeSync(ProducerEpoch)(0);
const ZERO_SEQUENCE = decodeCanonicalSequence(0);
const READ_PAGE = 1_024;
/** Stale-tail append retries per batch before the conflict propagates (see `appendBatch`). */
const MAX_APPEND_FENCE_REFRESHES = 8;
const MAX_FAILURE_MESSAGE_LENGTH = 16_384;
const RECONCILER_AUTHOR = "reconciler";
/** Canonical `ToolApprovalDecided.resolver` for policy-auto decisions made by the delegate. */
const APPROVAL_POLICY_RESOLVER = "approval-policy";
/** Ledger `ApprovalDecisionIntent.resolver` for the abort-driven suspension closure. */
const RECOVERY_RESOLVER = "recovery";
/** Upper bound of one `drain("all")` joining pass (`claimJoining.maxCount` must be positive). */
const MAX_JOIN_DRAIN = 32;
/**
 * Token presented when reserving a joined Submission's settlement (plan §2.5). A `joined` lane is
 * never worker-claimable (WP2 claim rule), so no real ownership token can exist for it: the
 * ledger authorizes the reservation by the recorded host linkage and does not consult this value.
 */
const JOINED_SETTLEMENT_TOKEN = Schema.decodeSync(OwnershipToken)("ownership-joined-settlement");

/**
 * Placeholder token for the P7 §7(c) queued-abort settlement: an aborted, never-claimed,
 * still-queued `ready` Submission has no live ownership to fence against, so the ledger
 * authorizes its aborted reservation by the durable abort intent itself (the joined-settlement
 * pattern) and the presented token is not consulted.
 */
const QUEUED_ABORT_SETTLEMENT_TOKEN = Schema.decodeSync(OwnershipToken)(
  "ownership-aborted-queued-settlement",
);

/** Bound a hook-supplied approval reason to the canonical `BoundedText` persistence limits. */
const boundedApprovalReason = (reason: string | undefined, fallback: string): string => {
  const value = reason === undefined || reason.length === 0 ? fallback : reason;

  return value.length > MAX_FAILURE_MESSAGE_LENGTH
    ? value.slice(0, MAX_FAILURE_MESSAGE_LENGTH)
    : value;
};

const boundedText = (value: string): string =>
  value.length > MAX_FAILURE_MESSAGE_LENGTH ? value.slice(0, MAX_FAILURE_MESSAGE_LENGTH) : value;

const decodePrincipalSync = Schema.decodeSync(Principal);
const decodeIdempotencyKeySync = Schema.decodeSync(IdempotencyKey);
const decodeChildReservationIdSync = Schema.decodeSync(ChildReservationId);
const decodeRecordIdSync = Schema.decodeSync(RecordId);
const decodeBatchIdSync = Schema.decodeSync(BatchId);
const decodeDefinitionDigests = Schema.decodeUnknownEffect(DefinitionDigests);

/**
 * Deterministic parent-owned child budget reservation identity (spec
 * §12 step 2, D4): one reservation per (parent Run, parent Tool Call) pair,
 * so a replayed establishment converges on the one existing row (SUB-016).
 */
export const childReservationIdFor = (runId: RunId, toolCallId: ToolCallId): ChildReservationId =>
  decodeChildReservationIdSync(`subagent-reservation:${runId}:${toolCallId}`);

/**
 * S2 fixes every attached durable child at delegation depth 1 (SUB-029
 * rejects all nested delegation at preflight), so recovery can rebuild the
 * child lineage from the canonical `SubagentRequested` record alone — the
 * record deliberately does not carry a depth field.
 */
const CHILD_DELEGATION_DEPTH: DelegationDepth = Schema.decodeSync(DelegationDepth)(1);

/** Canonical `AbortRequested.author` of every propagated parent-abort command (spec §13.1). */
const SUBAGENT_ABORT_AUTHOR = "subagent-parent-abort";

/** Keep this exact reason, including its historical citation: abort repair replays the same command. */
const SUBAGENT_ABORT_REASON =
  "The parent Submission was aborted; request-abort-and-join propagates the durable abort intent to every attached child (spec/subagents.md 13.1)";

/**
 * The deterministic zero-consumed accounting decision frozen for a
 * provably-childless orphaned reservation (spec §13/§14: "releases the
 * reservation exactly once"). Constant so every repair pass freezes the SAME
 * decision — an identical `beginChildBudgetRelease` replay is a no-op.
 */
const ORPHAN_ZERO_CONSUMED_ACCOUNTING = Schema.decodeSync(PersistedJson)({
  basis: "orphan-zero-consumed",
});

/** The four parent-log/child-log subagent records of one Run, indexed per Tool Call. */
interface SubagentCallRecords {
  readonly requested: Map<ToolCallId, SubagentRequested>;
  readonly started: Map<ToolCallId, SubagentStarted>;
  readonly joined: Map<ToolCallId, SubagentJoined>;
  /** Declared Tool name per prepared call (delegation joins reuse it for `ToolCallSettled`). */
  readonly preparedNames: Map<ToolCallId, string>;
}

/** Pure fold of one Run's canonical subagent lifecycle records (plan §1.2). */
const subagentRecordsOf = (
  records: ReadonlyArray<CanonicalRecordEnvelope>,
  runId: RunId,
): SubagentCallRecords => {
  const requested = new Map<ToolCallId, SubagentRequested>();
  const started = new Map<ToolCallId, SubagentStarted>();
  const joined = new Map<ToolCallId, SubagentJoined>();
  const preparedNames = new Map<ToolCallId, string>();

  for (const envelope of records) {
    const payload = envelope.record.payload;

    switch (payload._tag) {
      case "SubagentRequested": {
        if (payload.runId === runId) requested.set(payload.toolCallId, payload);
        break;
      }
      case "SubagentStarted": {
        if (payload.runId === runId) started.set(payload.toolCallId, payload);
        break;
      }
      case "SubagentJoined": {
        if (payload.runId === runId) joined.set(payload.toolCallId, payload);
        break;
      }
      case "ToolCallPrepared": {
        if (payload.runId === runId) preparedNames.set(payload.toolCallId, payload.toolName);
        break;
      }
      default: {
        break;
      }
    }
  }

  return { requested, started, joined, preparedNames };
};

/** Joined reports are canonical snapshots, keyed by child Run so replay cannot double charge. */
const childUsageReportsOf = (state: SubagentCallRecords): ReadonlyArray<ChildRunUsage> =>
  [...state.started.entries()].map(([toolCallId, child]) => {
    const joined = state.joined.get(toolCallId);

    return ChildRunUsage.make({
      runId: child.childRunId,
      report: RunUsageReport.make({
        usage: joined?.usage ?? unknownRunTotals(),
        delegatedUsage: joined?.delegatedUsage ?? unknownRunTotals(),
      }),
    });
  });

export { threadCreatedBatchId, threadCreatedRecordId } from "./internal/thread-initialization.ts";

/** Deterministic batch identity of one executed recovery decision's audit append (DUR-013). */
export const recoveryRepairBatchId = (submissionId: SubmissionId, decisionTag: string): BatchId =>
  decodeBatchId(`repair:${submissionId}:${decisionTag}`);

/** Deterministic record identity of one executed recovery decision's `RepairAnnotated` record. */
export const recoveryRepairRecordId = (submissionId: SubmissionId, decisionTag: string): RecordId =>
  decodeRecordId(`repair:${submissionId}:${decisionTag}`);

/**
 * The durable identity returned once ledger admission, Thread materialization, and
 * readiness are committed (DUR-001). It is an identifier for observation and reattachment, not
 * an authorization capability.
 */
export { Receipt } from "../core/Receipt.ts";

// Foreign names and tags may contain payloads. Retain only these static classifications.
const RecoveryCauseTag = Schema.Literals([
  "AdmissionPolicyError",
  "DigestError",
  "LedgerError",
  "OwnershipLost",
  "SettlementConflict",
  "ThreadStoreError",
  "ThreadNotMaterialized",
  "AppendConflict",
  "FenceRejected",
  "RunJournalError",
  "DurableRuntimeFailpointError",
  "SchemaError",
  "Error",
  "TypeError",
  "RangeError",
  "ReferenceError",
  "SyntaxError",
  "URIError",
  "EvalError",
  "AggregateError",
  "ForeignError",
  "NonErrorCause",
]);

const isRecoveryCauseTag = Schema.is(RecoveryCauseTag);

/** Recovery could not establish execution authority. This is never a Settlement or replay grant. */
export class RecoveryFailure extends Schema.Class<RecoveryFailure>(
  "@effect-agent/thread/RecoveryFailure",
)({
  phase: Schema.Literals(["history", "recovery"]),
  reason: Schema.Literals(["failure", "defect", "timeout"]),
  errorTag: Schema.String.check(Schema.isMaxLength(128)),
  /** Static operation names only; error messages and payloads are deliberately excluded. */
  operation: Schema.String.check(Schema.isMaxLength(256)),
  /** Ordered, bounded classifications. Foreign labels, operations and prose stay private. */
  causes: Schema.Array(
    Schema.Struct({
      errorTag: RecoveryCauseTag,
    }),
  ).check(Schema.isMaxLength(16)),
  causesTruncated: Schema.optionalKey(Schema.Literal(true)),
  diagnostic: Schema.optionalKey(ThreadStoreDiagnostic),
}) {}

const decodeRecoveryCause = Schema.decodeUnknownOption(
  Schema.Struct({
    diagnostic: Schema.optionalKey(Schema.Unknown),
    cause: Schema.optionalKey(Schema.Unknown),
  }),
);

/** Reuse the bounded foreign-error capture, then retain only content-free causal metadata. */
const recoveryFailureDetails = (cause: Cause.Cause<DurableWorkerFailure>) => {
  const pending = [FailureDiagnostic.capture(cause)];
  const causes: Array<RecoveryFailure["causes"][number]> = [];
  let truncated = false;

  while (pending.length > 0 && causes.length < 16) {
    const node = pending.shift();

    if (node === undefined) break;
    switch (node._tag) {
      case "Cause":
        pending.unshift(
          ...node.reasons.flatMap((reason) =>
            reason._tag === "Fail" ? [reason.error] : reason._tag === "Die" ? [reason.defect] : [],
          ),
        );
        truncated ||= node.truncated === true;
        break;
      case "Error": {
        const tag = node.errorTag ?? node.name;

        causes.push({
          errorTag: isRecoveryCauseTag(tag) ? tag : "ForeignError",
        });
        pending.unshift(
          ...(node.cause === undefined ? [] : [node.cause]),
          ...(node.reason === undefined ? [] : [node.reason]),
          ...(node.errors ?? []),
        );
        truncated ||= node.truncated === true;
        break;
      }
      case "Omitted":
        truncated = true;
        break;
      case "Value":
        causes.push({ errorTag: "NonErrorCause" });
        break;
    }
  }

  // Retain only adapter-created diagnostics, never reify a foreign structural lookalike.
  // Foreign wrappers retain only approved classifications above, never their operation text.
  let nested: unknown = Option.getOrUndefined(Cause.findErrorOption(cause));
  let diagnostic: ThreadStoreDiagnostic | undefined;

  for (let depth = 0; depth < 16 && nested !== undefined; depth++) {
    const decoded = decodeRecoveryCause(nested);

    if (Option.isNone(decoded)) break;
    if (decoded.value.diagnostic instanceof ThreadStoreDiagnostic) {
      diagnostic = decoded.value.diagnostic;
      break;
    }
    nested = decoded.value.cause;
  }

  return {
    causes,
    ...(truncated || pending.length > 0 ? { causesTruncated: true as const } : {}),
    ...(diagnostic === undefined ? {} : { diagnostic }),
  };
};

/** @internal One bounded failure boundary for execution history and host recovery control reads. */
export const isolateRecovery = Effect.fnUntraced(function* <A, E extends DurableWorkerFailure, R>(
  body: Effect.Effect<A, E, R>,
  options: {
    readonly timeout: Duration.Duration;
    readonly phase: () => RecoveryFailure["phase"];
    readonly operation?: string;
  },
): Effect.fn.Return<Result.Result<A, RecoveryFailure>, E, Exclude<R, Scope.Scope>> {
  const outcome = yield* body.pipe(
    Effect.scoped,
    Effect.timeoutOption(options.timeout),
    Effect.exit,
  );

  if (Exit.isSuccess(outcome) && Option.isSome(outcome.value))
    return Result.succeed(outcome.value.value);
  if (
    Exit.isFailure(outcome) &&
    (Cause.hasInterrupts(outcome.cause) ||
      outcome.cause.reasons.some(
        (reason) => reason._tag === "Fail" && reason.error._tag === "DurableRuntimeFailpointError",
      ))
  )
    return yield* Effect.failCause(outcome.cause);

  const error = Exit.isFailure(outcome) ? Cause.findErrorOption(outcome.cause) : Option.none<E>();
  const phase = options.phase();

  return Result.fail(
    RecoveryFailure.make({
      phase,
      reason: Exit.isSuccess(outcome)
        ? "timeout"
        : Cause.hasDies(outcome.cause)
          ? "defect"
          : "failure",
      errorTag: Option.isSome(error)
        ? error.value._tag
        : Exit.isSuccess(outcome)
          ? "RecoveryTimeout"
          : "Defect",
      operation:
        Option.isSome(error) && "operation" in error.value
          ? error.value.operation.slice(0, 256)
          : (options.operation ??
            (phase === "history" ? "read recovery history" : "recover submission")),
      ...(Exit.isFailure(outcome) ? recoveryFailureDetails(outcome.cause) : { causes: [] }),
    }),
  );
});

/** One failed Thread remains pending; the host must not claim it before recovery succeeds. */
export class RecoveryBlocked extends Schema.TaggedError<RecoveryBlocked>()("RecoveryBlocked", {
  threadId: ThreadId,
  failure: RecoveryFailure,
}) {}

/** One executed (or deliberately deferred) recovery decision (durability §14, DUR-013). */
export class RecoveryReport extends Schema.Class<RecoveryReport>(
  "@effect-agent/thread/RecoveryReport",
)({
  submissionId: SubmissionId,
  threadId: ThreadId,
  decision: RecoveryDecision,
  /**
   * `repaired` = executed; `deferred` = a claiming worker must finish it; `none` = settled;
   * `unknown` = this Submission is parked on an Unknown Outcome awaiting the authorized
   * DUR-017 resolution path — the settlement obligation stays visible while no worker permit
   * is consumed (durability §16).
   */
  disposition: Schema.Literals(["repaired", "deferred", "none", "unknown"]),
}) {}

/** Submission decisions and operational faults have different ownership and settlement semantics. */
export class RecoverySweepResult extends Schema.Class<RecoverySweepResult>("RecoverySweepResult")({
  reports: Schema.Array(RecoveryReport),
  /** Exactly one fault per failed Thread, regardless of its queued Submission count. */
  blocked: Schema.Array(RecoveryBlocked),
}) {}

/** Select one Thread before reading history, or omit to recover every pending Thread. */
export interface RecoverySweepOptions {
  readonly threadId?: ThreadId;
}

/** Per-submission options accepted by `DurableAgentRuntime.submit` (D2). */
export interface DurableSubmitOptions {
  readonly threadId: ThreadId;
  readonly principal: Principal;
  readonly idempotencyKey: IdempotencyKey;
  readonly admissionGroup?: string;
  readonly admissionFence?: AdmissionFence;
  /** Host-prepared worker input; immutable origin and per-input projection parameters. */
  readonly workerAdmission?: WorkerAdmission;
  /** Peer provenance or a worker completion, verified against frozen canonical delivery proof. */
  readonly messageAdmission?: InputMessage;
  /** Application-computed digests of the Agent/Model/Toolkit definitions (see `digestDefinitions`). */
  readonly definitions: DefinitionDigests;
}

export interface DurableObserveOptions {
  /** Resume the observation after an adapter-owned offset previously returned by `observe`. */
  readonly after?: CanonicalRecordEnvelope["offset"] | undefined;
}

/** The structural slice of an Agent Binding that `submit` needs. */
export interface DurableSubmitAgent<InputSchema extends Schema.Top> {
  readonly definition: {
    readonly id: AgentId;
    readonly input: InputSchema;
  };
}

export type DurableSubmitFailure =
  | AgentInputError
  | DigestError
  | AdmissionConflict
  | AdmissionPolicyError
  | LedgerError
  | ThreadStoreError
  | ThreadNotMaterialized
  | AppendConflict
  | FenceRejected
  | DurableRuntimeFailpointError;

/** Attempt resources could not be retained before deliberate approval suspension. */
export class ApprovalSuspensionError extends Schema.TaggedError<ApprovalSuspensionError>()(
  "ApprovalSuspensionError",
  { cause: Schema.Defect() },
) {}

export type DurableWorkerFailure =
  | AdmissionPolicyError
  | ApprovalSuspensionError
  | DigestError
  | LedgerError
  | OwnershipLost
  | SettlementConflict
  | ThreadStoreError
  | ThreadNotMaterialized
  | AppendConflict
  | FenceRejected
  | RunJournalError
  | DurableRuntimeFailpointError;

export type DurableAwaitFailure = LedgerError | SettlementConflict | OperationDenied;

/** Typed failures from the public canonical progress boundary. */
export type DurableProgressFailure = ThreadStoreError | ThreadNotMaterialized | OperationDenied;

export type DurableAbortFailure =
  | OperationDenied
  | LedgerError
  | SettlementConflict
  | JoinedToHost
  | DurableRuntimeFailpointError;

/**
 * Failure family of `resolveUnknown` (DUR-017, abort-shaped): the durable intent may conflict
 * with a divergent prior resolution, the Submission may already be settled, an `AbortSubmission`
 * resolution routes through the abort path (whose `JoinedToHost` conflict stays visible), and the
 * failpoint after the intent write is armable like every other durable mutation.
 */
export type DurableResolveFailure =
  | LedgerError
  | SettlementConflict
  | UnknownResolutionConflict
  | JoinedToHost
  | DurableRuntimeFailpointError;

/**
 * Failure family of `resolveApproval` (plan §2.6, abort-shaped): the durable intent may conflict
 * with a divergent prior decision, and the Submission may already be settled. The ledger adapter
 * owns the crash boundaries of the intent write (`ledger:approval-decision:{before,after}`).
 */
export type DurableApprovalFailure = LedgerError | SettlementConflict | ApprovalConflict;

/**
 * Failure family of the read-only `explain`/`explainThread` operations (P7 WP1): pure
 * observation over the two ports plus the evidence assembler's typed failures, and the
 * fail-closed `OperationDenied` when a host-supplied authorizer refuses.
 */
export type DurableExplainFailure =
  | LedgerError
  | ThreadStoreError
  | RunJournalError
  | OperationDenied;

/**
 * Failure family of the read-only `verify` operation (P7 WP1). `ThreadNotMaterialized`
 * stays visible: verifying a Thread that does not exist is a caller error, not an empty
 * report.
 */
export type DurableVerifyFailure =
  | LedgerError
  | ThreadStoreError
  | ThreadNotMaterialized
  | OperationDenied;

/**
 * Failure family of `retry` (P7 WP1): the scoped recovery execution carries the worker failure
 * family, refusals are typed (`RetryRefused` — settled work and lanes owned by the
 * resolveUnknown/resolveApproval paths), and denial is fail-closed.
 */
export type DurableRetryFailure = DurableWorkerFailure | RetryRefused | OperationDenied;

/** Failure family of `scanObligations` (P7 WP1): ledger scan + canonical unknown-age reads. */
export type DurableObligationFailure = LedgerError | ThreadStoreError | OperationDenied;

/**
 * Optional policy-auto approval delegate consulted by the durable approval hook (plan §2.6 step
 * 2) AFTER the recorded-decision lookup misses. An immediate `approved`/`denied` answer becomes
 * canonical (`ToolApprovalRequested` + `ToolApprovalDecided`, one atomic batch) before it is
 * honored; `unresolved` falls through to the durable suspension path. The default (`undefined`)
 * suspends every undecided approval durably until `resolveApproval` decides it — the fail-closed
 * posture. Adapt the P2 `ApprovalResolver` capability stack through
 * `@effect-agent/capabilities`' `toDurableRunApprovalHook`.
 */
export const DurableApprovalResolver: Context.Reference<RunApprovalHook<never, never> | undefined> =
  Context.Reference<RunApprovalHook<never, never> | undefined>(
    "@effect-agent/thread/DurableApprovalResolver",
    { defaultValue: () => undefined },
  );

/**
 * Optional attempt-local retention before an unresolved approval releases ownership. Supply
 * this from the Attempt's Layer, capturing its live resources. The canonical approval request
 * already exists; claim renewal and abort observation remain active while this operation runs.
 * Return only after retention is confirmed. Failure leaves the accepted work owed and preserves
 * its cause; interruption keeps normal resource cleanup. No approval-gated Tool runs here.
 *
 * A decision racing with successful retention resumes the pending batch in a fresh Attempt,
 * after the old services and claim finalize. The default leaves existing suspension unchanged.
 */
export const DurableApprovalSuspension: Context.Reference<
  Effect.Effect<void, ApprovalSuspensionError> | undefined
> = Context.Reference<Effect.Effect<void, ApprovalSuspensionError> | undefined>(
  "@effect-agent/thread/DurableApprovalSuspension",
  { defaultValue: () => undefined },
);

/**
 * Services a durable worker needs beyond the runtime's own Layer: the Agent Binding's inferred
 * requirements minus its supplied identity and history services. The coordinator provides
 * deterministic Run/Turn identity and journal-owned history because its coordinator owns all
 * durable reads and commits across Attempts.
 */
export type DurableWorkerRequirements<
  AgentValue extends Agent.Any,
  InstructionRequirements = never,
> =
  | Exclude<
      AgentRuntimeRequirements<AgentValue, never, InstructionRequirements>,
      ThreadHistory | RunContextPreparation
    >
  | AgentCompletionProjectionRequirements<AgentValue>;

export interface DurableRuntimeConfigOptions {
  /**
   * Deployment identity and the conservative operation version for direct execution without
   * a registered binding. Reuse asserts unchanged handler, Step, and idempotency semantics.
   */
  readonly deploymentId: DeploymentId;
  readonly producerId: ProducerId;
  /** `awaitSettlement` ledger re-check cadence when no wake arrives (default 500ms). */
  readonly settlementPollInterval?: Duration.Duration | undefined;
  /** Worker ownership-lease renewal cadence (default 10s; D5 lease default is 30s). */
  readonly leaseRenewalInterval?: Duration.Duration | undefined;
  /** Active-Run abort-intent poll cadence (default 500ms). */
  readonly abortPollInterval?: Duration.Duration | undefined;
  /** Cooperative bound for one Thread's recovery, including child reads (default 30s). */
  readonly recoveryTimeout?: Duration.Duration | undefined;
  /** Deployment-owned model pricing authority, captured for every recoverable Run. */
  readonly estimateCostMicrousd?: RunCostEstimator | undefined;
}

/** Deployment-scoped identity and liveness cadences for the durable coordinator. */
export class DurableRuntimeConfig extends Context.Service<
  DurableRuntimeConfig,
  {
    readonly deploymentId: DeploymentId;
    readonly producerId: ProducerId;
    readonly settlementPollInterval: Duration.Duration;
    readonly leaseRenewalInterval: Duration.Duration;
    readonly abortPollInterval: Duration.Duration;
    readonly recoveryTimeout: Duration.Duration;
    readonly estimateCostMicrousd?: RunCostEstimator | undefined;
  }
>()("@effect-agent/thread/DurableRuntimeConfig") {
  static make(options: DurableRuntimeConfigOptions): (typeof DurableRuntimeConfig)["Service"] {
    return {
      deploymentId: options.deploymentId,
      producerId: options.producerId,
      settlementPollInterval: options.settlementPollInterval ?? Duration.millis(500),
      leaseRenewalInterval: options.leaseRenewalInterval ?? Duration.seconds(10),
      abortPollInterval: options.abortPollInterval ?? Duration.millis(500),
      recoveryTimeout: options.recoveryTimeout ?? Duration.seconds(30),
      ...(options.estimateCostMicrousd === undefined
        ? {}
        : { estimateCostMicrousd: options.estimateCostMicrousd }),
    };
  }

  static layer(options: DurableRuntimeConfigOptions): Layer.Layer<DurableRuntimeConfig> {
    return Layer.succeed(DurableRuntimeConfig)(DurableRuntimeConfig.make(options));
  }
}

/** Terminal outcome an Attempt decided before terminalization (DUR-011). */
type AttemptOutcome = { readonly uncommittedModelUsage?: ReadonlyArray<ModelCallUsage> } & (
  | {
      readonly _tag: "completed";
      readonly result: PersistedJson;
      /** Schema-encoded application disposition, only for an ordinary completed Run. */
      readonly runDisposition?: PersistedJson;
      /** Set when the Run settled through the final-answer exhaustion resolution (RUN-018). */
      readonly finishReason?: "budget-exhausted";
      /** The dimension that bound; set exactly alongside `finishReason` (RUN-011). */
      readonly exhausted?: ExhaustedLimit;
      readonly usageSummary?: RunUsageSummary;
    }
  | {
      readonly _tag: "failed";
      readonly result: SettlementFailureDiagnostic;
      /** The typed limit of an `AgentPolicyError` failure; absent otherwise (RUN-011). */
      readonly policyLimit?: PolicyLimit;
      readonly usageSummary?: RunUsageSummary;
    }
  | { readonly _tag: "aborted"; readonly usageSummary?: RunUsageSummary }
);

/**
 * What one `runModel` pass produced: a terminal `AttemptOutcome` for terminalization, a
 * durable approval suspension (plan §2.6) — the unresolved call's canonical request is already
 * appended, NO settlement is owed by this pass, and `runAttempt` transitions the ledger — or a
 * durable `waitingForChild` suspension: every non-waiting
 * sibling result is already committed as a per-call late-settle batch and `runAttempt` executes
 * `ledger.suspend(WaitingForChild)`.
 */
type RunPhaseOutcome =
  | AttemptOutcome
  | { readonly _tag: "yielded"; readonly nextSubmissionId?: SubmissionId }
  | { readonly _tag: "suspended"; readonly toolCallId: ToolCallId }
  | { readonly _tag: "suspendedChild"; readonly children: AgentChildPending["children"] };

const approvalSuspension = (toolCallId: ToolCallId): RunPhaseOutcome => ({
  _tag: "suspended",
  toolCallId,
});

const childSuspension = (children: AgentChildPending["children"]): RunPhaseOutcome => ({
  _tag: "suspendedChild",
  children,
});

const abortedRunPhase = (usageSummary: RunUsageSummary): RunPhaseOutcome => ({
  _tag: "aborted",
  usageSummary,
});

/**
 * Internal marker separating coordinator infrastructure failures (fencing, storage, failpoints —
 * the Attempt aborts cleanly and the accepted work stays owed) from Agent Run failures (typed
 * engine errors — the Submission settles `failed`). Never exported: it exists only so the two
 * failure families cannot be confused inside the run phase.
 */
class CoordinatorHalt {
  readonly _tag = "CoordinatorHalt";
  constructor(readonly failure: DurableWorkerFailure) {}
}

const isCoordinatorHaltCause = (
  cause: Cause.Cause<unknown>,
): cause is Cause.Cause<CoordinatorHalt> =>
  cause.reasons.every(
    (reason) => reason._tag !== "Fail" || reason.error instanceof CoordinatorHalt,
  );

const PolicyFailure = Schema.TaggedStruct("AgentPolicyError", {
  limit: PolicyLimit,
});

const decodePolicyFailure = Schema.decodeUnknownOption(PolicyFailure);

const decodePolicyFailureSafely = (error: unknown) => {
  try {
    return decodePolicyFailure(error);
  } catch {
    return Option.none();
  }
};

const agentApprovalPendingOption = (
  cause: Cause.Cause<unknown>,
): Option.Option<AgentApprovalPending> => {
  try {
    // Suspension authority is nominal. Schema.is/decode would accept a forged tagged object.
    const first = cause.reasons.find(Cause.isFailReason);

    return first !== undefined &&
      first.error instanceof AgentApprovalPending &&
      cause.reasons.every(
        (reason) => reason._tag !== "Fail" || reason.error instanceof AgentApprovalPending,
      )
      ? Option.some(first.error)
      : Option.none();
  } catch {
    return Option.none();
  }
};

const agentChildPendingOption = (error: unknown): Option.Option<AgentChildPending> => {
  try {
    // Suspension authority is nominal. Schema.is/decode would accept a forged tagged object.
    return error instanceof AgentChildPending ? Option.some(error) : Option.none();
  } catch {
    return Option.none();
  }
};

const errorMessageOf = (error: unknown): string => {
  const diagnostic = inspectForeignDiagnostic(error);

  return diagnostic.message ?? safeUnknownString(error, "Unknown failure");
};

const errorTagOf = (error: unknown): string =>
  inspectForeignDiagnostic(error).tag ?? "UnknownError";

const nowUtc: Effect.Effect<DateTime.Utc> = Effect.map(Clock.currentTimeMillis, (millis) =>
  DateTime.toUtc(DateTime.makeUnsafe(millis)),
);

const decodePrompt = Schema.decodeUnknownEffect(Prompt.Prompt);
const decodePersisted = Schema.decodeUnknownEffect(PersistedJson);

/** One application Tool Call declared inside a canonical `ModelResponseRecorded`'s messages. */
interface DeclaredApplicationCall {
  readonly id: string;
  readonly name: string;
  /** Encoded JSON parameters exactly as canonical history carries them. */
  readonly params: unknown;
  readonly providerExecuted?: boolean;
}

interface DeclaredToolCalls {
  readonly application: Array<DeclaredApplicationCall>;
  readonly all: Array<DeclaredApplicationCall>;
  readonly providerResults: Array<Prompt.ToolResultPart>;
}

/**
 * Pure inspection of every Tool Call declared in one canonical response. Provider-executed calls
 * retain their terminal results, while only application calls enter the durable prepared/settled
 * protocol and completion singleton invariant.
 */
const declaredToolCalls = Effect.fn("DurableAgentRuntime.declaredToolCalls")(
  (messages: PersistedJson): Effect.Effect<DeclaredToolCalls, RunJournalError> =>
    decodePrompt(messages).pipe(
      Effect.mapError((cause) =>
        RunJournalError.make({
          message: "ModelResponseRecorded messages are not Schema-encoded Prompt messages",
          cause,
        }),
      ),
      Effect.flatMap((prompt) => {
        const application: Array<DeclaredApplicationCall> = [];
        const all: Array<DeclaredApplicationCall> = [];
        const providerResults: Array<Prompt.ToolResultPart> = [];

        for (const message of prompt.content) {
          if (message.role !== "assistant") continue;
          for (const part of message.content) {
            if (part.type === "tool-result" && part.providerExecuted) providerResults.push(part);
            if (part.type !== "tool-call") continue;
            all.push({
              id: part.id,
              name: part.name,
              params: part.params,
              providerExecuted: part.providerExecuted,
            });
            if (!part.providerExecuted) {
              application.push({ id: part.id, name: part.name, params: part.params });
            }
          }
        }

        const providerCalls = new Map(
          all.filter((call) => call.providerExecuted).map((call) => [call.id, call]),
        );

        const resultIds = new Set<string>();

        for (const result of providerResults) {
          if (providerCalls.get(result.id)?.name !== result.name || resultIds.has(result.id)) {
            return Effect.fail(
              RunJournalError.make({
                message: `Invalid canonical provider result ${result.id}`,
              }),
            );
          }
          resultIds.add(result.id);
        }
        for (const id of providerCalls.keys()) {
          if (!resultIds.has(id)) {
            return Effect.fail(
              RunJournalError.make({
                message: `Turn lacks canonical provider result for ${id}`,
              }),
            );
          }
        }

        return Effect.succeed({ application, all, providerResults });
      }),
    ),
);

/** Application calls alone drive durable preparation, settlement, and batch resume. */
const declaredApplicationCalls = Effect.fn("DurableAgentRuntime.declaredApplicationCalls")(
  (messages: PersistedJson): Effect.Effect<Array<DeclaredApplicationCall>, RunJournalError> =>
    declaredToolCalls(messages).pipe(Effect.map(({ application }) => application)),
);

/**
 * The declared-but-unsettled Tool batch of one Run's last committed Turn (§2.4 batch resume):
 * every declared call in canonical encoded form plus the recorded results of the calls that
 * already settled (results batch never committed, or per-call late settles from the resolution
 * path). `undefined` when the Run's journal ends at a complete Turn boundary.
 */
interface PendingToolBatch {
  readonly toolOperations?: ReadonlyArray<ToolOperation> | undefined;
  readonly toolParameterRejections?: ReadonlyArray<ToolParameterRejection> | undefined;
  readonly toolExposure?: Snapshot | undefined;
  readonly turn: number;
  readonly turnId: TurnId;
  readonly calls: ReadonlyArray<DeclaredApplicationCall>;
  readonly settled: ReadonlyArray<{
    readonly id: string;
    readonly result: PersistedJson;
    readonly isFailure: boolean;
    readonly budgetRejected?: true;
    readonly toolSelection?: Selection | undefined;
  }>;
  readonly declaredIds: ReadonlySet<string>;
  readonly responseRecordId: RecordId;
  /** The pending `ModelResponseRecorded.messages`: its pre-assistant slice is the resume's leading messages. */
  readonly messages: PersistedJson;
}

interface AttemptAppendContext {
  readonly threadId: ThreadId;
  readonly producerEpoch: ProducerEpoch;
  readonly tailRef: Ref.Ref<{ readonly sequence: CanonicalSequence; readonly digest: Digest }>;
  /** Serializes every canonical append of one Attempt (run commits vs. the abort watcher). */
  readonly gate: Semaphore.Semaphore;
}

/** What the resuming worker knows about the ownership period it superseded (durability §9). */
interface AttemptLineage {
  readonly attemptId: AttemptId;
  /** The Thread-store fence BEFORE this Attempt advanced it (0 = no prior producer). */
  readonly supersededEpoch: ProducerEpoch;
  /** The canonical `input:{sid}` record existed before this Attempt started. */
  readonly inputWasRecorded: boolean;
}

/** Review of one Submission's open (prepared-without-outcome) ordinary Tool Calls (DUR-009). */
interface OpenCallReview {
  /** No proof either way: these calls must become Unknown Outcomes (never auto-replayed). */
  readonly uncertain: Array<OpenToolCallEvidence>;
  /** Reconciliation or current execution support is unproven: defer without marking Unknown. */
  readonly unproven: Array<OpenToolCallEvidence>;
  /** Proven safe to re-execute (never-started / safe-retry / declared idempotent contract). */
  readonly retryable: Array<OpenToolCallEvidence>;
  /** Calls closed canonically with a recovered result (no handler execution). */
  readonly recovered: number;
}

const make = Effect.fn("DurableAgentRuntime.make")(function* (
  bindings: ReadonlyArray<ResolvedBinding>,
) {
  const registeredBindings = [...bindings];
  const bindingSelection = yield* CurrentBindingSelection;
  const workerAdmissionPort = yield* WorkerAdmissionPort;
  const ledger = yield* SubmissionLedger;
  const submissionScheduling = yield* SubmissionScheduling;
  const store = yield* ThreadStore;
  const deliveries = yield* Effect.serviceOption(MessageDeliveryStore);

  // Disposable: canonical tail and owner identify the exact projection, never ownership.
  // Retain only the most recent view; persisted checkpoints still govern cold recovery.
  let projectedJournal:
    | {
        readonly threadId: ThreadId;
        readonly through: CanonicalSequence;
        readonly runId: RunId;
        readonly seedThrough: CanonicalSequence | undefined;
        readonly contextThrough: CanonicalSequence | undefined;
        readonly journal: RunJournalProjection;
        readonly boundaries: ReadonlyArray<JournalBoundary>;
      }
    | undefined;

  const wake = yield* WakeScheduler;
  const failpoint = yield* DurableRuntimeFailpoint;
  const config = yield* DurableRuntimeConfig;
  const crypto = yield* Crypto.Crypto;
  const reconciler = yield* ToolReconciler;
  const approvalResolver = yield* DurableApprovalResolver;

  // Capture independent host choices at acquisition so worker callers cannot replace them.
  const runContextPreparation = yield* Effect.serviceOption(RunContextPreparation).pipe(
    Effect.map(Option.getOrElse(() => RunContextPreparation.of({}))),
  );

  const runToolAuthorization = yield* RunToolAuthorization;

  const runToolVisibility = yield* RunToolVisibility;

  const runToolScheduling = yield* RunToolScheduling;

  const compactor = yield* Effect.serviceOption(ContextCompactor).pipe(
    Effect.flatMap(
      Option.match({
        onSome: Effect.succeed,
        onNone: () => Effect.provide(ContextCompactor, ContextCompactor.layer),
      }),
    ),
  );

  // Possession-default authorization reference (P7 WP1): the default allows everything —
  // exactly the pre-P7 service-possession boundary — and a host-supplied non-default Layer is
  // consulted fail-closed by observe, the admin operations, and the two resolution paths.
  const operationAuthorizer = yield* OperationAuthorizer;
  // RUN-036: capture once with the runtime, including explicit absence. A worker caller's ambient
  // observer must never replace this host choice on a fresh or replacement Attempt.
  const toolFailureObserver = yield* CurrentToolFailureObserver;

  const withCrypto = <A, E>(effect: Effect.Effect<A, E, Crypto.Crypto>): Effect.Effect<A, E> =>
    Effect.provideService(effect, Crypto.Crypto, crypto);

  const contractsFor = (definition: Agent.AnyDefinition) => {
    const registered = registeredBindings.filter(
      (binding) => binding.agentId === definition.id && Object.is(binding.definition, definition),
    );

    const current = registered.length === 1 ? registered[0] : undefined;
    const contracts = current?.digests.replay?.tools;

    return contracts === undefined
      ? withCrypto(
          toolReplayContracts(definition, undefined, current?.digests.tools ?? config.deploymentId),
        )
      : Effect.succeed(contracts);
  };

  const resolveCurrentBinding = (submission: SubmissionSnapshot) =>
    resolveWorkerBinding(registeredBindings, submission).pipe(
      Effect.provideService(CurrentBindingSelection, bindingSelection),
    );

  const currentOperationsFor = Effect.fnUntraced(function* (submission: SubmissionSnapshot) {
    const binding = yield* resolveCurrentBinding(submission).pipe(
      Effect.catchTag("BindingUnavailable", () => Effect.succeed(undefined)),
    );

    return binding === undefined
      ? undefined
      : {
          definition: binding.definition,
          contracts: yield* contractsFor(binding.definition),
        };
  });

  const operationsFor = (records: ReadonlyArray<CanonicalRecordEnvelope>, runId: RunId) => {
    const operations = new Map<string, ToolOperation>();

    for (const {
      record: { payload },
    } of records) {
      if (payload._tag !== "ModelResponseRecorded" || payload.runId !== runId) continue;
      for (const operation of payload.toolOperations ?? [])
        operations.set(operation.toolCallId, operation);
    }

    return operations;
  };

  const supportsOperation = (
    submission: SubmissionSnapshot,
    call: OpenToolCallEvidence,
    operation: ToolOperation | undefined,
    prepared: ToolCallPrepared | undefined,
    current:
      | {
          readonly definition: Agent.AnyDefinition;
          readonly contracts: Readonly<Record<string, Digest>>;
        }
      | undefined,
  ): boolean => {
    const tool = current?.definition.toolkit.tools[call.toolName];

    const replay =
      operation?.replay ?? prepared?.replay ?? submission.agentDigests.replay?.tools[call.toolName];

    return (
      tool !== undefined &&
      replay !== undefined &&
      current?.contracts[call.toolName] === replay &&
      (operation === undefined ||
        (operation.toolName === call.toolName &&
          operation.executionClass === getToolExecutionClass(tool) &&
          operation.executionKind === getToolExecutionKind(tool.annotations))) &&
      (prepared === undefined ||
        (prepared.toolName === call.toolName &&
          (prepared.executionClass === undefined ||
            prepared.executionClass === getToolExecutionClass(tool)) &&
          (prepared.executionKind ?? "ordinary") === getToolExecutionKind(tool.annotations)))
    );
  };

  const hit = (
    location: DurableRuntimeFailpointLocation,
  ): Effect.Effect<void, DurableRuntimeFailpointError> => failpoint.hit(location);

  const makeEnvelope = (
    recordId: RecordId,
    payload: CanonicalRecordPayload,
  ): Effect.Effect<RecordEnvelope> =>
    Effect.map(nowUtc, (createdAt) =>
      RecordEnvelope.make({
        recordId,
        family: "thread",
        schemaVersion: 1,
        createdAt,
        deploymentId: config.deploymentId,
        payload,
      }),
    );

  const materializeSettlement = (
    settlement: Settlement,
    record: RecordEnvelope | undefined,
  ): Settlement => {
    const common = {
      submissionId: settlement.submissionId,
      settlementId: settlement.settlementId,
      receiptId: settlement.receiptId,
      outcome: settlement.outcome,
      ...(settlement.failure === undefined ? {} : { failure: settlement.failure }),
      settledAt: settlement.settledAt,
    };

    const payload = record?.payload;

    if (
      payload === undefined ||
      payload._tag !== "SubmissionSettled" ||
      payload.submissionId !== settlement.submissionId ||
      payload.settlementId !== settlement.settlementId ||
      payload.receiptId !== settlement.receiptId ||
      payload.outcome !== settlement.outcome
    ) {
      return Settlement.make(common);
    }

    const canonical = {
      ...common,
      ...(payload.usageSummary === undefined ? {} : { usageSummary: payload.usageSummary }),
    };

    if (settlement.outcome !== "completed" || payload.runDisposition === undefined) {
      return Settlement.make(canonical);
    }

    return Settlement.make({
      ...canonical,
      runDisposition: payload.runDisposition,
    });
  };

  /** Re-readable, contiguous canonical prefix. Each traversal retains only the adapter's chunk. */
  const canonicalRange = (
    threadId: ThreadId,
    throughSequence: CanonicalSequence,
    afterSequence: CanonicalSequence = ZERO_SEQUENCE,
  ): Stream.Stream<CanonicalRecordEnvelope, ThreadStoreError | ThreadNotMaterialized> =>
    Stream.suspend(() => {
      let expected = afterSequence + 1;
      let after = afterSequence;

      const next = (): Stream.Stream<
        CanonicalRecordEnvelope,
        ThreadStoreError | ThreadNotMaterialized
      > =>
        Stream.suspend(() => {
          if (expected > throughSequence) return Stream.empty;
          const start = expected;
          const limit = Math.min(READ_PAGE, throughSequence - start + 1);

          const page = store
            .read(
              ThreadRead.make({
                threadId,
                limit,
                ...(after === 0 ? {} : { afterSequence: after }),
              }),
            )
            .pipe(
              Stream.mapEffect((envelope) => {
                if (envelope.sequence !== expected || expected >= start + limit) {
                  return Effect.fail(
                    ThreadStoreError.make({
                      operation: "read recovery history",
                      message: `Canonical history for ${threadId} is not contiguous: expected sequence ${expected}, received ${envelope.sequence}`,
                    }),
                  );
                }
                expected += 1;
                after = envelope.sequence;

                return Effect.succeed(envelope);
              }),
            );

          return Stream.concat(
            page,
            Stream.suspend(() =>
              expected === start + limit
                ? next()
                : Stream.fail(
                    ThreadStoreError.make({
                      operation: "read recovery history",
                      message: `Canonical history for ${threadId} ended at ${after}; expected ${limit} records through sequence ${throughSequence}, received ${expected - start}`,
                    }),
                  ),
            ),
          );
        });

      return next();
    });

  /**
   * Retain addressed runs and their deterministic identities independently of payload claims.
   * Marker matching deliberately errs toward retaining malformed/conflicting identity evidence.
   */
  const controlRecords = (submissionIds: ReadonlyArray<SubmissionId>) => {
    const runIds = new Set(submissionIds.map(runIdForSubmission));
    const runMarkers = [...runIds].map((runId) => `:${runId}:`);

    const recordIds = new Set(
      submissionIds.flatMap((id) => [
        submissionInputRecordId(id),
        submissionAbortRecordId(id),
        submissionSettlementRecordId(id),
        runStartedRecordId(runIdForSubmission(id)),
        runCompletedRecordId(runIdForSubmission(id)),
      ]),
    );

    return ({ record }: CanonicalRecordEnvelope): boolean =>
      recordIds.has(record.recordId) ||
      runMarkers.some((marker) => record.recordId.includes(marker)) ||
      record.recordId.startsWith("subagent-lineage:") ||
      record.payload._tag === "SubagentLineageRecorded" ||
      record.payload._tag === "WorkerOriginRecorded" ||
      ("runId" in record.payload &&
        record.payload.runId !== undefined &&
        runIds.has(record.payload.runId));
  };

  const readControl = Effect.fn("DurableAgentRuntime.readControl")(function* (
    threadId: ThreadId,
    submissionIds: ReadonlyArray<SubmissionId>,
  ) {
    const tail = yield* store.inspectTail(ThreadTailRequest.make({ threadId }));
    const view = yield* recoveryView(threadId, tail.tailSequence, submissionIds);

    return yield* Stream.runCollect(
      view.canonical.pipe(Stream.filter(controlRecords(submissionIds))),
    );
  });

  const loadRecoveryCheckpoint = Effect.fn("DurableAgentRuntime.loadRecoveryCheckpoint")(function* (
    threadId: ThreadId,
    throughSequence: CanonicalSequence,
  ) {
    if (store.recoveryCheckpoints === undefined) return Option.none();

    const loaded = yield* store.recoveryCheckpoints
      .load(LoadCheckpointRequest.make({ threadId, atOrBeforeSequence: throughSequence }))
      .pipe(Effect.catchTag("CheckpointRejected", () => Effect.succeed(Option.none())));

    if (Option.isNone(loaded)) return Option.none();
    const checkpoint = loaded.value;

    if (
      checkpoint.engineVersion !== RECOVERY_ENGINE_VERSION ||
      checkpoint.threadId !== threadId ||
      checkpoint.throughSequence > throughSequence
    )
      return Option.none();

    const decoded = yield* Schema.decodeUnknownEffect(RecoveryCheckpointContents)(
      checkpoint.state,
    ).pipe(Effect.option);

    if (Option.isNone(decoded)) return Option.none();
    const { state, digest } = decoded.value;

    if (
      (state.seed === undefined && state.context === undefined) ||
      state.records.some(
        (record) => record.threadId !== threadId || record.sequence > checkpoint.throughSequence,
      ) ||
      (state.context !== undefined && state.context.throughSequence !== checkpoint.throughSequence)
    )
      return Option.none();

    const encoded = yield* Schema.encodeEffect(RecoveryCheckpointState)(state).pipe(
      Effect.mapError((cause) =>
        ThreadStoreError.make({
          operation: "decode recovery checkpoint",
          message: "Invalid recovery state",
          cause,
        }),
      ),
    );

    const actualDigest = yield* withCrypto(digestJson(encoded)).pipe(
      Effect.mapError((cause) =>
        ThreadStoreError.make({
          operation: "decode recovery checkpoint",
          message: cause.message,
          cause,
        }),
      ),
    );

    if (digest !== actualDigest) return Option.none();

    if (state.context !== undefined) {
      const prompt = yield* Schema.decodeUnknownEffect(Prompt.Prompt)(state.context.prompt).pipe(
        Effect.option,
      );

      if (Option.isNone(prompt)) return Option.none();
    }

    const owner = yield* ledger
      .lookup(SubmissionLookupById.make({ submissionId: state.submissionId }))
      .pipe(
        Effect.mapError((cause) =>
          ThreadStoreError.make({
            operation: "recovery checkpoint compatibility",
            message: cause.message,
            cause,
          }),
        ),
      );

    if (
      Option.isNone(owner) ||
      owner.value.threadId !== threadId ||
      owner.value.agentDigests.agent !== checkpoint.agentDefinitionDigest ||
      owner.value.agentDigests.model !== checkpoint.modelDigest ||
      owner.value.agentDigests.tools !== checkpoint.toolDigest
    )
      return Option.none();

    return Option.some({ checkpoint, state });
  });

  const retainThreadIdentity = ({ record }: CanonicalRecordEnvelope): boolean =>
    record.payload._tag === "ThreadCreated" ||
    record.payload._tag === "SubagentLineageRecorded" ||
    record.payload._tag === "WorkerOriginRecorded" ||
    record.recordId.startsWith("subagent-lineage:");

  /** Late/foreign evidence and new compactions require the original canonical proof. */
  const contextSuffixCompatible = (
    records: ReadonlyArray<CanonicalRecordEnvelope>,
    submissionId: SubmissionId,
  ): boolean => {
    const runId = runIdForSubmission(submissionId);
    const certificate = makeThreadContextCertificate(runId.length);

    for (const entry of records) {
      const { payload, recordId } = entry.record;

      if (payload._tag === "CompactionCreated" || retainThreadIdentity(entry)) return false;
      if ("runId" in payload && payload.runId !== undefined) {
        if (payload.runId !== runId) return false;
      } else if (payload._tag === "AbortRequested") {
        if (
          payload.submissionId !== submissionId ||
          recordId !== submissionAbortRecordId(submissionId)
        )
          return false;
      } else if (payload._tag === "SubmissionSettled") {
        if (
          payload.submissionId !== submissionId ||
          recordId !== submissionSettlementRecordId(submissionId)
        )
          return false;
      } else return false;
      certificate.add(entry);
    }

    return certificate.isValid();
  };

  /** Run seeds retain their owner; certified Thread context serves only provably later Runs. */
  const recoveryView = Effect.fn("DurableAgentRuntime.recoveryView")(function* (
    threadId: ThreadId,
    throughSequence: CanonicalSequence,
    submissionIds: ReadonlyArray<SubmissionId>,
    journalOwner?: RunId,
  ): Effect.fn.Return<
    {
      readonly canonical: Stream.Stream<
        CanonicalRecordEnvelope,
        ThreadStoreError | ThreadNotMaterialized
      >;
      readonly seed?: JournalCheckpointSeed;
      readonly context?: ThreadContextCheckpoint;
    },
    ThreadStoreError | ThreadNotMaterialized
  > {
    const full = { canonical: canonicalRange(threadId, throughSequence) };
    const loaded = yield* loadRecoveryCheckpoint(threadId, throughSequence);

    if (Option.isNone(loaded)) return full;
    const { checkpoint, state } = loaded.value;

    if (throughSequence - checkpoint.throughSequence > 4_096) return full;

    const submissionId = submissionIds.length === 1 ? submissionIds[0] : undefined;

    if (
      state.context !== undefined &&
      submissionId !== undefined &&
      submissionId.length === state.submissionId.length &&
      (journalOwner === undefined || journalOwner === runIdForSubmission(submissionId))
    ) {
      const runId = runIdForSubmission(submissionId);

      const input = yield* getRunInput({ threadId, runId }).pipe(
        Effect.provideService(ThreadStore, store),
      );

      const controls = yield* Effect.forEach(
        [
          submissionInputRecordId(submissionId),
          submissionAbortRecordId(submissionId),
          submissionSettlementRecordId(submissionId),
          runStartedRecordId(runId),
          runCompletedRecordId(runId),
        ],
        (recordId) =>
          getRecord({ threadId, recordId }).pipe(Effect.provideService(ThreadStore, store)),
      );

      const fresh = [input, ...controls].every(
        (record) =>
          Option.isNone(record) ||
          (record.value.sequence > checkpoint.throughSequence &&
            record.value.sequence <= throughSequence),
      );

      if (fresh) {
        const suffix = yield* Stream.runCollect(
          canonicalRange(threadId, throughSequence, checkpoint.throughSequence),
        );

        if (contextSuffixCompatible(suffix, submissionId))
          return {
            canonical: Stream.fromIterable([
              ...state.records.filter(retainThreadIdentity),
              ...suffix,
            ]),
            context: state.context,
          };
      }
    }

    if (
      state.seed === undefined ||
      !submissionIds.every((id) => state.submissionIds.includes(id)) ||
      state.seed.runId !== runIdForSubmission(state.submissionId) ||
      (journalOwner !== undefined && state.seed.runId !== journalOwner)
    )
      return full;
    const replacement = state.seed.compaction;

    if (
      replacement.threadId !== threadId ||
      replacement.sequence > checkpoint.throughSequence ||
      replacement.record.payload._tag !== "CompactionCreated" ||
      replacement.record.payload.kind === "clear-tool-results" ||
      replacement.record.payload.coversThrough < state.seed.throughSequence ||
      replacement.record.payload.coversThrough >= replacement.sequence ||
      !state.records.some(
        (record) =>
          record.sequence === replacement.sequence &&
          record.record.recordId === replacement.record.recordId,
      )
    )
      return full;

    const suffix = yield* Stream.runCollect(
      canonicalRange(threadId, throughSequence, checkpoint.throughSequence),
    );

    if (!checkpointSuffixCompatible(state.seed, suffix, state.records)) return full;

    return { canonical: Stream.fromIterable([...state.records, ...suffix]), seed: state.seed };
  });

  const encodeRecoveryCheckpoint = Effect.fnUntraced(function* (
    state: RecoveryCheckpointState,
  ): Effect.fn.Return<Option.Option<PersistedJson>, DurableWorkerFailure> {
    const encoded = yield* Schema.encodeEffect(RecoveryCheckpointState)(state).pipe(Effect.option);

    if (Option.isNone(encoded)) return Option.none();
    const digest = yield* withCrypto(digestJson(encoded.value));

    // Serialization removes shared in-memory references before applying persisted JSON bounds.
    return yield* Schema.encodeEffect(Schema.fromJsonString(RecoveryCheckpointContents))(
      RecoveryCheckpointContents.make({ state, digest }),
    ).pipe(
      Effect.flatMap(Schema.decodeUnknownEffect(Schema.fromJsonString(PersistedJson))),
      Effect.option,
    );
  });

  const persistRecoveryCheckpoint = Effect.fn("DurableAgentRuntime.persistRecoveryCheckpoint")(
    function* (
      ctx: AttemptAppendContext,
      submission: SubmissionSnapshot,
      contents: PersistedJson,
      tail: { readonly sequence: CanonicalSequence; readonly digest: Digest },
      createdAt: DateTime.Utc,
    ): Effect.fn.Return<void, DurableWorkerFailure> {
      if (store.recoveryCheckpoints === undefined) return;

      const checkpoint = ThreadCheckpoint.make({
        schemaVersion: 1,
        threadId: ctx.threadId,
        throughSequence: tail.sequence,
        tailDigest: tail.digest,
        engineVersion: RECOVERY_ENGINE_VERSION,
        agentDefinitionDigest: submission.agentDigests.agent,
        modelDigest: submission.agentDigests.model,
        toolDigest: submission.agentDigests.tools,
        state: contents,
        createdAt,
      });

      yield* hit("checkpoint:before-save");
      yield* store.recoveryCheckpoints
        .save(SaveRecoveryCheckpointRequest.make({ checkpoint, producerEpoch: ctx.producerEpoch }))
        .pipe(Effect.catchTag("CheckpointRejected", () => Effect.void));
      yield* hit("checkpoint:after-save");
    },
  );

  /** Refresh before settlement finalization, so completed processing includes the cache's cost. */
  const saveThreadContext = Effect.fn("DurableAgentRuntime.saveThreadContext")(function* (
    ctx: AttemptAppendContext,
    submission: SubmissionSnapshot,
    priorContext?: ThreadContextCheckpoint,
  ): Effect.fn.Return<void, DurableWorkerFailure> {
    if (store.recoveryCheckpoints === undefined) return;
    const tail = yield* Ref.get(ctx.tailRef);
    const loaded = yield* loadRecoveryCheckpoint(ctx.threadId, tail.sequence);

    // Start certification only after compaction has produced an eligible runtime checkpoint.
    if (Option.isNone(loaded)) return;
    const previous = loaded.value;

    let identities: ReadonlyArray<CanonicalRecordEnvelope> =
      previous.state.records.filter(retainThreadIdentity);

    let projection: RunJournalProjection | undefined;

    if (priorContext !== undefined && tail.sequence - priorContext.throughSequence <= 4_096) {
      const suffix = yield* Stream.runCollect(
        canonicalRange(ctx.threadId, tail.sequence, priorContext.throughSequence),
      );

      if (contextSuffixCompatible(suffix, submission.submissionId)) {
        projection = yield* projectRunJournalStream(
          Stream.fromIterable(suffix),
          undefined,
          undefined,
          undefined,
          undefined,
          priorContext,
        ).pipe(Effect.catchTag("RunJournalError", () => Effect.succeed(undefined)));
      }
    }

    if (projection === undefined) {
      const source = canonicalRange(ctx.threadId, tail.sequence);

      const certificate = makeThreadContextCertificate(
        runIdForSubmission(submission.submissionId).length,
      );

      const metadata = makeJournalMetadata(undefined);
      const retained: Array<CanonicalRecordEnvelope> = [];

      yield* Stream.runForEach(source, (entry) =>
        Effect.sync(() => {
          certificate.add(entry);
          metadata.add(entry);
          if (retainThreadIdentity(entry) && retained.length <= 4_096) retained.push(entry);
        }),
      );
      if (!certificate.isValid() || retained.length > 4_096) return;
      identities = retained;
      projection = yield* projectRunJournalStream(
        source,
        undefined,
        undefined,
        undefined,
        metadata.snapshot(),
      ).pipe(Effect.catchTag("RunJournalError", () => Effect.succeed(undefined)));
    }

    if (projection === undefined) return;

    const prompt = yield* Schema.encodeEffect(Prompt.Prompt)(projection.prompt).pipe(
      Effect.flatMap(decodePersisted),
      Effect.option,
    );

    if (Option.isNone(prompt)) return;

    const contextState = RecoveryCheckpointState.make({
      schemaVersion: 2,
      policyAccountingVersion: 1,
      submissionId: submission.submissionId,
      submissionIds: [submission.submissionId],
      context: ThreadContextCheckpoint.make({
        throughSequence: tail.sequence,
        prompt: prompt.value,
        ...(projection.contextWindowId === undefined
          ? {}
          : { contextWindowId: projection.contextWindowId }),
      }),
      records: identities,
    });

    let state = contextState;

    if (
      previous.state.submissionId === submission.submissionId &&
      previous.state.seed !== undefined &&
      tail.sequence - previous.checkpoint.throughSequence + previous.state.records.length <= 4_096
    ) {
      const suffix = yield* Stream.runCollect(
        canonicalRange(ctx.threadId, tail.sequence, previous.checkpoint.throughSequence),
      );

      if (checkpointSuffixCompatible(previous.state.seed, suffix, previous.state.records)) {
        state = RecoveryCheckpointState.make({
          ...contextState,
          seed: previous.state.seed,
          records: [...previous.state.records, ...suffix],
          submissionIds: previous.state.submissionIds,
        });
      }
    }

    let contents = yield* encodeRecoveryCheckpoint(state);

    // Prefer retaining same-Run recovery, but keep eligible Thread context when the combined
    // cache exceeds bounds. That Run can still recover from its unchanged canonical history.
    if (Option.isNone(contents) && state.seed !== undefined)
      contents = yield* encodeRecoveryCheckpoint(contextState);
    if (Option.isNone(contents)) return;

    yield* persistRecoveryCheckpoint(ctx, submission, contents.value, tail, yield* DateTime.now);
  });

  const readAllTolerant = Effect.fn("DurableAgentRuntime.readAllTolerant")(
    (
      threadId: ThreadId,
      submissionIds: ReadonlyArray<SubmissionId>,
    ): Effect.Effect<
      { readonly records: ReadonlyArray<CanonicalRecordEnvelope>; readonly materialized: boolean },
      ThreadStoreError
    > =>
      readControl(threadId, submissionIds).pipe(
        Effect.map((records) => ({ records, materialized: true })),
        Effect.catchTag("ThreadNotMaterialized", () =>
          Effect.succeed({ records: [], materialized: false }),
        ),
      ),
  );

  interface RecoveryHistorySnapshot {
    readonly records: ReadonlyArray<CanonicalRecordEnvelope>;
    readonly materialized: boolean;
    readonly throughSequence: CanonicalSequence;
    readonly submissionIds: ReadonlyArray<SubmissionId>;
  }

  /**
   * Read one exact canonical prefix. The authoritative tail captured by the caller bounds both
   * work and visibility: appends racing the read receive higher sequences and are deliberately
   * left for a later snapshot, while a short page or sequence gap fails typed before recovery
   * mutates anything. At most `ceil((through - after) / READ_PAGE)` store pages are requested.
   */
  const readCanonicalRange = Effect.fn("DurableAgentRuntime.readCanonicalRange")(function* (
    threadId: ThreadId,
    afterSequence: CanonicalSequence,
    throughSequence: CanonicalSequence,
    retain: (record: CanonicalRecordEnvelope) => boolean,
  ): Effect.fn.Return<Array<CanonicalRecordEnvelope>, ThreadStoreError | ThreadNotMaterialized> {
    return yield* Stream.runCollect(
      canonicalRange(threadId, throughSequence, afterSequence).pipe(Stream.filter(retain)),
    );
  });

  /**
   * Capture one strongly-consistent pass-start tail and read exactly that prefix. This snapshot
   * is disposable: `runRecovery` retains it only while processing the scan's contiguous group
   * for this Thread, retaining only the addressed runs' control evidence
   * and never survives the pass or an interruption/restart.
   */
  const readRecoveryHistory = Effect.fn("DurableAgentRuntime.readRecoveryHistory")(function* (
    threadId: ThreadId,
    submissionIds: ReadonlyArray<SubmissionId>,
  ): Effect.fn.Return<RecoveryHistorySnapshot, ThreadStoreError> {
    const tail = yield* store.inspectTail(ThreadTailRequest.make({ threadId })).pipe(
      Effect.map(Option.some),
      Effect.catchTag("ThreadNotMaterialized", () => Effect.succeed(Option.none())),
    );

    if (Option.isNone(tail))
      return { records: [], materialized: false, throughSequence: ZERO_SEQUENCE, submissionIds };

    const records = yield* recoveryView(threadId, tail.value.tailSequence, submissionIds).pipe(
      Effect.flatMap((view) =>
        Stream.runCollect(view.canonical.pipe(Stream.filter(controlRecords(submissionIds)))),
      ),
      Effect.catchTag("ThreadNotMaterialized", (error) =>
        ThreadStoreError.make({
          operation: "read recovery history",
          message: `Thread ${threadId} disappeared after its recovery tail was captured`,
          cause: error,
        }),
      ),
    );

    return { records, materialized: true, throughSequence: tail.value.tailSequence, submissionIds };
  });

  /**
   * A recovery mutation that must distinguish a racing canonical append reads only the suffix
   * beyond its pass snapshot. The append-only prefix remains valid; no full-history retry is
   * needed, and malformed suffix pagination fails through the same typed boundary.
   */
  const refreshRecoveryHistory = Effect.fn("DurableAgentRuntime.refreshRecoveryHistory")(function* (
    threadId: ThreadId,
    records: ReadonlyArray<CanonicalRecordEnvelope>,
    after: CanonicalSequence,
    submissionIds: ReadonlyArray<SubmissionId>,
  ): Effect.fn.Return<ReadonlyArray<CanonicalRecordEnvelope>, DurableWorkerFailure> {
    const tail = yield* store.inspectTail(ThreadTailRequest.make({ threadId }));

    if (tail.tailSequence <= after) return records;

    const suffix = yield* readCanonicalRange(
      threadId,
      after,
      tail.tailSequence,
      controlRecords(submissionIds),
    ).pipe(
      Effect.catchTag("ThreadNotMaterialized", (error) =>
        ThreadStoreError.make({
          operation: "read recovery history",
          message: `Thread ${threadId} disappeared after its recovery suffix tail was captured`,
          cause: error,
        }),
      ),
    );

    return [...records, ...suffix];
  });

  const knownRecordIdsOf = (records: ReadonlyArray<CanonicalRecordEnvelope>): Set<string> =>
    new Set(records.map((envelope) => envelope.record.recordId));

  const settlementPayloadFromRecord = Effect.fn("DurableAgentRuntime.settlementPayloadFromRecord")(
    function* (
      record: RecordEnvelope,
      submissionId: SubmissionId,
    ): Effect.fn.Return<SubmissionSettledRecord, LedgerError> {
      const payload = record.payload;

      if (
        payload._tag !== "SubmissionSettled" ||
        payload.submissionId !== submissionId ||
        payload.settlementId !== submissionSettlementId(submissionId) ||
        record.recordId !== submissionSettlementRecordId(submissionId)
      ) {
        return yield* LedgerError.make({
          operation: "settlementPayloadFromRecord",
          message: `The reserved canonical record is not the exact Settlement for Submission ${submissionId}`,
        });
      }

      return payload;
    },
  );

  const canonicalSettlementRecord = Effect.fn("DurableAgentRuntime.canonicalSettlementRecord")(
    function* (
      records: ReadonlyArray<CanonicalRecordEnvelope>,
      submissionId: SubmissionId,
    ): Effect.fn.Return<RecordEnvelope, LedgerError> {
      const record = records.find(
        (envelope) => envelope.record.recordId === submissionSettlementRecordId(submissionId),
      )?.record;

      if (record === undefined) {
        return yield* LedgerError.make({
          operation: "canonicalSettlementRecord",
          message: `Canonical history has no Settlement for Submission ${submissionId}`,
        });
      }
      yield* settlementPayloadFromRecord(record, submissionId);

      return record;
    },
  );

  /**
   * Fold structured recovery evidence from canonical records (plan §2.2). Canonical history is
   * the only recovery truth (DUR-015): open Tool Calls are `ToolCallPrepared` without a closing
   * `ToolCallSettled`/`ToolCallResolved`, a declared-pending batch is a committed tool-declaring
   * response with zero prepared and zero settled records for its Turn (the provably-safe
   * durability §15 window), approvals pend until a canonical decision exists, and joined-side
   * prompt coverage requires a host `ModelResponseRecorded` after the joined `input:{sid}` record.
   */
  const evidenceFor = Effect.fn("DurableAgentRuntime.evidenceFor")(function* (
    records: ReadonlyArray<CanonicalRecordEnvelope>,
    submissionId: SubmissionId,
    materialized: boolean,
    hostSubmissionId?: SubmissionId,
  ): Effect.fn.Return<RecoveryEvidence, RunJournalError | LedgerError> {
    const runId = runIdForSubmission(submissionId);

    const hostRunId =
      hostSubmissionId === undefined ? undefined : runIdForSubmission(hostSubmissionId);

    const inputId = submissionInputRecordId(submissionId);
    const abortId = submissionAbortRecordId(submissionId);
    const settlementId = submissionSettlementRecordId(submissionId);

    const hostSettlementId =
      hostSubmissionId === undefined ? undefined : submissionSettlementRecordId(hostSubmissionId);

    let inputRecorded = false;
    let inputSequence: CanonicalSequence | undefined;
    let abortRecorded = false;
    let subagentLineageRecorded = false;
    let recordedSettlementOutcome: SettlementOutcome | undefined;
    let hostSettlementOutcome: SettlementOutcome | undefined;
    let hostRespondedAfterInput = false;
    const prepared: Array<OpenToolCallEvidence> = [];
    const preparedKinds = new Map<RecordId, ToolCallPrepared["executionKind"]>();
    const preparedTurns = new Set<number>();
    const settledIds = new Set<string>();
    const resolvedIds = new Set<string>();
    const unknownIds = new Set<string>();
    const requested: Array<PendingApprovalEvidence> = [];
    const decidedIds = new Set<string>();

    let lastResponse:
      | {
          readonly turn: number;
          readonly messages: PersistedJson;
          readonly toolExposure?: Snapshot | undefined;
        }
      | undefined;

    for (const envelope of records) {
      const recordId = envelope.record.recordId;
      const payload = envelope.record.payload;

      if (recordId === inputId) {
        inputRecorded = true;
        inputSequence = envelope.sequence;
        continue;
      }
      if (recordId === abortId) {
        abortRecorded = true;
        continue;
      }
      if (recordId === settlementId && payload._tag === "SubmissionSettled") {
        recordedSettlementOutcome = payload.outcome;
        continue;
      }
      if (
        hostSettlementId !== undefined &&
        recordId === hostSettlementId &&
        payload._tag === "SubmissionSettled"
      ) {
        hostSettlementOutcome = payload.outcome;
        continue;
      }
      switch (payload._tag) {
        case "ToolCallPrepared": {
          if (payload.runId !== runId) break;
          const identity = toolCallPreparedRecordId(runId, payload.turn, payload.toolCallId);

          if (preparedKinds.has(identity)) {
            return yield* RunJournalError.make({
              message: "Duplicate canonical Tool preparation evidence",
            });
          }
          preparedKinds.set(identity, payload.executionKind);
          prepared.push(
            OpenToolCallEvidence.make({
              toolCallId: payload.toolCallId,
              toolName: payload.toolName,
              turn: payload.turn,
            }),
          );
          preparedTurns.add(payload.turn);
          break;
        }
        case "ToolCallSettled": {
          if (payload.runId === runId) settledIds.add(payload.toolCallId);
          break;
        }
        case "ToolCallUnknown": {
          if (payload.runId === runId) unknownIds.add(payload.toolCallId);
          break;
        }
        case "ToolCallResolved": {
          if (
            payload.runId === runId &&
            (payload.resolution === "completed-with-result" ||
              payload.resolution === "failed-with-error")
          )
            resolvedIds.add(payload.toolCallId);
          break;
        }
        case "ToolApprovalRequested": {
          if (payload.runId !== runId) break;
          requested.push(
            PendingApprovalEvidence.make({ toolCallId: payload.toolCallId, turn: payload.turn }),
          );
          break;
        }
        case "ToolApprovalDecided": {
          if (payload.runId === runId) decidedIds.add(payload.toolCallId);
          break;
        }
        case "SubagentLineageRecorded": {
          // Thread-level fact (one lineage record per child Thread, spec §11):
          // its presence gates the AwaitParentEstablishment row for parent-linked
          // Submissions; root Threads never carry it and never consult it.
          subagentLineageRecorded = true;
          break;
        }
        case "ModelResponseRecorded": {
          if (
            payload.runId === runId &&
            (lastResponse === undefined || payload.turn > lastResponse.turn)
          ) {
            lastResponse = {
              turn: payload.turn,
              messages: payload.messages,
              ...(payload.toolExposure === undefined ? {} : { toolExposure: payload.toolExposure }),
            };
          }
          if (
            hostRunId !== undefined &&
            payload.runId === hostRunId &&
            inputSequence !== undefined &&
            envelope.sequence > inputSequence
          ) {
            hostRespondedAfterInput = true;
          }
          break;
        }
        default: {
          break;
        }
      }
    }

    const allOpenCalls = prepared.filter(
      (call) => !settledIds.has(call.toolCallId) && !resolvedIds.has(call.toolCallId),
    );

    // Only canonical classification authorizes the idempotent establishment protocol.
    // A lifecycle record cannot silently upgrade an ordinary or unclassified preparation.
    const subagent = subagentRecordsOf(records, runId);

    const isPreparedDelegation = (call: OpenToolCallEvidence): boolean =>
      preparedKinds.get(toolCallPreparedRecordId(runId, call.turn, call.toolCallId)) ===
      "delegation";

    const openByCallId = new Map(
      allOpenCalls.filter(isPreparedDelegation).map((call) => [call.toolCallId, call]),
    );

    const delegationCallIds: Array<ToolCallId> = [];
    const seenDelegationIds = new Set<ToolCallId>();

    const noteDelegation = (toolCallId: ToolCallId): void => {
      if (seenDelegationIds.has(toolCallId)) return;
      seenDelegationIds.add(toolCallId);
      delegationCallIds.push(toolCallId);
    };

    for (const toolCallId of subagent.requested.keys()) noteDelegation(toolCallId);
    for (const toolCallId of subagent.started.keys()) noteDelegation(toolCallId);
    for (const toolCallId of subagent.joined.keys()) noteDelegation(toolCallId);
    for (const toolCallId of delegationCallIds) {
      const request = subagent.requested.get(toolCallId);

      if (
        request === undefined ||
        preparedKinds.get(toolCallPreparedRecordId(runId, request.turn, toolCallId)) !==
          "delegation"
      ) {
        return yield* RunJournalError.make({
          message: "Subagent evidence conflicts with Tool preparation classification",
        });
      }
    }
    for (const call of allOpenCalls) {
      if (isPreparedDelegation(call)) noteDelegation(call.toolCallId);
    }
    const openDelegationCalls: Array<OpenDelegationCallEvidence> = [];

    for (const toolCallId of delegationCallIds) {
      const open = openByCallId.get(toolCallId);
      const requestedRecord = subagent.requested.get(toolCallId);
      const startedRecord = subagent.started.get(toolCallId);
      // Authoritative admission tri-state for a requested-but-unstarted call (SUB-031): the
      // deterministic idempotency key queries the ledger directly — projection absence is
      // never proof of absence, and only a proven `not-admitted` permits an admission attempt.
      let admission: DelegationAdmissionEvidence | undefined;
      let childSubmissionId = startedRecord?.childSubmissionId;

      if (requestedRecord !== undefined && startedRecord === undefined) {
        const resolution = yield* ledger.resolveAdmission(
          SubmissionLookupByKey.make({
            threadId: requestedRecord.childThreadId,
            principal: decodePrincipalSync(requestedRecord.childPrincipal),
            idempotencyKey: decodeIdempotencyKeySync(requestedRecord.childIdempotencyKey),
          }),
        );

        switch (resolution._tag) {
          case "NotAdmitted": {
            admission = "not-admitted";
            break;
          }
          case "Admitted": {
            admission = "admitted";
            childSubmissionId = resolution.submission.submissionId;
            break;
          }
          case "Indeterminate": {
            admission = "indeterminate";
            break;
          }
        }
      }
      const childThreadId = startedRecord?.childThreadId ?? requestedRecord?.childThreadId;

      openDelegationCalls.push(
        OpenDelegationCallEvidence.make({
          toolCallId,
          toolName:
            open?.toolName ??
            subagent.preparedNames.get(toolCallId) ??
            requestedRecord?.delegationId ??
            "delegate_unknown",
          turn: open?.turn ?? requestedRecord?.turn ?? 1,
          requested: requestedRecord !== undefined,
          started: startedRecord !== undefined,
          joined: subagent.joined.has(toolCallId),
          ...(childThreadId === undefined ? {} : { childThreadId }),
          ...(childSubmissionId === undefined ? {} : { childSubmissionId }),
          ...(admission === undefined ? {} : { admission }),
        }),
      );
    }

    const isPreparedWorker = (call: OpenToolCallEvidence): boolean =>
      preparedKinds.get(toolCallPreparedRecordId(runId, call.turn, call.toolCallId)) ===
      "orchestration";

    const openWorkerCalls = allOpenCalls.filter(
      (call) => isPreparedWorker(call) && !unknownIds.has(call.toolCallId),
    );

    const openToolCalls = allOpenCalls.filter(
      (call) =>
        unknownIds.has(call.toolCallId) || (!isPreparedDelegation(call) && !isPreparedWorker(call)),
    );

    let declaredPendingBatch: DeclaredPendingBatchEvidence | undefined;

    if (lastResponse !== undefined && !preparedTurns.has(lastResponse.turn)) {
      const declared = yield* declaredApplicationCalls(lastResponse.messages);

      if (declared.length > 0 && !declared.some((call) => settledIds.has(call.id))) {
        declaredPendingBatch = DeclaredPendingBatchEvidence.make({
          turn: lastResponse.turn,
          callCount: declared.length,
        });
      }
    }
    const approvalsPending = requested.filter((pending) => !decidedIds.has(pending.toolCallId));

    return RecoveryEvidence.make({
      threadMaterialized: materialized,
      inputRecorded,
      abortRecorded,
      subagentLineageRecorded,
      openToolCalls,
      openDelegationCalls,
      openWorkerCalls,
      approvalsPending,
      joinedInputCovered: hostSubmissionId === undefined ? true : hostRespondedAfterInput,
      ...(recordedSettlementOutcome === undefined ? {} : { recordedSettlementOutcome }),
      ...(declaredPendingBatch === undefined ? {} : { declaredPendingBatch }),
      ...(hostSettlementOutcome === undefined ? {} : { hostSettlementOutcome }),
    });
  });

  /** Verify immutable preparation against the original declaration before any recovery side effect. */
  const validatePreparedCall = Effect.fnUntraced(function* (
    prepared: ToolCallPrepared,
    declared: Effect.Success<ReturnType<typeof declaredToolCalls>>,
    operations: ReadonlyArray<ToolOperation> | undefined,
  ) {
    const call = declared.application.find((call) => call.id === prepared.toolCallId);

    if (call === undefined || prepared.toolName !== call.name)
      return yield* RunJournalError.make({
        message: `Prepared Tool ${prepared.toolCallId} differs from its original declaration`,
      });

    const parameters = yield* decodePersisted(call.params).pipe(
      Effect.mapError((cause) =>
        RunJournalError.make({ message: "Invalid canonical Tool parameters", cause }),
      ),
    );

    const declarationDigest = yield* withCrypto(digestJson(parameters)).pipe(
      Effect.mapError((cause) =>
        RunJournalError.make({ message: "Cannot verify declared Tool parameters", cause }),
      ),
    );

    const preparedDigest = yield* withCrypto(digestJson(prepared.parameters)).pipe(
      Effect.mapError((cause) =>
        RunJournalError.make({ message: "Cannot verify prepared Tool parameters", cause }),
      ),
    );

    const operation = operations?.find((entry) => entry.toolCallId === prepared.toolCallId);

    if (
      prepared.parametersDigest !== declarationDigest ||
      preparedDigest !== declarationDigest ||
      (operation !== undefined &&
        ((prepared.executionClass !== undefined &&
          prepared.executionClass !== operation.executionClass) ||
          (prepared.executionKind ?? "ordinary") !== operation.executionKind ||
          (prepared.replay !== undefined && prepared.replay !== operation.replay)))
    )
      return yield* RunJournalError.make({
        message: `Prepared Tool ${prepared.toolCallId} differs from its original operation`,
      });
  });

  /**
   * The declared-but-unsettled Tool batch of the Run's LAST committed Turn (§2.4). Keyed on
   * SETTLED coverage deliberately: a call closed by a never-started/safe-retry `ToolCallResolved`
   * has authorized re-execution, so it stays in the resumed batch until its own `ToolCallSettled`
   * exists.
   */
  const pendingToolBatchFor = Effect.fn("DurableAgentRuntime.pendingToolBatchFor")(function* (
    records: ReadonlyArray<CanonicalRecordEnvelope>,
    runId: ReturnType<typeof runIdForSubmission>,
    completionTools: ReadonlyArray<string> = [],
  ): Effect.fn.Return<PendingToolBatch | undefined, RunJournalError> {
    let lastResponse:
      | {
          readonly turn: number;
          readonly messages: PersistedJson;
          readonly toolOperations?: ReadonlyArray<ToolOperation> | undefined;
          readonly toolParameterRejections?: ReadonlyArray<ToolParameterRejection> | undefined;
          readonly toolExposure?: Snapshot | undefined;
        }
      | undefined;

    const settledByCallId = new Map<
      string,
      {
        readonly recordId?: RecordId;
        readonly toolName?: string;
        readonly result: PersistedJson;
        readonly isFailure: boolean;
        readonly budgetRejected?: true;
        readonly toolSelection?: Selection | undefined;
      }
    >();

    for (const envelope of records) {
      const payload = envelope.record.payload;

      if (payload._tag === "ModelResponseRecorded" && payload.runId === runId) {
        if (lastResponse === undefined || payload.turn > lastResponse.turn) {
          settledByCallId.clear();
          lastResponse = {
            turn: payload.turn,
            messages: payload.messages,
            toolParameterRejections: payload.toolParameterRejections,
            toolOperations: payload.toolOperations,
            ...(payload.toolExposure === undefined ? {} : { toolExposure: payload.toolExposure }),
          };
        }
        continue;
      }
      if (payload._tag === "ToolCallSettled" && payload.runId === runId) {
        settledByCallId.set(payload.toolCallId, {
          recordId: envelope.record.recordId,
          toolName: payload.toolName,
          result: payload.result,
          isFailure: payload.isFailure,
          ...(payload.budgetRejected === true ? { budgetRejected: true } : {}),
          ...(payload.toolSelection === undefined ? {} : { toolSelection: payload.toolSelection }),
        });
      }
    }
    if (lastResponse === undefined) return undefined;
    const declared = yield* declaredToolCalls(lastResponse.messages);

    if (declared.application.length === 0) return undefined;
    const calls = declared.all;

    if (lastResponse.toolOperations !== undefined) {
      const identities = new Set<string>();

      for (const operation of lastResponse.toolOperations) {
        if (
          identities.has(operation.toolCallId) ||
          !declared.application.some(
            (call) => call.id === operation.toolCallId && call.name === operation.toolName,
          )
        )
          return yield* RunJournalError.make({
            message: "Operation evidence differs from the declared Tool batch",
          });
        identities.add(operation.toolCallId);
      }
      if (identities.size !== declared.application.length)
        return yield* RunJournalError.make({
          message: "Declared Tool batch has incomplete operation evidence",
        });
    }

    for (const {
      record: { payload },
    } of records) {
      if (
        payload._tag !== "ToolCallPrepared" ||
        payload.runId !== runId ||
        payload.turn !== lastResponse.turn
      )
        continue;
      yield* validatePreparedCall(payload, declared, lastResponse.toolOperations);
    }

    for (const part of declared.providerResults) {
      const result = yield* decodePersisted(part.result).pipe(
        Effect.mapError((cause) =>
          RunJournalError.make({ message: `Invalid canonical provider result ${part.id}`, cause }),
        ),
      );

      settledByCallId.set(part.id, { result, isFailure: part.isFailure });
    }

    const settled: Array<{
      id: string;
      result: PersistedJson;
      isFailure: boolean;
      budgetRejected?: true;
      toolSelection?: Selection | undefined;
    }> = [];

    for (const call of calls) {
      const recorded = settledByCallId.get(call.id);

      if (call.providerExecuted === true && recorded === undefined) {
        return yield* RunJournalError.make({
          message: `Pending Turn lacks canonical provider result for ${call.id}`,
        });
      }
      if (recorded !== undefined) {
        const { recordId, toolName, ...result } = recorded;

        if (
          call.providerExecuted !== true &&
          (toolName !== call.name ||
            recordId !==
              toolCallSettledRecordId(
                runId,
                lastResponse.turn,
                Schema.decodeSync(ToolCallId)(call.id),
              ))
        )
          return yield* RunJournalError.make({
            message: `Settled Tool ${call.id} differs from its original declaration`,
          });
        settled.push({ id: call.id, ...result });
      }
    }

    const completionCall = declared.application[0];

    const projectSettledCompletion =
      declared.application.length === 1 &&
      completionCall !== undefined &&
      completionTools.includes(completionCall.name) &&
      settledByCallId.get(completionCall.id)?.isFailure === false &&
      !records.some(
        ({ record }) => record.payload._tag === "RunCompleted" && record.payload.runId === runId,
      );

    if (settled.length >= calls.length && !projectSettledCompletion) return undefined;

    return {
      turn: lastResponse.turn,
      turnId: turnIdForRun(runId, lastResponse.turn),
      calls,
      settled,
      declaredIds: new Set(calls.map((call) => call.id)),
      responseRecordId: modelResponseRecordId(runId, lastResponse.turn),
      messages: lastResponse.messages,
      toolParameterRejections: lastResponse.toolParameterRejections,
      toolOperations: lastResponse.toolOperations,
      ...(lastResponse.toolExposure === undefined
        ? {}
        : { toolExposure: lastResponse.toolExposure }),
    };
  });

  /**
   * Records without the pending Turn's response and its partial results: the resumed Attempt's
   * canonical prompt boundary sits BEFORE the pending Turn, whose messages re-enter official
   * history through the engine's batch-resume continuation.
   */
  const withoutPendingBatch = (
    records: Stream.Stream<CanonicalRecordEnvelope, ThreadStoreError | ThreadNotMaterialized>,
    pending: PendingToolBatch,
    runId: ReturnType<typeof runIdForSubmission>,
  ): Stream.Stream<CanonicalRecordEnvelope, ThreadStoreError | ThreadNotMaterialized> =>
    records.pipe(
      Stream.filter((envelope) => {
        if (envelope.record.recordId === pending.responseRecordId) return false;
        const payload = envelope.record.payload;

        return !(
          payload._tag === "ToolCallSettled" &&
          payload.runId === runId &&
          pending.declaredIds.has(payload.toolCallId)
        );
      }),
    );

  /** Materialize without regressing a fence someone else already advanced. */
  const materializeAtLeast = (
    threadId: ThreadId,
    producerEpoch: ProducerEpoch,
  ): Effect.Effect<void, ThreadStoreError> =>
    store
      .materialize(ThreadMaterialization.make({ threadId, producerEpoch }))
      .pipe(Effect.catchTag("FenceRejected", () => Effect.void));

  const ensureThreadCreated = (
    threadId: ThreadId,
    agentId: AgentId,
    definitions: DefinitionDigests,
  ) =>
    ThreadInitialization.ensureThreadCreated(
      { producerId: config.producerId, deploymentId: config.deploymentId },
      threadId,
      agentId,
      definitions,
    ).pipe(Effect.provideService(ThreadStore, store), Effect.provideService(WakeScheduler, wake));

  const attemptContextFor = Effect.fn("DurableAgentRuntime.attemptContextFor")(function* (
    threadId: ThreadId,
    producerEpoch: ProducerEpoch,
  ): Effect.fn.Return<AttemptAppendContext, ThreadStoreError | ThreadNotMaterialized> {
    const tail = yield* store.inspectTail(ThreadTailRequest.make({ threadId }));
    const tailRef = yield* Ref.make({ sequence: tail.tailSequence, digest: tail.tailDigest });
    const gate = yield* Semaphore.make(1);

    return { threadId, producerEpoch, tailRef, gate };
  });

  /**
   * Existing ownership-free settlement protocol for queued aborts and joined outcomes.
   * Its canonical settlement reservation authorizes the append; it never authorizes tool
   * execution, unknown-resolution appends, or repair audits beside a live writer.
   */
  const attemptContextAtTail = Effect.fn("DurableAgentRuntime.attemptContextAtTail")(function* (
    threadId: ThreadId,
  ): Effect.fn.Return<AttemptAppendContext, ThreadStoreError | ThreadNotMaterialized> {
    const tail = yield* store.inspectTail(ThreadTailRequest.make({ threadId }));
    const tailRef = yield* Ref.make({ sequence: tail.tailSequence, digest: tail.tailDigest });
    const gate = yield* Semaphore.make(1);

    return { threadId, producerEpoch: tail.producerEpoch, tailRef, gate };
  });

  const appendBatch = (ctx: AttemptAppendContext, batch: CanonicalBatch) =>
    ctx.gate.withPermits(1)(
      Effect.gen(function* () {
        // Bounded fence refresh on a stale-tail conflict: `AppendConflict(reason: "tail")`
        // means this batch was NOT appended — another legitimate same-epoch writer advanced
        // the log after this context read its tail (a parent's establishment repair appending
        // the deterministic lineage/start records to a child Thread while the child's
        // own Attempt runs — routine when the child lives in its own Durable Object). The
        // retry re-reads the ACTUAL tail the conflict carries and re-appends under the SAME
        // epoch: a superseded epoch still fails `FenceRejected` (DUR-006 untouched) and the
        // batch/record identity dedupe absorbs true replays. Treating a stale-tail conflict
        // as "already appended" at the tolerant call sites would let a settlement finalize
        // WITHOUT its canonical record.
        for (let refresh = 0; ; refresh++) {
          const tail = yield* Ref.get(ctx.tailRef);

          const result = yield* store
            .append(
              FencedAppendRequest.make({
                threadId: ctx.threadId,
                batch,
                expectedTailSequence: tail.sequence,
                expectedTailDigest: tail.digest,
                producerEpoch: ctx.producerEpoch,
              }),
            )
            .pipe(
              Effect.catchTag("AppendConflict", (conflict) =>
                conflict.reason === "tail" &&
                conflict.actualTailSequence !== undefined &&
                conflict.actualTailDigest !== undefined &&
                refresh < MAX_APPEND_FENCE_REFRESHES
                  ? Effect.as(
                      Ref.set(ctx.tailRef, {
                        sequence: conflict.actualTailSequence,
                        digest: conflict.actualTailDigest,
                      }),
                      undefined,
                    )
                  : Effect.fail(conflict),
              ),
            );

          if (result !== undefined) {
            yield* Ref.set(ctx.tailRef, {
              sequence: result.lastSequence,
              digest: result.tailDigest,
            });
            // Canonical storage is already committed. This hint may be lost or duplicated, but
            // it lets scoped progress waiters re-read promptly without making memory authoritative.
            yield* wake.notify(ctx.threadId);

            return result;
          }
        }
      }),
    );

  /** Append the canonical `AbortRequested` record; an identity conflict means it already exists. */
  const appendAbortRecord = Effect.fn("DurableAgentRuntime.appendAbortRecord")(function* (
    ctx: AttemptAppendContext,
    intent: AbortIntent,
  ) {
    const envelope = yield* makeEnvelope(
      submissionAbortRecordId(intent.submissionId),
      AbortRequested.make({
        submissionId: intent.submissionId,
        author: intent.author,
        reason: intent.reason,
      }),
    );

    yield* appendBatch(
      ctx,
      CanonicalBatch.make({
        batchId: submissionAbortBatchId(intent.submissionId),
        producerId: config.producerId,
        records: [envelope],
      }),
    ).pipe(
      Effect.catchTag("AppendConflict", () => Effect.void),
      Effect.asVoid,
    );
  });

  /**
   * Append the canonical `ToolCallUnknown` audit records for the given open calls, grouped into
   * one batch per Turn (batch `mark-unknown:{sid}:{turn}`). Canonical-only: the operational
   * ledger marking is a separate step so abort settlement can record the uncertainty WITHOUT
   * blocking the lane (durability §13: abort never asserts external rollback).
   */
  const appendUnknownRecords = Effect.fn("DurableAgentRuntime.appendUnknownRecords")(function* (
    ctx: AttemptAppendContext,
    submissionId: SubmissionId,
    knownIds: Set<string>,
    calls: ReadonlyArray<OpenToolCallEvidence>,
    reason: string,
  ): Effect.fn.Return<void, DurableWorkerFailure> {
    const runId = runIdForSubmission(submissionId);
    const byTurn = new Map<number, Array<OpenToolCallEvidence>>();

    for (const call of calls) {
      const group = byTurn.get(call.turn);

      if (group === undefined) byTurn.set(call.turn, [call]);
      else group.push(call);
    }
    for (const [turn, group] of byTurn) {
      const missing = group.filter(
        (call) => !knownIds.has(toolCallUnknownRecordId(runId, turn, call.toolCallId)),
      );

      const first = missing[0];

      if (first === undefined) continue;
      const envelopes: Array<RecordEnvelope> = [];

      for (const call of missing) {
        envelopes.push(
          yield* makeEnvelope(
            toolCallUnknownRecordId(runId, turn, call.toolCallId),
            ToolCallUnknown.make({
              runId,
              turn: call.turn,
              toolCallId: call.toolCallId,
              toolName: call.toolName,
              reason,
            }),
          ),
        );
      }
      const head = envelopes[0];

      if (head === undefined) continue;
      // An identity conflict means another pass already recorded the same uncertainty.
      yield* appendBatch(
        ctx,
        CanonicalBatch.make({
          batchId: markUnknownBatchId(submissionId, turn),
          producerId: config.producerId,
          records: [head, ...envelopes.slice(1)],
        }),
      ).pipe(
        Effect.catchTag("AppendConflict", () => Effect.void),
        Effect.asVoid,
      );
      for (const call of missing) {
        knownIds.add(toolCallUnknownRecordId(runId, turn, call.toolCallId));
      }
    }
  });

  /**
   * Close one open Tool Call canonically: the recovered result (when one exists) settles under
   * the per-call late-settle batch (`turn-results:{runId}:{turn}:{toolCallId}`), then the
   * `ToolCallResolved` audit records who authorized the closure and how (DUR-017). Record
   * identity dedupes double-settles across the batch path and this path; an `AppendConflict`
   * means an identical closure (modulo timestamp) already committed.
   */
  const appendClosedCall = Effect.fn("DurableAgentRuntime.appendClosedCall")(function* (
    ctx: AttemptAppendContext,
    submissionId: SubmissionId,
    knownIds: Set<string>,
    call: OpenToolCallEvidence,
    closure: {
      readonly result?: { readonly value: PersistedJson; readonly isFailure: boolean } | undefined;
      readonly resolution: ToolCallResolution;
      readonly author: string;
      readonly reason: string;
    },
  ): Effect.fn.Return<void, DurableWorkerFailure> {
    const runId = runIdForSubmission(submissionId);

    const swallowIdentityConflict = (effect: ReturnType<typeof appendBatch>) =>
      effect.pipe(
        Effect.catchTag("AppendConflict", () => Effect.void),
        Effect.asVoid,
      );

    if (closure.result !== undefined) {
      const settledId = toolCallSettledRecordId(runId, call.turn, call.toolCallId);

      if (!knownIds.has(settledId)) {
        const envelope = yield* makeEnvelope(
          settledId,
          ToolCallSettled.make({
            runId,
            toolCallId: call.toolCallId,
            toolName: call.toolName,
            result: closure.result.value,
            isFailure: closure.result.isFailure,
          }),
        );

        yield* swallowIdentityConflict(
          appendBatch(
            ctx,
            CanonicalBatch.make({
              batchId: toolCallResultBatchId(runId, call.turn, call.toolCallId),
              producerId: config.producerId,
              records: [envelope],
            }),
          ),
        );
        knownIds.add(settledId);
      }
    }
    const resolvedId = toolCallResolvedRecordId(runId, call.turn, call.toolCallId);

    if (!knownIds.has(resolvedId)) {
      const envelope = yield* makeEnvelope(
        resolvedId,
        ToolCallResolved.make({
          runId,
          toolCallId: call.toolCallId,
          resolution: closure.resolution,
          author: closure.author,
          reason: closure.reason,
        }),
      );

      yield* swallowIdentityConflict(
        appendBatch(
          ctx,
          CanonicalBatch.make({
            batchId: toolCallResolutionBatchId(submissionId, call.toolCallId),
            producerId: config.producerId,
            records: [envelope],
          }),
        ),
      );
      knownIds.add(resolvedId);
    }
  });

  /**
   * Reconcile-then-mark (durability §10, DUR-009) over one Submission's open ordinary Tool Calls.
   *
   * Per open call, in order of authority: a durable DUR-017 resolution intent is applied
   * canonically (recovered results settle without execution; never-happened/safe-retry authorize
   * re-execution through the batch resume); a declared `idempotent` execution class is the
   * external idempotency contract and needs no proof; otherwise the registered `ToolReconciler`
   * is consulted — `NeverStarted`/`SafeToRetry` are point-in-time proofs (nothing is recorded;
   * every later pass re-proves them), `CompletedWithResult` becomes canonical supplier truth,
   * `Uncertain` collects for Unknown marking, and a reconciler FAILURE is no proof at all (the
   * call stays open and blocked without being marked). Nothing here ever executes a handler.
   */
  const reconcileOpenCalls = Effect.fn("DurableAgentRuntime.reconcileOpenCalls")(function* (
    ctx: AttemptAppendContext,
    submission: SubmissionSnapshot,
    snapshot: RecoverySnapshot,
    records: ReadonlyArray<CanonicalRecordEnvelope>,
    openCalls: ReadonlyArray<OpenToolCallEvidence>,
    knownIds: Set<string>,
    current?: {
      readonly definition: Agent.AnyDefinition;
      readonly contracts: Readonly<Record<string, Digest>>;
    },
  ): Effect.fn.Return<OpenCallReview, DurableWorkerFailure> {
    const submissionId = submission.submissionId;
    const runId = runIdForSubmission(submissionId);

    yield* pendingToolBatchFor(records, runId);
    const operations = operationsFor(records, runId);
    const preparedByCallId = new Map<string, ToolCallPrepared>();

    for (const { record } of records) {
      const payload = record.payload;

      if (
        payload._tag === "ToolCallPrepared" &&
        payload.runId === runId &&
        openCalls.some(
          (call) => call.toolCallId === payload.toolCallId && call.turn === payload.turn,
        )
      ) {
        if (
          preparedByCallId.has(payload.toolCallId) ||
          record.recordId !== toolCallPreparedRecordId(runId, payload.turn, payload.toolCallId)
        )
          return yield* RunJournalError.make({
            message: `Prepared Tool ${payload.toolCallId} has inconsistent canonical identity`,
          });
        preparedByCallId.set(payload.toolCallId, payload);
      }
    }
    // Validate all open declarations before the first reconciler call. A missing response or
    // a damaged turn number must never bypass the original parameters/identity checks.
    for (const call of openCalls) {
      const prepared = preparedByCallId.get(call.toolCallId);

      const responses = records.filter(
        ({ record }) =>
          record.payload._tag === "ModelResponseRecorded" &&
          record.payload.runId === runId &&
          record.payload.turn === call.turn,
      );

      const response = responses[0]?.record;

      if (
        prepared === undefined ||
        prepared.turn !== call.turn ||
        prepared.toolName !== call.toolName ||
        responses.length !== 1 ||
        response?.payload._tag !== "ModelResponseRecorded" ||
        response.recordId !== modelResponseRecordId(runId, call.turn) ||
        response.payload.turnId !== turnIdForRun(runId, call.turn)
      )
        return yield* RunJournalError.make({
          message: `Prepared Tool ${call.toolCallId} has no unique original response`,
        });
      if (
        (yield* withCrypto(digestJson(response.payload.messages))) !==
        response.payload.messagesDigest
      )
        return yield* RunJournalError.make({
          message: `Original response for Tool ${call.toolCallId} has an invalid digest`,
        });
      yield* validatePreparedCall(
        prepared,
        yield* declaredToolCalls(response.payload.messages),
        response.payload.toolOperations,
      );
    }

    const intents = new Map(
      snapshot.unknownResolutions.map((intent) => [intent.toolCallId, intent]),
    );

    const review: OpenCallReview = { uncertain: [], unproven: [], retryable: [], recovered: 0 };
    let recovered = 0;

    for (const call of openCalls) {
      const prepared = preparedByCallId.get(call.toolCallId);
      const operation = operations.get(call.toolCallId);

      const supported = supportsOperation(submission, call, operation, prepared, current);

      const intent = intents.get(call.toolCallId);
      const author = intent?.author ?? RECONCILER_AUTHOR;

      const reason =
        intent?.reason ?? "A registered reconciliation policy recovered the external outcome";

      const neverStarted = Effect.gen(function* () {
        if (current === undefined) {
          // Low-level drivers supply their current Agent only when claiming. Missing metadata
          // cannot prove retirement or authorize execution; the claimant checks the contract.
          review.unproven.push(call);

          return;
        }
        if (supported) {
          review.retryable.push(call);

          return;
        }

        const unavailable = yield* Schema.encodeEffect(ToolUnavailable)(
          ToolUnavailable.make({
            toolName: call.toolName,
            execution: "not-executed",
            message:
              "This operation never started and its original implementation is unavailable. Continue with the current tools.",
          }),
        ).pipe(Effect.flatMap(decodePersisted), Effect.orDie);

        yield* hit("tools:before-unavailable-append");
        yield* appendClosedCall(ctx, submissionId, knownIds, call, {
          result: { value: unavailable, isFailure: true },
          resolution: "never-started",
          author,
          reason,
        });
        yield* hit("tools:after-unavailable-append");
        recovered += 1;
      });

      if (intent !== undefined) {
        switch (intent.resolution._tag) {
          case "AbortSubmission":
            continue;
          case "CompletedWithResult": {
            yield* appendClosedCall(ctx, submissionId, knownIds, call, {
              result: { value: intent.resolution.result, isFailure: intent.resolution.isFailure },
              resolution: intent.resolution.isFailure
                ? "failed-with-error"
                : "completed-with-result",
              author,
              reason,
            });
            recovered += 1;
            continue;
          }
          case "NeverHappened": {
            yield* neverStarted;
            continue;
          }
          case "SafeToRetry": {
            // Permission to repeat the original operation is not proof it never happened.
            if (current === undefined) review.unproven.push(call);
            else if (supported) review.retryable.push(call);
            else review.uncertain.push(call);
            continue;
          }
        }
      }
      const tool = current?.definition.toolkit.tools[call.toolName];

      if (
        current === undefined &&
        (operation?.executionClass ?? prepared?.executionClass) === "idempotent"
      ) {
        review.unproven.push(call);
        continue;
      }
      if (supported && tool !== undefined && getToolExecutionClass(tool) === "idempotent") {
        review.retryable.push(call);
        continue;
      }
      if (prepared === undefined) {
        review.unproven.push(call);
        continue;
      }

      const reconciled = yield* reconciler
        .reconcile(
          PreparedToolCallEvidence.make({
            threadId: submission.threadId,
            submissionId,
            runId,
            turn: prepared.turn,
            toolCallId: prepared.toolCallId,
            toolName: prepared.toolName,
            parameters: prepared.parameters,
            parametersDigest: prepared.parametersDigest,
            ...(prepared.executionKind === undefined
              ? {}
              : { executionKind: prepared.executionKind }),
            ...(prepared.executionClass === undefined
              ? {}
              : { executionClass: prepared.executionClass }),
            ...(prepared.replay === undefined ? {} : { replay: prepared.replay }),
          }),
        )
        .pipe(
          Effect.map(Option.some),
          Effect.catchTag("ToolReconcilerError", () => Effect.succeed(Option.none())),
        );

      if (Option.isNone(reconciled)) {
        review.unproven.push(call);
        continue;
      }
      const decision = reconciled.value;

      switch (decision._tag) {
        case "CompletedWithResult": {
          yield* appendClosedCall(ctx, submissionId, knownIds, call, {
            result: { value: decision.result, isFailure: decision.isFailure },
            resolution: decision.isFailure ? "failed-with-error" : "completed-with-result",
            author,
            reason,
          });
          recovered += 1;
          continue;
        }
        case "NeverStarted": {
          yield* neverStarted;
          continue;
        }
        case "SafeToRetry": {
          if (current === undefined) review.unproven.push(call);
          else if (supported) review.retryable.push(call);
          else review.uncertain.push(call);
          continue;
        }
        case "Uncertain": {
          review.uncertain.push(call);
          continue;
        }
      }
    }

    return { ...review, recovered };
  });

  /**
   * Record the Unknown Outcomes durably: canonical `ToolCallUnknown` audit records FIRST
   * (history is the recovery truth, DUR-015), then the ownership-free ledger marking that blocks
   * the lane until the authorized DUR-017 resolution path covers every marked call.
   */
  const markCallsUnknown = Effect.fn("DurableAgentRuntime.markCallsUnknown")(function* (
    ctx: AttemptAppendContext,
    submissionId: SubmissionId,
    knownIds: Set<string>,
    calls: ReadonlyArray<OpenToolCallEvidence>,
    reason: string,
  ): Effect.fn.Return<void, DurableWorkerFailure> {
    const first = calls[0];

    if (first === undefined) return;
    yield* appendUnknownRecords(ctx, submissionId, knownIds, calls, reason);
    yield* ledger.markUnknown(
      MarkUnknownRequest.make({
        submissionId,
        toolCallIds: [first.toolCallId, ...calls.slice(1).map((call) => call.toolCallId)],
        reason,
      }),
    );
  });

  /**
   * Plan step 2: append the deterministic `UserInputRecorded` record (batch idempotency makes it
   * exactly-once canonical, DUR-007) and mark it applied. When canonical history already carries
   * the record — an earlier Attempt crashed after its append — only the ledger marker is repaired
   * (DUR-015/DUR-016).
   */
  const applyCanonicalInput = Effect.fn("DurableAgentRuntime.applyCanonicalInput")(function* (
    ctx: AttemptAppendContext,
    submission: SubmissionSnapshot,
    tokenRef: Ref.Ref<OwnershipToken>,
    records: ReadonlyArray<CanonicalRecordEnvelope>,
    inputApplied: RecoverySnapshot["inputApplied"],
  ) {
    const submissionId = submission.submissionId;
    const recordId = submissionInputRecordId(submissionId);
    const existing = records.find((envelope) => envelope.record.recordId === recordId);

    if (existing !== undefined) {
      if (inputApplied === undefined) {
        const ownershipToken = yield* Ref.get(tokenRef);

        yield* ledger.markInputApplied(
          MarkInputAppliedRequest.make({
            submissionId,
            ownershipToken,
            recordId,
            sequence: existing.sequence,
          }),
        );
      }

      return;
    }

    const envelope = yield* makeEnvelope(
      recordId,
      UserInputRecorded.make({
        submissionId,
        kind: "user",
        runId: runIdForSubmission(submissionId),
        input: submission.inputPayload,
        ...(submission.messageAdmission === undefined
          ? {}
          : { messageAdmission: submission.messageAdmission }),
      }),
    );

    const result = yield* appendBatch(
      ctx,
      CanonicalBatch.make({
        batchId: submissionInputBatchId(submissionId),
        producerId: config.producerId,
        records: [envelope],
      }),
    );

    yield* hit("input:after-canonical-append");
    const ownershipToken = yield* Ref.get(tokenRef);

    yield* ledger.markInputApplied(
      MarkInputAppliedRequest.make({
        submissionId,
        ownershipToken,
        recordId,
        sequence: result.firstSequence,
      }),
    );
  });

  const canonicalRunStartFromRecords = Effect.fn(
    "DurableAgentRuntime.canonicalRunStartFromRecords",
  )(function* (records: ReadonlyArray<CanonicalRecordEnvelope>, runId: RunId) {
    const recordId = runStartedRecordId(runId);

    const starts = records.filter(
      ({ record }) => record.payload._tag === "RunStarted" && record.payload.runId === runId,
    );

    const existing = records.find(({ record }) => record.recordId === recordId);

    if (
      starts.length > 1 ||
      (starts.length === 1 && starts[0]?.record.recordId !== recordId) ||
      (existing !== undefined &&
        (existing.record.payload._tag !== "RunStarted" || existing.record.payload.runId !== runId))
    ) {
      return yield* RunJournalError.make({
        message: `Run ${runId} has conflicting start evidence`,
      });
    }

    return existing?.record;
  });

  const ensureRunStarted = Effect.fn("DurableAgentRuntime.ensureRunStarted")(function* (
    ctx: AttemptAppendContext,
    submission: SubmissionSnapshot,
    maxDurationMillis: number,
    records: ReadonlyArray<CanonicalRecordEnvelope>,
  ) {
    const runId = runIdForSubmission(submission.submissionId);
    const recordId = runStartedRecordId(runId);
    const existing = yield* canonicalRunStartFromRecords(records, runId);
    let start: RecordEnvelope;
    let allowance = maxDurationMillis;

    if (existing !== undefined && existing.payload._tag === "RunStarted") {
      allowance = existing.payload.maxDurationMillis;
      start = existing;
    } else {
      const executionStarted = records.some(
        ({ record: { payload } }) =>
          payload._tag !== "UserInputRecorded" && "runId" in payload && payload.runId === runId,
      );

      if (executionStarted) {
        return yield* RunJournalError.make({
          message: `Run ${runId} has execution records but no canonical start; retain the request for evidence repair`,
        });
      }
      start = yield* makeEnvelope(
        recordId,
        RunStartedRecord.make({ runId, maxDurationMillis, policyAccountingVersion: 1 }),
      );
      yield* hit("run:before-start-append");
      yield* appendBatch(
        ctx,
        CanonicalBatch.make({
          batchId: runStartedBatchId(runId),
          producerId: config.producerId,
          records: [start],
        }),
      );
      yield* hit("run:after-start-append");
    }

    return {
      startedAt: start.createdAt,
      // Downtime is not execution. Reuse the original per-Attempt allowance without
      // moving the Run start or resetting journaled turn, Tool or cost accounting.
      deadline: records.some(
        ({ record }) =>
          record.payload._tag === "RunDurationExhausted" && record.payload.runId === runId,
      )
        ? start.createdAt
        : DateTime.addDuration(yield* DateTime.now, Duration.millis(allowance)),
    };
  });

  /**
   * Settle ONE joined Submission with its host Run's outcome (plan §2.5, DUR-002: every accepted
   * Submission is owed its own settlement). The same recoverable reserve → append → finalize
   * sequence as `terminalize`, with two joined-specific rules: the canonical record's `runId` is
   * the HOST Run (the joined input was consumed there), and the reservation is authorized by the
   * recorded host linkage instead of lane ownership — a `joined` lane is never worker-claimable,
   * so no ownership token can exist for it. Each step is idempotent; recovery completes any
   * prefix (`AppendReservedSettlement` / `FinalizeLedgerFromHistory` / `SettleJoinedWithHost`).
   */
  /**
   * Cross-lane drive-forward after one child Submission settles (spec §12 step 10): the child's
   * canonical Settlement is already durable, so the idempotent `recordChildSettled` wake is the
   * durable notification — `suspended(WaitingForChild) → input-applied` once every listed child
   * settled — and the parent-lane wake hint is liveness only. Invoked after the exact canonical
   * append but BEFORE child ledger finalization: once a child may become terminal, its parent's
   * durable marker and maintenance generation already exist. Finalization replays the same
   * notification for single-store parent re-suspension races; `ResumeWaitingParent` remains the
   * repair for older data and any already-recorded canonical settlement.
   */
  const notifyParentOfChildSettlement = Effect.fn(
    "DurableAgentRuntime.notifyParentOfChildSettlement",
  )(function* (
    submission: SubmissionSnapshot,
    record: RecordEnvelope,
  ): Effect.fn.Return<void, LedgerError> {
    const admission = submission.messageAdmission;
    const worker = submission.workerAdmission;

    const key =
      admission === undefined
        ? worker === undefined
          ? undefined
          : {
              ownerThreadId: worker.origin.source.threadId,
              messageId: worker.messageId,
            }
        : Schema.is(MessageAdmission)(admission)
          ? admission.message
          : {
              ownerThreadId:
                admission._tag === "WorkerCompletion"
                  ? admission.report.worker.threadId
                  : admission.worker.threadId,
              messageId: submission.idempotencyKey,
            };

    // Commit the destination's exact canonical acknowledgement at the source before
    // making the ledger terminal. A failed/lost response is replayed during recovery.
    if (key !== undefined && Option.isSome(deliveries)) {
      const settled = yield* settlementPayloadFromRecord(record, submission.submissionId);

      yield* deliveries.value
        .change(key, {
          _tag: "Complete",
          nowMillis: yield* Clock.currentTimeMillis,
          admissionKey: submission.idempotencyKey,
          inputDigest: submission.inputDigest,
          receipt: Receipt.make({
            threadId: submission.threadId,
            submissionId: submission.submissionId,
            receiptId: submission.receiptId,
            queueSequence: submission.queueSequence,
          }),
          settlement: Settlement.make({
            submissionId: settled.submissionId,
            receiptId: settled.receiptId,
            settlementId: settled.settlementId,
            outcome: settled.outcome,
            settledAt: record.createdAt,
            ...(settled.outcome === "failed" ? { failure: settled.result } : {}),
            ...(settled.usageSummary === undefined ? {} : { usageSummary: settled.usageSummary }),
            ...(settled.runDisposition === undefined
              ? {}
              : { runDisposition: settled.runDisposition }),
          }),
        })
        .pipe(
          Effect.catchCause((cause) =>
            Effect.failCause(
              Cause.map(cause, (error) =>
                LedgerError.make({
                  operation: "delivery-completion",
                  message: "Destination acknowledgement remains pending",
                  cause: error,
                }),
              ),
            ),
          ),
        );
    }
    if (submission.workerAdmission?.origin.reporting?.mode === "standard")
      yield* updateRuntime.repair(submission.threadId).pipe(
        Effect.mapError(() =>
          LedgerError.make({
            operation: "update-delivery",
            message: "Update delivery remains pending",
          }),
        ),
      );
    yield* workerRuntime
      .completeInput(submission)
      .pipe(
        Effect.mapError((cause) =>
          LedgerError.make({ operation: "worker-completion", message: cause.reason, cause }),
        ),
      );
    const linkage = submission.parentLinkage;

    if (linkage === undefined) return;
    yield* ledger.recordChildSettled(
      ChildSettledNotification.make({
        parentSubmissionId: linkage.parentSubmissionId,
        childSubmissionId: submission.submissionId,
      }),
    );

    const parent = yield* ledger.lookup(
      SubmissionLookupById.make({ submissionId: linkage.parentSubmissionId }),
    );

    if (Option.isSome(parent)) {
      yield* wake.notify(parent.value.threadId);
    }
  });

  const settleOneJoined = Effect.fn("DurableAgentRuntime.settleOneJoined")(function* (
    ctx: AttemptAppendContext,
    hostSettlement: SubmissionSettledRecord,
    joined: RecoverySnapshot,
  ): Effect.fn.Return<Settlement, DurableWorkerFailure> {
    const hostSubmissionId = hostSettlement.submissionId;
    const outcome = hostSettlement.outcome;
    const submission = joined.submission;
    const submissionId = submission.submissionId;
    const settlementId = submissionSettlementId(submissionId);
    let record: RecordEnvelope;

    if (joined.reservation !== undefined) {
      // A prior pass already reserved the exact outcome: re-append the STORED record so the
      // batch replay is byte-identical (DUR-011).
      record = joined.reservation.record;
    } else {
      const payload = yield* Schema.decodeEffect(SubmissionSettledRecord)(
        SubmissionSettled.make({
          submissionId,
          settlementId,
          receiptId: submission.receiptId,
          outcome,
          runId: runIdForSubmission(hostSubmissionId),
          ...(hostSettlement.outcome === "failed" ? { result: hostSettlement.result } : {}),
        }),
      ).pipe(Effect.orDie);

      const envelope = yield* makeEnvelope(submissionSettlementRecordId(submissionId), payload);
      // The envelope was constructed from validated parts, so an encode failure is a defect.
      const encoded = yield* Schema.encodeEffect(RecordEnvelope)(envelope).pipe(Effect.orDie);
      const recordDigest = yield* withCrypto(digestJson(encoded));

      const reserved = yield* ledger
        .reserveSettlement(
          SettlementReservation.make({
            submissionId,
            ownershipToken: JOINED_SETTLEMENT_TOKEN,
            settlementId,
            outcome,
            record: envelope,
            recordDigest,
          }),
        )
        .pipe(
          // A racing pass reserved first (its envelope differs only by `createdAt`): the
          // stored reservation with the same host-derived outcome is the exact record owed.
          Effect.catchTag("SettlementConflict", (conflict) =>
            Effect.gen(function* () {
              const current = yield* ledger.loadRecoverySnapshot(
                RecoverySnapshotRequest.make({ submissionId }),
              );

              const reservation = current.reservation;

              if (reservation === undefined || reservation.outcome !== outcome) {
                return yield* conflict;
              }

              return reservation;
            }),
          ),
        );

      record = reserved.record;
      yield* hit("terminalize:after-reserve");
    }
    yield* appendBatch(
      ctx,
      CanonicalBatch.make({
        batchId: submissionSettlementBatchId(submissionId),
        producerId: config.producerId,
        records: [record],
      }),
    ).pipe(
      Effect.catchTag("AppendConflict", () => Effect.void),
      Effect.asVoid,
    );
    yield* hit("terminalize:after-canonical-append");
    yield* notifyParentOfChildSettlement(submission, record);

    const settlement = yield* ledger.finalizeSettlement(
      SettlementFinalization.make({ submissionId, settlementId }),
    );

    yield* wake.notify(submission.threadId);
    yield* notifyParentOfChildSettlement(submission, record);

    return settlement;
  });

  /**
   * Terminalize joined-settlement loop (plan §2.5): after the host's own reserve → append →
   * finalize, every Submission joined to the host settles with the host outcome. `terminalizing`
   * rows are a prior pass's crashed joined settlement (reservation committed, finalize lost) and
   * complete here too; `joining` rows were never consumed and are recovery's to revert, and
   * settled rows are done. A crash anywhere in the loop leaves a classifiable prefix
   * (`SettleJoinedWithHost` / `AppendReservedSettlement` finish the rest).
   */
  const settleJoinedSubmissions = Effect.fn("DurableAgentRuntime.settleJoinedSubmissions")(
    function* (
      ctx: AttemptAppendContext,
      hostSettlement: SubmissionSettledRecord,
    ): Effect.fn.Return<void, DurableWorkerFailure> {
      const hostSubmissionId = hostSettlement.submissionId;

      const snapshot = yield* ledger.loadRecoverySnapshot(
        RecoverySnapshotRequest.make({ submissionId: hostSubmissionId }),
      );

      for (const join of snapshot.joins) {
        if (join.state !== "joined" && join.state !== "terminalizing") continue;

        const joinedSnapshot = yield* ledger.loadRecoverySnapshot(
          RecoverySnapshotRequest.make({ submissionId: join.submissionId }),
        );

        if (joinedSnapshot.submission.state === "settled") continue;
        yield* settleOneJoined(ctx, hostSettlement, joinedSnapshot);
      }
    },
  );

  /**
   * Terminalization (durability §12, DUR-011): reserve the single exact settlement record, append
   * that exact record canonically, finalize the ledger, release the lane, and hint waiters.
   * Submissions joined to this host Run settle with the host outcome immediately after
   * (plan §2.5); recovery completes any prefix of that loop.
   */
  const terminalize = Effect.fn("DurableAgentRuntime.terminalize")(function* (
    ctx: AttemptAppendContext,
    submission: SubmissionSnapshot,
    tokenRef: Ref.Ref<OwnershipToken>,
    outcome: AttemptOutcome,
    includeRunId: boolean,
    afterCanonical?: Effect.Effect<void, DurableWorkerFailure>,
  ): Effect.fn.Return<Settlement, DurableWorkerFailure> {
    const submissionId = submission.submissionId;
    const settlementId = submissionSettlementId(submissionId);

    const payload = yield* Schema.decodeEffect(SubmissionSettledRecord)(
      SubmissionSettled.make({
        submissionId,
        settlementId,
        receiptId: submission.receiptId,
        outcome: outcome._tag,
        ...(includeRunId ? { runId: runIdForSubmission(submissionId) } : {}),
        ...(outcome._tag === "aborted" ? {} : { result: outcome.result }),
        ...(includeRunId &&
        outcome._tag === "completed" &&
        outcome.finishReason === undefined &&
        outcome.runDisposition !== undefined
          ? { runDisposition: outcome.runDisposition }
          : {}),
        ...(outcome._tag === "completed" && outcome.finishReason !== undefined
          ? { finishReason: outcome.finishReason }
          : {}),
        ...(outcome._tag === "completed" && outcome.exhausted !== undefined
          ? { exhausted: outcome.exhausted }
          : {}),
        ...(outcome._tag === "failed" && outcome.policyLimit !== undefined
          ? { policyLimit: outcome.policyLimit }
          : {}),
        ...(outcome.usageSummary === undefined ? {} : { usageSummary: outcome.usageSummary }),
        ...(includeRunId &&
        outcome.uncommittedModelUsage !== undefined &&
        outcome.uncommittedModelUsage.length > 0
          ? { uncommittedModelUsage: outcome.uncommittedModelUsage }
          : {}),
      }),
    ).pipe(Effect.orDie);

    const record = yield* makeEnvelope(submissionSettlementRecordId(submissionId), payload);
    // The envelope was constructed from validated parts, so an encode failure is a defect.
    const encoded = yield* Schema.encodeEffect(RecordEnvelope)(record).pipe(Effect.orDie);
    const recordDigest = yield* withCrypto(digestJson(encoded));
    const ownershipToken = yield* Ref.get(tokenRef);

    const reserved = yield* ledger.reserveSettlement(
      SettlementReservation.make({
        submissionId,
        ownershipToken,
        settlementId,
        outcome: outcome._tag,
        record,
        recordDigest,
      }),
    );

    yield* hit("terminalize:after-reserve");
    yield* appendBatch(
      ctx,
      CanonicalBatch.make({
        batchId: submissionSettlementBatchId(submissionId),
        producerId: config.producerId,
        records: [reserved.record],
      }),
    ).pipe(
      Effect.catchTag("AppendConflict", () => Effect.void),
      Effect.asVoid,
    );
    yield* hit("terminalize:after-canonical-append");
    yield* notifyParentOfChildSettlement(submission, reserved.record);
    if (afterCanonical !== undefined) yield* afterCanonical;

    const settlement = yield* ledger.finalizeSettlement(
      SettlementFinalization.make({ submissionId, settlementId }),
    );

    const canonicalSettlement = yield* settlementPayloadFromRecord(reserved.record, submissionId);

    yield* wake.notify(submission.threadId);
    yield* notifyParentOfChildSettlement(submission, reserved.record);
    yield* settleJoinedSubmissions(ctx, canonicalSettlement);

    return materializeSettlement(settlement, reserved.record);
  });

  /** Complete a previously reserved settlement: append the EXACT reserved record, then finalize. */
  const completeReservation = Effect.fn("DurableAgentRuntime.completeReservation")(function* (
    ctx: AttemptAppendContext,
    submission: SubmissionSnapshot,
    reservation: NonNullable<RecoverySnapshot["reservation"]>,
    alreadyRecorded: boolean,
  ): Effect.fn.Return<Settlement, DurableWorkerFailure> {
    if (!alreadyRecorded) {
      yield* appendBatch(
        ctx,
        CanonicalBatch.make({
          batchId: submissionSettlementBatchId(submission.submissionId),
          producerId: config.producerId,
          records: [reservation.record],
        }),
      ).pipe(
        Effect.catchTag("AppendConflict", () => Effect.void),
        Effect.asVoid,
      );
      yield* hit("terminalize:after-canonical-append");
    }
    yield* notifyParentOfChildSettlement(submission, reservation.record);

    const settlement = yield* ledger.finalizeSettlement(
      SettlementFinalization.make({
        submissionId: submission.submissionId,
        settlementId: reservation.settlementId,
      }),
    );

    const canonicalSettlement = yield* settlementPayloadFromRecord(
      reservation.record,
      submission.submissionId,
    );

    yield* wake.notify(submission.threadId);
    yield* notifyParentOfChildSettlement(submission, reservation.record);
    yield* settleJoinedSubmissions(ctx, canonicalSettlement);

    return materializeSettlement(settlement, reservation.record);
  });

  /** Canonical settlement exists: rebuild the ledger from history, never the reverse (DUR-015). */
  const finalizeFromHistory = Effect.fn("DurableAgentRuntime.finalizeFromHistory")(function* (
    submission: SubmissionSnapshot,
    record: RecordEnvelope,
  ): Effect.fn.Return<Settlement, LedgerError | SettlementConflict> {
    const canonicalSettlement = yield* settlementPayloadFromRecord(record, submission.submissionId);

    yield* notifyParentOfChildSettlement(submission, record);

    const settlement = yield* ledger.finalizeSettlement(
      SettlementFinalization.make({
        submissionId: submission.submissionId,
        settlementId: canonicalSettlement.settlementId,
      }),
    );

    yield* wake.notify(submission.threadId);
    yield* notifyParentOfChildSettlement(submission, record);

    return materializeSettlement(settlement, record);
  });

  /**
   * Durable abort of owned work: canonical `AbortRequested` first, then `ToolCallUnknown` audit
   * records for every open ordinary Tool Call (abort settles the obligation but never asserts
   * external rollback, durability §13), then settle aborted.
   */
  const settleAborted = Effect.fn("DurableAgentRuntime.settleAborted")(function* (
    ctx: AttemptAppendContext,
    submission: SubmissionSnapshot,
    tokenRef: Ref.Ref<OwnershipToken>,
    intent: AbortIntent,
    evidence: RecoveryEvidence,
    knownIds: Set<string>,
  ): Effect.fn.Return<Settlement, DurableWorkerFailure> {
    if (!evidence.abortRecorded) {
      yield* appendAbortRecord(ctx, intent);
    }
    if (evidence.openToolCalls.length > 0) {
      yield* appendUnknownRecords(
        ctx,
        submission.submissionId,
        knownIds,
        evidence.openToolCalls,
        "The Submission was aborted while this ordinary Tool call had no canonical outcome; abort never asserts external rollback",
      );
    }

    return yield* terminalize(
      ctx,
      submission,
      tokenRef,
      { _tag: "aborted" },
      evidence.inputRecorded,
    );
  });

  /** Map a ledger conflict outside `DurableWorkerFailure` into the coordinator failure family. */
  const conflictToLedgerError =
    (operation: string) =>
    (conflict: { readonly _tag: string; readonly message?: string }): LedgerError =>
      LedgerError.make({
        operation,
        message: `${conflict._tag}${conflict.message === undefined ? "" : `: ${conflict.message}`}`,
        cause: conflict,
      });

  /**
   * Append the child Thread's immutable lineage record (spec §12 step 6, §11): its own
   * single-record batch under `subagent-lineage:{childThreadId}` so the generic
   * `thread-created:{cid}` batch identity is never contradicted. Idempotent by record
   * identity; a racing append is re-proved from the log. A claim of the admitted child may
   * advance only its fence, so bounded retries acquire the current tail before appending.
   */
  const ensureChildLineage = Effect.fn("DurableAgentRuntime.ensureChildLineage")(
    function* (
      parent: SubmissionSnapshot,
      request: SubagentRequested,
      childRecords: ReadonlyArray<CanonicalRecordEnvelope>,
    ): Effect.fn.Return<void, DurableWorkerFailure> {
      const recordId = subagentLineageRecordId(request.childThreadId);

      if (childRecords.some((envelope) => envelope.record.recordId === recordId)) return;

      const envelope = yield* makeEnvelope(
        recordId,
        SubagentLineageRecorded.make({
          parentLink: SubagentParentLink.make({
            delegationId: request.delegationId,
            parentAgentId: parent.agentId,
            parentThreadId: parent.threadId,
            parentRunId: request.runId,
            parentToolCallId: request.toolCallId,
            depth: request.depth ?? CHILD_DELEGATION_DEPTH,
          }),
          parentSubmissionId: parent.submissionId,
          childDefinitionDigests: request.targetDigests,
          childInputDigest: request.childInputDigest,
          grantDigest: request.grantDigest,
          ...(request.toolCallAllowance === undefined
            ? {}
            : { toolCallAllowance: request.toolCallAllowance }),
          ...(request.policy === undefined ? {} : { policy: request.policy }),
          ...(request.budget === undefined ? {} : { budget: request.budget }),
          ...(request.grant === undefined ? {} : { grant: request.grant }),
        }),
      );

      const tail = yield* store.inspectTail(
        ThreadTailRequest.make({ threadId: request.childThreadId }),
      );

      yield* store
        .append(
          FencedAppendRequest.make({
            threadId: request.childThreadId,
            batch: CanonicalBatch.make({
              batchId: subagentLineageBatchId(request.childThreadId),
              producerId: config.producerId,
              records: [envelope],
            }),
            expectedTailSequence: tail.tailSequence,
            expectedTailDigest: tail.tailDigest,
            producerEpoch: tail.producerEpoch,
          }),
        )
        .pipe(
          Effect.catchTag(["AppendConflict", "FenceRejected"], (error) =>
            // A racing establishment pass (or the child's own claimed worker) advanced the
            // log; the deterministic identity means the record either exists or the next
            // pass re-proves it — verify instead of trusting the race blindly.
            readControl(request.childThreadId, []).pipe(
              Effect.flatMap((current) =>
                current.some((candidate) => candidate.record.recordId === recordId)
                  ? Effect.void
                  : Effect.fail(error),
              ),
            ),
          ),
          Effect.andThen(wake.notify(request.childThreadId)),
          Effect.asVoid,
        );
    },
    (effect) =>
      effect.pipe(
        Effect.retry({
          times: 7,
          while: (error) => error._tag === "AppendConflict" || error._tag === "FenceRejected",
        }),
      ),
  );

  /** Where one idempotent child admission pass ended (spec §12 steps 4-8). */
  type ChildAdmissionOutcome =
    | {
        readonly _tag: "established";
        readonly childSubmissionId: SubmissionId;
        readonly receiptId: ReceiptId;
      }
    | { readonly _tag: "indeterminate"; readonly reason: string };

  /**
   * Complete (or replay) the child-admission half of establishment from the canonical
   * `SubagentRequested` payload alone — no live delegation handler is required (D3): the
   * `resolveAdmission` tri-state gate (SUB-031), the idempotency-keyed `admit` with immutable
   * parent linkage, child Thread materialization plus the immutable lineage record, and
   * readiness. Every step is get-or-create; a replay converges on the one existing child
   * (SUB-016) and an `indeterminate` answer NEVER admits a second child.
   */
  const establishChildFromRequest = Effect.fn("DurableAgentRuntime.establishChildFromRequest")(
    function* (
      parent: SubmissionSnapshot,
      request: SubagentRequested,
      allowAdmission = true,
    ): Effect.fn.Return<ChildAdmissionOutcome, DurableWorkerFailure> {
      const principal = decodePrincipalSync(request.childPrincipal);
      const idempotencyKey = decodeIdempotencyKeySync(request.childIdempotencyKey);

      const resolution = yield* ledger.resolveAdmission(
        SubmissionLookupByKey.make({
          threadId: request.childThreadId,
          principal,
          idempotencyKey,
        }),
      );

      let childSubmissionId: SubmissionId;
      let receiptId: ReceiptId;

      switch (resolution._tag) {
        case "Indeterminate": {
          return { _tag: "indeterminate", reason: resolution.reason };
        }
        case "NotAdmitted": {
          if (!allowAdmission) {
            return {
              _tag: "indeterminate",
              reason: "The expired parent cannot admit a new child",
            };
          }

          const admitted: AdmissionResult = yield* ledger
            .admit(
              AdmissionRequest.make({
                threadId: request.childThreadId,
                principal,
                idempotencyKey,
                agentId: request.targetAgentId,
                agentDigests: request.targetDigests,
                deploymentId: config.deploymentId,
                inputPayload: request.childInput,
                inputDigest: request.childInputDigest,
                parentLinkage: ParentLinkage.make({
                  parentSubmissionId: parent.submissionId,
                  parentToolCallId: request.toolCallId,
                }),
              }),
            )
            .pipe(
              Effect.catchTag(
                "AdmissionConflict",
                conflictToLedgerError("establishChildFromRequest"),
              ),
            );

          childSubmissionId = admitted.submissionId;
          receiptId = admitted.receiptId;
          break;
        }
        case "Admitted": {
          // The one existing child: verify the immutable admission facts against the canonical
          // request before reattaching — a divergent row can never be "the same child"
          // (fail-closed; identifiers are never capabilities, D10).
          const child = resolution.submission;
          const linkage = child.parentLinkage;

          if (
            child.agentId !== request.targetAgentId ||
            !definitionDigestsEqual(child.agentDigests, request.targetDigests) ||
            child.inputDigest !== request.childInputDigest ||
            linkage === undefined ||
            linkage.parentSubmissionId !== parent.submissionId ||
            linkage.parentToolCallId !== request.toolCallId
          ) {
            return yield* LedgerError.make({
              operation: "establishChildFromRequest",
              message: `The admitted child ${child.submissionId} diverges from the canonical SubagentRequested record for Tool Call ${request.toolCallId}; establishment fails closed (SUB-016)`,
            });
          }
          childSubmissionId = child.submissionId;
          receiptId = child.receiptId;
          break;
        }
      }
      yield* hit("subagent:after-admit");
      yield* materializeAtLeast(request.childThreadId, ZERO_EPOCH);
      yield* ensureThreadCreated(
        request.childThreadId,
        request.targetAgentId,
        request.targetDigests,
      );
      const childRead = yield* readAllTolerant(request.childThreadId, []);

      yield* ensureChildLineage(parent, request, childRead.records);
      yield* ledger.markReady(MarkReadyRequest.make({ submissionId: childSubmissionId }));
      yield* hit("subagent:after-child-ready");
      yield* wake.notify(request.childThreadId);

      return { _tag: "established", childSubmissionId, receiptId };
    },
  );

  /**
   * Bounded usage summary rebuilt from canonical child evidence (D11 structural dimensions).
   * The two finite counters always satisfy the persistence bounds, so a decode failure is a
   * defect (`orDie`), matching the file's `annotateRepair` pattern for provably-valid inputs.
   */
  const childUsageSummaryOf = (
    childRecords: ReadonlyArray<CanonicalRecordEnvelope>,
    childRunId: RunId,
  ): Effect.Effect<PersistedJson> => {
    let turns = 0;
    let toolCalls = 0;

    for (const envelope of childRecords) {
      const payload = envelope.record.payload;

      if (payload._tag === "ModelResponseRecorded" && payload.runId === childRunId) turns += 1;
      if (payload._tag === "ToolCallSettled" && payload.runId === childRunId) toolCalls += 1;
    }

    return decodePersisted({ turns, toolCalls }).pipe(Effect.orDie);
  };

  /** The coordinator's bounded `{errorTag, message}` projection of a non-completed child. */
  const boundedChildFailureResult = (
    payload: SubmissionSettledRecord,
    childSubmissionId: SubmissionId,
  ): Effect.Effect<PersistedJson> => {
    if (payload.outcome === "failed") {
      return Effect.succeed(payload.result);
    }

    return decodePersisted({
      errorTag: "SubagentAborted",
      message: `Attached child ${childSubmissionId} settled aborted`,
    }).pipe(Effect.orDie);
  };

  /** One verified child Settlement, ready to join (spec §12 join steps 1-3). */
  interface VerifiedChildSettlement {
    readonly outcome: SettlementOutcome;
    /** Child terminal output for `completed`; the bounded `{errorTag, message}` projection otherwise. */
    readonly encodedResult: PersistedJson;
    readonly settlement: SubmissionSettledRecord;
    readonly childRecords: ReadonlyArray<CanonicalRecordEnvelope>;
  }

  const verifiedChildUsage = Effect.fn("DurableAgentRuntime.verifiedChildUsage")(function* (
    verified: VerifiedChildSettlement,
    childRunId: RunId,
  ) {
    const reports = childUsageReportsOf(subagentRecordsOf(verified.childRecords, childRunId));

    const delegatedUsage = yield* sumRunTotals(
      reports.flatMap(({ report }) => [report.usage, report.delegatedUsage]),
    ).pipe(Effect.catchTag("UsageAggregationError", () => Effect.succeed(unknownRunTotals())));

    return RunUsageReport.make({
      usage:
        verified.settlement.usageSummary === undefined
          ? unknownRunTotals()
          : runTotalsFromSummary(verified.settlement.usageSummary),
      delegatedUsage,
    });
  });

  type ChildVerification =
    | { readonly _tag: "verified"; readonly value: VerifiedChildSettlement }
    | { readonly _tag: "mismatch"; readonly message: string };

  /**
   * §1.6 join verification, fail-closed (SUB-019/SUB-023, D10): the child's CANONICAL
   * Settlement and lineage records are read from the child Thread Log — cached ledger
   * state never fabricates a Settlement — and every identity/digest is checked against the
   * canonical `SubagentRequested` payload: Parent Link identity, target agent, stored
   * definition digests, input/grant digests, settlement identity, and the settlement record
   * digest pinned by the child's reservation. Any mismatch is a typed verification failure.
   */
  const verifySettledChild = Effect.fn("DurableAgentRuntime.verifySettledChild")(function* (
    parent: SubmissionSnapshot,
    request: SubagentRequested,
    childSubmissionId: SubmissionId,
  ): Effect.fn.Return<ChildVerification, DurableWorkerFailure> {
    const mismatch = (message: string): ChildVerification => ({ _tag: "mismatch", message });

    // The child's lane state crosses the store boundary through `lookup` — a status check on
    // the child's owning ledger — because recovery snapshots are lane-local by construction:
    // on Cloudflare the child Thread lives in a different Durable Object whose
    // operational rows are not readable across the boundary (deployment §11). The child's
    // CANONICAL Settlement, read below from its Thread Log, remains the only
    // cross-lane verification authority (spec §12 join step 1, SUB-019, DUR-015).
    const childLookup = yield* ledger.lookup(
      SubmissionLookupById.make({ submissionId: childSubmissionId }),
    );

    if (Option.isNone(childLookup)) {
      return yield* LedgerError.make({
        operation: "verifySettledChild",
        message: `Attached child ${childSubmissionId} is unknown to its owning Submission Ledger`,
      });
    }
    const child = childLookup.value;

    if (child.threadId !== request.childThreadId) {
      return mismatch("The child Thread does not match the intended child identity");
    }
    if (child.agentId !== request.targetAgentId) {
      return mismatch("The child Agent identity does not match the declared delegation target");
    }
    if (!definitionDigestsEqual(child.agentDigests, request.targetDigests)) {
      return mismatch("The child definition digests do not match the stored target digests");
    }
    if (child.inputDigest !== request.childInputDigest) {
      return mismatch("The child input digest does not match the canonical request");
    }
    const linkage = child.parentLinkage;

    if (
      linkage === undefined ||
      linkage.parentSubmissionId !== parent.submissionId ||
      linkage.parentToolCallId !== request.toolCallId
    ) {
      return mismatch("The child admission linkage does not name this parent Tool Call");
    }
    const childRecords = yield* readControl(request.childThreadId, [child.submissionId]);

    const lineageEnvelope = childRecords.find(
      (envelope) => envelope.record.recordId === subagentLineageRecordId(request.childThreadId),
    );

    const lineage = lineageEnvelope?.record.payload;

    if (lineage === undefined || lineage._tag !== "SubagentLineageRecorded") {
      return mismatch("The child Thread carries no immutable lineage record");
    }
    if (
      lineage.parentLink.delegationId !== request.delegationId ||
      lineage.parentLink.parentAgentId !== parent.agentId ||
      lineage.parentLink.parentThreadId !== parent.threadId ||
      lineage.parentLink.parentRunId !== request.runId ||
      lineage.parentLink.parentToolCallId !== request.toolCallId ||
      lineage.parentLink.depth !== (request.depth ?? CHILD_DELEGATION_DEPTH) ||
      lineage.parentSubmissionId !== parent.submissionId
    ) {
      return mismatch("The child Parent Link does not name exactly this parent Run and Tool Call");
    }
    if (
      !definitionDigestsEqual(lineage.childDefinitionDigests, request.targetDigests) ||
      lineage.childInputDigest !== request.childInputDigest ||
      lineage.grantDigest !== request.grantDigest ||
      lineage.toolCallAllowance !== request.toolCallAllowance ||
      !Equal.equals(lineage.policy, request.policy) ||
      !Equal.equals(lineage.budget, request.budget) ||
      !Equal.equals(lineage.grant, request.grant)
    ) {
      return mismatch("The child lineage digests or allowance do not match the canonical request");
    }

    const settlementEnvelope = childRecords.find(
      (envelope) => envelope.record.recordId === submissionSettlementRecordId(childSubmissionId),
    );

    const settlement = settlementEnvelope?.record.payload;

    if (settlement === undefined || settlement._tag !== "SubmissionSettled") {
      return mismatch("The child has no canonical Settlement record");
    }
    if (
      settlement.submissionId !== childSubmissionId ||
      settlement.settlementId !== submissionSettlementId(childSubmissionId) ||
      settlement.receiptId !== child.receiptId
    ) {
      return mismatch("The child Settlement identity does not match the child Receipt");
    }
    // No parent-side crosscheck against the child's settlement RESERVATION row exists here:
    // the reservation lives in the child's own store, invisible across the Object boundary on
    // Cloudflare, and its byte-identity with the canonical record is the child store's own
    // conformance-tested reserve→append→finalize invariant (DUR-011) — never a parent
    // obligation. The canonical Settlement verified above is the sole cross-lane authority.
    if (settlement.outcome === "completed" && settlement.result === undefined) {
      return mismatch("The completed child Settlement carries no terminal output");
    }

    const encodedResult =
      settlement.outcome === "completed" && settlement.result !== undefined
        ? settlement.result
        : yield* boundedChildFailureResult(settlement, childSubmissionId);

    return {
      _tag: "verified",
      value: { outcome: settlement.outcome, encodedResult, settlement, childRecords },
    };
  });

  /**
   * Apply the frozen accounting decision to one reservation (spec §12 join step 6, DUR-015):
   * `beginChildBudgetRelease` freezes it exactly once (an identical replay is a no-op) and
   * `releaseChildBudget` applies it exactly once — budget stays unavailable until repair, never
   * available twice.
   */
  const applyReservationRelease = Effect.fn("DurableAgentRuntime.applyReservationRelease")(
    function* (
      reservationId: ChildReservationId,
      accounting: PersistedJson,
    ): Effect.fn.Return<void, DurableWorkerFailure> {
      yield* ledger
        .beginChildBudgetRelease(BeginChildBudgetReleaseRequest.make({ reservationId, accounting }))
        .pipe(
          Effect.catchTag(
            "ChildReservationConflict",
            conflictToLedgerError("beginChildBudgetRelease"),
          ),
        );
      yield* hit("subagent:after-release-pending");
      yield* ledger
        .releaseChildBudget(ReleaseChildBudgetRequest.make({ reservationId }))
        .pipe(
          Effect.catchTag("ChildReservationConflict", conflictToLedgerError("releaseChildBudget")),
        );
      yield* hit("subagent:after-release");
    },
  );

  /**
   * Release a provably-childless reservation exactly once (spec §13 "reservation exists,
   * request absent"): freeze the deterministic zero-consumed decision — a conflict means a
   * different decision already froze first, and the release below applies THAT frozen decision.
   */
  const releaseOrphanReservation = Effect.fn("DurableAgentRuntime.releaseOrphanReservation")(
    function* (reservationId: ChildReservationId): Effect.fn.Return<void, DurableWorkerFailure> {
      yield* ledger
        .beginChildBudgetRelease(
          BeginChildBudgetReleaseRequest.make({
            reservationId,
            accounting: ORPHAN_ZERO_CONSUMED_ACCOUNTING,
          }),
        )
        .pipe(
          Effect.catchTag("ChildReservationConflict", () => Effect.void),
          Effect.asVoid,
        );
      yield* hit("subagent:after-release-pending");
      yield* ledger
        .releaseChildBudget(ReleaseChildBudgetRequest.make({ reservationId }))
        .pipe(
          Effect.catchTag("ChildReservationConflict", conflictToLedgerError("releaseChildBudget")),
        );
      yield* hit("subagent:after-release");
    },
  );

  /**
   * Join a settled child after parent abort or expiry without running application handlers.
   * The canonical child outcome stays intact; the parent result records why it cannot continue.
   */
  const joinSettledChildWithoutHandler = Effect.fn(
    "DurableAgentRuntime.joinSettledChildWithoutHandler",
  )(function* (
    ctx: AttemptAppendContext,
    parent: SubmissionSnapshot,
    knownIds: Set<string>,
    subagent: SubagentCallRecords,
    reservation: ChildBudgetReservationSnapshot,
    toolCallId: ToolCallId,
    childSubmissionId: SubmissionId,
    reason: "aborted" | "duration" | "unavailable",
  ): Effect.fn.Return<void, DurableWorkerFailure> {
    const runId = runIdForSubmission(parent.submissionId);
    const request = subagent.requested.get(toolCallId);

    if (request === undefined) {
      return yield* LedgerError.make({
        operation: "joinSettledChildWithoutHandler",
        message: `Tool Call ${toolCallId} has an attached child but no canonical SubagentRequested record`,
      });
    }
    const joinedRecordId = subagentJoinedRecordId(runId, toolCallId);
    let finalAccounting: PersistedJson;
    const existing = subagent.joined.get(toolCallId);

    if (existing !== undefined) {
      finalAccounting = existing.finalAccounting;
    } else {
      const verification = yield* verifySettledChild(parent, request, childSubmissionId);

      if (verification._tag === "mismatch") {
        return yield* LedgerError.make({
          operation: "joinSettledChildWithoutHandler",
          message: `Child Settlement verification failed for Tool Call ${toolCallId}: ${verification.message}`,
        });
      }
      const verified = verification.value;

      // The child's actual outcome and usage remain authoritative even when the parent can
      // no longer project it with the original delegation implementation.
      const boundedResult = yield* decodePersisted(
        reason === "unavailable"
          ? {
              _tag: "ToolUnavailable",
              toolName: subagent.preparedNames.get(toolCallId) ?? request.delegationId,
              execution: "unavailable",
              message: `The original delegation implementation is unavailable. Its original child settled ${verified.outcome}; no replacement child was started.`,
            }
          : {
              errorTag:
                reason === "aborted" ? "SubagentParentAborted" : "SubagentParentDurationExceeded",
              message: boundedText(
                `The parent Submission ${reason === "aborted" ? "aborted" : "exceeded its duration"}; attached child ${childSubmissionId} settled ${verified.outcome}`,
              ),
            },
      ).pipe(Effect.orDie);

      finalAccounting = yield* decodePersisted({
        basis: `${reason}-conservative`,
        allocation: reservation.allocation,
      }).pipe(Effect.orDie);
      const childRunId = runIdForSubmission(childSubmissionId);

      yield* hit("subagent:before-join-append");

      const joinedPayload = SubagentJoined.make({
        runId,
        toolCallId,
        childSubmissionId,
        childSettlementId: verified.settlement.settlementId,
        childOutcome: verified.outcome,
        childResultDigest: yield* withCrypto(digestJson(verified.settlement.result ?? null)),
        projectedResultDigest: yield* withCrypto(digestJson(boundedResult)),
        usageSummary: yield* childUsageSummaryOf(verified.childRecords, childRunId),
        ...(yield* verifiedChildUsage(verified, childRunId)),
        reservationId: reservation.reservationId,
        finalAccounting,
      });

      const settledRecordId = toolCallSettledRecordId(runId, request.turn, toolCallId);
      const joinedEnvelope = yield* makeEnvelope(joinedRecordId, joinedPayload);

      const settledEnvelope = yield* makeEnvelope(
        settledRecordId,
        ToolCallSettled.make({
          runId,
          toolCallId,
          toolName: subagent.preparedNames.get(toolCallId) ?? request.delegationId,
          result: boundedResult,
          isFailure: true,
        }),
      );

      if (!knownIds.has(joinedRecordId)) {
        yield* appendBatch(
          ctx,
          CanonicalBatch.make({
            batchId: subagentJoinBatchId(runId, toolCallId),
            producerId: config.producerId,
            records: [joinedEnvelope, settledEnvelope],
          }),
        ).pipe(
          Effect.catchTag("AppendConflict", () => Effect.void),
          Effect.asVoid,
        );
        knownIds.add(joinedRecordId);
        knownIds.add(settledRecordId);
        subagent.joined.set(toolCallId, joinedPayload);
        yield* hit("subagent:after-join-append");
      }
    }
    yield* applyReservationRelease(reservation.reservationId, finalAccounting);
  });

  /**
   * Complete every joined-but-unreleased reservation BEFORE the parent settles (spec §12 join
   * step 6): the canonical `SubagentJoined` accounting authorizes the release (DUR-015), and a
   * parent that settled first would strand the repair — a settled lane classifies `NoAction`.
   * Returns whether any reservation remains unreleased (a reserved row without a canonical
   * join), which must block the settlement (spec §13: a parent never settles across an open
   * child obligation).
   */
  const completeJoinedReleases = Effect.fn("DurableAgentRuntime.completeJoinedReleases")(function* (
    submission: SubmissionSnapshot,
  ): Effect.fn.Return<boolean, DurableWorkerFailure> {
    const snapshot = yield* ledger.loadRecoverySnapshot(
      RecoverySnapshotRequest.make({ submissionId: submission.submissionId }),
    );

    if (snapshot.childReservations.length === 0) return false;
    const records = yield* readControl(submission.threadId, [submission.submissionId]);
    const subagent = subagentRecordsOf(records, runIdForSubmission(submission.submissionId));
    let open = false;

    for (const reservation of snapshot.childReservations) {
      if (reservation.status === "released") continue;
      const joined = subagent.joined.get(reservation.parentToolCallId);

      if (joined !== undefined) {
        yield* applyReservationRelease(reservation.reservationId, joined.finalAccounting);
        continue;
      }
      if (reservation.status === "releasePending" && reservation.accounting !== undefined) {
        yield* applyReservationRelease(reservation.reservationId, reservation.accounting);
        continue;
      }
      open = true;
    }

    return open;
  });

  /** Release unused reservations or repair and join existing children, never admit new work. */
  const reconcileRetainedChildren = Effect.fn("DurableAgentRuntime.reconcileRetainedChildren")(
    function* (
      ctx: AttemptAppendContext,
      parent: SubmissionSnapshot,
      ownershipToken: OwnershipToken,
      unavailableCalls?: ReadonlySet<ToolCallId>,
    ) {
      const snapshot = yield* ledger.loadRecoverySnapshot(
        RecoverySnapshotRequest.make({ submissionId: parent.submissionId }),
      );

      const records = yield* readControl(parent.threadId, [parent.submissionId]);
      const runId = runIdForSubmission(parent.submissionId);
      const pending = yield* pendingToolBatchFor(records, runId);
      const knownIds = knownRecordIdsOf(records);
      const subagent = subagentRecordsOf(records, runId);

      const notExecuted = new Set<ToolCallId>();
      const waiting: Array<WaitingChild> = [];
      const indeterminate = new Set<ToolCallId>();

      for (const toolCallId of unavailableCalls ?? []) {
        if (
          snapshot.childReservations.some(
            (reservation) => reservation.parentToolCallId === toolCallId,
          )
        )
          continue;
        if (subagent.requested.has(toolCallId) || subagent.started.has(toolCallId))
          return yield* LedgerError.make({
            operation: "reconcileRetainedChildren",
            message: "Child request has no original reservation",
          });
        notExecuted.add(toolCallId);
      }
      for (const reservation of snapshot.childReservations) {
        const toolCallId = reservation.parentToolCallId;

        if (unavailableCalls !== undefined && !unavailableCalls.has(toolCallId)) continue;
        const joined = subagent.joined.get(toolCallId);

        if (joined !== undefined) {
          yield* applyReservationRelease(reservation.reservationId, joined.finalAccounting);
          continue;
        }
        if (reservation.status !== "reserved") {
          if (reservation.accounting !== undefined)
            yield* applyReservationRelease(reservation.reservationId, reservation.accounting);
          // An orphan release proves non-admission; it never hides an attached child.
          if (reservation.childSubmissionId !== undefined || subagent.started.has(toolCallId))
            return yield* LedgerError.make({
              operation: "reconcileRetainedChildren",
              message: "Unjoined child reservation was already released",
            });
          notExecuted.add(toolCallId);
          continue;
        }
        let started = subagent.started.get(toolCallId);
        const request = subagent.requested.get(toolCallId);

        if (
          started === undefined &&
          request === undefined &&
          reservation.childSubmissionId === undefined
        ) {
          yield* releaseOrphanReservation(reservation.reservationId);
          notExecuted.add(toolCallId);
          continue;
        }
        const call = pending?.calls.find((candidate) => candidate.id === toolCallId);

        if (
          pending === undefined ||
          call === undefined ||
          request === undefined ||
          subagent.preparedNames.get(toolCallId) !== call.name ||
          request.delegationId !== call.name ||
          reservation.parentSubmissionId !== parent.submissionId ||
          request.reservationId !== reservation.reservationId ||
          request.reservationDigest !== reservation.allocationDigest ||
          request.turn !== pending.turn ||
          request.turnId !== pending.turnId
        ) {
          return yield* LedgerError.make({
            operation: "reconcileRetainedChildren",
            message: `Tool Call ${toolCallId} has inconsistent canonical child request evidence`,
          });
        }
        if (started === undefined) {
          const resolution = yield* ledger.resolveAdmission(
            SubmissionLookupByKey.make({
              threadId: request.childThreadId,
              principal: decodePrincipalSync(request.childPrincipal),
              idempotencyKey: decodeIdempotencyKeySync(request.childIdempotencyKey),
            }),
          );

          if (resolution._tag === "Indeterminate") {
            indeterminate.add(toolCallId);
            continue;
          }
          if (resolution._tag === "NotAdmitted") {
            if (reservation.childSubmissionId !== undefined) {
              return yield* LedgerError.make({
                operation: "reconcileRetainedChildren",
                message: `Tool Call ${toolCallId} has an attachment but no admitted child`,
              });
            }
            if (unavailableCalls === undefined) {
              yield* releaseOrphanReservation(reservation.reservationId);
              notExecuted.add(toolCallId);
              continue;
            }
          }

          // A canonical request already authorized this exact idempotent admission. Finish it
          // when its handler is unavailable: a stale admission can still arrive after the lookup,
          // so NotAdmitted cannot justify releasing its reservation. Expiry keeps admission closed.
          const admission = yield* establishChildFromRequest(
            parent,
            request,
            unavailableCalls !== undefined,
          );

          if (admission._tag === "indeterminate") {
            indeterminate.add(toolCallId);
            continue;
          }
          started = SubagentStarted.make({
            runId,
            toolCallId,
            childThreadId: request.childThreadId,
            childSubmissionId: admission.childSubmissionId,
            childReceiptId: admission.receiptId,
            childRunId: runIdForSubmission(admission.childSubmissionId),
          });
          const startRecordId = subagentStartedRecordId(runId, toolCallId);
          const envelope = yield* makeEnvelope(startRecordId, started);

          yield* appendBatch(
            ctx,
            CanonicalBatch.make({
              batchId: subagentStartedBatchId(runId, toolCallId),
              producerId: config.producerId,
              records: [envelope],
            }),
          );
          knownIds.add(startRecordId);
          subagent.started.set(toolCallId, started);
          yield* hit("subagent:after-start-append");
        }

        const child = yield* ledger.lookup(
          SubmissionLookupById.make({ submissionId: started.childSubmissionId }),
        );

        if (
          Option.isNone(child) ||
          (reservation.childSubmissionId !== undefined &&
            reservation.childSubmissionId !== started.childSubmissionId) ||
          request.childThreadId !== started.childThreadId ||
          started.childThreadId !== child.value.threadId ||
          started.childReceiptId !== child.value.receiptId ||
          started.childRunId !== runIdForSubmission(started.childSubmissionId)
        ) {
          return yield* LedgerError.make({
            operation: "reconcileRetainedChildren",
            message: `Tool Call ${call.id} has inconsistent canonical child attachment evidence`,
          });
        }
        yield* ledger
          .attachChildToReservation(
            AttachChildToReservationRequest.make({
              reservationId: reservation.reservationId,
              ownershipToken,
              childSubmissionId: started.childSubmissionId,
            }),
          )
          .pipe(
            Effect.catchTag(
              "ChildReservationConflict",
              conflictToLedgerError("attachChildToReservation"),
            ),
          );
        if (child.value.state !== "settled") {
          waiting.push(
            WaitingChild.make({ toolCallId, childSubmissionId: started.childSubmissionId }),
          );
          yield* wake.notify(child.value.threadId);
          continue;
        }
        yield* joinSettledChildWithoutHandler(
          ctx,
          parent,
          knownIds,
          subagent,
          reservation,
          started.toolCallId,
          started.childSubmissionId,
          unavailableCalls === undefined ? "duration" : "unavailable",
        );
      }

      return { notExecuted, waiting, indeterminate };
    },
  );

  /** Where the request-abort-and-join pass over attached children ended (spec §13.1). */
  type ChildAbortDisposition = "clear" | "waiting" | "blocked";

  /**
   * Request-abort-and-join over every attached child of an aborting parent (spec §13.1,
   * SUB-022): joined-but-unreleased reservations finish their idempotent release; settled
   * children join coordinator-side; nonterminal children receive the ONE idempotent durable
   * abort command (the recorded `AbortIntent` row IS the propagation marker, DUR-012) and the
   * parent suspends `waitingForChild` for their joins; an admitted-but-unlinked child is
   * reattached first; a provably-childless reservation releases exactly once; an indeterminate
   * admission blocks honestly — never a second admission, never a fabricated settlement.
   */
  const abortAttachedChildren = Effect.fn("DurableAgentRuntime.abortAttachedChildren")(function* (
    ctx: AttemptAppendContext,
    parent: SubmissionSnapshot,
    tokenRef: Ref.Ref<OwnershipToken>,
    knownIds: Set<string>,
  ): Effect.fn.Return<ChildAbortDisposition, DurableWorkerFailure> {
    const submissionId = parent.submissionId;
    const runId = runIdForSubmission(submissionId);

    while (true) {
      const snapshot = yield* ledger.loadRecoverySnapshot(
        RecoverySnapshotRequest.make({ submissionId }),
      );

      if (snapshot.childReservations.length === 0) return "clear";
      const records = yield* readControl(parent.threadId, [parent.submissionId]);

      for (const envelope of records) knownIds.add(envelope.record.recordId);
      const subagent = subagentRecordsOf(records, runId);
      const waiting: Array<WaitingChild> = [];
      let blocked = false;

      for (const reservation of snapshot.childReservations) {
        if (reservation.status === "released") continue;
        const toolCallId = reservation.parentToolCallId;
        const joined = subagent.joined.get(toolCallId);

        if (joined !== undefined) {
          yield* applyReservationRelease(reservation.reservationId, joined.finalAccounting);
          continue;
        }
        if (reservation.status === "releasePending") {
          // The decision is already frozen (join or orphan): finish the idempotent release —
          // NEVER re-freeze, a divergent second decision would conflict.
          yield* applyReservationRelease(
            reservation.reservationId,
            reservation.accounting ?? ORPHAN_ZERO_CONSUMED_ACCOUNTING,
          );
          continue;
        }
        const request = subagent.requested.get(toolCallId);

        let childSubmissionId =
          subagent.started.get(toolCallId)?.childSubmissionId ?? reservation.childSubmissionId;

        if (childSubmissionId === undefined) {
          if (request === undefined) {
            // Reservation without a canonical request under abort: provably childless —
            // release the unused allocation exactly once (spec §13/§14).
            yield* releaseOrphanReservation(reservation.reservationId);
            continue;
          }
          const admission = yield* establishChildFromRequest(parent, request);

          if (admission._tag === "indeterminate") {
            // A child may exist: never release, settle, or re-admit until the authoritative
            // owner answers (SUB-031).
            blocked = true;
            continue;
          }
          childSubmissionId = admission.childSubmissionId;
        }

        const child = yield* ledger.lookup(
          SubmissionLookupById.make({ submissionId: childSubmissionId }),
        );

        if (Option.isNone(child)) {
          return yield* LedgerError.make({
            operation: "abortAttachedChildren",
            message: `Attached child ${childSubmissionId} is unknown to the ledger`,
          });
        }
        if (child.value.state === "settled") {
          yield* joinSettledChildWithoutHandler(
            ctx,
            parent,
            knownIds,
            subagent,
            reservation,
            toolCallId,
            childSubmissionId,
            "aborted",
          );
          continue;
        }
        yield* ledger
          .requestAbort(
            AbortCommand.make({
              submissionId: childSubmissionId,
              author: SUBAGENT_ABORT_AUTHOR,
              reason: SUBAGENT_ABORT_REASON,
            }),
          )
          .pipe(
            // The child settled concurrently: the one winning Settlement joins on the next
            // pass of this loop (spec §13 "child terminal races abort").
            Effect.catchTags({
              SettlementConflict: () => Effect.void,
              JoinedToHost: conflictToLedgerError("abortAttachedChildren"),
            }),
            Effect.asVoid,
          );
        yield* hit("subagent:after-child-abort-intent");
        yield* wake.notify(child.value.threadId);
        waiting.push(WaitingChild.make({ toolCallId, childSubmissionId }));
      }
      if (blocked) return "blocked";
      const first = waiting[0];

      if (first === undefined) return "clear";
      const ownershipToken = yield* Ref.get(tokenRef);

      const suspension = yield* ledger.suspend(
        SuspendRequest.make({
          submissionId,
          ownershipToken,
          reason: WaitingForChildSuspension.make({ children: [first, ...waiting.slice(1)] }),
        }),
      );

      yield* hit("subagent:after-suspend");
      if (suspension === "suspended") return "waiting";
      // Every listed child settled before the suspend committed: loop to join the winners.
    }
  });

  const failureOutcome = (
    error: unknown,
    cause: Cause.Cause<unknown>,
    context: FailureDiagnostic.Context,
  ): Effect.Effect<AttemptOutcome> =>
    Schema.decodeEffect(SettlementFailureDiagnostic)({
      errorTag: errorTagOf(error).slice(0, 256) || "UnknownError",
      message: errorMessageOf(error).slice(0, MAX_FAILURE_MESSAGE_LENGTH),
      diagnostic: FailureDiagnostic.capture(cause),
      context: FailureDiagnostic.captureContext(context),
    }).pipe(
      // The exact diagnostic Schema admits only causal fields, never arbitrary provider payloads.
      Effect.orDie,
      Effect.map((result) => ({
        _tag: "failed" as const,
        result,
        // A hard-rail policy failure keeps its typed limit durable (RUN-011):
        // the bounded message stays diagnostic, never the dimension authority.
        ...Option.match(decodePolicyFailureSafely(error), {
          onNone: () => ({}),
          onSome: ({ limit }) => ({ policyLimit: limit }),
        }),
      })),
    );

  const halt = <A, R>(
    effect: Effect.Effect<A, DurableWorkerFailure, R>,
  ): Effect.Effect<A, CoordinatorHalt, R> =>
    Effect.catchCause(effect, (cause) =>
      Effect.failCause(Cause.map(cause, (failure) => new CoordinatorHalt(failure))),
    );

  /**
   * Superseding-Attempt interruption audit (durability §9): appended at most once per superseded
   * fence epoch before this Attempt re-invokes the model. It deliberately over-approximates — a
   * prior ownership period that ended cleanly between commits still gets one — because durable
   * state cannot distinguish a mid-stream provider loss from a crash between boundaries, and the
   * honest direction is to record that duplicate provider cost is possible, never to hide it.
   */
  const appendInterruptedAudit = Effect.fn("DurableAgentRuntime.appendInterruptedAudit")(function* (
    ctx: AttemptAppendContext,
    runId: ReturnType<typeof runIdForSubmission>,
    lineage: AttemptLineage,
    knownIds: Set<string>,
  ): Effect.fn.Return<void, DurableWorkerFailure> {
    const recordId = modelResponseInterruptedRecordId(runId, lineage.supersededEpoch);

    if (knownIds.has(recordId)) return;

    const envelope = yield* makeEnvelope(
      recordId,
      ModelResponseInterrupted.make({
        runId,
        supersededEpoch: lineage.supersededEpoch,
        attemptId: lineage.attemptId,
        reason:
          "A prior ownership period ended without a canonical settlement; any in-flight model response was lost and the model may be re-invoked (duplicate provider cost is observable)",
      }),
    );

    yield* appendBatch(
      ctx,
      CanonicalBatch.make({
        batchId: modelResponseInterruptedBatchId(runId, lineage.supersededEpoch),
        producerId: config.producerId,
        records: [envelope],
      }),
    ).pipe(
      Effect.catchTag("AppendConflict", () => Effect.void),
      Effect.asVoid,
    );
    knownIds.add(recordId);
  });

  /**
   * Plan step 3 (+6): drive `AgentRuntime.stream` with history rebuilt by the run journal, commit
   * each Turn canonically through the fenced append, watch for durable abort intent, and keep the
   * ownership lease renewed. Engine Run failures settle `failed`; coordinator failures abort the
   * Attempt cleanly with the obligation still owed.
   *
   * Phase 5 commit shape (plan §2.1): a tool-declaring Turn splits into a RESPONSE batch
   * (committed by the engine's `commitResponse` hook at the finish part — pending steering plus
   * the response messages, creating the durability §15 provably-safe window), the durable
   * approval preflight (§2.6 — recorded decisions replay deterministically, unresolved requests
   * become canonical and suspend the Attempt), an optional PREPARED batch (before any handler
   * starts), and a RESULTS batch at the next TurnStarted/RunCompleted/RunFailed seam. A completed
   * no-tool Turn atomically adds its `RunCompleted` marker to the P4 single-batch shape. When the
   * journal ends mid-batch,
   * `RunOptions.resume` replays the declared batch without re-invoking the model (§2.4).
   */
  const runModel = <
    InputSchema extends Schema.Top,
    OutputSchema extends Schema.Top,
    Instructions,
    Tools extends Record<string, Tool.Any>,
    Provider,
    ModelProvides,
    ModelRequires,
    InstructionError = InstructionErrorOf<Instructions, InputSchema["Type"]>,
    InstructionRequirements = InstructionRequirementsOf<Instructions, InputSchema["Type"]>,
    RunDispositionValue extends
      | RunDispositionDeclaration<OutputSchema["Type"], Schema.Top>
      | undefined = undefined,
    InputPromptValue extends InputPromptSource<InputSchema["Type"], unknown, unknown> | undefined =
      undefined,
    UpdatesSchema extends Schema.Top | undefined = undefined,
  >(
    agent: RuntimeBinding<
      InputSchema,
      OutputSchema,
      Instructions,
      Tools,
      Provider,
      ModelProvides,
      ModelRequires,
      InstructionError,
      InstructionRequirements,
      RunDispositionValue,
      InputPromptValue,
      UpdatesSchema
    >,
    ctx: AttemptAppendContext,
    submission: SubmissionSnapshot,
    tokenRef: Ref.Ref<OwnershipToken>,
    renewAtRef: Ref.Ref<number>,
    records: ReadonlyArray<CanonicalRecordEnvelope>,
    canonical: Stream.Stream<CanonicalRecordEnvelope, ThreadStoreError | ThreadNotMaterialized>,
    canonicalThrough: CanonicalSequence,
    journalSeed: JournalCheckpointSeed | undefined,
    priorContext: ThreadContextCheckpoint | undefined,
    journalMetadata: JournalMetadata | undefined,
    lineage: AttemptLineage,
    approvalDecisions: ReadonlyArray<ApprovalDecisionIntent>,
    currentContracts: Readonly<Record<string, Digest>>,
    runTiming: { readonly startedAt: DateTime.Utc; readonly deadline: DateTime.Utc },
    yieldAfter?: DateTime.Utc,
  ) =>
    Effect.gen(function* () {
      const submissionId = submission.submissionId;

      const runId = runIdForSubmission(submissionId);
      const boundaries: Array<JournalBoundary> = [];

      const cached = projectedJournal;

      const journal =
        cached !== undefined &&
        cached.threadId === ctx.threadId &&
        cached.through === canonicalThrough &&
        cached.runId === runId &&
        cached.seedThrough === journalSeed?.throughSequence &&
        cached.contextThrough === priorContext?.throughSequence
          ? (boundaries.push(...cached.boundaries), cached.journal)
          : yield* projectRunJournalStream(
              canonical,
              runId,
              (boundary) => boundaries.push(boundary),
              journalSeed,
              journalMetadata,
              priorContext,
            );

      // Do not retain the metadata snapshot across model or Tool waits, including cache hits.
      // The projected prompt owns its needed context.
      journalMetadata = undefined;

      projectedJournal = {
        threadId: ctx.threadId,
        through: canonicalThrough,
        runId,
        seedThrough: journalSeed?.throughSequence,
        contextThrough: priorContext?.throughSequence,
        journal,
        boundaries,
      };

      const saveRecoveryCheckpoint = Effect.fn("DurableAgentRuntime.saveRecoveryCheckpoint")(
        function* (compactionId: RecordId): Effect.fn.Return<void, DurableWorkerFailure> {
          if (store.recoveryCheckpoints === undefined) return;
          const tail = yield* Ref.get(ctx.tailRef);

          const source =
            priorContext === undefined
              ? Stream.concat(
                  canonical,
                  canonicalRange(ctx.threadId, tail.sequence, canonicalThrough),
                )
              : canonicalRange(ctx.threadId, tail.sequence);

          let compaction: CanonicalRecordEnvelope | undefined;
          let latestResponse: CanonicalSequence | undefined;
          let firstSequence = journalSeed?.firstSequence;
          const orchestrationCalls = new Set<string>();

          yield* Stream.runForEach(source, (entry) =>
            Effect.sync(() => {
              const payload = entry.record.payload;

              if (entry.record.recordId === compactionId) compaction = entry;
              if (!("runId" in payload) || payload.runId !== runId) return;
              firstSequence ??= entry.sequence;
              if (payload._tag === "ModelResponseRecorded") latestResponse = entry.sequence;
              if (
                payload._tag === "ToolCallPrepared" &&
                (payload.executionKind === "delegation" ||
                  payload.executionKind === "orchestration")
              )
                orchestrationCalls.add(payload.toolCallId);
            }),
          );
          if (
            compaction === undefined ||
            compaction.record.payload._tag !== "CompactionCreated" ||
            compaction.record.payload.kind === "clear-tool-results"
          )
            return;
          const replacement = compaction;
          const covered = compaction.record.payload.coversThrough;

          const retiredThrough = decodeCanonicalSequence(
            Math.min(covered, (latestResponse ?? covered + 1) - 1),
          );

          if (retiredThrough <= (journalSeed?.throughSequence ?? 0)) return;

          const retired = yield* projectRunJournalStream(
            source.pipe(Stream.filter((entry) => entry.sequence <= retiredThrough)),
            runId,
            undefined,
            journalSeed,
          );

          const detailed = yield* summarizeModelUsage(
            retired.usage.modelUsage,
            retired.usage.summarizedModelUsage,
          ).pipe(
            Effect.mapError((cause) =>
              RunJournalError.make({ message: "Retired usage exceeds accounting bounds", cause }),
            ),
          );

          const protectedContext = retired.protectedContext ?? journal.protectedContext;
          // The first native rollover may precede this Attempt's first journal snapshot response.
          const current = yield* projectRunJournalStream(source, runId, undefined, journalSeed);
          const protectedMessages = protectedContext ?? current.protectedContext;

          const encodedContext =
            protectedMessages === undefined
              ? undefined
              : yield* Schema.encodeEffect(Prompt.Prompt)(protectedMessages).pipe(
                  Effect.flatMap(decodePersisted),
                  Effect.mapError((cause) =>
                    RunJournalError.make({ message: "Cannot checkpoint protected context", cause }),
                  ),
                );

          let frontier = journalSeed?.frontier;

          const retained = yield* Stream.runCollect(
            source.pipe(
              Stream.filter((entry) => {
                if (entry.sequence > retiredThrough) return true;
                const payload = entry.record.payload;

                if (payload._tag === "ModelResponseRecorded" || payload._tag === "ToolCallSettled")
                  frontier = { sequence: entry.sequence, tag: payload._tag };
                if (
                  payload._tag === "ThreadCreated" ||
                  payload._tag === "SubagentLineageRecorded" ||
                  payload._tag === "WorkerOriginRecorded"
                )
                  return true;
                if (!("runId" in payload) || payload.runId !== runId) return false;
                if ("toolCallId" in payload && orchestrationCalls.has(payload.toolCallId))
                  return true;
                switch (payload._tag) {
                  case "ModelResponseRecorded":
                  case "ToolCallPrepared":
                  case "ToolCallSettled":
                  case "ToolCallUnknown":
                  case "ToolCallResolved":
                  case "ToolApprovalRequested":
                  case "ToolApprovalDecided":
                  case "CompactionCreated":
                  case "RunPolicyUsageReserved":
                    return false;
                  default:
                    return true;
                }
              }),
            ),
          );

          const ids = new Set<SubmissionId>([submissionId]);

          for (const {
            record: { payload },
          } of retained)
            if (payload._tag === "UserInputRecorded" && payload.submissionId !== undefined)
              ids.add(payload.submissionId);

          const validated = yield* Effect.try({
            try: () =>
              RecoveryCheckpointState.make({
                schemaVersion: 2,
                policyAccountingVersion: 1,
                submissionId,
                submissionIds: [...ids],
                seed: JournalCheckpointSeed.make({
                  runId,
                  throughSequence: retiredThrough,
                  ...(firstSequence === undefined ? {} : { firstSequence }),
                  committedTurns: retired.committedTurns,
                  ...(retired.toolSelection === undefined
                    ? {}
                    : { toolSelection: retired.toolSelection }),
                  policyUsage: retired.policyUsage,
                  modelCalls: retired.usage.modelCalls,
                  unobservedModelCalls: retired.usage.unobservedModelCalls ?? 0,
                  inputTokens: retired.usage.inputTokens,
                  outputTokens: retired.usage.outputTokens,
                  lastInputTokens: retired.usage.lastInputTokens,
                  lastOutputTokens: retired.usage.lastOutputTokens,
                  costMicrousd: retired.usage.costMicrousd,
                  summarizedModelUsage: detailed,
                  ...(current.contextWindowId === undefined
                    ? {}
                    : { contextWindowId: current.contextWindowId }),
                  ...(frontier === undefined ? {} : { frontier }),
                  ...(encodedContext === undefined ? {} : { protectedContext: encodedContext }),
                  compaction: replacement,
                }),
                records: retained,
              }),
            catch: (cause) =>
              RunJournalError.make({ message: "Recovery checkpoint exceeds cache bounds", cause }),
          }).pipe(Effect.option);

          // Capacity is a cache eligibility limit, never a reason to truncate canonical evidence.
          if (Option.isNone(validated)) return;

          // Removing proof must not make a previously invalid historical compaction valid.
          // Check the disposable projection against the canonical source before publishing it.
          const replayed = yield* projectRunJournalStream(
            Stream.fromIterable(retained),
            runId,
            undefined,
            validated.value.seed,
          ).pipe(Effect.option);

          if (Option.isNone(replayed)) return;
          const candidate = replayed.value;
          const equalPrompt = Schema.toEquivalence(Prompt.Prompt);

          if (
            !equalPrompt(current.prompt, candidate.prompt) ||
            !equalPrompt(current.historyBefore, candidate.historyBefore) ||
            !Schema.toEquivalence(Schema.optional(Prompt.Prompt))(
              current.protectedContext,
              candidate.protectedContext,
            ) ||
            current.contextWindowId !== candidate.contextWindowId ||
            current.pendingContextToolCallId !== candidate.pendingContextToolCallId ||
            !Schema.toEquivalence(Schema.optional(Selection))(
              current.toolSelection,
              candidate.toolSelection,
            ) ||
            current.committedTurns !== candidate.committedTurns ||
            !Schema.toEquivalence(RunPolicyUsage)(current.policyUsage, candidate.policyUsage) ||
            (
              [
                "modelCalls",
                "inputTokens",
                "outputTokens",
                "lastInputTokens",
                "lastOutputTokens",
                "costMicrousd",
              ] as const
            ).some((field) => current.usage[field] !== candidate.usage[field]) ||
            (current.usage.unobservedModelCalls ?? 0) !==
              (candidate.usage.unobservedModelCalls ?? 0)
          )
            return;

          const summaries = yield* Effect.forEach([current, candidate], (projection) =>
            summarizeModelUsage(projection.usage.modelUsage, projection.usage.summarizedModelUsage),
          ).pipe(Effect.option);

          if (
            Option.isNone(summaries) ||
            summaries.value[0] === undefined ||
            summaries.value[1] === undefined ||
            !Schema.toEquivalence(RunUsageSummary)(summaries.value[0], summaries.value[1])
          )
            return;

          const contents = yield* encodeRecoveryCheckpoint(validated.value);

          if (Option.isNone(contents)) return;

          yield* persistRecoveryCheckpoint(
            ctx,
            submission,
            contents.value,
            tail,
            replacement.record.createdAt,
          );
        },
      );

      const childLineage = records.find(
        ({ record }) => record.recordId === subagentLineageRecordId(submission.threadId),
      )?.record.payload;

      const inheritedGrant =
        submission.workerAdmission?.origin.grant ??
        (childLineage?._tag === "SubagentLineageRecorded" ? childLineage.grant : undefined);

      const delegationDepth =
        submission.workerAdmission?.origin.depth ??
        (childLineage?._tag === "SubagentLineageRecorded" ? childLineage.parentLink.depth : 0);

      // worker-run origins supply a frozen ceiling, not usage credit. Only this native
      // host Run's journal owns usage; joined inputs and replacement Attempts keep its RunId.
      const inheritedBudget =
        submission.workerAdmission?.origin.budget ??
        (childLineage?._tag === "SubagentLineageRecorded" ? childLineage.budget : undefined);

      if (
        submission.parentLinkage !== undefined &&
        (childLineage?._tag !== "SubagentLineageRecorded" ||
          childLineage.parentSubmissionId !== submission.parentLinkage.parentSubmissionId ||
          childLineage.parentLink.parentToolCallId !== submission.parentLinkage.parentToolCallId ||
          !definitionDigestsEqual(childLineage.childDefinitionDigests, submission.agentDigests) ||
          childLineage.childInputDigest !== submission.inputDigest)
      ) {
        return yield* RunJournalError.make({
          message: "The child Run has no matching canonical lineage and execution bounds",
        });
      }

      const pending = yield* pendingToolBatchFor(
        records,
        runId,
        agent.definition.completionFromTools?.map((declaration) => declaration.tool),
      );

      const resumeProjection =
        pending === undefined
          ? journal
          : yield* projectRunJournalStream(
              withoutPendingBatch(canonical, pending, runId),
              runId,
              undefined,
              journalSeed,
              undefined,
              priorContext,
            );

      const rolloverOperation =
        journal.pendingContextToolCallId === undefined
          ? undefined
          : operationsFor(records, runId).get(journal.pendingContextToolCallId);

      const rolloverTool =
        rolloverOperation === undefined
          ? undefined
          : agent.definition.toolkit.tools[rolloverOperation.toolName];

      // A current annotation cannot reinterpret a formerly ordinary settled result as control.
      const pendingContextToolCallId =
        rolloverOperation !== undefined &&
        rolloverTool !== undefined &&
        Context.get(rolloverTool.annotations, ContextRolloverTool) &&
        currentContracts[rolloverOperation.toolName] === rolloverOperation.replay
          ? journal.pendingContextToolCallId
          : undefined;

      const applicationCalls = pending?.calls.filter((call) => !call.providerExecuted);

      // Only the original single-call action-completion case may project a reconciled receipt.
      // Other settled calls are historical outcomes, regardless of their current completion role.
      const completionCandidate =
        applicationCalls?.length === 1 &&
        agent.definition.completionFromTools?.some(
          (declaration) => declaration.tool === applicationCalls[0]?.name,
        ) &&
        pending?.settled.some(
          (result) => result.id === applicationCalls[0]?.id && !result.isFailure,
        )
          ? applicationCalls[0]
          : undefined;

      const settledCompletion =
        pending !== undefined &&
        completionCandidate !== undefined &&
        supportsOperation(
          submission,
          OpenToolCallEvidence.make({
            toolCallId: Schema.decodeSync(ToolCallId)(completionCandidate.id),
            toolName: completionCandidate.name,
            turn: pending.turn,
          }),
          pending.toolOperations?.find(
            (operation) => operation.toolCallId === completionCandidate.id,
          ),
          undefined,
          { definition: agent.definition, contracts: currentContracts },
        )
          ? Schema.decodeSync(ToolCallId)(completionCandidate.id)
          : undefined;

      const knownIds = knownRecordIdsOf(records);
      const stepOutputs = new Map<string, PersistedJson>();

      // Derive replay identity from the recorded tuple, never from its historical ID format.
      // This preserves committed Step outputs when reading legacy colon-separated record IDs.
      for (const envelope of records) {
        const payload = envelope.record.payload;

        if (payload._tag === "ToolStepSettled" && payload.runId === runId) {
          stepOutputs.set(
            toolStepSettledRecordId(runId, payload.toolCallId, payload.stepName),
            payload.output,
          );
        }
      }
      // Recorded approval authority (plan §2.6): canonical `ToolApprovalDecided` records are the
      // deterministic decision source across Attempts; durable `resolveApproval` intents become
      // canonical before they are honored; requested Turns pin the Turn-shared approval batch
      // identity so a later append never contradicts a committed batch.
      const canonicalApprovalDecisions = new Map<string, ApprovalDecision>();
      const approvalRequestedTurns = new Set<number>();

      for (const envelope of records) {
        const payload = envelope.record.payload;

        if (payload._tag === "ToolApprovalDecided" && payload.runId === runId) {
          canonicalApprovalDecisions.set(payload.toolCallId, payload.decision);
        } else if (payload._tag === "ToolApprovalRequested" && payload.runId === runId) {
          approvalRequestedTurns.add(payload.turn);
        }
      }
      const approvalIntents = new Map<string, ApprovalDecisionIntent>();

      for (const intent of approvalDecisions) {
        approvalIntents.set(intent.toolCallId, intent);
      }
      // Joined queued input (plan §2.5): canonical facts for the prompt-coverage rule, computed
      // once per Attempt from the same strongly consistent read as the journal. A joined
      // `input:{sid}` record is prompt-covered iff a host `ModelResponseRecorded` committed
      // after it — commit 1 of every later Turn carries all pending steering (D8 extension), so
      // covered inputs are already inside the journal prompt and must never re-deliver.
      const joinedInputEnvelopes = new Map<string, CanonicalRecordEnvelope>();
      let lastHostResponseSequence: CanonicalSequence | undefined;

      for (const envelope of records) {
        const payload = envelope.record.payload;

        if (
          payload._tag === "UserInputRecorded" &&
          payload.runId === runId &&
          payload.submissionId !== undefined &&
          payload.submissionId !== submissionId
        ) {
          joinedInputEnvelopes.set(payload.submissionId, envelope);
        } else if (payload._tag === "ModelResponseRecorded" && payload.runId === runId) {
          if (
            lastHostResponseSequence === undefined ||
            envelope.sequence > lastHostResponseSequence
          ) {
            lastHostResponseSequence = envelope.sequence;
          }
        }
      }

      // RUN-023: per-Turn usage staged by the engine's `noteTurnUsage` for the
      // Turn's canonical response record (keyed by CANONICAL turn number).
      const stagedToolExposure = new Map<number, Snapshot>();
      const stagedToolSelections = new Map<string, Selection>();

      const stagedUsage = new Map<
        number,
        {
          readonly inputTokens: number;
          readonly outputTokens: number;
          readonly costMicrousd: number;
          readonly modelUsage: ReadonlyArray<ModelCallUsage>;
        }
      >();

      // Staging also backs the cumulative summary; keep it intact and track canonical prefixes.
      const committedUsageLengths = new Map<number, number>();
      const committedUnobservedCalls = new Map<number, number>();

      const usageForCommit = (turn: number) => {
        const staged = stagedUsage.get(turn);

        if (staged === undefined) return undefined;
        const modelUsage = staged.modelUsage.slice(committedUsageLengths.get(turn) ?? 0);

        if (modelUsage.length === 0) return undefined;

        return {
          modelUsage,
          inputTokens: modelUsage.reduce((sum, call) => sum + call.inputTokens.total, 0),
          outputTokens: modelUsage.reduce((sum, call) => sum + call.outputTokens.total, 0),
          costMicrousd: modelUsage.reduce((sum, call) => sum + call.costMicrousd, 0),
        };
      };

      const unobservedForCommit = (turn: number) =>
        (stagedUnobservedCalls.get(turn) ?? 0) - (committedUnobservedCalls.get(turn) ?? 0);

      const recordCommittedUsage = (batch: CanonicalBatch) => {
        for (const record of batch.records) {
          if (
            record.payload._tag !== "ModelResponseRecorded" &&
            record.payload._tag !== "ModelCallAborted"
          )
            continue;
          const payload = record.payload;

          committedUsageLengths.set(
            payload.turn,
            (committedUsageLengths.get(payload.turn) ?? 0) + (payload.modelUsage?.length ?? 0),
          );
          committedUnobservedCalls.set(
            payload.turn,
            (committedUnobservedCalls.get(payload.turn) ?? 0) + (payload.unobservedModelCalls ?? 0),
          );
        }
      };

      const uncommittedModelUsage = () =>
        [...stagedUsage.entries()].flatMap(([turn, usage]) =>
          usage.modelUsage.slice(committedUsageLengths.get(turn) ?? 0),
        );

      // Like stagedUsage, these counts remain relative to the initial journal snapshot.
      const stagedUnobservedCalls = new Map<number, number>();

      let interruptedUsage = records.some(
        ({ record }) =>
          record.payload._tag === "ModelResponseInterrupted" && record.payload.runId === runId,
      );

      const checkedUsageTotal = (
        field: string,
        value: number,
      ): Effect.Effect<number, RunJournalError> =>
        Schema.decodeEffect(Schema.Natural)(value).pipe(
          Effect.mapError((cause) =>
            RunJournalError.make({
              message: `Run usage summary exceeds safe-integer bounds at ${field}`,
              cause,
            }),
          ),
        );

      const addUsageTotal = (field: string, left: number, right: number) =>
        checkedUsageTotal(field, left + right);

      const subtractUsageTotal = (field: string, left: number, right: number) =>
        checkedUsageTotal(field, left - right);

      const currentUsageSummary = (): Effect.Effect<RunUsageSummary, RunJournalError> =>
        Effect.gen(function* () {
          const stagedCalls = [...stagedUsage.values()].flatMap((usage) => usage.modelUsage);
          let unobservedModelCalls = journal.usage.unobservedModelCalls ?? 0;

          for (const count of stagedUnobservedCalls.values()) {
            unobservedModelCalls = yield* addUsageTotal(
              "unobservedModelCalls",
              unobservedModelCalls,
              count,
            );
          }
          const detailedCalls = [...journal.usage.modelUsage, ...stagedCalls];

          const detailed = yield* summarizeModelUsage(
            detailedCalls,
            journal.usage.summarizedModelUsage,
          ).pipe(
            Effect.mapError((cause) =>
              RunJournalError.make({
                message: "Run detailed usage exceeds safe-integer accounting bounds",
                cause,
              }),
            ),
          );

          let inputTokens = journal.usage.inputTokens;
          let outputTokens = journal.usage.outputTokens;
          let costMicrousd = journal.usage.costMicrousd;

          for (const usage of stagedUsage.values()) {
            inputTokens = yield* addUsageTotal("inputTokens", inputTokens, usage.inputTokens);
            outputTokens = yield* addUsageTotal("outputTokens", outputTokens, usage.outputTokens);
            costMicrousd = yield* addUsageTotal("costMicrousd", costMicrousd, usage.costMicrousd);
          }

          const modelCalls = yield* addUsageTotal(
            "modelCalls",
            journal.usage.modelCalls,
            stagedCalls.length,
          );

          const legacyCalls = yield* subtractUsageTotal(
            "legacy.modelCalls",
            modelCalls,
            detailed.modelCalls,
          );

          const legacyInput = yield* subtractUsageTotal(
            "legacy.inputTokens",
            inputTokens,
            detailed.inputTokens.total,
          );

          const legacyOutput = yield* subtractUsageTotal(
            "legacy.outputTokens",
            outputTokens,
            detailed.outputTokens.total,
          );

          const legacyCost = yield* subtractUsageTotal(
            "legacy.costMicrousd",
            costMicrousd,
            detailed.costMicrousd,
          );

          if (legacyCalls === 0 && (legacyInput !== 0 || legacyOutput !== 0 || legacyCost !== 0)) {
            return yield* RunJournalError.make({
              message: "Run aggregate usage has legacy totals without a legacy model call",
            });
          }
          const byModel = [...detailed.byModel];

          if (legacyCalls > 0) {
            const existingIndex = byModel.findIndex(
              (group) =>
                group.provider === "unknown" &&
                group.model === "legacy-record" &&
                group.responseModel === undefined &&
                group.serviceTier === undefined &&
                group.pricingVersion === undefined,
            );

            const existing = existingIndex < 0 ? undefined : byModel[existingIndex];

            const legacyGroup = ModelUsageGroup.make({
              provider: "unknown",
              model: "legacy-record",
              modelCalls: yield* addUsageTotal(
                "byModel.modelCalls",
                existing?.modelCalls ?? 0,
                legacyCalls,
              ),
              inputTokens: InputTokenUsage.make({
                total: yield* addUsageTotal(
                  "byModel.inputTokens.total",
                  existing?.inputTokens.total ?? 0,
                  legacyInput,
                ),
                uncached: yield* addUsageTotal(
                  "byModel.inputTokens.uncached",
                  existing?.inputTokens.uncached ?? 0,
                  legacyInput,
                ),
                cacheRead: existing?.inputTokens.cacheRead ?? 0,
                cacheWrite: existing?.inputTokens.cacheWrite ?? 0,
              }),
              outputTokens: OutputTokenUsage.make({
                total: yield* addUsageTotal(
                  "byModel.outputTokens.total",
                  existing?.outputTokens.total ?? 0,
                  legacyOutput,
                ),
                text: yield* addUsageTotal(
                  "byModel.outputTokens.text",
                  existing?.outputTokens.text ?? 0,
                  legacyOutput,
                ),
                reasoning: existing?.outputTokens.reasoning ?? 0,
              }),
              costMicrousd: yield* addUsageTotal(
                "byModel.costMicrousd",
                existing?.costMicrousd ?? 0,
                legacyCost,
              ),
            });

            if (existingIndex < 0) byModel.push(legacyGroup);
            else byModel[existingIndex] = legacyGroup;
          }

          const uncached = yield* addUsageTotal(
            "inputTokens.uncached",
            detailed.inputTokens.uncached,
            legacyInput,
          );

          const text = yield* addUsageTotal(
            "outputTokens.text",
            detailed.outputTokens.text,
            legacyOutput,
          );

          return RunUsageSummary.make({
            ...(legacyCalls === 0 && detailed.webSearchCalls !== undefined
              ? { webSearchCalls: detailed.webSearchCalls }
              : {}),
            modelCalls,
            inputTokens: InputTokenUsage.make({
              total: inputTokens,
              // Legacy aggregate inputs are conservatively classified as uncached.
              uncached,
              cacheRead: detailed.inputTokens.cacheRead,
              cacheWrite: detailed.inputTokens.cacheWrite,
            }),
            outputTokens: OutputTokenUsage.make({
              total: outputTokens,
              text,
              reasoning: detailed.outputTokens.reasoning,
            }),
            costMicrousd,
            byModel,
            unobservedModelCalls,
            usageStatus:
              legacyCalls > 0 || unobservedModelCalls > 0 || interruptedUsage
                ? detailed.usageStatus === "unknown"
                  ? "unknown"
                  : "partial"
                : detailed.usageStatus,
            pricingStatus:
              legacyCalls > 0 || unobservedModelCalls > 0 || interruptedUsage
                ? detailed.pricingStatus === "unknown"
                  ? "unknown"
                  : "partial"
                : detailed.pricingStatus,
          });
        });

      const recordedCompletion = records.find(
        (envelope) => envelope.record.recordId === runCompletedRecordId(runId),
      )?.record.payload;

      if (recordedCompletion !== undefined) {
        if (recordedCompletion._tag !== "RunCompleted" || recordedCompletion.runId !== runId) {
          return yield* RunJournalError.make({
            message: `Run ${runId} has an invalid terminal completion marker`,
          });
        }

        const response = [...records]
          .reverse()
          .find(
            (envelope) =>
              envelope.record.payload._tag === "ModelResponseRecorded" &&
              envelope.record.payload.runId === runId,
          )?.record.payload;

        if (response?._tag !== "ModelResponseRecorded") {
          return yield* RunJournalError.make({
            message: `Run ${runId} has a terminal completion marker without a response`,
          });
        }
        const declared = yield* declaredToolCalls(response.messages);
        const calls = declared.application;

        if (calls.length > 0) {
          const call = calls[0];

          const settled =
            call === undefined
              ? undefined
              : records.find(
                  ({ record }) =>
                    record.payload._tag === "ToolCallSettled" &&
                    record.payload.runId === runId &&
                    record.payload.toolCallId === call.id,
                )?.record.payload;

          if (
            calls.length !== 1 ||
            call === undefined ||
            settled?._tag !== "ToolCallSettled" ||
            settled.toolName !== call.name ||
            settled.isFailure
          ) {
            return yield* RunJournalError.make({
              message: `Run ${runId} has a terminal completion marker without one successful declared Tool result`,
            });
          }
        }
        if (
          recordedCompletion.resultDigest !== undefined &&
          recordedCompletion.resultDigest !==
            (yield* withCrypto(runCompletionDigest(recordedCompletion)))
        )
          return yield* RunJournalError.make({
            message: "RunCompleted terminal values failed their integrity check",
          });
        // Output and disposition were validated before the atomic RunCompleted commit.
        // Future application codecs and completion functions have no authority to reinterpret it.

        return {
          _tag: "completed" as const,
          result: recordedCompletion.output,
          ...(recordedCompletion.runDisposition === undefined
            ? {}
            : { runDisposition: recordedCompletion.runDisposition }),
          ...(recordedCompletion.finishReason === undefined
            ? {}
            : { finishReason: recordedCompletion.finishReason }),
          ...(recordedCompletion.exhausted === undefined
            ? {}
            : { exhausted: recordedCompletion.exhausted }),
          usageSummary: yield* currentUsageSummary(),
        };
      }
      // Summaries cover only prior Runs. Pruning and rollover also map fully settled
      // current-Run records and preserves the canonical instruction/input block during replay.
      let ownerFirstSequence: CanonicalSequence | undefined;

      for (const envelope of records) {
        const payload = envelope.record.payload;

        if ("runId" in payload && payload.runId === runId) {
          ownerFirstSequence = envelope.sequence;
          break;
        }
      }

      /** Only canonical joined inputs can require restoration from an earlier Attempt. */
      let joinBacklog: ReadonlyArray<JoinSnapshot> | undefined =
        joinedInputEnvelopes.size === 0 ? [] : undefined;

      /** Joined inputs already handed to the engine during THIS Attempt (never re-deliver). */
      const deliveredJoinInputs = new Set<string>();
      // Canonical encoded parameters per declared call, for the approval request digest: seeded
      // by `commitResponse` (which the engine invokes before approval preflight) and by the
      // resumed batch's declared calls.
      const encodedParamsByCallId = new Map<string, unknown>();
      // Declared Tool name per call: the subagent join/sibling-settle appends rebuild exact
      // `ToolCallSettled` records outside the engine's results commit, so the declared name must
      // be recoverable per call id (seeded from canonical prepared records, the resumed batch,
      // and every `commitResponse`).
      const declaredNamesByCallId = new Map<string, string>();
      // Canonical subagent lifecycle state of this Run (SUB-016): seeded from canonical records,
      // advanced by the establish/join hook closures below, and consulted on every replay so an
      // identical establishment converges on the one existing child.
      const subagentState = subagentRecordsOf(records, runId);

      for (const [callId, name] of subagentState.preparedNames) {
        declaredNamesByCallId.set(callId, name);
      }
      if (pending !== undefined) {
        for (const call of pending.calls) {
          encodedParamsByCallId.set(call.id, call.params);
          declaredNamesByCallId.set(call.id, call.name);
        }
      }
      // Task #12 (WP1 `resume.leadingMessages`): the pending canonical response's messages
      // BEFORE its first assistant message — Turn-1 evaluated instructions + input, or steering
      // committed inside the pending record — re-enter official history through the engine so
      // the resumed live model context does not silently drop them.
      let resumeLeadingMessages: Prompt.Prompt | undefined;
      let resumeResponseMessages: Prompt.Prompt | undefined;

      if (pending !== undefined) {
        const pendingMessages = yield* decodePrompt(pending.messages).pipe(
          Effect.mapError((cause) =>
            RunJournalError.make({
              message:
                "Pending ModelResponseRecorded messages are not Schema-encoded Prompt messages",
              cause,
            }),
          ),
        );

        const firstAssistant = pendingMessages.content.findIndex(
          (message) => message.role === "assistant",
        );

        if (firstAssistant > 0) {
          resumeLeadingMessages = Prompt.fromMessages(
            pendingMessages.content
              .slice(0, firstAssistant)
              .filter((message) => message.role !== "system"),
          );
        }
        if (firstAssistant >= 0) {
          resumeResponseMessages = Prompt.fromMessages(
            pendingMessages.content.slice(firstAssistant),
          );
        }
      }

      let currentToolTurn: { readonly turn: number; readonly turnId: TurnId } | undefined =
        pending === undefined ? undefined : { turn: pending.turn, turnId: pending.turnId };

      // Terminal sibling results observed from the Run event stream, keyed by Tool Call id: the
      // suspension seam commits each settled non-waiting sibling as a per-call late-settle batch
      // BEFORE the `waitingForChild` suspension so no sibling effect is lost to it (plan §2).
      const siblingResults = new Map<
        string,
        { readonly toolCallId: ToolCallId; readonly result: unknown; readonly isFailure: boolean }
      >();

      const budgetRejectedCalls = new Set<string>();
      // Step-hook coordinator failures are re-wrapped by the engine as `DurableStepError` in the
      // handler channel; this side channel preserves the original failure so the Attempt aborts
      // (obligation still owed) instead of settling the Run `failed` on an infrastructure fault.
      const haltRef = yield* Ref.make<DurableWorkerFailure | undefined>(undefined);
      const yieldSignal = yield* Deferred.make<SubmissionId | undefined>();

      const recordHalt = <A, R>(
        effect: Effect.Effect<A, DurableWorkerFailure, R>,
      ): Effect.Effect<A, CoordinatorHalt, R> =>
        effect.pipe(
          Effect.tapError((failure) => Ref.set(haltRef, failure)),
          halt,
        );

      interface RunState {
        readonly baseLen: number | undefined;
        readonly lastCommitLen: number;
        readonly history: Prompt.Prompt | undefined;
        readonly pendingTurn: { readonly turn: number; readonly turnId: TurnId } | undefined;
        readonly completedOutput: PersistedJson | undefined;
        readonly completedRunDisposition: PersistedJson | undefined;
        readonly completedFinishReason: "budget-exhausted" | undefined;
        readonly completedExhausted: ExhaustedLimit | undefined;
      }

      const stateRef = yield* Ref.make<RunState>({
        baseLen: undefined,
        lastCommitLen: 0,
        history: undefined,
        pendingTurn: undefined,
        completedOutput: undefined,
        completedRunDisposition: undefined,
        completedFinishReason: undefined,
        completedExhausted: undefined,
      });

      const turnCounter = yield* Ref.make(
        journal.committedTurns + (journal.policyUsage.modelRestarts ?? 0),
      );

      const idGenerator: (typeof IdGenerator)["Service"] = {
        nextThreadId: Effect.succeed(submission.threadId),
        nextRunId: Effect.succeed(runId),
        nextTurnId: Ref.modify(turnCounter, (turn) => [turnIdForRun(runId, turn + 1), turn + 1]),
      };

      // Track live Prompt boundaries only. The journal owns durable per-Turn commits and recovery;
      // successful-run ThreadHistory retention cannot replace those incremental commits.
      const onHistory = (history: Prompt.Prompt): Effect.Effect<void> =>
        Ref.update(stateRef, (state) =>
          state.baseLen === undefined
            ? {
                ...state,
                baseLen: history.content.length,
                // A fresh Run's first commit starts at the engine-provided history boundary so
                // the evaluated instruction + user messages become canonical inside Turn 1 (D8).
                // A resumed Run's boundary is the engine's re-evaluated initial prompt: those
                // messages are already canonical inside the original Turn 1 and never re-enter
                // (a pending batch resume always implies at least one committed Turn).
                lastCommitLen:
                  journal.committedTurns === 0
                    ? journal.historyBefore.content.length
                    : history.content.length,
                history,
              }
            : { ...state, history },
        );

      // Current instructions govern the continuation; the original user intent, steering and
      // committed history survive. The pending Turn re-enters through the batch continuation,
      // without duplicating the engine's freshly rendered input.
      // Retained immediate history can contain system messages. Its prefix stays untouched;
      // only this Run's instruction slots receive the freshly evaluated instructions.
      const instructionView = (
        messages: ReadonlyArray<Prompt.Message>,
        instructions: ReadonlyArray<Prompt.Message>,
        insertWhenAbsent: boolean,
        priorRunPrefixLength: number,
      ) => {
        const projected: Array<Prompt.Message> = [];
        const lengths = [0];
        let inserted = false;

        for (const [index, message] of messages.entries()) {
          if (index >= priorRunPrefixLength && message.role === "system") {
            if (!inserted) projected.push(...instructions);
            inserted = true;
          } else projected.push(message);
          lengths.push(projected.length);
        }
        if (!inserted && insertWhenAbsent) projected.push(...instructions);

        return {
          messages: projected,
          prefixLength: (length: number) => lengths[length] ?? projected.length,
        };
      };

      const resumeContext = {
        prepare: ({ source }: { readonly source: Prompt.Prompt }) =>
          Ref.get(stateRef).pipe(
            Effect.map((state) => {
              const view = instructionView(
                resumeProjection.prompt.content,
                source.content
                  .slice(resumeProjection.historyBefore.content.length, state.baseLen)
                  .filter((message) => message.role === "system"),
                true,
                resumeProjection.historyBefore.content.length,
              );

              return {
                prompt: Prompt.fromMessages([
                  ...view.messages,
                  ...source.content.slice(state.baseLen ?? source.content.length),
                ]),
                priorRunPrefixLength: view.prefixLength(
                  resumeProjection.historyBefore.content.length,
                ),
              };
            }),
          ),
      } satisfies RunContextHook<never, never>;

      const externalContext = runContextPreparation.hook;

      const preparedContext: RunContextHook<RunContextPreparationError, never> | undefined =
        externalContext === undefined
          ? journal.committedTurns === 0
            ? undefined
            : resumeContext
          : {
              prepare: (request) =>
                (journal.committedTurns === 0
                  ? Effect.succeed({
                      prompt: request.source,
                      priorRunPrefixLength: journal.historyBefore.content.length,
                    })
                  : resumeContext.prepare(request)
                ).pipe(
                  Effect.flatMap(({ prompt, priorRunPrefixLength }) =>
                    externalContext.prepare({
                      ...request,
                      source: prompt,
                      priorRunPrefixLength,
                    }),
                  ),
                ),
            };

      const durability: RunDurabilityHook<CoordinatorHalt | CompactionError, never> = {
        commitModelRestart: (restart) =>
          recordHalt(
            Effect.gen(function* () {
              if (knownIds.has(modelResponseRecordId(runId, restart.turn)))
                return yield* RunJournalError.make({
                  message: "Cannot restart a canonical model response",
                });
              const recordId = decodeRecordIdSync(`model-aborted:${runId}:${restart.restart}`);

              const record = yield* makeEnvelope(
                recordId,
                ModelCallAborted.make({
                  runId,
                  ...restart,
                  reason: "joined-input",
                  modelUsage: usageForCommit(restart.turn)?.modelUsage ?? [],
                  unobservedModelCalls: unobservedForCommit(restart.turn),
                }),
              );

              const batch = CanonicalBatch.make({
                batchId: decodeBatchIdSync(recordId),
                producerId: config.producerId,
                records: [record],
              });

              yield* appendBatch(ctx, batch);
              recordCommittedUsage(batch);
              knownIds.add(recordId);
            }),
          ),
        noteToolExposure: (turn, snapshot) =>
          Effect.sync(() => {
            stagedToolExposure.set(turn, snapshot);
          }),
        reservePolicyUsage: (usage) =>
          recordHalt(
            Effect.gen(function* () {
              const recordId = decodeRecordIdSync(
                `policy:${runId}:${usage.programmaticToolCalls}:${usage.finalizationUsed}`,
              );

              if (knownIds.has(recordId)) return;

              const record = yield* makeEnvelope(
                recordId,
                RunPolicyUsageReserved.make({ runId, ...usage }),
              );

              yield* hit("policy:before-reservation-append");
              yield* appendBatch(
                ctx,
                CanonicalBatch.make({
                  batchId: decodeBatchIdSync(recordId),
                  producerId: config.producerId,
                  records: [record],
                }),
              );
              knownIds.add(recordId);
              yield* hit("policy:after-reservation-append");
            }),
          ),
        commitResponse: (commit) =>
          recordHalt(
            Effect.gen(function* () {
              const canonicalTurn = commit.turn;

              currentToolTurn = { turn: canonicalTurn, turnId: commit.turnId };
              for (const call of commit.calls) {
                encodedParamsByCallId.set(call.toolCallId, call.parameters);
                declaredNamesByCallId.set(call.toolCallId, call.toolName);
              }
              const responseId = modelResponseRecordId(runId, canonicalTurn);

              if (knownIds.has(responseId)) return;
              const state = yield* Ref.get(stateRef);
              const history = state.history;

              if (history === undefined) {
                return yield* RunJournalError.make({
                  message: `Turn ${canonicalTurn} committed a response before official history advanced`,
                });
              }
              // D8 extension (decision point 6): the pending slice — evaluated instructions +
              // input for Turn 1, queued steering for later Turns — becomes canonical as the
              // leading messages of this response batch.
              const pendingSlice = history.content.slice(state.lastCommitLen);
              const createdAt = yield* nowUtc;

              const batch = yield* withCrypto(
                turnResponseBatch({
                  toolExposure: commit.toolExposure,
                  toolOperations: commit.calls.map((call) =>
                    ToolOperation.make({
                      toolCallId: call.toolCallId,
                      toolName: call.toolName,
                      executionClass: call.executionClass,
                      executionKind: call.executionKind,
                      replay: currentContracts[call.toolName]!,
                    }),
                  ),
                  toolParameterRejections: commit.toolParameterRejections,
                  runId,
                  turn: canonicalTurn,
                  turnId: commit.turnId,
                  appended: [...pendingSlice, ...commit.responseMessages.content],
                  producerId: config.producerId,
                  deploymentId: config.deploymentId,
                  createdAt,
                  ...(canonicalTurn === 1 && pendingSlice.length > 0
                    ? { runScopedPrefixLength: pendingSlice.length }
                    : {}),
                  usage: usageForCommit(canonicalTurn),
                  unobservedModelCalls: unobservedForCommit(canonicalTurn),
                }),
              );

              yield* appendBatch(ctx, batch);
              recordCommittedUsage(batch);
              for (const record of batch.records) knownIds.add(record.recordId);
              yield* hit("turn:after-response-append");
            }),
          ),
        prepareToolCalls: (calls) =>
          recordHalt(
            Effect.gen(function* () {
              const first = calls[0];

              if (first === undefined) return;
              const turnInfo = currentToolTurn;

              if (turnInfo === undefined) {
                return yield* RunJournalError.make({
                  message: "Tool Calls were prepared before any canonical response commit",
                });
              }
              // The prepared batch is atomic: one canonical record implies all of them, so a
              // batch-identity replay (resume) is skipped wholesale.
              if (knownIds.has(toolCallPreparedRecordId(runId, turnInfo.turn, first.toolCallId))) {
                return;
              }
              const preparedRecords: Array<RecordEnvelope> = [];

              for (const call of calls) {
                const parameters = yield* decodePersisted(call.parameters).pipe(
                  Effect.mapError((cause) =>
                    RunJournalError.make({
                      message: `Tool Call ${call.toolCallId} parameters exceed canonical persistence bounds`,
                      cause,
                    }),
                  ),
                );

                const parametersDigest = yield* withCrypto(digestJson(parameters));

                preparedRecords.push(
                  yield* makeEnvelope(
                    toolCallPreparedRecordId(runId, turnInfo.turn, call.toolCallId),
                    ToolCallPrepared.make({
                      runId,
                      turnId: turnInfo.turnId,
                      turn: turnInfo.turn,
                      toolCallId: call.toolCallId,
                      toolName: call.toolName,
                      parameters,
                      parametersDigest,
                      executionKind: call.executionKind,
                      executionClass: call.executionClass,
                      replay: currentContracts[call.toolName]!,
                    }),
                  ),
                );
              }
              const head = preparedRecords[0];

              if (head === undefined) return;
              yield* hit("tools:before-prepared-append");
              yield* appendBatch(
                ctx,
                CanonicalBatch.make({
                  batchId: turnPreparedBatchId(runId, turnInfo.turn),
                  producerId: config.producerId,
                  records: [head, ...preparedRecords.slice(1)],
                }),
              );
              for (const record of preparedRecords) knownIds.add(record.recordId);
              yield* hit("tools:after-prepared-append");
            }),
          ),
        step: {
          lookup: (key) =>
            Effect.sync(() => {
              const output = stepOutputs.get(
                toolStepSettledRecordId(runId, key.toolCallId, key.stepName),
              );

              return output === undefined ? Option.none() : Option.some({ encodedOutput: output });
            }),
          commit: (key, encodedOutput) =>
            recordHalt(
              Effect.gen(function* () {
                const recordId = toolStepSettledRecordId(runId, key.toolCallId, key.stepName);

                if (knownIds.has(recordId)) return;

                const output = yield* decodePersisted(encodedOutput).pipe(
                  Effect.mapError((cause) =>
                    RunJournalError.make({
                      message: `Durable Step ${key.stepName} output exceeds canonical persistence bounds`,
                      cause,
                    }),
                  ),
                );

                const outputDigest = yield* withCrypto(digestJson(output));

                const envelope = yield* makeEnvelope(
                  recordId,
                  ToolStepSettled.make({
                    runId,
                    toolCallId: key.toolCallId,
                    stepName: key.stepName,
                    output,
                    outputDigest,
                  }),
                );

                yield* appendBatch(
                  ctx,
                  CanonicalBatch.make({
                    batchId: toolStepSettledBatchId(runId, key.toolCallId, key.stepName),
                    producerId: config.producerId,
                    records: [envelope],
                  }),
                );
                knownIds.add(recordId);
                stepOutputs.set(recordId, output);
                yield* hit("step:after-step-append");
              }),
            ),
        },
        noteTurnUsage: (usage) =>
          Effect.sync(() => {
            // Accumulate, never replace: a compaction summarizer and the
            // Turn's own response stage into the same canonical Turn.
            const key = usage.turn;
            const prior = stagedUsage.get(key);

            stagedUsage.set(key, {
              inputTokens: (prior?.inputTokens ?? 0) + usage.usage.inputTokens.total,
              outputTokens: (prior?.outputTokens ?? 0) + usage.usage.outputTokens.total,
              costMicrousd: (prior?.costMicrousd ?? 0) + usage.usage.costMicrousd,
              modelUsage: [...(prior?.modelUsage ?? []), usage.usage],
            });
          }),
        commitCompaction: (commit) =>
          Effect.gen(function* () {
            const canonicalTurn = commit.turn;
            const recordId = compactionRecordId(runId, canonicalTurn, commit.kind);

            if (knownIds.has(recordId)) {
              return yield* CompactionError.make({
                message: "Compaction is already committed for this Turn and kind",
              });
            }

            let sourceJournal = journal;
            let sourceBoundaries = boundaries;

            if (commit.kind !== "summarize" || priorContext !== undefined) {
              // Results must be canonical before pruning or rollover can cover them. Newly committed
              // compactions remain overlays on this Attempt's append-only source, so omit those
              // overlays while reconstructing the exact source-to-record mapping.
              if (commit.kind !== "summarize") yield* recordHalt(commitPendingTurn);
              const tail = yield* Ref.get(ctx.tailRef);

              sourceBoundaries = [];
              sourceJournal = yield* recordHalt(
                projectRunJournalStream(
                  (priorContext === undefined
                    ? Stream.concat(
                        canonical,
                        canonicalRange(ctx.threadId, tail.sequence, canonicalThrough),
                      )
                    : canonicalRange(
                        ctx.threadId,
                        commit.kind === "summarize" ? canonicalThrough : tail.sequence,
                      )
                  ).pipe(
                    Stream.filter(
                      (envelope) =>
                        envelope.record.payload._tag !== "CompactionCreated" ||
                        envelope.sequence <= canonicalThrough,
                    ),
                  ),
                  runId,
                  (boundary) => sourceBoundaries.push(boundary),
                  journalSeed,
                ),
              );
            }

            // Summaries use the initial prior-Run boundaries; pruning and rollover also admit
            // complete current-Run boundaries from the fresh canonical source above.
            const coverable = sourceBoundaries.filter(
              (boundary) =>
                commit.kind !== "summarize" ||
                ownerFirstSequence === undefined ||
                boundary.sequence < ownerFirstSequence,
            );

            if (coverable.length === 0) {
              return yield* CompactionError.make({
                message:
                  commit.kind === "rollover"
                    ? "Durable rollover requires complete canonical records"
                    : "Durable compaction requires eligible canonical records",
              });
            }

            const state = yield* Ref.get(stateRef);

            const comparisonView = instructionView(
              sourceJournal.prompt.content,
              state.history?.content
                .slice(resumeProjection.historyBefore.content.length, state.baseLen)
                .filter((message) => message.role === "system") ?? [],
              false,
              sourceJournal.historyBefore.content.length,
            );

            // Compare each visible message once. A transformed source can authorize only its
            // exact canonical prefix; no per-candidate rereads or full encoded Prompt copies.
            let matchingPrefix = 0;
            let requiredThrough = 0;
            const comparisonLimit = Math.min(comparisonView.messages.length, commit.through);

            for (let index = 0; index < commit.through; index += 1) {
              const message = commit.source.content[index];

              if (
                message !== undefined &&
                (commit.kind === "clear-tool-results"
                  ? message.role === "tool"
                  : message.role !== "system")
              )
                requiredThrough = index + 1;
              if (index >= comparisonLimit || index !== matchingPrefix || message === undefined)
                continue;
              const canonicalMessage = comparisonView.messages[index];

              if (canonicalMessage === undefined) continue;

              const encode = (entry: Prompt.Message) =>
                Schema.encodeEffect(Prompt.Message)(entry).pipe(
                  Effect.mapError((cause) =>
                    CompactionError.make({
                      message: "Could not encode the canonical compaction prefix",
                      cause,
                    }),
                  ),
                );

              const left = yield* encode(canonicalMessage);
              const right = yield* encode(message);

              if (JSON.stringify(left) === JSON.stringify(right)) matchingPrefix += 1;
            }

            let lastCovered: JournalBoundary | undefined;

            for (let index = 0; index < coverable.length; index += 1) {
              const candidate = coverable[index];

              if (candidate === undefined) continue;
              const following = coverable[index + 1];

              if (following !== undefined && following.tag !== "ModelResponseRecorded") continue;

              const length = comparisonView.prefixLength(candidate.promptLength);

              if (length === 0 || length > commit.through) continue;
              if (length < requiredThrough || length > matchingPrefix) continue;
              lastCovered = candidate;
            }
            if (lastCovered === undefined) {
              return yield* CompactionError.make({
                message:
                  commit.kind === "rollover"
                    ? "Rollover coverage cannot be mapped to complete canonical records"
                    : "Compaction coverage cannot be mapped to complete canonical records",
              });
            }
            const coveredSequence = lastCovered.sequence;

            if (
              commit.kind !== "summarize" &&
              sourceBoundaries.some(
                (boundary) =>
                  boundary.incomplete === true &&
                  boundary.terminalPriorRun !== true &&
                  boundary.sequence <= coveredSequence,
              )
            ) {
              return yield* CompactionError.make({
                message: "Compaction cannot cover an incomplete Tool batch",
              });
            }
            if (commit.kind === "summarize" && (commit.summary ?? "").trim().length === 0) {
              return yield* CompactionError.make({
                message: "A summarize compaction commit carried no summary",
              });
            }

            const payload = yield* Schema.decodeEffect(CompactionCreated)({
              _tag: "CompactionCreated",
              runId,
              turn: canonicalTurn,
              kind: commit.kind,
              coversThrough: lastCovered.sequence,
              ...(commit.kind === "summarize" ? { summary: commit.summary } : {}),
              ...(commit.kind === "rollover" && commit.handoff !== undefined
                ? { handoff: commit.handoff }
                : {}),
            }).pipe(
              Effect.mapError((cause) =>
                CompactionError.make({
                  message: "Compaction decision exceeds canonical persistence bounds",
                  cause,
                }),
              ),
            );

            const envelope = yield* recordHalt(makeEnvelope(recordId, payload));

            yield* recordHalt(hit("compaction:before-canonical-append"));
            yield* recordHalt(
              appendBatch(
                ctx,
                CanonicalBatch.make({
                  batchId: compactionBatchId(runId, canonicalTurn, commit.kind),
                  producerId: config.producerId,
                  records: [envelope],
                }),
              ),
            );
            knownIds.add(recordId);
            yield* recordHalt(hit("compaction:after-canonical-append"));
            if (commit.kind !== "clear-tool-results")
              yield* recordHalt(saveRecoveryCheckpoint(recordId));
          }),
      };

      /** Digest of one declared call's canonical encoded parameters (same family as prepared). */
      const approvalParametersDigest = (
        toolCallId: string,
      ): Effect.Effect<Digest, DurableWorkerFailure> =>
        Effect.gen(function* () {
          if (!encodedParamsByCallId.has(toolCallId)) {
            return yield* RunJournalError.make({
              message: `Tool Call ${toolCallId} requested approval before its response commit`,
            });
          }

          const parameters = yield* decodePersisted(encodedParamsByCallId.get(toolCallId)).pipe(
            Effect.mapError((cause) =>
              RunJournalError.make({
                message: `Tool Call ${toolCallId} parameters exceed canonical persistence bounds`,
                cause,
              }),
            ),
          );

          return yield* withCrypto(digestJson(parameters));
        });

      /**
       * Append the canonical approval records for one declared call: the `ToolApprovalRequested`
       * record — plus the immediate `ToolApprovalDecided` for a policy-auto or intent-backed
       * decision, one atomic batch — or the decision alone when the request is already canonical.
       * Batch identity: the Turn's FIRST canonical approval append owns
       * `turn-approvals:{runId}:{turn}`; later appends of the same Turn (across suspension
       * cycles) use deterministic per-call batches so committed batch content is never
       * contradicted; decision-only appends use `approval-decision:{sid}:{toolCallId}`. Record
       * identity dedupes every replay; an identity conflict means another pass already committed
       * the same records.
       */
      const appendApprovalRecords = (
        turnInfo: { readonly turn: number; readonly turnId: TurnId },
        toolCallId: ToolCallId,
        toolName: string,
        decided:
          | {
              readonly decision: ApprovalDecision;
              readonly resolver: string;
              readonly reason: string;
            }
          | undefined,
      ): Effect.Effect<void, DurableWorkerFailure> =>
        Effect.gen(function* () {
          const requestRecordId = toolApprovalRequestRecordId(runId, turnInfo.turn, toolCallId);
          const decisionRecordId = toolApprovalDecisionRecordId(runId, turnInfo.turn, toolCallId);
          const envelopes: Array<RecordEnvelope> = [];
          const appendRequest = !knownIds.has(requestRecordId);

          if (appendRequest) {
            const parametersDigest = yield* approvalParametersDigest(toolCallId);

            envelopes.push(
              yield* makeEnvelope(
                requestRecordId,
                ToolApprovalRequested.make({
                  runId,
                  turnId: turnInfo.turnId,
                  turn: turnInfo.turn,
                  toolCallId,
                  toolName,
                  parametersDigest,
                }),
              ),
            );
          }
          if (decided !== undefined && !knownIds.has(decisionRecordId)) {
            envelopes.push(
              yield* makeEnvelope(
                decisionRecordId,
                ToolApprovalDecided.make({
                  runId,
                  turn: turnInfo.turn,
                  toolCallId,
                  decision: decided.decision,
                  resolver: decided.resolver,
                  reason: decided.reason,
                }),
              ),
            );
          }
          const head = envelopes[0];

          if (head !== undefined) {
            const batchId = appendRequest
              ? approvalRequestedTurns.has(turnInfo.turn)
                ? decodeBatchId(`approval-request:${runId}:${turnInfo.turn}:${toolCallId}`)
                : turnApprovalsBatchId(runId, turnInfo.turn)
              : approvalDecisionBatchId(submissionId, toolCallId);

            yield* appendBatch(
              ctx,
              CanonicalBatch.make({
                batchId,
                producerId: config.producerId,
                records: [head, ...envelopes.slice(1)],
              }),
            ).pipe(
              Effect.catchTag("AppendConflict", () => Effect.void),
              Effect.asVoid,
            );
            for (const record of envelopes) knownIds.add(record.recordId);
          }
          if (appendRequest) {
            approvalRequestedTurns.add(turnInfo.turn);
            yield* hit("approval:after-request-append");
          }
          if (decided !== undefined) {
            canonicalApprovalDecisions.set(toolCallId, decided.decision);
          }
        });

      /**
       * Durable approval hook (plan §2.6). Resolution order per declared call: (1) a canonical
       * `ToolApprovalDecided` record — the deterministic decision authority across Attempts;
       * (2) a durable `resolveApproval` intent, appended canonically before it is honored;
       * (3) the optional policy-auto delegate, whose immediate decision becomes canonical
       * (request + decision, one atomic batch) before it is honored; (4) otherwise the canonical
       * `ToolApprovalRequested` record is appended and the call reports unresolved — with the
       * request canonical, "waiting for explicit approval" is a safe durable boundary
       * (durability §8), the engine raises `AgentApprovalPending`, and the Attempt suspends
       * without settling. A denied decision fails the Run through the engine's
       * `AgentApprovalDenied` path with the denial already canonical.
       */
      const approval: RunApprovalHook<CoordinatorHalt, never> = {
        request: (request) =>
          recordHalt(
            Effect.gen(function* () {
              const turnInfo = currentToolTurn;

              if (turnInfo === undefined) {
                return yield* RunJournalError.make({
                  message: `Tool Call ${request.toolCallId} requested approval before any canonical response commit`,
                });
              }
              const toolCallId = request.toolCallId;
              const canonical = canonicalApprovalDecisions.get(toolCallId);

              if (canonical !== undefined) {
                return canonical === "approved"
                  ? { _tag: "approved" as const }
                  : { _tag: "denied" as const };
              }
              const intent = approvalIntents.get(toolCallId);

              if (intent !== undefined) {
                yield* appendApprovalRecords(turnInfo, toolCallId, request.toolName, {
                  decision: intent.decision,
                  resolver: intent.resolver,
                  reason: intent.reason,
                });

                return intent.decision === "approved"
                  ? { _tag: "approved" as const, reason: intent.reason }
                  : { _tag: "denied" as const, reason: intent.reason };
              }
              if (approvalResolver !== undefined) {
                const delegated = yield* approvalResolver.request(request);

                if (delegated._tag !== "unresolved") {
                  yield* appendApprovalRecords(turnInfo, toolCallId, request.toolName, {
                    decision: delegated._tag,
                    resolver: APPROVAL_POLICY_RESOLVER,
                    reason: boundedApprovalReason(
                      delegated.reason,
                      "The configured approval policy decided immediately",
                    ),
                  });

                  return delegated;
                }
              }
              yield* appendApprovalRecords(turnInfo, toolCallId, request.toolName, undefined);

              return {
                _tag: "unresolved" as const,
                reason:
                  "The approval request is canonical and awaits a durable resolveApproval decision",
              };
            }),
          ),
      };

      /**
       * Joining/Joined queued input hook (plan §2.5, DUR-016). At every engine drain seam:
       *
       * 1. Reattach first — pre-existing joins whose canonical `input:{sid}` record is not yet
       *    prompt-covered re-deliver WITHOUT re-appending (record identity is the dedupe);
       *    covered inputs are already inside the journal prompt. A `joining` row whose input is
       *    canonical only lost its marker: it is repaired from history under the host's live
       *    ownership (DUR-015). A `joining` row WITHOUT canonical input was never consumed and
       *    is recovery's to revert — the hook never guesses at it (fail-closed).
       * 2. Claim fresh — `claimJoining` atomically transitions the contiguous ready prefix of
       *    strictly-later queue sequences to `joining` under the host's ownership token (no
       *    epoch bump; an admitted-not-ready row breaks the prefix). Per fresh claim: honor a
       *    pre-consumption abort intent by reverting (revert-then-abort), else append the
       *    deterministic `UserInputRecorded` (batch `submission-input:{sid}`, record
       *    `input:{sid}`, `runId` = host Run, kind `steering`) → `join:after-canonical-append`
       *    → `markJoined` → hand the engine the `RunInputCommand`.
       *
       * Delivered input is `steering`: the engine appends it to official history at the seam,
       * so the next Turn's response commit makes it model-visible canonically — exactly the
       * prompt-coverage rule recovery relies on.
       */
      const renderJoinedInput = ({
        input: encodedInput,
        messageAdmission,
      }: Pick<UserInputRecorded, "input" | "messageAdmission">) =>
        Effect.gen(function* () {
          if (Schema.is(FrameworkMessage)(messageAdmission))
            return yield* Schema.encodeEffect(Schema.fromJsonString(FrameworkMessage))(
              messageAdmission,
            ).pipe(
              Effect.mapError(() =>
                AgentInputError.make({ message: "Invalid worker completion message" }),
              ),
            );
          const inputPrompt = agent.definition.inputPrompt;

          if (inputPrompt === undefined) {
            return yield* renderInputPrompt(undefined, encodedInput, encodedInput);
          }

          const decodedInput = yield* Schema.decodeEffect(agent.definition.input)(
            encodedInput,
          ).pipe(
            Effect.mapError((cause) =>
              AgentInputError.make({
                message: cause.message,
              }),
            ),
          );

          return yield* renderInputPrompt(inputPrompt, decodedInput, encodedInput);
        });

      // Empty successful drains leave Tool results and RunCompleted in one batch.
      // A join or interrupted continuation must still retain already returned results.
      const preserveToolResults = Effect.gen(function* () {
        const state = yield* Ref.get(stateRef);

        if (
          state.pendingTurn !== undefined &&
          knownIds.has(modelResponseRecordId(runId, state.pendingTurn.turn))
        )
          yield* commitPendingTurn;
      });

      // Claims are authority, wakes are hints. A cancelled waiter retains every claim
      // for the seam drain; it never appends input while an old response can still commit.
      type PreparedJoin = {
        readonly claim: JoiningClaim;
        readonly input: Pick<UserInputRecorded, "input" | "messageAdmission">;
        readonly rendered: Prompt.RawInput;
      };

      const pendingJoinClaims: Array<{ readonly claim: JoiningClaim; prepared?: PreparedJoin }> =
        [];

      const claimInputs = Effect.fnUntraced(function* (maxCount: number) {
        const ownershipToken = yield* Ref.get(tokenRef);

        const claims = yield* ledger.claimJoining(
          ClaimJoiningRequest.make({
            threadId: submission.threadId,
            hostSubmissionId: submissionId,
            ownershipToken,
            maxCount,
          }),
        );

        pendingJoinClaims.push(...claims.map((claim) => ({ claim })));

        return claims.length;
      }, Effect.uninterruptible);

      const revertClaims = Effect.fnUntraced(function* (
        claims: ReadonlyArray<(typeof pendingJoinClaims)[number]>,
      ) {
        for (const pending of claims) {
          yield* ledger.revertJoining(
            RevertJoiningRequest.make({ submissionId: pending.claim.submissionId }),
          );
          pendingJoinClaims.splice(pendingJoinClaims.indexOf(pending), 1);
        }
      }, Effect.uninterruptible);

      // Preparation remains interruptible; a completed render stays with its claim so
      // cancellation of the waiter cannot lose it or invoke the callback again at the seam.
      const prepareInputs = Effect.fnUntraced(function* (limit: number, firstReady = false) {
        if (
          pendingJoinClaims.length < limit &&
          (yield* claimInputs(limit - pendingJoinClaims.length)) > 0
        )
          yield* hit("join:after-claim");
        const prepared: Array<PreparedJoin> = [];

        for (const pending of pendingJoinClaims.slice(0, limit)) {
          const claim = pending.claim;

          const snapshot = yield* ledger.loadRecoverySnapshot(
            RecoverySnapshotRequest.make({ submissionId: claim.submissionId }),
          );

          if (snapshot.abortIntent !== undefined) {
            yield* revertClaims([pending]);
            continue;
          }
          if (pending.prepared === undefined) {
            const input = {
              input: claim.inputPayload,
              ...(snapshot.submission.messageAdmission === undefined
                ? {}
                : { messageAdmission: snapshot.submission.messageAdmission }),
            };

            const rendered = yield* Effect.result(renderJoinedInput(input));

            if (Result.isFailure(rendered)) {
              // A rejected prompt and its suffix retain their own Runs in queue order.
              yield* revertClaims(pendingJoinClaims.slice(pendingJoinClaims.indexOf(pending)));
              break;
            }
            pending.prepared = { claim, input, rendered: rendered.success };
          }
          prepared.push(pending.prepared);
          if (firstReady) break;
        }

        return prepared;
      });

      const awaitJoin = recordHalt(
        Effect.gen(function* () {
          while (true) {
            const ready = yield* Effect.scoped(
              Effect.gen(function* () {
                const notified = yield* wake.subscribe(submission.threadId);

                if ((yield* prepareInputs(MAX_JOIN_DRAIN, true)).length > 0) return true;
                yield* notified;

                return false;
              }),
            );

            if (ready) return;
          }
        }),
      );

      const input: RunInputHook<
        CoordinatorHalt | Agent.Failure<typeof agent>,
        Agent.DefinitionRequirements<(typeof agent)["definition"]>
      > = {
        awaitJoin,
        drain: (policy) =>
          Effect.gen(function* () {
            const joinedInputs = yield* recordHalt(
              Effect.gen(function* () {
                const limit = policy === "one" ? 1 : MAX_JOIN_DRAIN;

                const joinedInputs: Array<
                  Pick<UserInputRecorded, "input" | "messageAdmission"> & {
                    readonly rendered?: Prompt.RawInput;
                  }
                > = [];

                if (joinBacklog === undefined) {
                  const hostSnapshot = yield* ledger.loadRecoverySnapshot(
                    RecoverySnapshotRequest.make({ submissionId }),
                  );

                  joinBacklog = hostSnapshot.joins;
                }
                // These inputs were already consumed by an earlier attempt. Restore the
                // entire uncovered prompt; only fresh claims are subject to the drain bound.
                for (const join of joinBacklog) {
                  const joinId = join.submissionId;

                  if (deliveredJoinInputs.has(joinId)) continue;
                  if (join.state !== "joining" && join.state !== "joined") continue;
                  const existing = joinedInputEnvelopes.get(joinId);

                  if (existing === undefined) continue;
                  if (join.state === "joining") {
                    // Canonical input without its joined marker (crash between the append and
                    // `markJoined`): repair the marker from history before reattaching.
                    const ownershipToken = yield* Ref.get(tokenRef);

                    yield* ledger.markJoined(
                      MarkJoinedRequest.make({
                        submissionId: joinId,
                        ownershipToken,
                        recordId: existing.record.recordId,
                        sequence: existing.sequence,
                      }),
                    );
                  }
                  deliveredJoinInputs.add(joinId);
                  if (
                    lastHostResponseSequence !== undefined &&
                    lastHostResponseSequence > existing.sequence
                  ) {
                    continue;
                  }
                  const payload = existing.record.payload;

                  if (payload._tag !== "UserInputRecorded") continue;
                  yield* preserveToolResults;
                  joinedInputs.push(payload);
                }
                const claims = yield* prepareInputs(limit);

                pendingJoinClaims.splice(0, claims.length);
                for (const { claim, input: payload, rendered } of claims) {
                  yield* preserveToolResults;
                  const recordId = submissionInputRecordId(claim.submissionId);
                  let sequence: CanonicalSequence;
                  const existing = joinedInputEnvelopes.get(claim.submissionId);

                  if (existing !== undefined) {
                    // Defensive reattach: the exact record is already canonical, so only the
                    // marker and the delivery remain (DUR-016 — never a duplicate append).
                    sequence = existing.sequence;
                  } else {
                    const envelope = yield* makeEnvelope(
                      recordId,
                      UserInputRecorded.make({
                        submissionId: claim.submissionId,
                        kind: "steering",
                        runId,
                        input: claim.inputPayload,
                        ...(payload.messageAdmission === undefined
                          ? {}
                          : { messageAdmission: payload.messageAdmission }),
                      }),
                    );

                    const result = yield* appendBatch(
                      ctx,
                      CanonicalBatch.make({
                        batchId: submissionInputBatchId(claim.submissionId),
                        producerId: config.producerId,
                        records: [envelope],
                      }),
                    );

                    sequence = result.firstSequence;
                    knownIds.add(recordId);
                    yield* hit("join:after-canonical-append");
                  }
                  // Re-read the token: the concurrent lease renewal may rotate it mid-batch.
                  const markToken = yield* Ref.get(tokenRef);

                  yield* ledger.markJoined(
                    MarkJoinedRequest.make({
                      submissionId: claim.submissionId,
                      ownershipToken: markToken,
                      recordId,
                      sequence,
                    }),
                  );
                  deliveredJoinInputs.add(claim.submissionId);
                  joinedInputs.push({
                    ...payload,
                    rendered,
                  });
                }

                return joinedInputs;
              }).pipe(
                Effect.onExit((exit) => (Exit.isFailure(exit) ? preserveToolResults : Effect.void)),
              ),
            );

            return yield* Effect.forEach(joinedInputs, (joinedInput) =>
              (joinedInput.rendered === undefined
                ? renderJoinedInput(joinedInput)
                : Effect.succeed(joinedInput.rendered)
              ).pipe(
                Effect.map((input): RunInputCommand => ({
                  kind: "steering",
                  input,
                })),
              ),
            );
          }),
      };

      /**
       * Durable child establishment: `establish` performs or replays
       * the idempotent get-or-create establishment protocol under the
       * parent's ownership fence and reports where the one child stands; `join` appends the
       * atomic `[SubagentJoined, ToolCallSettled]` settlement batch (SUB-019) and applies the
       * reservation release. Both use the halt side channel exactly like the durability/step
       * hooks: the engine wraps a `CoordinatorHalt` into `SubagentDurabilityError` in the
       * handler channel while the Attempt aborts with the original infrastructure failure.
       */
      const establishmentGate = yield* Semaphore.make(1);

      const establishSubagent = (
        request: RunSubagentEstablishRequest,
      ): Effect.Effect<ChildEstablishStatus, CoordinatorHalt> =>
        recordHalt(
          Effect.gen(function* () {
            const toolCallId = request.toolCallId;
            const turnInfo = currentToolTurn;

            if (turnInfo === undefined) {
              return yield* RunJournalError.make({
                message: `Delegation Tool Call ${toolCallId} established before any canonical response commit`,
              });
            }

            const denied = (errorTag: string, message: string): ChildEstablishStatus => ({
              _tag: "denied",
              errorTag,
              message: boundedText(message),
            });

            let requestedPayload = subagentState.requested.get(toolCallId);

            if (requestedPayload === undefined) {
              // FIRST establishment of this call: fix every digest fail-closed BEFORE any
              // durable mutation, then reserve → append the canonical request (spec §12
              // steps 2-3). Replays below proceed from the canonical record instead — the
              // recorded request, not the re-computed handler values, is the establishment
              // authority (SUB-016/SUB-018).
              if (request.depth !== delegationDepth + 1) {
                return denied(
                  "SubagentDepthUnsupported",
                  `The child depth must be exactly one greater than its source depth ${delegationDepth}`,
                );
              }

              // Resolve the exact declaration through ordinary host registration. Recovery
              // below uses the already-persisted request, never a newer registration.
              let targetDigests = request.targetDigests;

              if (request.target !== undefined) {
                if (request.target.id !== request.targetAgentId) {
                  return denied(
                    "SubagentBindingUnavailable",
                    "The child target identity differs from its Definition",
                  );
                }

                const binding = yield* resolveDefinitionBinding(
                  registeredBindings,
                  request.target,
                ).pipe(Effect.result);

                if (binding._tag === "Failure") {
                  return denied("SubagentBindingUnavailable", binding.failure.message);
                }
                if (
                  targetDigests !== undefined &&
                  (targetDigests.agent !== binding.success.digests.agent ||
                    targetDigests.model !== binding.success.digests.model ||
                    targetDigests.tools !== binding.success.digests.tools)
                ) {
                  return denied(
                    "SubagentDigestsInvalid",
                    "The explicit child digests differ from its exact registration",
                  );
                }
                targetDigests = binding.success.digests;
              }

              const decodedDigests = yield* decodeDefinitionDigests(targetDigests).pipe(
                Effect.option,
              );

              if (Option.isNone(decodedDigests)) {
                return denied(
                  "SubagentDigestsInvalid",
                  "The declared child Binding digests are not valid stored digests",
                );
              }

              const childInput = yield* decodePersisted(request.encodedChildInput).pipe(
                Effect.option,
              );

              if (Option.isNone(childInput)) {
                return denied(
                  "SubagentInputUnpersistable",
                  "The prepared child input does not satisfy the canonical persistence bounds",
                );
              }
              const grant = yield* decodePersisted(request.encodedGrant).pipe(Effect.option);

              const allocation = yield* decodePersisted(request.encodedAllocation).pipe(
                Effect.option,
              );

              if (Option.isNone(grant) || Option.isNone(allocation)) {
                return denied(
                  "SubagentDeclarationUnpersistable",
                  "The delegation grant or allocation does not satisfy the canonical persistence bounds",
                );
              }
              const decodedGrant = Schema.decodeUnknownOption(SubagentGrant)(grant.value);

              if (Option.isNone(decodedGrant))
                return denied("SubagentGrantInvalid", "The child authority grant is invalid");
              if (request.policy === undefined || request.budget === undefined)
                return denied(
                  "SubagentBudgetInvalid",
                  "New durable children require their full execution policy and subtree allocation",
                );
              if (
                request.toolCallAllowance !== undefined &&
                !Schema.is(SubagentRequested.fields.toolCallAllowance)(request.toolCallAllowance)
              ) {
                return denied(
                  "SubagentAllowanceInvalid",
                  "The child Tool Call allowance must be a positive integer",
                );
              }
              if (request.policy !== undefined && !Schema.is(AgentPolicy)(request.policy)) {
                return denied("SubagentPolicyInvalid", "The resolved child policy is invalid");
              }
              if (request.budget !== undefined) {
                if (!Schema.is(SubagentBudgetReservation)(request.budget)) {
                  return denied("SubagentBudgetInvalid", "The shared delegation budget is invalid");
                }

                const decodedAllocation = Schema.decodeUnknownOption(SubagentReservationAmounts)(
                  allocation.value,
                );

                if (
                  Option.isNone(decodedAllocation) ||
                  !Equal.equals(decodedAllocation.value, request.budget.allocation)
                ) {
                  return denied(
                    "SubagentBudgetInvalid",
                    "The reserved allocation differs from its budget declaration",
                  );
                }
                const { caps, allocation: requested } = request.budget;
                const prior = [...subagentState.requested.values()];

                if (
                  prior.some(
                    (entry) => entry.budget === undefined || !Equal.equals(entry.budget.caps, caps),
                  )
                ) {
                  return denied(
                    "SubagentParentBudgetConflict",
                    "Delegations in one parent Run must share the same caps",
                  );
                }
                if (
                  caps.maxTotalChildInvocations !== undefined &&
                  prior.reduce(
                    (sum, entry) => sum + 1 + (entry.budget?.descendantInvocations ?? 0),
                    1 + (request.budget.descendantInvocations ?? 0),
                  ) > caps.maxTotalChildInvocations
                ) {
                  return denied(
                    "SubagentBudgetExhausted",
                    "The parent Run exhausted its child invocation budget",
                  );
                }
                const active = prior.filter((entry) => !subagentState.joined.has(entry.toolCallId));

                if (
                  caps.maxConcurrentChildren !== undefined &&
                  active.length >= caps.maxConcurrentChildren
                ) {
                  return denied(
                    "SubagentBudgetExhausted",
                    "The parent Run exhausted its concurrent child budget",
                  );
                }

                const dimensions = [
                  ["turns", "maxTurns"],
                  ["toolCalls", "maxToolCalls"],
                  ["durationMillis", "maxDurationMillis"],
                  ["inputTokens", "maxInputTokens"],
                  ["outputTokens", "maxOutputTokens"],
                  ["costMicrousd", "maxCostMicrousd"],
                  ["resultBytes", "maxResultBytes"],
                ] as const;

                const accounting = Schema.Struct({ consumed: SubagentReservationAmounts });

                for (const [amount, cap] of dimensions) {
                  const limit = caps[cap];

                  if (limit === undefined) continue;
                  let consumed = requested[amount];

                  for (const entry of prior) {
                    const joined = subagentState.joined.get(entry.toolCallId);

                    const observed =
                      joined === undefined
                        ? Option.none()
                        : Schema.decodeUnknownOption(accounting)(joined.finalAccounting);

                    consumed += Option.isSome(observed)
                      ? observed.value.consumed[amount]
                      : (entry.budget?.allocation[amount] ?? limit);
                  }
                  if (consumed > limit) {
                    return denied(
                      "SubagentBudgetExhausted",
                      `The parent Run exhausted its shared ${amount} budget`,
                    );
                  }
                }
              }
              const childInputDigest = yield* withCrypto(digestJson(childInput.value));
              const grantDigest = yield* withCrypto(digestJson(grant.value));
              const allocationDigest = yield* withCrypto(digestJson(allocation.value));
              const reservationId = childReservationIdFor(runId, toolCallId);
              const ownershipToken = yield* Ref.get(tokenRef);

              // Top-level attached declarations retain their independent explicit pool. A
              // child with an ancestor allocation shares its residual with both lifetimes.
              const subtree =
                delegationDepth === 0
                  ? undefined
                  : yield* workerRuntime
                      .reserveSubtree(
                        submission.threadId,
                        SubtreeBudgetReserved.make({
                          reservationId,
                          sourceSubmissionId: submissionId,
                          childThreadId: childThreadIdFor(submissionId, toolCallId),
                          lifetime: "attached",
                          depth: request.depth,
                          policy: request.policy,
                          grant: decodedGrant.value,
                          budget: request.budget,
                        }),
                      )
                      .pipe(Effect.result);

              if (subtree?._tag === "Failure") {
                if (subtree.failure.reason === "storage")
                  return yield* LedgerError.make({
                    operation: "reserve-subtree",
                    message: "Subtree reservation is unavailable",
                  });

                return denied(
                  "SubagentBudgetExhausted",
                  `The subtree reservation was refused: ${subtree.failure.reason}`,
                );
              }

              yield* ledger
                .reserveChildBudget(
                  ChildBudgetReservationRequest.make({
                    reservationId,
                    parentSubmissionId: submissionId,
                    parentToolCallId: toolCallId,
                    ownershipToken,
                    allocation: allocation.value,
                    allocationDigest,
                  }),
                )
                .pipe(
                  Effect.catchTag(
                    "ChildReservationConflict",
                    conflictToLedgerError("reserveChildBudget"),
                  ),
                );
              yield* hit("subagent:after-reserve");
              requestedPayload = SubagentRequested.make({
                runId,
                turnId: turnInfo.turnId,
                turn: turnInfo.turn,
                toolCallId,
                delegationId: request.delegationId,
                targetAgentId: request.targetAgentId,
                targetDigests: decodedDigests.value,
                childInput: childInput.value,
                childInputDigest,
                grantDigest,
                grant: decodedGrant.value,
                depth: request.depth,
                reservationId,
                reservationDigest: allocationDigest,
                childThreadId: childThreadIdFor(submissionId, toolCallId),
                childPrincipal: submission.principal,
                childIdempotencyKey: childIdempotencyKeyFor(runId, toolCallId),
                ...(request.toolCallAllowance === undefined
                  ? {}
                  : { toolCallAllowance: request.toolCallAllowance }),
                ...(request.policy === undefined ? {} : { policy: request.policy }),
                ...(request.budget === undefined ? {} : { budget: request.budget }),
              });
              const requestRecordId = subagentRequestedRecordId(runId, toolCallId);

              if (!knownIds.has(requestRecordId)) {
                const envelope = yield* makeEnvelope(requestRecordId, requestedPayload);

                yield* appendBatch(
                  ctx,
                  CanonicalBatch.make({
                    batchId: subagentRequestedBatchId(runId, toolCallId),
                    producerId: config.producerId,
                    records: [envelope],
                  }),
                ).pipe(
                  Effect.catchTag("AppendConflict", () => Effect.void),
                  Effect.asVoid,
                );
                knownIds.add(requestRecordId);
              }
              subagentState.requested.set(toolCallId, requestedPayload);
              yield* hit("subagent:after-request-append");
            }
            // Steps 4-8: resolveAdmission-gated admission with immutable parent linkage,
            // child materialization + lineage, readiness, Receipt (SUB-016/SUB-017/SUB-031).
            const admission = yield* establishChildFromRequest(submission, requestedPayload);

            if (admission._tag === "indeterminate") {
              // Wait-and-retry, never a second admission: the Attempt aborts with the
              // obligation still owed and the next pass re-queries the authoritative owner.
              return yield* LedgerError.make({
                operation: "establishSubagent",
                message: `Child admission for Tool Call ${toolCallId} is indeterminate (${admission.reason}); retrying without a second admission (SUB-031)`,
              });
            }
            const childRunId = runIdForSubmission(admission.childSubmissionId);
            // Step 9: the start link is appended only after the child Receipt exists (SUB-017).
            let startedPayload = subagentState.started.get(toolCallId);

            if (startedPayload === undefined) {
              startedPayload = SubagentStarted.make({
                runId,
                toolCallId,
                childThreadId: requestedPayload.childThreadId,
                childSubmissionId: admission.childSubmissionId,
                childReceiptId: admission.receiptId,
                childRunId,
              });
              const startRecordId = subagentStartedRecordId(runId, toolCallId);

              if (!knownIds.has(startRecordId)) {
                const envelope = yield* makeEnvelope(startRecordId, startedPayload);

                yield* appendBatch(
                  ctx,
                  CanonicalBatch.make({
                    batchId: subagentStartedBatchId(runId, toolCallId),
                    producerId: config.producerId,
                    records: [envelope],
                  }),
                ).pipe(
                  Effect.catchTag("AppendConflict", () => Effect.void),
                  Effect.asVoid,
                );
                knownIds.add(startRecordId);
              }
              subagentState.started.set(toolCallId, startedPayload);
              yield* hit("subagent:after-start-append");
            } else if (startedPayload.childSubmissionId !== admission.childSubmissionId) {
              return yield* LedgerError.make({
                operation: "establishSubagent",
                message: `The canonical SubagentStarted record names child ${startedPayload.childSubmissionId} but admission resolved ${admission.childSubmissionId}; establishment fails closed (SUB-016)`,
              });
            }
            const attachToken = yield* Ref.get(tokenRef);

            yield* ledger
              .attachChildToReservation(
                AttachChildToReservationRequest.make({
                  reservationId: decodeChildReservationIdSync(requestedPayload.reservationId),
                  ownershipToken: attachToken,
                  childSubmissionId: startedPayload.childSubmissionId,
                }),
              )
              .pipe(
                Effect.catchTag(
                  "ChildReservationConflict",
                  conflictToLedgerError("attachChildToReservation"),
                ),
              );

            const identity = {
              childThreadId: startedPayload.childThreadId,
              childSubmissionId: startedPayload.childSubmissionId,
              childRunId: startedPayload.childRunId,
              receiptId: startedPayload.childReceiptId,
            };

            const child = yield* ledger.lookup(
              SubmissionLookupById.make({ submissionId: startedPayload.childSubmissionId }),
            );

            if (Option.isNone(child)) {
              return yield* LedgerError.make({
                operation: "establishSubagent",
                message: `Established child ${startedPayload.childSubmissionId} is unknown to the ledger`,
              });
            }
            if (child.value.state !== "settled") {
              return { _tag: "waiting" as const, ...identity };
            }

            // §1.6: the child already settled — verify Parent Link, target, digests, and the
            // settlement record fail-closed before handing the outcome to the handler.
            const verification = yield* verifySettledChild(
              submission,
              requestedPayload,
              startedPayload.childSubmissionId,
            );

            if (verification._tag === "mismatch") {
              return denied("SubagentVerificationFailed", verification.message);
            }

            return {
              _tag: "settled" as const,
              ...identity,
              outcome: verification.value.outcome,
              encodedResult: verification.value.encodedResult,
              ...(yield* verifiedChildUsage(verification.value, startedPayload.childRunId)),
              // The child Settlement's honest exhaustion marker (RUN-018)
              // rides to the parent handler so the delegation can surface a
              // budget-truncated partial to the orchestrator (SUB-034).
              ...(verification.value.settlement.finishReason === undefined
                ? {}
                : { finishReason: verification.value.settlement.finishReason }),
            };
          }).pipe(establishmentGate.withPermits(1)),
        );

      const joinSubagent = (
        request: RunSubagentJoinRequest,
      ): Effect.Effect<void, CoordinatorHalt> =>
        recordHalt(
          Effect.gen(function* () {
            const toolCallId = request.toolCallId;
            const turnInfo = currentToolTurn;

            if (turnInfo === undefined) {
              return yield* RunJournalError.make({
                message: `Delegation Tool Call ${toolCallId} joined before any canonical response commit`,
              });
            }
            const requestedPayload = subagentState.requested.get(toolCallId);
            const startedPayload = subagentState.started.get(toolCallId);

            if (requestedPayload === undefined || startedPayload === undefined) {
              return yield* RunJournalError.make({
                message: `Delegation Tool Call ${toolCallId} joined without canonical establishment records`,
              });
            }
            const reservationId = decodeChildReservationIdSync(requestedPayload.reservationId);
            const joinedRecordId = subagentJoinedRecordId(runId, toolCallId);
            let finalAccounting: PersistedJson;
            const existingJoined = subagentState.joined.get(toolCallId);

            if (existingJoined !== undefined) {
              // The atomic join batch is already canonical: only the reservation release below
              // may remain (spec §12 join step 6 — the canonical record is the replay source).
              finalAccounting = existingJoined.finalAccounting;
            } else {
              const encodedResult = yield* decodePersisted(request.encodedResult).pipe(
                Effect.mapError((cause) =>
                  RunJournalError.make({
                    message: `The projected result of Tool Call ${toolCallId} exceeds canonical persistence bounds`,
                    cause,
                  }),
                ),
              );

              const accounting = yield* decodePersisted(request.encodedAccounting).pipe(
                Effect.mapError((cause) =>
                  RunJournalError.make({
                    message: `The join accounting of Tool Call ${toolCallId} exceeds canonical persistence bounds`,
                    cause,
                  }),
                ),
              );

              const verification = yield* verifySettledChild(
                submission,
                requestedPayload,
                startedPayload.childSubmissionId,
              );

              if (verification._tag === "mismatch") {
                return yield* LedgerError.make({
                  operation: "joinSubagent",
                  message: `Child Settlement verification failed for Tool Call ${toolCallId}: ${verification.message}`,
                });
              }
              const verified = verification.value;
              const toolName = declaredNamesByCallId.get(toolCallId);

              if (toolName === undefined) {
                return yield* RunJournalError.make({
                  message: `Delegation Tool Call ${toolCallId} joined without a declared Tool name`,
                });
              }

              yield* hit("subagent:before-join-append");

              const joinedPayload = SubagentJoined.make({
                runId,
                toolCallId,
                childSubmissionId: startedPayload.childSubmissionId,
                childSettlementId: verified.settlement.settlementId,
                childOutcome: verified.outcome,
                childResultDigest: yield* withCrypto(
                  digestJson(verified.settlement.result ?? null),
                ),
                projectedResultDigest: yield* withCrypto(digestJson(encodedResult)),
                usageSummary: yield* childUsageSummaryOf(
                  verified.childRecords,
                  startedPayload.childRunId,
                ),
                ...(yield* verifiedChildUsage(verified, startedPayload.childRunId)),
                reservationId: requestedPayload.reservationId,
                finalAccounting: accounting,
              });

              const settledRecordId = toolCallSettledRecordId(runId, turnInfo.turn, toolCallId);
              const joinedEnvelope = yield* makeEnvelope(joinedRecordId, joinedPayload);

              const settledEnvelope = yield* makeEnvelope(
                settledRecordId,
                ToolCallSettled.make({
                  runId,
                  toolCallId,
                  toolName,
                  result: encodedResult,
                  isFailure: request.isFailure,
                }),
              );

              yield* appendBatch(
                ctx,
                CanonicalBatch.make({
                  batchId: subagentJoinBatchId(runId, toolCallId),
                  producerId: config.producerId,
                  records: [joinedEnvelope, settledEnvelope],
                }),
              ).pipe(
                Effect.catchTag("AppendConflict", () => Effect.void),
                Effect.asVoid,
              );
              knownIds.add(joinedRecordId);
              knownIds.add(settledRecordId);
              subagentState.joined.set(toolCallId, joinedPayload);
              finalAccounting = accounting;
              yield* hit("subagent:after-join-append");
            }
            yield* applyReservationRelease(reservationId, finalAccounting);
          }),
        );

      const subagent: RunSubagentHook<CoordinatorHalt, never> = {
        establish: establishSubagent,
        join: joinSubagent,
      };

      const toolAuthorization: RunToolAuthorizationHook<AgentToolAuthorizationCheckError> = {
        authorize: (request: RunToolAuthorizationRequest) =>
          inheritedGrant !== undefined &&
          !inheritedGrant.allowedToolNames.includes(request.call.toolName)
            ? Effect.succeed({
                _tag: "denied",
                reason: "Tool exceeds the worker's immutable grant",
              })
            : runToolAuthorization.authorize({
                ...request,
                // Preserve the admitted wire value even when an Agent Schema's decode/encode
                // pair normalizes differently on a second pass.
                input: submission.inputPayload,
                ...(Schema.is(FrameworkMessage)(submission.messageAdmission)
                  ? { frameworkMessage: submission.messageAdmission }
                  : {}),
              }),
      };

      const options: RunOptions<
        | CoordinatorHalt
        | AgentToolAuthorizationCheckError
        | CompactionError
        | RunContextPreparationError
        | Agent.Failure<typeof agent>,
        Agent.DefinitionRequirements<(typeof agent)["definition"]>
      > = {
        threadId: submission.threadId,
        runId,
        history: pending === undefined ? journal.historyBefore : resumeProjection.historyBefore,
        onHistory,
        input,
        // Ready corrections share the next model Turn, bounded by MAX_JOIN_DRAIN.
        commandDrainPolicy: "all",
        ...(journal.committedTurns > 0 || Schema.is(FrameworkMessage)(submission.messageAdmission)
          ? { retainedInput: submission.inputPayload }
          : {}),
        ...(Schema.is(FrameworkMessage)(submission.messageAdmission)
          ? { frameworkMessage: submission.messageAdmission }
          : {}),
        approval,
        toolAuthorization,
        ...(journal.toolSelection === undefined
          ? {}
          : {
              toolSelection: {
                // A settled discovery receipt survives deployment; its selection only
                // names current tools. Keep validation of fresh selections fail-closed.
                toolNames: journal.toolSelection.toolNames.filter((name) =>
                  Object.hasOwn(agent.definition.toolkit.tools, name),
                ),
              },
            }),
        durability,
        subagent,
        delegationDepth,
        ...(inheritedGrant === undefined ? {} : { subagentGrant: inheritedGrant }),
        ...(inheritedBudget === undefined ? {} : { subagentBudget: inheritedBudget }),
        ...(submission.workerAdmission?.origin.budgetScope === undefined
          ? {}
          : { subagentBudgetScope: submission.workerAdmission.origin.budgetScope }),
        runStartedAt: runTiming.startedAt,
        durationDeadline: runTiming.deadline,
        ...(submission.workerAdmission === undefined
          ? {}
          : {
              toolCallAllowance: submission.workerAdmission.origin.toolCallAllowance,
            }),
        ...(submission.parentLinkage !== undefined &&
        childLineage?._tag === "SubagentLineageRecorded"
          ? { toolCallAllowance: childLineage.toolCallAllowance }
          : {}),
        ...(pending === undefined
          ? {}
          : {
              resume: {
                ...(settledCompletion === undefined ? {} : { settledCompletion }),
                turn: pending.turn,
                turnId: pending.turnId,
                calls: pending.calls,
                toolParameterRejections: pending.toolParameterRejections,
                settled: pending.settled,
                // Legacy eager requests have no exposure snapshot. Their validated canonical
                // declarations establish the minimal original exposure needed for batch resume.
                toolExposure:
                  pending.toolExposure ??
                  Snapshot.make({
                    exposedToolNames: [...new Set(pending.calls.map((call) => call.name))],
                  }),
                ...(resumeLeadingMessages === undefined
                  ? {}
                  : { leadingMessages: resumeLeadingMessages }),
                ...(resumeResponseMessages === undefined
                  ? {}
                  : { responseMessages: resumeResponseMessages }),
              },
            }),
        ...(preparedContext === undefined ? {} : { context: preparedContext }),
        beforeTurn: () =>
          Effect.gen(function* () {
            // Preparation may resolve the next Model from canonical Tool results or invoke
            // a compaction Model. Publish the completed Turn before either can observe it.
            yield* recordHalt(commitPendingTurn);

            if (
              yieldAfter !== undefined &&
              (yield* Clock.currentTimeMillis) >= DateTime.toEpochMillis(yieldAfter)
            ) {
              yield* Deferred.succeed(yieldSignal, undefined);

              // The successful signal wins the outer race and closes the stream Scope;
              // no synthetic engine RunFailed event or terminal Settlement is produced.
              return yield* Effect.never;
            }
            if (submissionScheduling.yieldTo !== undefined && (yield* Ref.get(turnCounter)) > 0) {
              const candidate = yield* recordHalt(
                eligibleThreadHead(submission.threadId, submission.queueSequence),
              );

              if (
                Option.isSome(candidate) &&
                (candidate.value.state === "ready" ||
                  candidate.value.state === "running" ||
                  candidate.value.state === "input-applied")
              ) {
                const next = yield* recordHalt(
                  ledger.lookup(
                    SubmissionLookupById.make({
                      submissionId: candidate.value.submissionId,
                    }),
                  ),
                );

                if (
                  Option.isSome(next) &&
                  next.value.agentId === submission.agentId &&
                  (next.value.state === "ready" ||
                    next.value.state === "running" ||
                    next.value.state === "input-applied") &&
                  (yield* recordHalt(
                    submissionScheduling.yieldTo({ active: submission, next: next.value }),
                  ))
                ) {
                  yield* Deferred.succeed(yieldSignal, next.value.submissionId);

                  return yield* Effect.never;
                }
              }
            }
          }),
        ...(runContextPreparation.transientContext === undefined
          ? {}
          : { transientContext: runContextPreparation.transientContext }),
        ...(config.estimateCostMicrousd === undefined
          ? {}
          : { estimateCostMicrousd: config.estimateCostMicrousd }),
        resumeUsage: {
          ...journal.usage,
          ...journal.policyUsage,
          ...(journal.usage.modelCalls === 0 &&
          (journal.usage.unobservedModelCalls ?? 0) === 0 &&
          !records.some(
            ({ record }) =>
              record.payload._tag === "ModelResponseInterrupted" && record.payload.runId === runId,
          )
            ? emptyRunTotals()
            : runTotalsFromSummary(yield* currentUsageSummary())),
          children: childUsageReportsOf(subagentState),
        },
        ...(journal.contextWindowId === undefined
          ? {}
          : { initialContextWindowId: journal.contextWindowId }),
        ...(journal.protectedContext === undefined
          ? {}
          : { protectedContext: journal.protectedContext }),
        ...(pendingContextToolCallId === undefined ? {} : { pendingContextToolCallId }),
      };

      const commitPendingTurn: Effect.Effect<void, DurableWorkerFailure> = Effect.gen(function* () {
        const state = yield* Ref.get(stateRef);
        const history = state.history;

        if (state.pendingTurn === undefined || history === undefined) return;
        let appended = history.content.slice(state.lastCommitLen);

        if (appended.length === 0) return;
        const canonicalTurn = state.pendingTurn.turn;
        const createdAt = yield* nowUtc;
        let committedLen = history.content.length;

        const completedRun =
          state.completedOutput === undefined
            ? undefined
            : {
                output: state.completedOutput,
                ...(state.completedRunDisposition === undefined
                  ? {}
                  : { runDisposition: state.completedRunDisposition }),
                ...(state.completedFinishReason === undefined
                  ? {}
                  : { finishReason: state.completedFinishReason }),
                ...(state.completedExhausted === undefined
                  ? {}
                  : { exhausted: state.completedExhausted }),
              };

        if (knownIds.has(modelResponseRecordId(runId, canonicalTurn))) {
          // The response is already durable (commit 1 of the split shape): only the results
          // batch remains. The slice is [response messages…, tool message, trailing input…]:
          // this commit's canonical coverage ends at the batch's Tool message — messages drained
          // at the post-batch seam stay pending and become the leading messages of the NEXT
          // response batch (decision point 6 / D8), never silently dropped.
          for (let index = appended.length - 1; index >= 0; index -= 1) {
            if (appended[index]?.role === "tool") {
              committedLen = state.lastCommitLen + index + 1;
              appended = appended.slice(0, index + 1);
              break;
            }
          }
          // Already-canonical per-call settles (late settles from the resolution path, or
          // resume-injected results) are excluded by record identity.
          const remaining: Array<Prompt.Message> = [];
          const resultParts: Array<Prompt.ToolResultPart> = [];
          let toolParts = 0;

          for (const message of appended) {
            if (message.role !== "tool") {
              remaining.push(message);
              continue;
            }

            const parts = message.content.filter(
              (part): part is Prompt.ToolResultPart =>
                part.type === "tool-result" &&
                !knownIds.has(`tool-settled:${runId}:${canonicalTurn}:${part.id}`),
            );

            if (parts.length === 0) continue;
            toolParts += parts.length;
            resultParts.push(...parts);
            remaining.push(Prompt.makeMessage("tool", { content: parts }));
          }

          const settledCompletionPart =
            completedRun === undefined || toolParts > 0
              ? undefined
              : appended
                  .flatMap((message) => (message.role === "tool" ? message.content : []))
                  .find(
                    (part) =>
                      part.type === "tool-result" &&
                      !part.isFailure &&
                      agent.definition.completionFromTools?.some(
                        (declaration) => declaration.tool === part.name,
                      ),
                  );

          if (settledCompletionPart?.type === "tool-result") {
            resultParts.push(settledCompletionPart);
            remaining.push(Prompt.makeMessage("tool", { content: [settledCompletionPart] }));
          }

          if (toolParts > 0 || settledCompletionPart !== undefined) {
            const completion = agent.definition.completion;
            const completionPart = resultParts[0];

            const runCompletion =
              resultParts.length === 1 &&
              (completionPart?.name === completion?.tool ||
                agent.definition.completionFromTools?.some(
                  (declaration) => declaration.tool === completionPart?.name,
                )) &&
              completionPart.isFailure !== true &&
              completedRun !== undefined
                ? completedRun
                : undefined;

            const batch = yield* withCrypto(
              turnResultsBatch({
                toolSelections: stagedToolSelections,
                budgetRejectedCalls,
                runId,
                turn: canonicalTurn,
                turnId: state.pendingTurn.turnId,
                appended: remaining,
                producerId: config.producerId,
                deploymentId: config.deploymentId,
                createdAt,
                ...(runCompletion === undefined ? {} : { runCompletion }),
              }),
            );

            // A recovered external receipt is already canonical. Commit only the terminal
            // marker at the same results boundary; never duplicate or rewrite its result.
            let pendingBatch = batch;

            if (settledCompletionPart !== undefined) {
              const completionRecord = batch.records.find(
                (record) => record.payload._tag === "RunCompleted",
              );

              if (completionRecord === undefined || knownIds.has(completionRecord.recordId)) {
                return yield* RunJournalError.make({
                  message: "Recovered action completion has no new terminal record",
                });
              }
              pendingBatch = CanonicalBatch.make({ ...batch, records: [completionRecord] });
            }

            yield* appendBatch(ctx, pendingBatch);
            for (const record of pendingBatch.records) knownIds.add(record.recordId);
            yield* hit("turn:after-results-append");
          }
        } else {
          // No durable response commit: the P4 single-batch shape (no-tool Turns).
          const runScopedPrefixLength =
            canonicalTurn === 1
              ? appended.findIndex((message) => message.role === "assistant")
              : -1;

          const batch = yield* withCrypto(
            turnCanonicalBatch({
              toolExposure: stagedToolExposure.get(canonicalTurn),
              toolSelections: stagedToolSelections,
              budgetRejectedCalls,
              runId,
              turn: canonicalTurn,
              turnId: state.pendingTurn.turnId,
              appended,
              producerId: config.producerId,
              deploymentId: config.deploymentId,
              createdAt,
              ...(runScopedPrefixLength > 0 ? { runScopedPrefixLength } : {}),
              ...(completedRun === undefined ? {} : { runCompletion: completedRun }),
              usage: usageForCommit(canonicalTurn),
              unobservedModelCalls: unobservedForCommit(canonicalTurn),
            }),
          );

          yield* appendBatch(ctx, batch);
          recordCommittedUsage(batch);
          for (const record of batch.records) knownIds.add(record.recordId);
          yield* hit("turn:after-canonical-append");
        }
        yield* Ref.update(stateRef, (current) => ({
          ...current,
          lastCommitLen: committedLen,
          pendingTurn: undefined,
        }));
      });

      const recordCompleted = (
        output: unknown,
        finishReason: "completed" | "model-stop" | "budget-exhausted",
        exhausted: ExhaustedLimit | undefined,
        runDisposition: unknown,
      ): Effect.Effect<void, DurableWorkerFailure> =>
        Effect.gen(function* () {
          const result = yield* Schema.decodeUnknownEffect(PersistedJson)(output).pipe(
            Effect.mapError((cause): DurableWorkerFailure =>
              LedgerError.make({
                operation: "recordCompleted",
                message: "Run output exceeds canonical persistence bounds",
                cause,
              }),
            ),
          );

          if (finishReason === "budget-exhausted" && runDisposition !== undefined) {
            return yield* LedgerError.make({
              operation: "recordCompleted",
              message: "A budget-exhausted Run cannot declare an application run disposition",
            });
          }

          const persistedRunDisposition =
            runDisposition === undefined
              ? undefined
              : yield* Schema.decodeUnknownEffect(PersistedJson)(runDisposition).pipe(
                  Effect.mapError((cause): DurableWorkerFailure =>
                    LedgerError.make({
                      operation: "recordCompleted",
                      message: "Run disposition exceeds canonical persistence bounds",
                      cause,
                    }),
                  ),
                );

          yield* Ref.update(stateRef, (state) => ({
            ...state,
            completedOutput: result,
            completedRunDisposition: persistedRunDisposition,
            completedFinishReason: finishReason === "budget-exhausted" ? finishReason : undefined,
            // The pair travels together or not at all (RUN-011 fail-safe): a
            // divergent event never persists a lone dimension.
            completedExhausted: finishReason === "budget-exhausted" ? exhausted : undefined,
          }));
        });

      const handleEvent = (event: RunEvent): Effect.Effect<void, DurableWorkerFailure> => {
        switch (event._tag) {
          case "ModelRestarted": {
            // A finish part can arrive before the provider stream closes. Its TurnCompleted
            // only staged this disposable Turn; never let the next seam commit its prefix.
            return Ref.update(stateRef, (state) => ({ ...state, pendingTurn: undefined }));
          }
          case "TurnStarted": {
            // Suspension owns only this Turn's siblings. Earlier results are already canonical
            // under their original Turn and must never be re-recorded with a later Turn id.
            return commitPendingTurn.pipe(
              Effect.andThen(
                Effect.sync(() => {
                  siblingResults.clear();
                  stagedToolSelections.clear();
                }),
              ),
            );
          }
          case "TurnCompleted": {
            const turnId = event.turnId ?? turnIdForRun(runId, event.turn);

            return Ref.update(stateRef, (state) => ({
              ...state,
              pendingTurn: { turn: event.turn, turnId },
            }));
          }
          case "RunCompleted": {
            return recordCompleted(
              event.output,
              event.finishReason,
              event.exhausted,
              event.runDisposition,
            ).pipe(
              // The terminal state is available while the final canonical
              // batch is built, so its RunCompleted marker commits atomically
              // with either the no-tool response or the completion Tool result.
              Effect.andThen(commitPendingTurn),
            );
          }
          case "RunFailed": {
            // Preserve a completed-and-advanced final Turn for audit before the Run settles failed.
            return commitPendingTurn;
          }
          case "ToolCallSucceeded": {
            if (!event.providerExecuted && event.toolSelection !== undefined)
              stagedToolSelections.set(event.toolCallId, event.toolSelection);
            // Collected for the waitingForChild suspension seam: a batch that suspends never
            // reaches its results commit, so each settled sibling result is committed there as
            // a per-call late-settle batch instead (plan §2 step 2).
            if (!event.providerExecuted) {
              siblingResults.set(event.toolCallId, {
                toolCallId: event.toolCallId,
                result: event.result,
                isFailure: false,
              });
            }

            return Effect.void;
          }
          case "ToolCallFailed": {
            if (event.budgetRejected === true) budgetRejectedCalls.add(event.toolCallId);
            // Only the bounded diagnostics survive the event stream for a failed sibling; the
            // per-call late-settle carries this same bounded `{errorTag, message}` projection.
            if (!event.providerExecuted) {
              siblingResults.set(event.toolCallId, {
                toolCallId: event.toolCallId,
                result: { errorTag: event.errorTag, message: boundedText(event.message) },
                isFailure: true,
              });
            }

            return Effect.void;
          }
          default: {
            return Effect.void;
          }
        }
      };

      /**
       * The waitingForChild suspension seam (plan §2 steps 1-4): every non-waiting sibling of
       * the suspending batch has settled — commit each terminal sibling result as a per-call
       * late-settle batch (`turn-results:{runId}:{turn}:{toolCallId}`) in the batch's declared
       * order, so no sibling effect is lost to the suspension and the resumed batch injects
       * them via `resume.settled`. Record identity dedupes results already canonical (joined
       * delegation calls, resume-injected siblings).
       */
      const commitSiblingLateSettles = (
        children: AgentChildPending["children"],
      ): Effect.Effect<void, DurableWorkerFailure> =>
        Effect.gen(function* () {
          const turnInfo = currentToolTurn;

          if (turnInfo === undefined) return;
          const waitingIds = new Set<string>(children.map((child) => child.toolCallId));

          // Declared order first (SUB-013's commit-order rule), then any residue in arrival order.
          const ordered = [
            ...[...declaredNamesByCallId.keys()].filter((callId) => siblingResults.has(callId)),
            ...[...siblingResults.keys()].filter((callId) => !declaredNamesByCallId.has(callId)),
          ];

          for (const callId of ordered) {
            if (waitingIds.has(callId)) continue;
            const settled = siblingResults.get(callId);

            if (settled === undefined) continue;
            const toolCallId = settled.toolCallId;
            const recordId = toolCallSettledRecordId(runId, turnInfo.turn, toolCallId);

            if (knownIds.has(recordId)) continue;
            const toolName = declaredNamesByCallId.get(callId);

            if (toolName === undefined) {
              return yield* RunJournalError.make({
                message: `Settled sibling ${toolCallId} has no declared Tool name at the suspension seam`,
              });
            }

            const result = yield* decodePersisted(settled.result).pipe(
              Effect.mapError((cause) =>
                RunJournalError.make({
                  message: `Sibling result ${toolCallId} exceeds canonical persistence bounds`,
                  cause,
                }),
              ),
            );

            const envelope = yield* makeEnvelope(
              recordId,
              ToolCallSettled.make({
                runId,
                toolCallId,
                toolName,
                result,
                isFailure: settled.isFailure,
                ...(stagedToolSelections.get(toolCallId) === undefined
                  ? {}
                  : { toolSelection: stagedToolSelections.get(toolCallId) }),
              }),
            );

            yield* appendBatch(
              ctx,
              CanonicalBatch.make({
                batchId: toolCallResultBatchId(runId, turnInfo.turn, toolCallId),
                producerId: config.producerId,
                records: [envelope],
              }),
            ).pipe(
              Effect.catchTag("AppendConflict", () => Effect.void),
              Effect.asVoid,
            );
            knownIds.add(recordId);
            yield* hit("subagent:after-sibling-settle");
          }
        });

      // Durability §9: the superseding Attempt records the interruption BEFORE re-invoking the
      // model. A batch resume never re-invokes the model for the pending Turn, so it is exempt.
      if (
        pending === undefined &&
        lineage.inputWasRecorded &&
        lineage.supersededEpoch >= 1 &&
        lineage.supersededEpoch < ctx.producerEpoch
      ) {
        yield* appendInterruptedAudit(ctx, runId, lineage, knownIds);
        interruptedUsage = true;
      }

      const consume = Stream.runForEach(
        AgentRuntime.streamWithUsageAccountingUnknown(agent, submission.inputPayload, options).pipe(
          Stream.provideService(AgentUpdateAcceptance, {
            accept: (update) =>
              updateRuntime
                .emit({
                  updateId: update.updateId,
                  value: update.value,
                  submission,
                  runId,
                  producerEpoch: ctx.producerEpoch,
                  definitions: submission.agentDigests,
                })
                .pipe(
                  Effect.catchTag(["LedgerError", "DurableRuntimeFailpointError"], (failure) =>
                    // Preserve the original infrastructure failure at the coordinator boundary;
                    // the engine's next event must not commit this Tool's failure as an outcome.
                    Ref.set(haltRef, failure).pipe(
                      Effect.andThen(Effect.fail(UpdateError.make({ reason: "storage" }))),
                    ),
                  ),
                ),
          }),
          Stream.provideService(ModelUsageAccounting, {
            noteIncompleteUsage: (turn) =>
              Effect.sync(() => {
                stagedUnobservedCalls.set(turn, (stagedUnobservedCalls.get(turn) ?? 0) + 1);
              }),
          }),
          Stream.provide(ThreadHistory.layer),
          Stream.provideService(SubagentHost.forTool, (source) =>
            source.threadId !== submission.threadId ||
            source.agentId !== submission.agentId ||
            source.runId !== runId
              ? SubagentHost.unavailable
              : workerRuntime.facet(
                  {
                    source,
                    policy: agent.definition.policy,
                    depth: delegationDepth,
                    ...(inheritedGrant === undefined ? {} : { grant: inheritedGrant }),
                  },
                  submission.principal,
                  submission.submissionId,
                ),
          ),
          Stream.provideService(MessagingHost.forTool, (source) =>
            source.threadId !== submission.threadId ||
            source.agentId !== submission.agentId ||
            source.runId !== runId
              ? MessagingHost.unavailable
              : messagingRuntime.forTool(source, submission.principal),
          ),
          Stream.provideService(CurrentToolFailureObserver, toolFailureObserver),
          Stream.provideService(RunToolVisibility, runToolVisibility),
          Stream.provideService(RunToolScheduling, runToolScheduling),
          Stream.provideService(ContextCompactor, compactor),
          Stream.provideService(RunContextPreparation, runContextPreparation),
        ),
        (event) =>
          halt(
            Effect.gen(function* () {
              // A broker reports hook failures as Tool preflight data. The coordinator's recorded
              // infrastructure halt must win before any subsequent event commits that Tool outcome.
              const failure = yield* Ref.get(haltRef);

              if (failure !== undefined) return yield* Effect.fail(failure);
              yield* handleEvent(event);
            }),
          ),
      ).pipe(
        Effect.onExit((exit) => (Exit.hasInterrupts(exit) ? preserveToolResults : Effect.void)),
        // Retain while the Attempt's services, claim renewal and abort watcher are still live.
        // A failed retention halts the coordinator; it is not a failed Tool or a safe suspension.
        Effect.tapCause((cause) =>
          Option.isSome(agentApprovalPendingOption(cause)) &&
          cause.reasons.every(Cause.isFailReason)
            ? Effect.flatMap(DurableApprovalSuspension, (retain) =>
                retain === undefined ? Effect.void : halt(retain),
              )
            : Effect.void,
        ),
        Effect.as({ _tag: "run" as const }),
      );

      // Durable §13: the abort command becomes canonical (serialized on the append gate) BEFORE
      // the Run fiber is interrupted by losing the race.
      const abortWatcher = halt(
        Effect.gen(function* () {
          while (true) {
            yield* Effect.sleep(config.abortPollInterval);

            const intent = yield* ledger.readAbortIntent(AbortIntentRequest.make({ submissionId }));

            if (intent === undefined) continue;
            yield* appendAbortRecord(ctx, intent);

            return { _tag: "aborted" as const };
          }
        }),
      );

      // Liveness only: the lease keeps the claim visible; correctness stays with the epoch fence.
      // OwnershipLost ends the race and interrupts the Run fiber cleanly.
      const renewal = halt(
        Effect.gen(function* () {
          // Binding selection and preparation consume the acquired lease too. Carry the next
          // deadline across model continuations; an overdue first renewal must run immediately.
          const renewAt = yield* Ref.get(renewAtRef);
          const now = yield* Clock.currentTimeMillis;

          yield* Effect.sleep(Math.max(0, renewAt - now));
          yield* Effect.repeat(
            Effect.gen(function* () {
              const ownershipToken = yield* Ref.get(tokenRef);
              const renewingAt = yield* Clock.currentTimeMillis;

              const renewal = yield* ledger.renewOwnership(
                RenewOwnershipRequest.make({ submissionId, ownershipToken }),
              );

              yield* Ref.set(tokenRef, renewal.ownershipToken);
              yield* Ref.set(
                renewAtRef,
                renewingAt + Duration.toMillis(config.leaseRenewalInterval),
              );
            }).pipe(Effect.uninterruptible),
            { schedule: Schedule.spaced(config.leaseRenewalInterval) },
          );

          return yield* Effect.never;
        }),
      );

      const execution = Effect.raceFirst(consume, Effect.raceFirst(abortWatcher, renewal));

      const raced = (
        yieldAfter === undefined && submissionScheduling.yieldTo === undefined
          ? execution
          : Effect.raceFirst(
              execution,
              Deferred.await(yieldSignal).pipe(
                Effect.map((nextSubmissionId) => ({
                  _tag: "yielded" as const,
                  ...(nextSubmissionId === undefined ? {} : { nextSubmissionId }),
                })),
              ),
            )
      ).pipe(Effect.provideService(IdGenerator, idGenerator));

      const result = yield* raced.pipe(
        Effect.catchCauseFilter(
          Cause.findError,
          (
            error,
            cause,
          ): Effect.Effect<
            | { readonly _tag: "failedRun"; readonly outcome: AttemptOutcome }
            | { readonly _tag: "aborted" }
            | { readonly _tag: "suspendedRun"; readonly toolCallId: ToolCallId }
            | {
                readonly _tag: "suspendedChildRun";
                readonly children: AgentChildPending["children"];
              },
            DurableWorkerFailure
          > => {
            if (isCoordinatorHaltCause(cause)) {
              return Effect.failCause(Cause.map(cause, (halt) => halt.failure));
            }
            const approvalPending = agentApprovalPendingOption(cause);

            if (Option.isSome(approvalPending)) {
              // The canonical request preserves the pending control marker. A coexisting defect
              // or interruption must escape intact, without retention or a safe suspension.
              const residual = Cause.fromReasons<never>(
                cause.reasons.filter(
                  (reason): reason is Cause.Die | Cause.Interrupt => reason._tag !== "Fail",
                ),
              );

              if (residual.reasons.length > 0) return Effect.failCause(residual);

              // Durable approval suspension (plan §2.6): the approval hook already made the
              // request canonical; `runAttempt` owns the ledger transition. The engine decoded
              // the declared call id before raising the suspension, so a failure is a defect.
              return decodeToolCallIdUnknown(approvalPending.value.toolCallId).pipe(
                Effect.orDie,
                Effect.map((toolCallId) => ({ _tag: "suspendedRun" as const, toolCallId })),
              );
            }
            const childPending = agentChildPendingOption(error);

            if (Option.isSome(childPending)) {
              // Durable waitingForChild suspension (spec §12 step 10): every non-waiting
              // sibling settled before the Run terminated; commit their results as per-call
              // late-settle batches FIRST so no sibling effect is lost, then let `runAttempt`
              // own the ledger transition.
              return commitSiblingLateSettles(childPending.value.children).pipe(
                Effect.map(() => ({
                  _tag: "suspendedChildRun" as const,
                  children: childPending.value.children,
                })),
              );
            }

            return Effect.gen(function* () {
              // A recorded halt means a coordinator mutation failed inside a Tool handler
              // (the engine re-wraps step-hook and subagent-hook errors): abort the Attempt
              // with the original infrastructure failure instead of settling the Run failed.
              const halted = yield* Ref.get(haltRef);

              if (halted !== undefined) {
                return yield* halted;
              }

              // Host authorization can observe cancellation before the abort watcher ticks.
              // Only an authorization denial with this Submission's durable intent is an abort.
              if (error instanceof AgentToolAuthorizationDenied) {
                const intent = yield* ledger.readAbortIntent(
                  AbortIntentRequest.make({ submissionId }),
                );

                if (intent !== undefined) {
                  yield* appendAbortRecord(ctx, intent);

                  return { _tag: "aborted" as const };
                }
              }

              // Report the original live Cause here, before its private diagnostic projection,
              // after excluding suspensions, so hosts retain its cause and stack exactly
              // once per failed Run; reading or retrying its receipt never reports again.
              if (
                cause.reasons.some(
                  (reason) =>
                    reason._tag === "Die" ||
                    (reason._tag === "Fail" &&
                      !(reason.error instanceof AgentApprovalDenied) &&
                      !(reason.error instanceof AgentToolAuthorizationDenied)),
                )
              )
                yield* Effect.logError("Agent run failed", cause).pipe(
                  Effect.annotateLogs({
                    agentId: agent.definition.id,
                    runId,
                    threadId: ctx.threadId,
                    submissionId,
                    attemptId: lineage.attemptId,
                  }),
                );

              return {
                _tag: "failedRun" as const,
                outcome: yield* failureOutcome(error, cause, {
                  agentId: agent.definition.id,
                  runId,
                  threadId: ctx.threadId,
                  submissionId,
                  attemptId: lineage.attemptId,
                }),
              };
            });
          },
        ),
      );

      if (result._tag === "yielded") return result;
      if (result._tag === "suspendedRun") return approvalSuspension(result.toolCallId);
      if (result._tag === "suspendedChildRun") return childSuspension(result.children);
      if (result._tag === "aborted") {
        return {
          ...abortedRunPhase(yield* currentUsageSummary()),
          uncommittedModelUsage: uncommittedModelUsage(),
        };
      }
      if (result._tag === "failedRun") {
        const failed: RunPhaseOutcome = {
          ...result.outcome,
          usageSummary: yield* currentUsageSummary(),
          uncommittedModelUsage: uncommittedModelUsage(),
        };

        return failed;
      }
      const state = yield* Ref.get(stateRef);

      if (state.completedOutput === undefined) {
        return yield* LedgerError.make({
          operation: "runModel",
          message: "Agent Run stream ended without RunCompleted",
        });
      }

      const completed: RunPhaseOutcome = {
        _tag: "completed",
        result: state.completedOutput,
        ...(state.completedRunDisposition === undefined
          ? {}
          : { runDisposition: state.completedRunDisposition }),
        ...(state.completedFinishReason === undefined
          ? {}
          : { finishReason: state.completedFinishReason }),
        ...(state.completedFinishReason === undefined || state.completedExhausted === undefined
          ? {}
          : { exhausted: state.completedExhausted }),
        usageSummary: yield* currentUsageSummary(),
        uncommittedModelUsage: uncommittedModelUsage(),
      };

      return completed;
    });

  /**
   * One ownership period over the claimed lane head. The step order mirrors the pure recovery
   * classifier's decision table, so a fresh Attempt and a recovering Attempt take the same path
   * through the same idempotent steps. Returns `Option.none` when the lane is durably blocked
   * (Unknown Outcomes, or a durable approval suspension) — no settlement occurs and the
   * obligation stays owed.
   */
  const runAttempt = <
    InputSchema extends Schema.Top,
    OutputSchema extends Schema.Top,
    Instructions,
    Tools extends Record<string, Tool.Any>,
    Provider,
    ModelProvides,
    ModelRequires,
    InstructionError = InstructionErrorOf<Instructions, InputSchema["Type"]>,
    InstructionRequirements = InstructionRequirementsOf<Instructions, InputSchema["Type"]>,
    RunDispositionValue extends
      | RunDispositionDeclaration<OutputSchema["Type"], Schema.Top>
      | undefined = undefined,
    InputPromptValue extends InputPromptSource<InputSchema["Type"], unknown, unknown> | undefined =
      undefined,
    UpdatesSchema extends Schema.Top | undefined = undefined,
  >(
    registeredAgent: RuntimeBinding<
      InputSchema,
      OutputSchema,
      Instructions,
      Tools,
      Provider,
      ModelProvides,
      ModelRequires,
      InstructionError,
      InstructionRequirements,
      RunDispositionValue,
      InputPromptValue,
      UpdatesSchema
    >,
    threadId: ThreadId,
    claim: Claim,
    tokenRef: Ref.Ref<OwnershipToken>,
    renewAtRef: Ref.Ref<number>,
    resumeAfterRetention: () => void,
    onHandoff: (nextSubmissionId: SubmissionId) => void,
    yieldAfter?: DateTime.Utc,
  ) =>
    Effect.gen(function* () {
      const submissionId = claim.submissionId;

      // The Thread-store fence BEFORE this Attempt advances it identifies the superseded
      // ownership period for the durability §9 interruption audit.
      const supersededEpoch = yield* store.inspectTail(ThreadTailRequest.make({ threadId })).pipe(
        Effect.map((tail) => tail.producerEpoch),
        Effect.catchTag("ThreadNotMaterialized", () => Effect.succeed(ZERO_EPOCH)),
      );

      // Advance the Thread-store fence to this Attempt's epoch (idempotent when equal).
      yield* store.materialize(
        ThreadMaterialization.make({ threadId, producerEpoch: claim.producerEpoch }),
      );

      const snapshot = yield* ledger.loadRecoverySnapshot(
        RecoverySnapshotRequest.make({ submissionId }),
      );

      const submission = snapshot.submission;

      yield* ensureThreadCreated(threadId, submission.agentId, submission.agentDigests);
      if (submission.workerAdmission?.origin.reporting?.mode === "standard")
        yield* updateRuntime.repair(threadId);
      if (submission.workerAdmission !== undefined) {
        yield* workerRuntime
          .ensureOrigin(submission.workerAdmission.origin)
          .pipe(
            Effect.mapError((cause) =>
              LedgerError.make({ operation: "worker-origin", message: cause.reason, cause }),
            ),
          );
      }
      if (submission.state === "admitted") {
        yield* ledger.markReady(MarkReadyRequest.make({ submissionId }));
      }
      const ctx = yield* attemptContextFor(threadId, claim.producerEpoch);

      let controlThrough = (yield* store.inspectTail(ThreadTailRequest.make({ threadId })))
        .tailSequence;

      const initialThrough = controlThrough;

      const initialView = yield* recoveryView(
        threadId,
        initialThrough,
        [submissionId],
        runIdForSubmission(submissionId),
      );

      let journalMetadata =
        initialView.seed === undefined
          ? makeJournalMetadata(runIdForSubmission(submissionId))
          : undefined;

      const retainControl = controlRecords([submissionId]);

      const collectControl = (record: CanonicalRecordEnvelope): boolean => {
        journalMetadata?.add(record);

        return retainControl(record);
      };

      const takeJournalMetadata = (): JournalMetadata | undefined => {
        const metadata = journalMetadata?.snapshot();

        // Reuse the validated prefix once, then release compaction payloads before model
        // waits. An immediate resume falls back to a fresh canonical metadata scan.
        if (metadata !== undefined && metadata.compactions.length > 0) journalMetadata = undefined;

        return metadata;
      };

      let records: ReadonlyArray<CanonicalRecordEnvelope> = yield* Stream.runCollect(
        initialView.canonical.pipe(Stream.filter(collectControl)),
      );

      // The append-only prefix remains valid for this Attempt. Retain only this Run's control
      // evidence and validate each newly visible suffix against its own captured tail.
      const refreshControl = Effect.fn("DurableAgentRuntime.refreshAttemptControl")(function* (
        throughSequence?: CanonicalSequence,
      ) {
        const through =
          throughSequence ??
          (yield* store.inspectTail(ThreadTailRequest.make({ threadId }))).tailSequence;

        if (through > controlThrough) {
          const suffix = yield* readCanonicalRange(
            threadId,
            controlThrough,
            through,
            collectControl,
          );

          records = [...records, ...suffix];
          controlThrough = through;
        }

        return records;
      });

      const workerOrigin = records
        .map((envelope) => envelope.record.payload)
        .find((payload) => payload._tag === "WorkerOriginRecorded")?.origin;

      if (
        workerOrigin !== undefined &&
        (submission.workerAdmission === undefined ||
          !Schema.toEquivalence(WorkerAdmission.fields.origin)(
            workerOrigin,
            submission.workerAdmission.origin,
          ))
      ) {
        return yield* RunJournalError.make({
          message: "Worker input does not match its immutable Thread origin",
        });
      }

      const childPolicy =
        workerOrigin?.policy ??
        records
          .map((envelope) => envelope.record.payload)
          .find((payload) => payload._tag === "SubagentLineageRecorded")?.policy;

      const agent =
        childPolicy === undefined
          ? registeredAgent
          : {
              ...registeredAgent,
              definition: { ...registeredAgent.definition, policy: childPolicy },
            };

      // Restoring the accepted child policy changes no Tool declarations. Retain the
      // selected registration's contracts instead of resolving the copied Definition.
      const currentContracts = yield* contractsFor(registeredAgent.definition);

      const evidence = yield* evidenceFor(records, submissionId, true, snapshot.hostSubmissionId);
      const knownIds = knownRecordIdsOf(records);

      if (evidence.recordedSettlementOutcome !== undefined) {
        const record = yield* canonicalSettlementRecord(records, submissionId);
        const settlement = yield* finalizeFromHistory(submission, record);
        const canonicalSettlement = yield* settlementPayloadFromRecord(record, submissionId);

        yield* settleJoinedSubmissions(ctx, canonicalSettlement);

        return Option.some(settlement);
      }
      if (snapshot.reservation !== undefined) {
        return Option.some(
          yield* completeReservation(ctx, submission, snapshot.reservation, false),
        );
      }
      if (snapshot.abortIntent !== undefined) {
        // request-abort-and-join (spec §13.1, SUB-022): propagate the durable abort to every
        // nonterminal attached child, join every settled child coordinator-side, and settle
        // aborted ONLY once no child obligation stays open. A waiting/blocked disposition ends
        // the ownership period without settling — the obligation stays owed.
        const disposition = yield* abortAttachedChildren(ctx, submission, tokenRef, knownIds);

        if (disposition === "waiting") {
          return Option.none<Settlement>();
        }
        if (disposition === "blocked") {
          const ownershipToken = yield* Ref.get(tokenRef);

          yield* ledger
            .releaseOwnership(ReleaseOwnershipRequest.make({ submissionId, ownershipToken }))
            .pipe(Effect.catchTag("OwnershipLost", () => Effect.void));

          return Option.none<Settlement>();
        }

        return Option.some(
          yield* settleAborted(ctx, submission, tokenRef, snapshot.abortIntent, evidence, knownIds),
        );
      }
      yield* applyCanonicalInput(ctx, submission, tokenRef, records, snapshot.inputApplied);

      const savedRunTiming = yield* ensureRunStarted(
        ctx,
        submission,
        Duration.toMillis(agent.definition.policy.maxDuration),
        yield* refreshControl(),
      );

      const runTiming =
        workerOrigin === undefined
          ? savedRunTiming
          : {
              ...savedRunTiming,
              deadline: DateTime.makeUnsafe(
                Math.min(
                  DateTime.toEpochMillis(savedRunTiming.deadline),
                  workerOrigin.expiresAtMillis,
                ),
              ),
            };

      let expiredChildObligation = false;

      if ((yield* Clock.currentTimeMillis) >= DateTime.toEpochMillis(runTiming.deadline)) {
        yield* reconcileRetainedChildren(ctx, submission, yield* Ref.get(tokenRef));
        expiredChildObligation = yield* completeJoinedReleases(submission);
      }

      // Recheck after duration interruption too: that Attempt may have prepared new ordinary calls.
      const ordinaryCallsResolved = Effect.gen(function* () {
        const reconciliationRecords = yield* refreshControl();

        const reconciliationEvidence = yield* evidenceFor(
          reconciliationRecords,
          submissionId,
          true,
          snapshot.hostSubmissionId,
        );

        if (reconciliationEvidence.openToolCalls.length === 0) return true;

        const reconciliationSnapshot = yield* ledger.loadRecoverySnapshot(
          RecoverySnapshotRequest.make({ submissionId }),
        );

        for (const envelope of reconciliationRecords) knownIds.add(envelope.record.recordId);

        const review = yield* reconcileOpenCalls(
          ctx,
          submission,
          reconciliationSnapshot,
          reconciliationRecords,
          reconciliationEvidence.openToolCalls,
          knownIds,
          { definition: agent.definition, contracts: currentContracts },
        );

        if (review.uncertain.length > 0 || review.unproven.length > 0) {
          if (review.uncertain.length > 0) {
            yield* markCallsUnknown(
              ctx,
              submissionId,
              knownIds,
              review.uncertain,
              "An ordinary Tool call may have executed without a canonical outcome",
            );
          }
          // This Submission is parked (marked Unknown, or reconciliation itself failed):
          // release the claim without settling — the accepted-work obligation stays owed.
          const ownershipToken = yield* Ref.get(tokenRef);

          yield* ledger
            .releaseOwnership(ReleaseOwnershipRequest.make({ submissionId, ownershipToken }))
            .pipe(Effect.catchTag("OwnershipLost", () => Effect.void));

          return false;
        }

        return true;
      });

      if (!expiredChildObligation && !(yield* ordinaryCallsResolved))
        return Option.none<Settlement>();

      const continuationRecords = yield* refreshControl();

      const continuation = yield* pendingToolBatchFor(
        continuationRecords,
        runIdForSubmission(submissionId),
      );

      if (continuation !== undefined) {
        const current = {
          definition: agent.definition,
          contracts: currentContracts,
        };

        const operations = operationsFor(continuationRecords, runIdForSubmission(submissionId));
        const settled = new Set(continuation.settled.map((call) => call.id));

        const rejected = new Set(
          continuation.toolParameterRejections?.map((call) => call.toolCallId),
        );

        const unsupported: Array<OpenToolCallEvidence> = [];
        const unavailableDelegations = new Set<ToolCallId>();

        for (const call of continuation.calls) {
          const original = continuationRecords
            .map(({ record }) => record.payload)
            .find(
              (payload) =>
                payload._tag === "ToolCallPrepared" &&
                payload.runId === runIdForSubmission(submissionId) &&
                payload.toolCallId === call.id,
            );

          if (
            original?._tag === "ToolCallPrepared" &&
            original.executionKind === "delegation" &&
            !settled.has(call.id) &&
            !supportsOperation(
              submission,
              OpenToolCallEvidence.make(original),
              operations.get(call.id),
              original,
              current,
            )
          )
            unavailableDelegations.add(original.toolCallId);
        }

        const children =
          unavailableDelegations.size === 0
            ? undefined
            : yield* reconcileRetainedChildren(
                ctx,
                submission,
                yield* Ref.get(tokenRef),
                unavailableDelegations,
              );

        for (const envelope of yield* refreshControl()) knownIds.add(envelope.record.recordId);

        for (const call of continuation.calls) {
          if (
            call.providerExecuted ||
            settled.has(call.id) ||
            rejected.has(Schema.decodeSync(ToolCallId)(call.id))
          )
            continue;

          const evidence = OpenToolCallEvidence.make({
            toolCallId: Schema.decodeSync(ToolCallId)(call.id),
            toolName: call.name,
            turn: continuation.turn,
          });

          const operation = operations.get(call.id);

          const prepared = continuationRecords
            .map(({ record }) => record.payload)
            .find(
              (payload) =>
                payload._tag === "ToolCallPrepared" &&
                payload.runId === runIdForSubmission(submissionId) &&
                payload.turn === continuation.turn &&
                payload.toolCallId === call.id,
            );

          const preparation = prepared?._tag === "ToolCallPrepared" ? prepared : undefined;

          if (supportsOperation(submission, evidence, operation, preparation, current)) continue;
          if (preparation !== undefined && !children?.notExecuted.has(evidence.toolCallId)) {
            if (!unavailableDelegations.has(evidence.toolCallId)) unsupported.push(evidence);
            continue;
          }

          // Mutating handlers cannot cross this protocol boundary without preparation.
          // Readonly handlers may already have run; their unavailable result makes no nonexecution claim.
          const execution =
            children?.notExecuted.has(evidence.toolCallId) ||
            (operation !== undefined &&
              (operation.executionClass !== "readonly" || operation.executionKind !== "ordinary"))
              ? "not-executed"
              : "unavailable";

          const result = yield* Schema.encodeEffect(ToolUnavailable)(
            ToolUnavailable.make({
              toolName: call.name,
              execution,
              message:
                execution === "not-executed"
                  ? "This operation was not executed and its original implementation is unavailable. Continue with the current tools."
                  : "The original operation is unavailable. No mutating handler was dispatched; readonly work may have run without a recorded result.",
            }),
          ).pipe(Effect.flatMap(decodePersisted), Effect.orDie);

          yield* hit("tools:before-unavailable-append");
          yield* appendClosedCall(ctx, submissionId, knownIds, evidence, {
            result: { value: result, isFailure: true },
            resolution: execution === "not-executed" ? "never-started" : "failed-with-error",
            author: "runtime",
            reason: "The declared operation cannot execute under its original contract",
          });
          yield* hit("tools:after-unavailable-append");
        }
        const firstWaiting = children?.waiting[0];

        if (children !== undefined && firstWaiting !== undefined) {
          const disposition = yield* ledger.suspend(
            SuspendRequest.make({
              submissionId,
              ownershipToken: yield* Ref.get(tokenRef),
              reason: WaitingForChildSuspension.make({
                children: [firstWaiting, ...children.waiting.slice(1)],
              }),
            }),
          );

          yield* hit("subagent:after-suspend");
          if (disposition === "resume-immediately") yield* wake.notify(threadId);

          return Option.none<Settlement>();
        }
        if ((children?.indeterminate.size ?? 0) > 0) return Option.none<Settlement>();
        if (unsupported.length > 0) {
          yield* markCallsUnknown(
            ctx,
            submissionId,
            knownIds,
            unsupported,
            "The unfinished operation has no supported recovery implementation; its original identity and evidence remain unresolved",
          );

          return Option.none<Settlement>();
        }
      }

      const lineage: AttemptLineage = {
        attemptId: claim.attemptId,
        supersededEpoch,
        inputWasRecorded: evidence.inputRecorded,
      };

      let approvalDecisionIntents = snapshot.approvalDecisions;
      let priorContext = initialView.context;

      while (true) {
        const tail = yield* store.inspectTail(ThreadTailRequest.make({ threadId }));

        // An immediate resume may include a newly committed compaction. Rebuild its canonical
        // proof rather than carrying the initial Thread context across that boundary.
        const fullContextReplay = initialView.context !== undefined && priorContext === undefined;

        const canonical = fullContextReplay
          ? canonicalRange(threadId, tail.tailSequence)
          : Stream.concat(
              initialView.canonical,
              canonicalRange(threadId, tail.tailSequence, initialThrough),
            );

        const currentRecords = yield* refreshControl(tail.tailSequence);

        const outcome = yield* runModel(
          agent,
          ctx,
          submission,
          tokenRef,
          renewAtRef,
          currentRecords,
          canonical,
          tail.tailSequence,
          initialView.seed,
          priorContext,
          fullContextReplay ? undefined : takeJournalMetadata(),
          lineage,
          approvalDecisionIntents,
          currentContracts,
          runTiming,
          yieldAfter,
        );

        priorContext = undefined;

        if (outcome._tag === "yielded") {
          if (outcome.nextSubmissionId !== undefined) onHandoff(outcome.nextSubmissionId);

          return Option.none();
        }
        if (outcome._tag === "suspendedChild") {
          // Durable waitingForChild suspension (spec §12 step 10, SUB-030): the sibling
          // late-settles are already canonical; the ledger transition ends the ownership
          // period WITHOUT settling and the lane consumes no worker permit while each listed
          // child runs on its own Thread lane. A child settlement racing ahead of the
          // suspend transaction returns `resume-immediately`: the declared batch replays under
          // this same claim and the handler joins the settled child.
          const [firstChild, ...restChildren] = outcome.children;

          const waitingChildren: readonly [WaitingChild, ...Array<WaitingChild>] = [
            WaitingChild.make({
              toolCallId: firstChild.toolCallId,
              childSubmissionId: firstChild.childSubmissionId,
            }),
            ...restChildren.map((child) =>
              WaitingChild.make({
                toolCallId: child.toolCallId,
                childSubmissionId: child.childSubmissionId,
              }),
            ),
          ];

          const ownershipToken = yield* Ref.get(tokenRef);

          const suspension = yield* ledger.suspend(
            SuspendRequest.make({
              submissionId,
              ownershipToken,
              reason: WaitingForChildSuspension.make({ children: waitingChildren }),
            }),
          );

          yield* hit("subagent:after-suspend");
          for (const child of outcome.children) {
            yield* wake.notify(child.childThreadId);
          }
          if (suspension === "suspended") {
            return Option.none<Settlement>();
          }
          continue;
        }
        if (outcome._tag === "suspended") {
          // Durable approval suspension (plan §2.6): the ledger transition ends the ownership
          // period WITHOUT settling — the accepted-work obligation stays owed while the lane
          // consumes no worker permit. A decision that raced ahead of the suspend transaction
          // returns `resume-immediately`. Retained resources require a fresh Attempt; otherwise
          // the declared batch replays under this claim with the fresh decision intents.
          const ownershipToken = yield* Ref.get(tokenRef);

          const suspension = yield* ledger.suspend(
            SuspendRequest.make({
              submissionId,
              ownershipToken,
              reason: ApprovalPendingSuspension.make({ toolCallIds: [outcome.toolCallId] }),
            }),
          );

          yield* hit("approval:after-suspend");
          if (suspension === "suspended") {
            return Option.none<Settlement>();
          }
          if ((yield* DurableApprovalSuspension) !== undefined) {
            // Retention completed inside runModel. Leave both the service and claim scopes
            // before reacquiring: a transferred attachment cannot execute the approved batch.
            resumeAfterRetention();

            return Option.none<Settlement>();
          }
          approvalDecisionIntents = (yield* ledger.loadRecoverySnapshot(
            RecoverySnapshotRequest.make({ submissionId }),
          )).approvalDecisions;
          continue;
        }
        if (outcome._tag === "aborted") {
          // Durable abort ended the Run while attached children may still be open:
          // request-abort-and-join before the aborted settlement (spec §13.1).
          const disposition = yield* abortAttachedChildren(ctx, submission, tokenRef, knownIds);

          if (disposition === "waiting") {
            return Option.none<Settlement>();
          }
          if (disposition === "blocked") {
            const ownershipToken = yield* Ref.get(tokenRef);

            yield* ledger
              .releaseOwnership(ReleaseOwnershipRequest.make({ submissionId, ownershipToken }))
              .pipe(Effect.catchTag("OwnershipLost", () => Effect.void));

            return Option.none<Settlement>();
          }

          return Option.some(yield* terminalize(ctx, submission, tokenRef, outcome, true));
        }
        // Canonical joins drive their reservation release BEFORE the parent settles (a settled
        // lane would strand the repair); a reserved row WITHOUT a canonical join is an open
        // attached-child obligation and the parent never settles across it (spec §13).
        if (outcome._tag === "failed" && outcome.policyLimit === "duration") {
          const exhaustedId = runDurationRecordId(runIdForSubmission(submissionId));

          if (!(yield* refreshControl()).some(({ record }) => record.recordId === exhaustedId)) {
            yield* hit("run:before-duration-append");
            yield* appendBatch(
              ctx,
              CanonicalBatch.make({
                batchId: runDurationBatchId(runIdForSubmission(submissionId)),
                producerId: config.producerId,
                records: [
                  yield* makeEnvelope(
                    exhaustedId,
                    RunDurationExhausted.make({
                      runId: runIdForSubmission(submissionId),
                    }),
                  ),
                ],
              }),
            );
            yield* hit("run:after-duration-append");
          }
          yield* reconcileRetainedChildren(ctx, submission, yield* Ref.get(tokenRef));
        }
        const openObligation = yield* completeJoinedReleases(submission);

        if (openObligation) {
          if (outcome._tag === "failed") {
            // Release the claim and leave the lane to recovery classification.
            const ownershipToken = yield* Ref.get(tokenRef);

            yield* ledger
              .releaseOwnership(ReleaseOwnershipRequest.make({ submissionId, ownershipToken }))
              .pipe(Effect.catchTag("OwnershipLost", () => Effect.void));

            return Option.none<Settlement>();
          }

          // A completed Run with an unjoined reservation is structurally unreachable (the
          // delegation Tool Call settles only through the atomic join batch): fail closed
          // with the obligation visibly owed instead of settling across it.
          return yield* LedgerError.make({
            operation: "runAttempt",
            message: `Submission ${submissionId} completed with an unjoined child budget reservation; the settlement is withheld fail-closed (spec 13)`,
          });
        }
        if (
          outcome._tag === "failed" &&
          outcome.policyLimit === "duration" &&
          !(yield* ordinaryCallsResolved)
        ) {
          return Option.none<Settlement>();
        }

        return Option.some(
          yield* terminalize(
            ctx,
            submission,
            tokenRef,
            outcome,
            true,
            outcome._tag === "completed"
              ? saveThreadContext(ctx, submission, initialView.context)
              : undefined,
          ),
        );
      }
    }).pipe(Effect.scoped);

  /** A missing current binding leaves both roots and children owed, with their claims released. */
  type CapturedWorkerBinding = Effect.Success<ReturnType<typeof makeLegacyWorkerBinding>>;

  // Register cleanup before any interruptible work can observe a granted claim. The token
  // reference is shared with renewal, so cleanup never releases with a superseded token.
  const acquireClaim = Effect.fn("DurableAgentRuntime.acquireClaim")(function* (
    threadId: ThreadId,
    handoff?: ClaimHandoff,
  ) {
    const acquiringAt = yield* Clock.currentTimeMillis;

    const claimed = yield* ledger.claim(
      ClaimRequest.make({
        threadId,
        producerId: config.producerId,
        ...(handoff === undefined ? {} : { handoff }),
      }),
    );

    if (Option.isNone(claimed)) return Option.none();
    const claim = claimed.value;
    const tokenRef = yield* Ref.make(claim.ownershipToken);

    const renewAtRef = yield* Ref.make(
      acquiringAt + Duration.toMillis(config.leaseRenewalInterval),
    );

    yield* Effect.addFinalizer(() =>
      Ref.get(tokenRef).pipe(
        Effect.flatMap((ownershipToken) =>
          ledger.releaseOwnership(
            ReleaseOwnershipRequest.make({ submissionId: claim.submissionId, ownershipToken }),
          ),
        ),
        Effect.catchTag("OwnershipLost", () => Effect.void),
        Effect.catchTag("LedgerError", () =>
          Effect.logWarning(
            "Attempt ownership release failed; lease recovery remains required",
          ).pipe(Effect.annotateLogs({ submissionId: claim.submissionId })),
        ),
      ),
    );

    if (handoff !== undefined && claim.submissionId !== handoff.submissionId)
      return yield* LedgerError.make({
        operation: "claim handoff",
        message: "The submission adapter did not honor the requested handoff",
      });

    return Option.some({ claim, tokenRef, renewAtRef });
  }, Effect.uninterruptible);

  const processThreadHead = (
    resolve: (
      submission: SubmissionSnapshot,
    ) => Effect.Effect<CapturedWorkerBinding, DurableBindingFailure | DurableWorkerFailure>,
    threadId: ThreadId,
    options?: { readonly yieldAfter?: DateTime.Utc },
  ): Effect.Effect<
    {
      readonly settlement: Option.Option<Settlement>;
      readonly firstClaimedSubmissionId: SubmissionId | undefined;
    },
    DurableWorkerFailure | DurableBindingFailure
  > =>
    Effect.gen(function* () {
      let resumeAfterRetention = false;
      let handoff: ClaimHandoff | undefined;
      let nextHandoff: ClaimHandoff | undefined;
      let firstClaimedSubmissionId: SubmissionId | undefined;

      const attempt = Effect.scoped(
        Effect.gen(function* () {
          const claimed = yield* acquireClaim(threadId, handoff);

          if (Option.isNone(claimed)) return Option.none();
          const { claim, tokenRef, renewAtRef } = claimed.value;

          firstClaimedSubmissionId ??= claim.submissionId;

          const attributes = {
            threadId,
            submissionId: claim.submissionId,
            attemptId: claim.attemptId,
          };

          yield* Effect.annotateCurrentSpan(attributes);
          yield* Effect.annotateLogsScoped(attributes);
          yield* hit("claim:after-claim");

          const found = yield* ledger.lookup(
            SubmissionLookupById.make({ submissionId: claim.submissionId }),
          );

          if (Option.isNone(found)) {
            return yield* LedgerError.make({
              operation: "processThreadHead",
              message: `Claimed unknown Submission ${claim.submissionId}`,
            });
          }
          const submission = found.value;

          // The claim head rule legally grants an `admitted` head, so the worker path
          // enforces the same AwaitParentEstablishment discipline as the recovery classifier —
          // a parent-linked child whose Thread lacks its canonical lineage record is not
          // runnable yet (the parent's idempotent establishment appends lineage BEFORE
          // readiness, SUB-016).
          // Release the claim, nudge the parent lane, and leave the child to establishment.
          if (submission.parentLinkage !== undefined && submission.state === "admitted") {
            const read = yield* readAllTolerant(threadId, []);

            const lineageRecorded = read.records.some(
              (envelope) => envelope.record.payload._tag === "SubagentLineageRecorded",
            );

            if (!lineageRecorded) {
              yield* ledger
                .releaseOwnership(
                  ReleaseOwnershipRequest.make({
                    submissionId: claim.submissionId,
                    ownershipToken: claim.ownershipToken,
                  }),
                )
                .pipe(Effect.catchTag("OwnershipLost", () => Effect.void));

              const parent = yield* ledger.lookup(
                SubmissionLookupById.make({
                  submissionId: submission.parentLinkage.parentSubmissionId,
                }),
              );

              if (Option.isSome(parent)) {
                yield* wake.notify(parent.value.threadId);
              }

              return Option.none();
            }
          }

          const resolution = yield* resolve(submission).pipe(
            Effect.map((binding) => ({ _tag: "resolved" as const, binding })),
            Effect.catchTags({
              BindingUnavailable: (failure) =>
                Effect.succeed({ _tag: "refused" as const, failure }),
            }),
          );

          if (resolution._tag === "refused") {
            return yield* resolution.failure;
          }

          return yield* resolution.binding.attempt(
            (agent, attemptThreadId, attemptClaim) =>
              runAttempt(
                agent,
                attemptThreadId,
                attemptClaim,
                tokenRef,
                renewAtRef,
                () => {
                  resumeAfterRetention = true;
                },
                (nextSubmissionId) => {
                  nextHandoff = ClaimHandoff.make({
                    producerEpoch: claim.producerEpoch,
                    deferredSubmissionIds: [
                      ...(handoff?.deferredSubmissionIds ?? []),
                      claim.submissionId,
                    ],
                    submissionId: nextSubmissionId,
                  });
                },
                options?.yieldAfter,
              ),
            threadId,
            claim,
          );
        }),
      );

      while (true) {
        resumeAfterRetention = false;
        nextHandoff = undefined;
        const settlement = yield* attempt;

        // The previous Attempt's entire Scope has closed before the next authority is built.
        if (nextHandoff !== undefined) {
          handoff = nextHandoff;
          continue;
        }
        if (!resumeAfterRetention) return { settlement, firstClaimedSubmissionId };
      }
    }).pipe(withThreadHeadSpan);

  const eligibleThreadHead = (threadId: ThreadId, afterQueueSequence?: number) =>
    Stream.runHead(
      ledger.scanNonterminal.pipe(
        Stream.filter(
          (entry) =>
            entry.threadId === threadId &&
            (afterQueueSequence === undefined || entry.queueSequence > afterQueueSequence),
        ),
        Stream.filterEffect((entry) =>
          entry.state !== "unknown"
            ? Effect.succeed(true)
            : ledger
                .loadRecoverySnapshot(
                  RecoverySnapshotRequest.make({ submissionId: entry.submissionId }),
                )
                .pipe(Effect.map((snapshot) => snapshot.abortIntent !== undefined)),
        ),
      ),
    );

  const drainThread = (
    resolve: (
      submission: SubmissionSnapshot,
    ) => Effect.Effect<CapturedWorkerBinding, DurableBindingFailure | DurableWorkerFailure>,
    threadId: ThreadId,
  ): Effect.Effect<ReadonlyArray<Settlement>, DurableWorkerFailure | DurableBindingFailure> =>
    Effect.gen(function* () {
      const settlements: Array<Settlement> = [];

      while (true) {
        const { settlement, firstClaimedSubmissionId } = yield* processThreadHead(
          resolve,
          threadId,
        );

        if (Option.isNone(settlement)) {
          if (firstClaimedSubmissionId === undefined) return settlements;
          const after = yield* eligibleThreadHead(threadId);

          // Parking an unknown operation exposes later runnable work. Other suspensions,
          // live ownership and a transiently unproven operation retain the existing barrier.
          // Keep the first claim across handoffs: its unfinished lane may still be the head.
          if (Option.isSome(after) && firstClaimedSubmissionId !== after.value.submissionId)
            continue;

          return settlements;
        }
        settlements.push(settlement.value);
      }
    });

  const processThreadImpl = <
    InputSchema extends Schema.Top,
    OutputSchema extends Schema.Top,
    Instructions,
    Tools extends Record<string, Tool.Any>,
    Provider,
    ModelProvides,
    ModelRequires,
    InstructionError = InstructionErrorOf<Instructions, InputSchema["Type"]>,
    InstructionRequirements = InstructionRequirementsOf<Instructions, InputSchema["Type"]>,
    RunDispositionValue extends
      | RunDispositionDeclaration<OutputSchema["Type"], Schema.Top>
      | undefined = undefined,
    InputPromptValue extends InputPromptSource<InputSchema["Type"], unknown, unknown> | undefined =
      undefined,
    UpdatesSchema extends Schema.Top | undefined = undefined,
  >(
    agent: RuntimeBinding<
      InputSchema,
      OutputSchema,
      Instructions,
      Tools,
      Provider,
      ModelProvides,
      ModelRequires,
      InstructionError,
      InstructionRequirements,
      RunDispositionValue,
      InputPromptValue,
      UpdatesSchema
    >,
    threadId: ThreadId,
  ) =>
    Effect.gen(function* () {
      // The legacy single-binding worker is a singleton resolver (plan §1.7): identity-exact —
      // a claimed head with a different Agent never runs against this binding (the latent P4
      // gap) — and digest-transparent, because this call site registers no digest authority.
      const binding = yield* makeLegacyWorkerBinding(agent);

      return yield* drainThread(
        (submission) =>
          submission.agentId === binding.agentId
            ? Effect.succeed(binding)
            : Effect.fail(
                BindingUnavailable.make({
                  agentId: submission.agentId,
                  message: `This worker is bound to Agent ${binding.agentId}; the claimed head belongs to Agent ${submission.agentId} (SUB-023)`,
                }),
              ),
        threadId,
      );
    });

  const processThreadResolvedImpl = (
    threadId: ThreadId,
  ): Effect.Effect<ReadonlyArray<Settlement>, DurableWorkerFailure | DurableBindingFailure> =>
    drainThread(resolveCurrentBinding, threadId);

  const processThreadHeadImpl = (
    threadId: ThreadId,
    options?: { readonly yieldAfter?: DateTime.Utc },
  ): Effect.Effect<Option.Option<Settlement>, DurableWorkerFailure | DurableBindingFailure> =>
    processThreadHead(resolveCurrentBinding, threadId, options).pipe(
      Effect.map(({ settlement }) => settlement),
    );

  const claimFor = Effect.fn("DurableAgentRuntime.claimFor")(function* (
    submission: SubmissionSnapshot,
    decision: RecoveryDecision,
  ): Effect.fn.Return<Option.Option<Claim>, LedgerError | OwnershipLost, Scope.Scope> {
    const head = yield* eligibleThreadHead(submission.threadId);

    if (Option.isNone(head) || head.value.submissionId !== submission.submissionId) {
      return Option.none();
    }
    const claimed = yield* acquireClaim(submission.threadId);

    if (Option.isNone(claimed)) return Option.none();
    if (claimed.value.claim.submissionId !== submission.submissionId) {
      // Only the first eligible Submission is claimable; selection may have changed since the read.
      yield* ledger
        .releaseOwnership(
          ReleaseOwnershipRequest.make({
            submissionId: claimed.value.claim.submissionId,
            ownershipToken: claimed.value.claim.ownershipToken,
          }),
        )
        .pipe(Effect.catchTag("OwnershipLost", () => Effect.void));

      return Option.none();
    }

    yield* annotateRepair(submission.threadId, decision, claimed.value.claim.producerEpoch);

    return Option.some(claimed.value.claim);
  });

  /**
   * Best-effort DUR-013 audit of an owned repair attempt, before it can release its claim.
   * The fixed granted epoch never borrows a later writer's authority. State-only repairs
   * omit canonical annotations; their decision and operator author/reason remain in telemetry.
   */
  const annotateRepair = (
    threadId: ThreadId,
    decision: RecoveryDecision,
    producerEpoch: ProducerEpoch,
  ): Effect.Effect<void> =>
    Effect.gen(function* () {
      yield* store.materialize(ThreadMaterialization.make({ threadId, producerEpoch }));
      const tail = yield* store.inspectTail(ThreadTailRequest.make({ threadId }));

      // ThreadCreated must remain the first canonical record of a new Thread.
      if (tail.tailSequence === ZERO_SEQUENCE) return;

      const encodedDecision = yield* Schema.encodeEffect(RecoveryDecision)(decision).pipe(
        Effect.orDie,
      );

      const details = yield* Schema.decodeEffect(PersistedJson)(encodedDecision).pipe(Effect.orDie);

      const envelope = yield* makeEnvelope(
        recoveryRepairRecordId(decision.submissionId, decision._tag),
        RepairAnnotated.make({ reason: `recovery:${decision._tag}`, details }),
      );

      yield* store.append(
        FencedAppendRequest.make({
          threadId,
          batch: CanonicalBatch.make({
            batchId: recoveryRepairBatchId(decision.submissionId, decision._tag),
            producerId: config.producerId,
            records: [envelope],
          }),
          expectedTailSequence: tail.tailSequence,
          expectedTailDigest: tail.tailDigest,
          producerEpoch,
        }),
      );
    }).pipe(Effect.ignore);

  const settleAbortedForRecovery = Effect.fn("DurableAgentRuntime.settleAbortedForRecovery")(
    function* (
      snapshot: RecoverySnapshot,
      evidence: RecoveryEvidence,
      records: ReadonlyArray<CanonicalRecordEnvelope>,
      decision: SettleAbortedDecision,
    ): Effect.fn.Return<"repaired" | "deferred", DurableWorkerFailure, Scope.Scope> {
      const intent = snapshot.abortIntent;

      if (intent === undefined) return "deferred";
      const submission = snapshot.submission;

      if (submission.state === "suspended" && snapshot.suspension !== undefined) {
        if (snapshot.suspension.reason._tag === "WaitingForChild") {
          // The classifier reaches SettleAborted only when every attached-child obligation is
          // closed (open ones route to PropagateChildAbort/ResumeWaitingParent, spec §13.1), so
          // every listed child is provably settled: replay the idempotent wake to make the
          // suspended lane claimable, then settle aborted below. A wake the adapter cannot yet
          // verify defers honestly instead of guessing.
          const woken = yield* Effect.gen(function* () {
            for (const child of snapshot.suspension?.reason._tag === "WaitingForChild"
              ? snapshot.suspension.reason.children
              : []) {
              yield* ledger.recordChildSettled(
                ChildSettledNotification.make({
                  parentSubmissionId: submission.submissionId,
                  childSubmissionId: child.childSubmissionId,
                }),
              );
            }

            return true;
          }).pipe(Effect.catchTag("LedgerError", () => Effect.succeed(false)));

          if (!woken) return "deferred";
        } else {
          // A suspended head is never worker-claimable (WP2 claim rule), so the aborted
          // settlement first closes the suspension: every undecided call of the stored reason
          // gets a durable DENIED decision, which wakes the lane (`suspended → input-applied`)
          // without ever resuming the batch — the abort intent settles the Submission before
          // any Run resumes. A raced real decision also covers the reason, so its conflict is
          // absorbed.
          const decided = new Set(
            snapshot.approvalDecisions.map((decision) => decision.toolCallId),
          );

          for (const toolCallId of snapshot.suspension.reason.toolCallIds) {
            if (decided.has(toolCallId)) continue;
            yield* ledger
              .recordApprovalDecision(
                ApprovalDecisionCommand.make({
                  submissionId: submission.submissionId,
                  toolCallId,
                  decision: "denied",
                  resolver: RECOVERY_RESOLVER,
                  reason:
                    "The Submission was aborted while durably suspended; the pending approval closes denied so the aborted settlement can commit",
                }),
              )
              .pipe(
                Effect.catchTag("ApprovalConflict", () => Effect.void),
                Effect.asVoid,
              );
          }
        }
      }
      const claimed = yield* claimFor(submission, decision);

      if (Option.isNone(claimed)) {
        // P7 §7(c): an aborted, never-claimed, still-queued `ready` Submission settles NOW
        // instead of waiting to head the lane — settlement order of never-run work is not
        // execution order (DUR-004 bounds execution; DUR-012 allows settling inactive
        // accepted work without an Attempt). The appends run at the current tail with the
        // durable abort intent as the reservation authority; any racing owner's fence
        // advance (or a concurrent joining claim) defers honestly to the next pass.
        if (submission.state === "ready" && snapshot.ownership === undefined) {
          return yield* Effect.gen(function* () {
            yield* materializeAtLeast(submission.threadId, ZERO_EPOCH);
            yield* ensureThreadCreated(
              submission.threadId,
              submission.agentId,
              submission.agentDigests,
            );
            const ctx = yield* attemptContextAtTail(submission.threadId);
            const tokenRef = yield* Ref.make(QUEUED_ABORT_SETTLEMENT_TOKEN);

            yield* settleAborted(
              ctx,
              submission,
              tokenRef,
              intent,
              evidence,
              knownRecordIdsOf(records),
            );

            return "repaired" as const;
          }).pipe(
            Effect.catchTags({
              FenceRejected: () => Effect.succeed("deferred" as const),
              AppendConflict: () => Effect.succeed("deferred" as const),
              OwnershipLost: () => Effect.succeed("deferred" as const),
            }),
          );
        }

        return "deferred";
      }
      const claim = claimed.value;

      yield* store.materialize(
        ThreadMaterialization.make({
          threadId: submission.threadId,
          producerEpoch: claim.producerEpoch,
        }),
      );
      yield* ensureThreadCreated(submission.threadId, submission.agentId, submission.agentDigests);
      const ctx = yield* attemptContextFor(submission.threadId, claim.producerEpoch);
      const tokenRef = yield* Ref.make(claim.ownershipToken);

      yield* settleAborted(ctx, submission, tokenRef, intent, evidence, knownRecordIdsOf(records));

      return "repaired";
    },
  );

  /**
   * Execute the reconcile-then-mark flow for a `MarkUnknown` decision (plan §2.2). Current
   * registration metadata checks retry support when available. Low-level drivers supply their
   * Agent at claim time, so retry proofs defer that check without permitting execution. Calls
   * without a durable intent, original idempotent declaration, or reconciler proof stay uncertain.
   * Closed calls report `repaired`; deferred checks report `deferred`; uncertain calls become Unknown.
   */
  const markUnknownForRecovery = Effect.fn("DurableAgentRuntime.markUnknownForRecovery")(function* (
    snapshot: RecoverySnapshot,
    evidence: RecoveryEvidence,
    records: ReadonlyArray<CanonicalRecordEnvelope>,
    decision: MarkUnknownDecision,
  ): Effect.fn.Return<"repaired" | "deferred" | "unknown", DurableWorkerFailure, Scope.Scope> {
    const submission = snapshot.submission;
    const claimed = yield* claimFor(submission, decision);

    if (Option.isNone(claimed)) return "deferred";
    const claim = claimed.value;

    yield* store.materialize(
      ThreadMaterialization.make({
        threadId: submission.threadId,
        producerEpoch: claim.producerEpoch,
      }),
    );
    const ctx = yield* attemptContextFor(submission.threadId, claim.producerEpoch);
    const knownIds = knownRecordIdsOf(records);
    // The classifier's decision lists ONLY ordinary open calls (S2: an open delegation call
    // never marks Unknown — its establishment is idempotent and routes through the Subagent
    // rows), so reconciliation is scoped to exactly those ids.
    const markableIds = new Set<string>(decision.openToolCallIds);

    const review = yield* reconcileOpenCalls(
      ctx,
      submission,
      snapshot,
      records,
      evidence.openToolCalls.filter((call) => markableIds.has(call.toolCallId)),
      knownIds,
      yield* currentOperationsFor(submission),
    );

    let disposition: "repaired" | "deferred" | "unknown";

    if (review.uncertain.length > 0) {
      yield* markCallsUnknown(
        ctx,
        submission.submissionId,
        knownIds,
        review.uncertain,
        decision.reason,
      );
      disposition = "unknown";
    } else if (review.unproven.length > 0 || review.retryable.length > 0) {
      disposition = "deferred";
    } else {
      disposition = "repaired";
    }
    yield* ledger
      .releaseOwnership(
        ReleaseOwnershipRequest.make({
          submissionId: submission.submissionId,
          ownershipToken: claim.ownershipToken,
        }),
      )
      .pipe(Effect.catchTag("OwnershipLost", () => Effect.void));

    return disposition;
  });

  /** A retry intent permits only the saved operation under its supported current contract. */
  const hasUnsupportedRetry = Effect.fnUntraced(function* (
    snapshot: RecoverySnapshot,
    records: ReadonlyArray<CanonicalRecordEnvelope>,
  ) {
    if (!snapshot.unknownResolutions.some((intent) => intent.resolution._tag === "SafeToRetry"))
      return false;
    const submission = snapshot.submission;
    const current = yield* currentOperationsFor(submission);
    const operations = operationsFor(records, runIdForSubmission(submission.submissionId));

    for (const intent of snapshot.unknownResolutions) {
      if (intent.resolution._tag === "SafeToRetry") {
        const prepared = records
          .map(({ record }) => record.payload)
          .find(
            (payload) =>
              payload._tag === "ToolCallPrepared" &&
              payload.runId === runIdForSubmission(submission.submissionId) &&
              payload.toolCallId === intent.toolCallId,
          );

        if (
          prepared?._tag !== "ToolCallPrepared" ||
          (current !== undefined &&
            !supportsOperation(
              submission,
              OpenToolCallEvidence.make(prepared),
              operations.get(intent.toolCallId),
              prepared,
              current,
            ))
        )
          return true;
      }
    }

    return false;
  });

  /**
   * Replay covering resolution intents as state-only wakes. Canonical outcomes wait for an
   * actual claim, so resolving an older request cannot append using a later writer's epoch.
   */
  const applyUnknownResolutionsForRecovery = Effect.fn(
    "DurableAgentRuntime.applyUnknownResolutionsForRecovery",
  )(function* (
    snapshot: RecoverySnapshot,
    _evidence: RecoveryEvidence,
    records: ReadonlyArray<CanonicalRecordEnvelope>,
  ): Effect.fn.Return<"repaired" | "deferred" | "unknown", DurableWorkerFailure> {
    if (yield* hasUnsupportedRetry(snapshot, records)) return "unknown";
    const submission = snapshot.submission;

    for (const intent of snapshot.unknownResolutions) {
      yield* ledger
        .recordUnknownResolution(
          UnknownResolutionCommand.make({
            submissionId: intent.submissionId,
            toolCallId: intent.toolCallId,
            author: intent.author,
            reason: intent.reason,
            resolution: intent.resolution,
          }),
        )
        .pipe(
          Effect.catchTag("UnknownResolutionConflict", (error) =>
            LedgerError.make({
              operation: "applyUnknownResolutions",
              message: `Replaying the stored resolution intent for ${error.toolCallId} diverged`,
              cause: error,
            }),
          ),
        );
    }
    // Canonical outcomes are applied by the next claim. A wake never takes an active epoch.
    yield* wake.notify(submission.threadId);

    return "repaired";
  });

  /**
   * Repair a lost durable suspension from canonical history (plan §2.6, crash between the
   * canonical `ToolApprovalRequested` append and the ledger `suspend` transition): the lane is
   * claimable but the Run cannot proceed without a decision, so the executor claims it and moves
   * it to `suspended` — the ledger op ends the ownership period itself — reporting `repaired`.
   * Nothing executes and nothing settles. A lane that is already suspended has nothing to
   * repair: it waits durably for the authorized `resolveApproval` path, consuming no worker
   * permit, and stays `deferred`. Decisions that raced ahead of the repair leave the lane to a
   * worker's batch resume (`deferred`).
   */
  const awaitApprovalForRecovery = Effect.fn("DurableAgentRuntime.awaitApprovalForRecovery")(
    function* (
      snapshot: RecoverySnapshot,
      evidence: RecoveryEvidence,
      decision: RecoveryDecision,
    ): Effect.fn.Return<"repaired" | "deferred", DurableWorkerFailure, Scope.Scope> {
      const submission = snapshot.submission;

      if (submission.state === "suspended") return "deferred";
      const decided = new Set(snapshot.approvalDecisions.map((decision) => decision.toolCallId));

      const undecided = evidence.approvalsPending.filter(
        (pending) => !decided.has(pending.toolCallId),
      );

      const first = undecided[0];

      if (first === undefined) return "deferred";
      const claimed = yield* claimFor(submission, decision);

      if (Option.isNone(claimed)) return "deferred";
      const claim = claimed.value;

      const outcome = yield* ledger.suspend(
        SuspendRequest.make({
          submissionId: submission.submissionId,
          ownershipToken: claim.ownershipToken,
          reason: ApprovalPendingSuspension.make({
            toolCallIds: [
              first.toolCallId,
              ...undecided.slice(1).map((pending) => pending.toolCallId),
            ],
          }),
        }),
      );

      yield* hit("approval:after-suspend");
      if (outcome === "resume-immediately") {
        // Decisions raced in between the snapshot read and the suspend transaction: nothing to
        // repair — release the claim so a worker resumes the declared batch.
        yield* ledger
          .releaseOwnership(
            ReleaseOwnershipRequest.make({
              submissionId: submission.submissionId,
              ownershipToken: claim.ownershipToken,
            }),
          )
          .pipe(Effect.catchTag("OwnershipLost", () => Effect.void));

        return "deferred";
      }

      return "repaired";
    },
  );

  /**
   * Defensive branch for a `suspended` lane whose canonical approval requests are all decided
   * (the classifier's `ResumeSuspended`). Under this coordinator the state is unreachable: the
   * covering `recordApprovalDecision` wakes the lane atomically inside the adapter (WP2), and a
   * decision racing ahead of `suspend` returns `resume-immediately` without ever suspending. The
   * executor therefore only re-hints the lane and reports `deferred`, keeping the obligation
   * visible instead of guessing at a wake the ledger port does not offer.
   */
  const resumeSuspendedForRecovery = Effect.fn("DurableAgentRuntime.resumeSuspendedForRecovery")(
    function* (snapshot: RecoverySnapshot): Effect.fn.Return<"deferred", DurableWorkerFailure> {
      yield* wake.notify(snapshot.submission.threadId);

      return "deferred";
    },
  );

  const executeRecoveryDecision = Effect.fn("DurableAgentRuntime.executeRecoveryDecision")(
    function* (
      snapshot: RecoverySnapshot,
      evidence: RecoveryEvidence,
      decision: RecoveryDecision,
      records: ReadonlyArray<CanonicalRecordEnvelope>,
      history: RecoveryHistorySnapshot,
    ): Effect.fn.Return<
      "repaired" | "deferred" | "none" | "unknown",
      DurableWorkerFailure,
      Scope.Scope
    > {
      const submission = snapshot.submission;
      const runId = runIdForSubmission(submission.submissionId);
      const start = yield* canonicalRunStartFromRecords(records, runId);

      if (
        start?.payload._tag === "RunStarted" &&
        start.payload.runId === runId &&
        (records.some(
          ({ record }) =>
            record.payload._tag === "RunDurationExhausted" && record.payload.runId === runId,
        ) ||
          (submission.workerAdmission !== undefined &&
            (yield* Clock.currentTimeMillis) >=
              submission.workerAdmission.origin.expiresAtMillis)) &&
        (decision._tag === "CompleteChildAdmission" ||
          decision._tag === "RepairSubagentStartLink" ||
          decision._tag === "AwaitChildAdmissionResolution" ||
          (decision._tag === "MarkUnknown" &&
            snapshot.childReservations.some((reservation) => reservation.status !== "released")))
      ) {
        // A closed admission window must release provably-unused reservations or restore the
        // existing child's link. Do this before ordinary Unknown Outcomes make the lane
        // unclaimable, and never let binding-free recovery admit new work after expiry.
        const claimed = yield* claimFor(submission, decision);

        if (Option.isNone(claimed)) return "deferred";
        const claim = claimed.value;

        yield* store.materialize(
          ThreadMaterialization.make({
            threadId: submission.threadId,
            producerEpoch: claim.producerEpoch,
          }),
        );
        const ctx = yield* attemptContextFor(submission.threadId, claim.producerEpoch);

        yield* reconcileRetainedChildren(ctx, submission, claim.ownershipToken);
        const open = yield* completeJoinedReleases(submission);

        yield* ledger
          .releaseOwnership(
            ReleaseOwnershipRequest.make({
              submissionId: submission.submissionId,
              ownershipToken: claim.ownershipToken,
            }),
          )
          .pipe(Effect.catchTag("OwnershipLost", () => Effect.void));

        return open ? "deferred" : "repaired";
      }
      switch (decision._tag) {
        case "NoAction": {
          return "none";
        }
        case "ResumeFromTurnBoundary":
        case "ResumePendingToolBatch": {
          // Resumption needs the Agent Binding: a claiming worker resumes from the committed
          // boundary (the declared batch resumes without model re-invocation, durability §15).
          return "deferred";
        }
        case "MarkUnknown": {
          return yield* markUnknownForRecovery(snapshot, evidence, records, decision);
        }
        case "ApplyUnknownResolutions": {
          return yield* applyUnknownResolutionsForRecovery(snapshot, evidence, records);
        }
        case "AwaitUnknownResolution": {
          // This Submission stays parked awaiting the authorized DUR-017 resolution path;
          // the settlement obligation stays visible, nothing replays.
          return "unknown";
        }
        case "AwaitApprovalDecision": {
          return yield* awaitApprovalForRecovery(snapshot, evidence, decision);
        }
        case "ResumeSuspended": {
          return yield* resumeSuspendedForRecovery(snapshot);
        }
        case "RevertJoining": {
          // `joining` without a canonical `input:{sid}` record: the host never consumed the
          // input, so the claim returns to ready and is delivered exactly once later
          // (DUR-016). Ownership-free by contract; the wake hint reopens the lane.
          yield* ledger.revertJoining(
            RevertJoiningRequest.make({ submissionId: submission.submissionId }),
          );
          yield* wake.notify(submission.threadId);

          return "repaired";
        }
        case "RepairJoinMarker": {
          const hostSubmissionId = snapshot.hostSubmissionId;

          if (hostSubmissionId === undefined) return "deferred";

          const inputEnvelope = records.find(
            (envelope) =>
              envelope.record.recordId === submissionInputRecordId(submission.submissionId),
          );

          if (inputEnvelope === undefined) return "deferred";
          if (evidence.hostSettlementOutcome !== undefined) {
            // The host settled while the marker was lost, so no host ownership can ever repair
            // it. The coverage rule decides honestly (DUR-016): an uncovered input was never
            // consumed by the host and returns to ready to run as its own Run (the canonical
            // `input:{sid}` record reattaches through the ordinary input-marker repair); a
            // covered-but-unmarked input is unreachable under this coordinator (`markJoined`
            // always precedes delivery), so it stays visible instead of being guessed at.
            if (!evidence.joinedInputCovered) {
              yield* ledger.revertJoining(
                RevertJoiningRequest.make({ submissionId: submission.submissionId }),
              );
              yield* wake.notify(submission.threadId);

              return "repaired";
            }

            return "deferred";
          }

          // `markJoined` is fenced by the HOST lane's ownership: claim the host head, repair
          // the marker from history (DUR-015), and release. A live host defers to that host's
          // own drain-seam repair.
          const host = yield* ledger.lookup(
            SubmissionLookupById.make({ submissionId: hostSubmissionId }),
          );

          if (Option.isNone(host)) return "deferred";
          const claimed = yield* claimFor(host.value, decision);

          if (Option.isNone(claimed)) return "deferred";
          const claim = claimed.value;

          yield* ledger.markJoined(
            MarkJoinedRequest.make({
              submissionId: submission.submissionId,
              ownershipToken: claim.ownershipToken,
              recordId: inputEnvelope.record.recordId,
              sequence: inputEnvelope.sequence,
            }),
          );
          yield* ledger
            .releaseOwnership(
              ReleaseOwnershipRequest.make({
                submissionId: hostSubmissionId,
                ownershipToken: claim.ownershipToken,
              }),
            )
            .pipe(Effect.catchTag("OwnershipLost", () => Effect.void));
          yield* wake.notify(submission.threadId);

          return "repaired";
        }
        case "SettleJoinedWithHost": {
          const hostSubmissionId = snapshot.hostSubmissionId;

          if (hostSubmissionId === undefined) return "deferred";
          const hostRecord = yield* canonicalSettlementRecord(records, hostSubmissionId);
          const hostSettlement = yield* settlementPayloadFromRecord(hostRecord, hostSubmissionId);
          // The host settled canonically, so no live owner can exist for this lane (a joined
          // head is never claimable): the joined settlement completes unfenced at the current
          // tail, deferring to any racing fence advance.
          const ctx = yield* attemptContextAtTail(submission.threadId);

          const applied = yield* settleOneJoined(ctx, hostSettlement, snapshot).pipe(
            Effect.as(true),
            Effect.catchTag("FenceRejected", () => Effect.succeed(false)),
          );

          return applied ? "repaired" : "deferred";
        }
        case "AwaitHostSettlement": {
          // The joined input reattaches through the host Run's resume (prompt-coverage rule);
          // hint the shared lane and keep the obligation visible.
          yield* wake.notify(submission.threadId);

          return "deferred";
        }
        case "CompleteMaterialization":
        case "RepairReadiness": {
          yield* materializeAtLeast(submission.threadId, ZERO_EPOCH);
          yield* ensureThreadCreated(
            submission.threadId,
            submission.agentId,
            submission.agentDigests,
          );
          if (submission.workerAdmission !== undefined) {
            yield* workerRuntime
              .ensureOrigin(submission.workerAdmission.origin)
              .pipe(
                Effect.mapError((cause) =>
                  LedgerError.make({ operation: "worker-origin", message: cause.reason, cause }),
                ),
              );
          }
          yield* ledger.markReady(MarkReadyRequest.make({ submissionId: submission.submissionId }));

          return "repaired";
        }
        case "ApplyInput":
        case "RepairInputMarker": {
          const claimed = yield* claimFor(submission, decision);

          if (Option.isNone(claimed)) return "deferred";
          const claim = claimed.value;

          yield* store.materialize(
            ThreadMaterialization.make({
              threadId: submission.threadId,
              producerEpoch: claim.producerEpoch,
            }),
          );
          yield* ensureThreadCreated(
            submission.threadId,
            submission.agentId,
            submission.agentDigests,
          );
          const ctx = yield* attemptContextFor(submission.threadId, claim.producerEpoch);
          const tokenRef = yield* Ref.make(claim.ownershipToken);

          const currentRecords = yield* refreshRecoveryHistory(
            submission.threadId,
            records,
            history.throughSequence,
            history.submissionIds,
          );

          yield* applyCanonicalInput(
            ctx,
            submission,
            tokenRef,
            currentRecords,
            snapshot.inputApplied,
          );
          const ownershipToken = yield* Ref.get(tokenRef);

          yield* ledger
            .releaseOwnership(
              ReleaseOwnershipRequest.make({
                submissionId: submission.submissionId,
                ownershipToken,
              }),
            )
            .pipe(Effect.catchTag("OwnershipLost", () => Effect.void));

          return "repaired";
        }
        case "AppendReservedSettlement": {
          const reservation = snapshot.reservation;

          if (reservation === undefined) return "deferred";
          const claimed = yield* claimFor(submission, decision);

          if (Option.isNone(claimed)) {
            // P7 §7(c) crash replay: a queued-abort settlement that committed its reservation
            // but lost the append/finalize completes at the current tail — the aborted,
            // never-claimed row still holds no live ownership, so no claim can ever exist
            // for it while it stays queued behind the head.
            if (
              reservation.outcome === "aborted" &&
              snapshot.abortIntent !== undefined &&
              snapshot.ownership === undefined
            ) {
              const ctx = yield* attemptContextAtTail(submission.threadId);

              return yield* completeReservation(
                ctx,
                submission,
                reservation,
                evidence.recordedSettlementOutcome !== undefined,
              ).pipe(
                Effect.as("repaired" as const),
                Effect.catchTags({
                  FenceRejected: () => Effect.succeed("deferred" as const),
                  AppendConflict: () => Effect.succeed("deferred" as const),
                }),
              );
            }

            return "deferred";
          }
          const claim = claimed.value;

          yield* store.materialize(
            ThreadMaterialization.make({
              threadId: submission.threadId,
              producerEpoch: claim.producerEpoch,
            }),
          );
          const ctx = yield* attemptContextFor(submission.threadId, claim.producerEpoch);

          yield* completeReservation(
            ctx,
            submission,
            reservation,
            evidence.recordedSettlementOutcome !== undefined,
          );

          return "repaired";
        }
        case "FinalizeLedgerFromHistory": {
          const record = yield* canonicalSettlementRecord(records, submission.submissionId);

          yield* finalizeFromHistory(submission, record);

          return "repaired";
        }
        case "SettleAborted": {
          return yield* settleAbortedForRecovery(snapshot, evidence, records, decision);
        }
        case "CompleteChildAdmission": {
          // Binding-free (D3): the canonical `SubagentRequested` payload carries the encoded
          // child input, intended identity, and every digest, so admission completes without a
          // live delegation handler — one child, same Receipt on every replay (SUB-016).
          const subagent = subagentRecordsOf(records, runIdForSubmission(submission.submissionId));
          const requestedPayload = subagent.requested.get(decision.toolCallId);

          if (requestedPayload === undefined) return "deferred";
          const admission = yield* establishChildFromRequest(submission, requestedPayload);

          return admission._tag === "indeterminate" ? "deferred" : "repaired";
        }
        case "RepairSubagentStartLink": {
          // Resolve the SAME child by its deterministic idempotency key, complete any missing
          // materialization/lineage/readiness, then append the exact deterministic
          // `SubagentStarted` link and reattach the reservation under the parent fence
          // (spec §13, SUB-016/SUB-017).
          const runId = runIdForSubmission(submission.submissionId);
          const subagent = subagentRecordsOf(records, runId);
          const requestedPayload = subagent.requested.get(decision.toolCallId);

          if (requestedPayload === undefined) return "deferred";
          const admission = yield* establishChildFromRequest(submission, requestedPayload);

          if (admission._tag === "indeterminate") return "deferred";
          const claimed = yield* claimFor(submission, decision);

          if (Option.isNone(claimed)) return "deferred";
          const claim = claimed.value;

          yield* store.materialize(
            ThreadMaterialization.make({
              threadId: submission.threadId,
              producerEpoch: claim.producerEpoch,
            }),
          );
          const ctx = yield* attemptContextFor(submission.threadId, claim.producerEpoch);
          const knownIds = knownRecordIdsOf(records);
          const startRecordId = subagentStartedRecordId(runId, decision.toolCallId);

          if (!knownIds.has(startRecordId)) {
            const envelope = yield* makeEnvelope(
              startRecordId,
              SubagentStarted.make({
                runId,
                toolCallId: decision.toolCallId,
                childThreadId: requestedPayload.childThreadId,
                childSubmissionId: admission.childSubmissionId,
                childReceiptId: admission.receiptId,
                childRunId: runIdForSubmission(admission.childSubmissionId),
              }),
            );

            yield* appendBatch(
              ctx,
              CanonicalBatch.make({
                batchId: subagentStartedBatchId(runId, decision.toolCallId),
                producerId: config.producerId,
                records: [envelope],
              }),
            ).pipe(
              Effect.catchTag("AppendConflict", () => Effect.void),
              Effect.asVoid,
            );
            yield* hit("subagent:after-start-append");
          }
          yield* ledger
            .attachChildToReservation(
              AttachChildToReservationRequest.make({
                reservationId: decodeChildReservationIdSync(requestedPayload.reservationId),
                ownershipToken: claim.ownershipToken,
                childSubmissionId: admission.childSubmissionId,
              }),
            )
            .pipe(
              Effect.catchTag(
                "ChildReservationConflict",
                conflictToLedgerError("attachChildToReservation"),
              ),
            );
          yield* ledger
            .releaseOwnership(
              ReleaseOwnershipRequest.make({
                submissionId: submission.submissionId,
                ownershipToken: claim.ownershipToken,
              }),
            )
            .pipe(Effect.catchTag("OwnershipLost", () => Effect.void));
          yield* wake.notify(requestedPayload.childThreadId);
          yield* wake.notify(submission.threadId);

          return "repaired";
        }
        case "EnsureWaitingForChild": {
          // Restore the lost `waitingForChild` checkpoint (spec §14 "after parent start, before
          // waitingForChild checkpoint"): claim the lane and suspend it — the ledger op ends the
          // ownership period itself, so the lane holds no worker permit while each child runs
          // on its own lane. Never spawns a replacement invocation (SUB-018/SUB-030).
          const claimed = yield* claimFor(submission, decision);

          if (Option.isNone(claimed)) return "deferred";
          const claim = claimed.value;

          const suspension = yield* ledger.suspend(
            SuspendRequest.make({
              submissionId: submission.submissionId,
              ownershipToken: claim.ownershipToken,
              reason: WaitingForChildSuspension.make({ children: decision.children }),
            }),
          );

          yield* hit("subagent:after-suspend");
          if (suspension === "resume-immediately") {
            // Every listed child already settled: leave the joins to a claiming worker's batch
            // resume (they need the parent Binding and its result projection).
            yield* ledger
              .releaseOwnership(
                ReleaseOwnershipRequest.make({
                  submissionId: submission.submissionId,
                  ownershipToken: claim.ownershipToken,
                }),
              )
              .pipe(Effect.catchTag("OwnershipLost", () => Effect.void));

            return "deferred";
          }

          return "repaired";
        }
        case "ResumeWaitingParent": {
          // Every relevant child is provably settled: replay the idempotent ownership-free wake
          // (a dropped wake is never a lost obligation) so a claiming worker resumes the
          // declared batch and joins each child's canonical Settlement (spec §13).
          for (const child of decision.children) {
            yield* ledger.recordChildSettled(
              ChildSettledNotification.make({
                parentSubmissionId: submission.submissionId,
                childSubmissionId: child.childSubmissionId,
              }),
            );
          }
          yield* wake.notify(submission.threadId);

          return "repaired";
        }
        case "ApplyJoinAccounting": {
          // Budget release incomplete after a canonical join: replay the accounting decision
          // FROM the canonical `SubagentJoined` record — budget stays unavailable until repair,
          // never available twice (spec §12 join step 6, DUR-015).
          const reservation = snapshot.childReservations.find(
            (row) => row.reservationId === decision.reservationId,
          );

          if (reservation === undefined) return "deferred";
          if (reservation.status === "released") return "repaired";
          const subagent = subagentRecordsOf(records, runIdForSubmission(submission.submissionId));
          const joinedPayload = subagent.joined.get(decision.toolCallId);

          if (joinedPayload !== undefined) {
            yield* applyReservationRelease(decision.reservationId, joinedPayload.finalAccounting);

            return "repaired";
          }
          if (reservation.status === "releasePending" && reservation.accounting !== undefined) {
            // The decision is already frozen: finish the idempotent release — never re-freeze.
            yield* applyReservationRelease(decision.reservationId, reservation.accounting);

            return "repaired";
          }

          return "deferred";
        }
        case "PropagateChildAbort": {
          // Request-abort-and-join (spec §13.1): the ONE idempotent durable abort command per
          // nonterminal child — the recorded child `AbortIntent` row IS the propagation marker,
          // so the replayed command returns it unchanged (DUR-012) — while the parent stays (or
          // becomes) suspended `waitingForChild` for the joins.
          for (const child of decision.children) {
            yield* ledger
              .requestAbort(
                AbortCommand.make({
                  submissionId: child.childSubmissionId,
                  author: SUBAGENT_ABORT_AUTHOR,
                  reason: SUBAGENT_ABORT_REASON,
                }),
              )
              .pipe(
                // The child settled concurrently: its one winning Settlement joins next pass.
                Effect.catchTags({
                  SettlementConflict: () => Effect.void,
                  JoinedToHost: conflictToLedgerError("PropagateChildAbort"),
                }),
                Effect.asVoid,
              );
            yield* hit("subagent:after-child-abort-intent");

            const childRow = yield* ledger.lookup(
              SubmissionLookupById.make({ submissionId: child.childSubmissionId }),
            );

            if (Option.isSome(childRow)) {
              yield* wake.notify(childRow.value.threadId);
            }
          }
          if (submission.state !== "suspended") {
            const claimed = yield* claimFor(submission, decision);

            if (Option.isNone(claimed)) return "deferred";
            const claim = claimed.value;

            const suspension = yield* ledger.suspend(
              SuspendRequest.make({
                submissionId: submission.submissionId,
                ownershipToken: claim.ownershipToken,
                reason: WaitingForChildSuspension.make({ children: decision.children }),
              }),
            );

            yield* hit("subagent:after-suspend");
            if (suspension === "resume-immediately") {
              // Every child settled while suspending: the next pass joins the winners.
              yield* ledger
                .releaseOwnership(
                  ReleaseOwnershipRequest.make({
                    submissionId: submission.submissionId,
                    ownershipToken: claim.ownershipToken,
                  }),
                )
                .pipe(Effect.catchTag("OwnershipLost", () => Effect.void));
            }
          }

          return "repaired";
        }
        case "ReleaseOrphanChildReservation": {
          // Provably childless reservations release exactly once (spec §13/§14): freeze the
          // deterministic zero-consumed decision, then apply it idempotently.
          for (const reservationId of decision.reservationIds) {
            yield* releaseOrphanReservation(reservationId);
          }

          return "repaired";
        }
        case "AwaitChildAdmissionResolution": {
          // Wait-and-retry (SUB-031): the evidence assembler re-queries the authoritative owner
          // with the deterministic idempotency key on every recovery pass; an indeterminate
          // answer never permits a second admission and holds no worker permit.
          return "deferred";
        }
        case "AwaitChildSettlement": {
          // The parent lane stays dormant `waitingForChild` (SUB-030): the child's Settlement
          // wakes it durably through `recordChildSettled`; an unresolved ordinary Tool inside
          // the child keeps the parent here honestly with the obligation visible (SUB-021).
          return "deferred";
        }
        case "AwaitParentEstablishment": {
          // The child lane defers its own materialization/readiness repair until the
          // parent's idempotent establishment appends the immutable lineage record — a child
          // never runs a Turn before its lineage is canonical. A droppable wake hint nudges the
          // parent lane, whose own recovery re-drives establishment (CompleteChildAdmission /
          // RepairSubagentStartLink); the deterministic child identity makes every replay
          // converge on this one child (SUB-016).
          const parent = yield* ledger.lookup(
            SubmissionLookupById.make({ submissionId: decision.parentSubmissionId }),
          );

          if (Option.isSome(parent)) {
            yield* wake.notify(parent.value.threadId);
          }

          return "deferred";
        }
      }
    },
  );

  const recoverSnapshot = Effect.fn("DurableAgentRuntime.recoverSnapshot")(function* (
    submission: SubmissionSnapshot,
    history: RecoveryHistorySnapshot,
  ): Effect.fn.Return<RecoveryReport, DurableWorkerFailure> {
    const snapshot = yield* ledger.loadRecoverySnapshot(
      RecoverySnapshotRequest.make({ submissionId: submission.submissionId }),
    );

    // A racing steering link can name a host outside the pass's nonterminal group. Read that
    // host from the same verified prefix, without changing this snapshot's visibility.
    if (
      snapshot.hostSubmissionId !== undefined &&
      !history.submissionIds.includes(snapshot.hostSubmissionId)
    ) {
      const hostId = snapshot.hostSubmissionId;
      const hostView = yield* recoveryView(submission.threadId, history.throughSequence, [hostId]);

      const hostRecords = yield* Stream.runCollect(
        hostView.canonical.pipe(Stream.filter(controlRecords([hostId]))),
      );

      const merged = new Map(history.records.map((entry) => [entry.sequence, entry]));

      for (const entry of hostRecords) merged.set(entry.sequence, entry);
      history = {
        ...history,
        records: [...merged.values()].sort((left, right) => left.sequence - right.sequence),
        submissionIds: [...history.submissionIds, snapshot.hostSubmissionId],
      };
    }

    const evidence = yield* evidenceFor(
      history.records,
      submission.submissionId,
      history.materialized,
      snapshot.hostSubmissionId,
    );

    const decision = classifyRecovery(snapshot, evidence);

    // Untouched ready input belongs to the worker's first claim. Running attempts and
    // canonical appends with a missing marker still take their classified repair path.
    const disposition =
      decision._tag === "ApplyInput" && snapshot.submission.state === "ready"
        ? "deferred"
        : yield* Effect.scoped(
            executeRecoveryDecision(snapshot, evidence, decision, history.records, history),
          );

    return RecoveryReport.make({
      submissionId: submission.submissionId,
      threadId: submission.threadId,
      decision,
      disposition,
    });
  });

  const recoverSubmission = Effect.fn("DurableAgentRuntime.recoverSubmission")(function* (
    submissionId: SubmissionId,
  ): Effect.fn.Return<RecoveryReport, DurableWorkerFailure> {
    const found = yield* ledger.lookup(SubmissionLookupById.make({ submissionId }));

    if (Option.isNone(found)) {
      return yield* LedgerError.make({
        operation: "recoverSubmission",
        message: `Unknown Submission ${submissionId}`,
      });
    }

    if (found.value.state === "settled")
      yield* workerRuntime.completeInput(found.value).pipe(
        Effect.mapError((cause) =>
          LedgerError.make({
            operation: "recoverSubmission",
            message: "Worker completion repair failed",
            cause,
          }),
        ),
      );
    const history = yield* readRecoveryHistory(found.value.threadId, [submissionId]);

    if (history.materialized && found.value.workerAdmission?.origin.reporting?.mode === "standard")
      yield* updateRuntime.repair(found.value.threadId);

    return yield* recoverSnapshot(found.value, history);
  });

  const runRecovery = Effect.fn("DurableAgentRuntime.runRecovery")(function* (
    options?: RecoverySweepOptions,
  ): Effect.fn.Return<RecoverySweepResult, DurableWorkerFailure> {
    const nonterminal = yield* Stream.runCollect(ledger.scanNonterminal);
    const reports: Array<RecoveryReport> = [];
    const blocked: Array<RecoveryBlocked> = [];
    // SubmissionLedger guarantees `(threadId, queueSequence)` order. Capture and retain
    // one verified canonical prefix only for the current contiguous Thread group: read
    // work is one tail inspection plus `ceil(passStartTail / READ_PAGE)` pages per Thread
    // rather than multiplied by its nonterminal Submission count, and the prefix becomes
    // unreachable before the next Thread is read.
    let index = 0;

    while (index < nonterminal.length) {
      const first = nonterminal[index];

      if (first === undefined) break;
      const submissionIds: Array<SubmissionId> = [];

      for (let offset = index; offset < nonterminal.length; offset += 1) {
        const entry = nonterminal[offset];

        if (entry === undefined || entry.threadId !== first.threadId) break;
        submissionIds.push(entry.submissionId);
      }

      index += submissionIds.length;
      if (options?.threadId !== undefined && options.threadId !== first.threadId) continue;
      let phase: RecoveryFailure["phase"] = "recovery";

      // A retained record or child read can fail before any new Attempt exists. Isolate the
      // entire Thread: a partial repair never grants a later head permission to run through
      // incomplete evidence. Scope/timeout release resources before the next Thread starts.
      const outcome = yield* isolateRecovery(
        Effect.gen(function* () {
          // The worklist contains only control state. Retained input/worker metadata belongs
          // to this Thread's failure boundary, never to global discovery or fresh admission.
          const group = yield* Effect.forEach(submissionIds, (submissionId) =>
            lookupKnownSubmission("recover submission", submissionId),
          );

          phase = "history";
          const history = yield* readRecoveryHistory(first.threadId, submissionIds);

          phase = "recovery";
          if (
            history.materialized &&
            group.some((row) => row.workerAdmission?.origin.reporting?.mode === "standard")
          )
            yield* updateRuntime.repair(first.threadId);

          return yield* Effect.forEach(group, (submission) => recoverSnapshot(submission, history));
        }),
        { timeout: config.recoveryTimeout, phase: () => phase },
      );

      if (Result.isSuccess(outcome)) reports.push(...outcome.success);
      else
        blocked.push(RecoveryBlocked.make({ threadId: first.threadId, failure: outcome.failure }));
    }

    return RecoverySweepResult.make({ reports, blocked });
  });

  const submit = Effect.fn("DurableAgentRuntime.submit")(function* <InputSchema extends Schema.Top>(
    agent: DurableSubmitAgent<InputSchema>,
    input: InputSchema["Type"],
    options: DurableSubmitOptions,
  ): Effect.fn.Return<Receipt, DurableSubmitFailure, InputSchema["EncodingServices"]> {
    const encodedInput = yield* Schema.encodeEffect(agent.definition.input)(input).pipe(
      Effect.mapError((cause) =>
        AgentInputError.make({ message: `Unable to encode Agent input: ${cause.message}` }),
      ),
    );

    const inputPayload = yield* Schema.decodeUnknownEffect(PersistedJson)(encodedInput).pipe(
      Effect.mapError(() =>
        AgentInputError.make({
          message: "Agent input does not satisfy the canonical persistence bounds",
        }),
      ),
    );

    const inputDigest = yield* withCrypto(digestJson(inputPayload));

    const workerAdmission =
      options.workerAdmission === undefined
        ? undefined
        : yield* workerRuntime
            .validateAdmission(
              options.workerAdmission,
              options,
              agent.definition.id,
              inputDigest,
              inputPayload,
            )
            .pipe(
              Effect.mapError((cause) =>
                AdmissionPolicyError.make({
                  reason:
                    cause.reason === "storage" || cause.reason === "unavailable"
                      ? "unavailable"
                      : cause.reason === "capacity" &&
                          cause.retryable === true &&
                          Schema.is(FrameworkMessage)(options.messageAdmission)
                        ? "occupied"
                        : "refused",
                  code: `worker-${cause.reason}`,
                  cause,
                }),
              ),
            );

    const pendingMessage = options.messageAdmission;

    const messageAdmission =
      pendingMessage === undefined
        ? undefined
        : yield* Effect.suspend((): Effect.Effect<InputMessage, MessagingError | WorkerError> =>
            Schema.is(MessageAdmission)(pendingMessage)
              ? messagingRuntime.validateAdmission(
                  pendingMessage,
                  options,
                  agent.definition.id,
                  inputDigest,
                )
              : workerRuntime.validateCompletion(
                  pendingMessage,
                  options,
                  agent.definition.id,
                  inputDigest,
                ),
          ).pipe(
            Effect.mapError((cause) =>
              AdmissionPolicyError.make({
                reason:
                  cause.reason === "storage" || cause.reason === "unavailable"
                    ? "unavailable"
                    : "refused",
                code: `message-${cause.reason}`,
                cause,
              }),
            ),
          );

    // Replay metadata is registration authority, never a caller's compatibility assertion.
    // Frozen native deliveries already proved their original envelope above. Root retries may
    // reuse only the original row; a new root must name a host-owned contract.
    if (
      options.definitions.replay !== undefined &&
      workerAdmission === undefined &&
      messageAdmission === undefined &&
      !registeredBindings.some(
        (binding) =>
          binding.agentId === agent.definition.id &&
          definitionDigestsEqual(binding.digests, options.definitions),
      )
    ) {
      const retained = yield* ledger.lookup(
        SubmissionLookupByKey.make({
          threadId: options.threadId,
          principal: options.principal,
          idempotencyKey: options.idempotencyKey,
        }),
      );

      if (
        Option.isNone(retained) ||
        retained.value.agentId !== agent.definition.id ||
        !definitionDigestsEqual(retained.value.agentDigests, options.definitions)
      )
        return yield* AdmissionPolicyError.make({
          reason: "refused",
          code: "unregistered-replay-contract",
        });
    }

    const request = yield* Schema.decodeEffect(AdmissionRequest)({
      threadId: options.threadId,
      principal: options.principal,
      idempotencyKey: options.idempotencyKey,
      ...(options.admissionGroup === undefined ? {} : { admissionGroup: options.admissionGroup }),
      ...(options.admissionFence === undefined ? {} : { admissionFence: options.admissionFence }),
      agentId: agent.definition.id,
      agentDigests: options.definitions,
      deploymentId: config.deploymentId,
      inputPayload,
      inputDigest,
      ...(workerAdmission === undefined
        ? {}
        : {
            workerAdmission: yield* Schema.encodeEffect(WorkerAdmission)(workerAdmission).pipe(
              Effect.mapError(() =>
                LedgerError.make({
                  operation: "submit",
                  message: "Worker admission cannot be encoded",
                }),
              ),
            ),
          }),
      ...(messageAdmission === undefined ? {} : { messageAdmission }),
    }).pipe(
      Effect.mapError(() =>
        LedgerError.make({
          operation: "submit",
          message: "Admission fields do not satisfy the ledger contract",
        }),
      ),
    );

    if (workerAdmission !== undefined) {
      const admitted = yield* workerAdmissionPort
        .admit(
          WorkerAdmissionRequest.make({
            ...request,
            workerAdmission,
            producerId: config.producerId,
          }),
        )
        .pipe(
          Effect.provideService(SubmissionLedger, ledger),
          Effect.provideService(ThreadStore, store),
          Effect.provideService(WakeScheduler, wake),
          Effect.provideService(DurableRuntimeFailpoint, failpoint),
        );

      return Receipt.make({
        receiptId: admitted.receiptId,
        submissionId: admitted.submissionId,
        threadId: request.threadId,
        queueSequence: admitted.queueSequence,
      });
    }
    const admitted = yield* ledger.admit(request);

    yield* hit("submit:after-admit");

    const receipt = Receipt.make({
      receiptId: admitted.receiptId,
      submissionId: admitted.submissionId,
      threadId: options.threadId,
      queueSequence: admitted.queueSequence,
    });

    // A replay of an already-ready Submission resumes by returning the original Receipt;
    // an admitted-but-not-ready Submission (ours or a crashed predecessor's) is completed here.
    if (admitted.replayed && admitted.state !== "admitted") {
      return receipt;
    }
    yield* materializeAtLeast(options.threadId, ZERO_EPOCH);
    yield* ensureThreadCreated(options.threadId, agent.definition.id, options.definitions);
    yield* hit("submit:after-materialize");
    yield* ledger.markReady(MarkReadyRequest.make({ submissionId: admitted.submissionId }));
    yield* wake.notify(options.threadId);

    return receipt;
  });

  const authorizeSettlement = (receipt: Receipt) =>
    operationAuthorizer.authorize(
      OperationAuthorizationRequest.make({
        operation: "awaitSettlement",
        threadId: receipt.threadId,
        submissionId: receipt.submissionId,
      }),
    );

  const submitRegistered = Effect.fn("DurableAgentRuntime.submitRegistered")(function* <
    InputSchema extends Schema.Top,
  >(
    agent: DurableSubmitAgent<InputSchema>,
    input: InputSchema["Type"],
    options: Omit<DurableSubmitOptions, "definitions">,
  ) {
    const binding = yield* resolveDefinitionBinding(registeredBindings, agent.definition);

    return yield* submit(agent, input, { ...options, definitions: binding.digests });
  });

  const readSubmissionStatus = Effect.fn("DurableAgentRuntime.readSubmissionStatus")(function* (
    receipt: Receipt,
  ): Effect.fn.Return<SubmissionStatus, DurableAwaitFailure> {
    const snapshot = yield* ledger.lookup(
      SubmissionLookupById.make({ submissionId: receipt.submissionId }),
    );

    if (Option.isNone(snapshot)) {
      return yield* LedgerError.make({
        operation: "awaitSettlement",
        message: `Unknown Submission ${receipt.submissionId}`,
      });
    }
    if (
      snapshot.value.threadId !== receipt.threadId ||
      snapshot.value.receiptId !== receipt.receiptId ||
      snapshot.value.queueSequence !== receipt.queueSequence
    ) {
      return yield* OperationDenied.make({
        operation: "awaitSettlement",
        reason: "Receipt does not match the authorized Submission",
        threadId: receipt.threadId,
        submissionId: receipt.submissionId,
      });
    }
    if (snapshot.value.state !== "settled") return PendingSubmission.make({});

    // Finalization replay reads the canonical outcome without changing settledAt.
    const settlement = yield* ledger.finalizeSettlement(
      SettlementFinalization.make({
        submissionId: receipt.submissionId,
        settlementId: submissionSettlementId(receipt.submissionId),
      }),
    );

    const recovery = yield* ledger.loadRecoverySnapshot(
      RecoverySnapshotRequest.make({ submissionId: receipt.submissionId }),
    );

    return SettledSubmission.make({
      settlement: materializeSettlement(settlement, recovery.reservation?.record),
    });
  });

  const submissionStatus = Effect.fn("DurableAgentRuntime.submissionStatus")(function* (
    receipt: Receipt,
  ): Effect.fn.Return<SubmissionStatus, DurableAwaitFailure> {
    yield* authorizeSettlement(receipt);

    return yield* readSubmissionStatus(receipt);
  });

  const settlementRecord = Effect.fn("DurableAgentRuntime.settlementRecord")(function* (
    receipt: Receipt,
  ) {
    yield* authorizeSettlement(receipt);
    const status = yield* readSubmissionStatus(receipt);

    if (status._tag !== "settled") {
      return yield* LedgerError.make({
        operation: "settlementRecord",
        message: "Submission has not settled",
      });
    }

    const snapshot = yield* ledger.loadRecoverySnapshot(
      RecoverySnapshotRequest.make({ submissionId: receipt.submissionId }),
    );

    if (snapshot.reservation === undefined) {
      return yield* LedgerError.make({
        operation: "settlementRecord",
        message: "Settlement has no canonical reservation",
      });
    }

    const record = yield* settlementPayloadFromRecord(
      snapshot.reservation.record,
      receipt.submissionId,
    );

    if (
      record.receiptId !== receipt.receiptId ||
      record.settlementId !== status.settlement.settlementId ||
      record.outcome !== status.settlement.outcome
    ) {
      return yield* LedgerError.make({
        operation: "settlementRecord",
        message: "Canonical Settlement disagrees with the receipt or finalized outcome",
      });
    }

    return record;
  });

  const awaitSettlement = Effect.fn("DurableAgentRuntime.awaitSettlement")(function* (
    receipt: Receipt,
  ): Effect.fn.Return<Settlement, DurableAwaitFailure> {
    // Authorization lasts for this wait, as it does for one observe subscription.
    yield* authorizeSettlement(receipt);
    while (true) {
      const status = yield* Effect.scoped(
        Effect.gen(function* () {
          // Register before reading the ledger so settlement between the read and
          // parking cannot be lost. Hints never replace the authoritative re-read.
          const awaitHint = yield* wake.subscribe(receipt.threadId);
          const status = yield* readSubmissionStatus(receipt);

          if (status._tag !== "settled")
            yield* Effect.raceFirst(awaitHint, Effect.sleep(config.settlementPollInterval));

          return status;
        }),
      );

      if (status._tag === "settled") return status.settlement;
    }
  });

  const awaitProgress = Effect.fn("DurableAgentRuntime.awaitProgress")(function* (
    threadId: ThreadId,
    afterSequence: CanonicalSequence,
  ): Effect.fn.Return<void, DurableProgressFailure> {
    yield* operationAuthorizer.authorize(
      OperationAuthorizationRequest.make({
        operation: "observe",
        threadId,
      }),
    );
    yield* Effect.scoped(
      Effect.gen(function* () {
        // Registration MUST precede the authoritative read. A notify between this acquisition
        // and parking completes the returned one-shot Effect, so neither subscribe/check nor
        // check/park can lose progress.
        const awaitHint = yield* wake.subscribe(threadId);

        const committed = yield* Stream.runHead(
          store.read(
            ThreadRead.make({
              threadId,
              afterSequence,
              limit: 1,
            }),
          ),
        );

        if (Option.isSome(committed)) return;
        // A wake is only a hint. The caller re-reads canonical records after this returns.
        yield* awaitHint;
      }),
    );
  });

  const observe = (receipt: Receipt, options?: DurableObserveOptions) =>
    Stream.unwrap(
      operationAuthorizer
        .authorize(
          OperationAuthorizationRequest.make({
            operation: "observe",
            threadId: receipt.threadId,
            submissionId: receipt.submissionId,
          }),
        )
        .pipe(
          Effect.as(
            store.observe(
              ThreadObservation.make({
                threadId: receipt.threadId,
                ...(options?.after === undefined ? {} : { afterOffset: options.after }),
              }),
            ),
          ),
        ),
    );

  const abort = Effect.fn("DurableAgentRuntime.abort")(function* (
    command: AbortCommand,
  ): Effect.fn.Return<AbortIntent, DurableAbortFailure> {
    yield* operationAuthorizer.authorize(
      OperationAuthorizationRequest.make({
        operation: "abort",
        submissionId: command.submissionId,
      }),
    );
    const intent = yield* ledger.requestAbort(command);

    yield* hit("abort:after-intent");

    const snapshot = yield* ledger.lookup(
      SubmissionLookupById.make({ submissionId: command.submissionId }),
    );

    if (Option.isSome(snapshot)) {
      yield* wake.notify(snapshot.value.threadId);
    }

    return intent;
  });

  /**
   * DUR-017 resolution surface (abort-shaped, plan §2.2): the durable ledger intent commits
   * first; the canonical `ToolCallResolved` (+ `ToolCallSettled` for a recovered result) is
   * appended by the recovery pass or the next owning Attempt. An `AbortSubmission` resolution
   * routes into the existing abort path — the unknown calls stay recorded and abort never
   * asserts external rollback (durability §13). Possession of this service plus the mandatory
   * author/reason audit fields is the Phase 5 authorization boundary, identical to `abort`; the
   * authenticated operator surface is a P7 deliverable.
   */
  const resolveUnknown = Effect.fn("DurableAgentRuntime.resolveUnknown")(function* (
    command: UnknownResolutionCommand,
  ): Effect.fn.Return<UnknownResolutionIntent, DurableResolveFailure | OperationDenied> {
    yield* operationAuthorizer.authorize(
      OperationAuthorizationRequest.make({
        operation: "resolveUnknown",
        submissionId: command.submissionId,
      }),
    );
    const intent = yield* ledger.recordUnknownResolution(command);

    yield* hit("resolve:after-intent");
    if (command.resolution._tag === "AbortSubmission") {
      yield* ledger.requestAbort(
        AbortCommand.make({
          submissionId: command.submissionId,
          author: command.author,
          reason: command.reason,
        }),
      );
    }

    const snapshot = yield* ledger.lookup(
      SubmissionLookupById.make({ submissionId: command.submissionId }),
    );

    if (Option.isSome(snapshot)) {
      yield* wake.notify(snapshot.value.threadId);
    }

    return intent;
  });

  /**
   * Durable approval decision surface (plan §2.6, abort-shaped): the ledger intent commits
   * first — idempotent per (submission, tool call), with a typed `ApprovalConflict` on a
   * divergent re-decision — and the adapter transitions `suspended → input-applied` atomically
   * once every pending call of the stored suspension reason is decided; the wake hint then lets
   * a worker resume the declared batch through the batch-resume seam (no model re-invocation).
   * The canonical `ToolApprovalDecided` record is appended by the resuming Attempt's approval
   * hook before the decision is honored — never here. A denied decision fails the Run through
   * the engine's `AgentApprovalDenied` path (denial-terminal, P2 policy default). Possession of
   * this service plus the mandatory resolver/reason audit fields is the Phase 5 authorization
   * boundary, identical to `abort`; the authenticated operator surface is a P7 deliverable.
   */
  const resolveApproval = Effect.fn("DurableAgentRuntime.resolveApproval")(function* (
    command: ApprovalDecisionCommand,
  ): Effect.fn.Return<ApprovalDecisionIntent, DurableApprovalFailure | OperationDenied> {
    yield* operationAuthorizer.authorize(
      OperationAuthorizationRequest.make({
        operation: "resolveApproval",
        submissionId: command.submissionId,
      }),
    );
    const intent = yield* ledger.recordApprovalDecision(command);

    const snapshot = yield* ledger.lookup(
      SubmissionLookupById.make({ submissionId: command.submissionId }),
    );

    if (Option.isSome(snapshot)) {
      yield* wake.notify(snapshot.value.threadId);
    }

    return intent;
  });

  // -------------------------------------------------------------------------
  // P7 administrative operations (plan §3): explain/verify/retry/wake/scanObligations over the
  // SAME two ports the coordinator already owns, so they behave identically on DN and DC.
  // -------------------------------------------------------------------------

  /** Whole non-negative seconds between a recorded instant and Effect Clock-now. */
  const ageSecondsSince = (instant: DateTime.Utc, nowMillis: number): number =>
    Math.max(0, Math.floor((nowMillis - DateTime.toEpochMillis(instant)) / 1_000));

  const lookupKnownSubmission = Effect.fn("DurableAgentRuntime.lookupKnownSubmission")(function* (
    operation: string,
    submissionId: SubmissionId,
  ): Effect.fn.Return<SubmissionSnapshot, LedgerError> {
    const found = yield* ledger.lookup(SubmissionLookupById.make({ submissionId }));

    if (Option.isNone(found)) {
      return yield* LedgerError.make({
        operation,
        message: `Unknown Submission ${submissionId}`,
      });
    }

    return found.value;
  });

  /**
   * Read-only explanation of one Submission: the same snapshot + tolerant canonical read +
   * pure classification the recovery pass performs, packaged WITHOUT executing anything —
   * assembling it performs zero writes (P7 exit gate: operators explain recovery state without
   * editing storage).
   */
  const explainSubmission = Effect.fn("DurableAgentRuntime.explainSubmission")(function* (
    submission: SubmissionSnapshot,
  ): Effect.fn.Return<RecoveryExplanation, LedgerError | ThreadStoreError | RunJournalError> {
    const snapshot = yield* ledger.loadRecoverySnapshot(
      RecoverySnapshotRequest.make({ submissionId: submission.submissionId }),
    );

    const read = yield* readRecoveryHistory(submission.threadId, [
      submission.submissionId,
      ...(snapshot.hostSubmissionId === undefined ? [] : [snapshot.hostSubmissionId]),
    ]);

    const evidence = yield* evidenceFor(
      read.records,
      submission.submissionId,
      read.materialized,
      snapshot.hostSubmissionId,
    );

    const decision = classifyRecovery(snapshot, evidence);
    const nowMillis = yield* Clock.currentTimeMillis;
    const explainedAt = yield* nowUtc;
    const runId = runIdForSubmission(submission.submissionId);

    const resolvedIds = new Set(
      read.records.flatMap(({ record }) =>
        record.payload._tag === "ToolCallSettled" && record.payload.runId === runId
          ? [record.payload.toolCallId]
          : [],
      ),
    );

    const unknownCalls: Array<ExplainedUnknownCall> = [];

    for (const envelope of read.records) {
      const payload = envelope.record.payload;

      if (payload._tag !== "ToolCallUnknown" || payload.runId !== runId) continue;
      unknownCalls.push(
        ExplainedUnknownCall.make({
          toolCallId: payload.toolCallId,
          toolName: payload.toolName,
          reason: payload.reason,
          recordedAt: envelope.record.createdAt,
          resolved: resolvedIds.has(payload.toolCallId),
        }),
      );
    }
    const row = snapshot.submission;

    return RecoveryExplanation.make({
      submission: ExplainedSubmission.make({
        submissionId: row.submissionId,
        threadId: row.threadId,
        state: row.state,
        queueSequence: row.queueSequence,
        createdAt: row.createdAt,
        ageSeconds: ageSecondsSince(row.createdAt, nowMillis),
        ...(row.readyAt === undefined
          ? {}
          : { readyAt: row.readyAt, readyAgeSeconds: ageSecondsSince(row.readyAt, nowMillis) }),
        ...(row.parentLinkage === undefined ? {} : { parentLinkage: row.parentLinkage }),
      }),
      evidence: ExplainedEvidence.make({
        threadMaterialized: evidence.threadMaterialized,
        inputRecorded: evidence.inputRecorded,
        abortRecorded: evidence.abortRecorded,
        openToolCalls: evidence.openToolCalls,
        pendingOperations: read.records.flatMap(({ record }) =>
          record.payload._tag === "ToolCallPrepared" &&
          record.payload.runId === runId &&
          !resolvedIds.has(record.payload.toolCallId)
            ? [record.payload]
            : [],
        ),
        openDelegationCalls: evidence.openDelegationCalls,
        approvalsPending: evidence.approvalsPending,
        unknownCalls,
        approvalDecisions: snapshot.approvalDecisions,
        unknownResolutions: snapshot.unknownResolutions,
        childAttachments: snapshot.childAttachments,
        joins: snapshot.joins,
        ...(evidence.recordedSettlementOutcome === undefined
          ? {}
          : { recordedSettlementOutcome: evidence.recordedSettlementOutcome }),
        ...(snapshot.hostSubmissionId === undefined
          ? {}
          : { hostSubmissionId: snapshot.hostSubmissionId }),
        ...(snapshot.suspension === undefined ? {} : { suspension: snapshot.suspension }),
        ...(snapshot.abortIntent === undefined ? {} : { abortIntent: snapshot.abortIntent }),
      }),
      decision,
      decisionMeaning: recoveryDecisionMeaning(decision._tag),
      disposition:
        decision._tag === "ApplyUnknownResolutions" &&
        (yield* hasUnsupportedRetry(snapshot, read.records).pipe(
          Effect.mapError((cause) =>
            RunJournalError.make({ message: "Cannot verify the pending retry contract", cause }),
          ),
        ))
          ? "unknown"
          : predictRecoveryDisposition(decision, snapshot),
      explainedAt,
    });
  });

  const explain = Effect.fn("DurableAgentRuntime.explain")(function* (
    submissionId: SubmissionId,
  ): Effect.fn.Return<RecoveryExplanation, DurableExplainFailure> {
    yield* operationAuthorizer.authorize(
      OperationAuthorizationRequest.make({ operation: "explain", submissionId }),
    );
    const submission = yield* lookupKnownSubmission("explain", submissionId);

    return yield* explainSubmission(submission);
  });

  const explainThread = Effect.fn("DurableAgentRuntime.explainThread")(function* (
    threadId: ThreadId,
  ): Effect.fn.Return<ReadonlyArray<RecoveryExplanation>, DurableExplainFailure> {
    yield* operationAuthorizer.authorize(
      OperationAuthorizationRequest.make({ operation: "explain", threadId }),
    );
    const nonterminal = yield* Stream.runCollect(ledger.scanNonterminal);
    const explanations: Array<RecoveryExplanation> = [];

    for (const submission of nonterminal) {
      if (submission.threadId !== threadId) continue;
      explanations.push(
        yield* explainSubmission(
          yield* lookupKnownSubmission("explain Thread", submission.submissionId),
        ),
      );
    }

    return explanations;
  });

  const verifyImpl = Effect.fn("DurableAgentRuntime.verify")(function* (
    threadId: ThreadId,
  ): Effect.fn.Return<IntegrityReport, DurableVerifyFailure> {
    yield* operationAuthorizer.authorize(
      OperationAuthorizationRequest.make({ operation: "verify", threadId }),
    );
    const exported = yield* store.export(ThreadExportRequest.make({ threadId }));
    // Lane rows: the nonterminal scan plus every Submission the canonical log itself names —
    // the ledger port scans nonterminal work only, and canonical history is the authority for
    // everything settled (DUR-015).
    const rows = new Map<SubmissionId, SubmissionSnapshot>();
    const nonterminal = yield* Stream.runCollect(ledger.scanNonterminal);
    const named = new Set<SubmissionId>();

    for (const submission of nonterminal) {
      if (submission.threadId === threadId) named.add(submission.submissionId);
    }

    for (const envelope of exported.records) {
      const payload = envelope.record.payload;

      if (
        payload._tag === "UserInputRecorded" ||
        payload._tag === "SubmissionSettled" ||
        payload._tag === "AbortRequested"
      ) {
        if (payload.submissionId !== undefined) named.add(payload.submissionId);
      }
    }
    for (const submissionId of named) {
      if (rows.has(submissionId)) continue;
      const found = yield* ledger.lookup(SubmissionLookupById.make({ submissionId }));

      if (Option.isSome(found) && found.value.threadId === threadId) {
        rows.set(submissionId, found.value);
      }
    }

    // The latest stored checkpoint binds against the report; a typed load rejection IS an
    // integrity finding rather than an operation failure.
    const checkpointLoad:
      | { readonly _tag: "loaded"; readonly checkpoint: ThreadCheckpoint | undefined }
      | { readonly _tag: "rejected"; readonly reason: string }
      | { readonly _tag: "unsupported" } =
      store.checkpoints === undefined
        ? { _tag: "unsupported" }
        : yield* store.checkpoints.load(LoadCheckpointRequest.make({ threadId })).pipe(
            Effect.map((checkpoint) => ({
              _tag: "loaded" as const,
              checkpoint: Option.getOrUndefined(checkpoint),
            })),
            Effect.catchTag("CheckpointRejected", (rejected) =>
              Effect.succeed({ _tag: "rejected" as const, reason: rejected.reason }),
            ),
          );

    const report = yield* verifyThreadInvariants({
      export: exported,
      submissions: [...rows.values()],
      checkpointsSupported: checkpointLoad._tag !== "unsupported",
      ...(checkpointLoad._tag === "loaded" && checkpointLoad.checkpoint !== undefined
        ? { checkpoint: checkpointLoad.checkpoint }
        : {}),
    }).pipe(withCrypto);

    if (checkpointLoad._tag === "rejected") {
      const checks = [
        ...report.checks.filter((result) => result.name !== "checkpoint-binding"),
        IntegrityCheck.make({
          name: "checkpoint-binding",
          status: "failed",
          detail: `the stored checkpoint was rejected on load: ${checkpointLoad.reason}`,
        }),
      ];

      return IntegrityReport.make({
        threadId: report.threadId,
        tailSequence: report.tailSequence,
        recordCount: report.recordCount,
        submissionCount: report.submissionCount,
        checks,
        ok: false,
      });
    }

    return report;
  });

  /**
   * Safe re-drive of exactly one Submission's recovery decision (plan §3): classify, execute
   * the ONE repair the classifier names, annotate owned repair attempts with their actual
   * claim epoch (DUR-013), and wake the lane. Typed refusals
   * protect the paths that own their own operations: settled work (`NoAction`), requests parked
   * on Unknown Outcomes (`resolveUnknown`, DUR-017), and lanes awaiting approval decisions
   * (`resolveApproval`). The mandatory `author`/`reason` audit fields (SEC-011) annotate the
   * structured operator log.
   */
  const retryImpl = Effect.fn("DurableAgentRuntime.retry")(function* (
    command: RetryCommand,
  ): Effect.fn.Return<RecoveryReport, DurableRetryFailure> {
    yield* operationAuthorizer.authorize(
      OperationAuthorizationRequest.make({
        operation: "retry",
        submissionId: command.submissionId,
      }),
    );
    const submission = yield* lookupKnownSubmission("retry", command.submissionId);

    const snapshot = yield* ledger.loadRecoverySnapshot(
      RecoverySnapshotRequest.make({ submissionId: command.submissionId }),
    );

    const read = yield* readRecoveryHistory(submission.threadId, [
      submission.submissionId,
      ...(snapshot.hostSubmissionId === undefined ? [] : [snapshot.hostSubmissionId]),
    ]);

    const evidence = yield* evidenceFor(
      read.records,
      command.submissionId,
      read.materialized,
      snapshot.hostSubmissionId,
    );

    const decision = classifyRecovery(snapshot, evidence);

    if (decision._tag === "NoAction") {
      return yield* RetryRefused.make({
        submissionId: command.submissionId,
        refusal: "settled",
        decisionTag: decision._tag,
        message: "The Submission is settled; terminal outcomes are never revisited (DUR-002).",
      });
    }
    if (decision._tag === "AwaitUnknownResolution") {
      return yield* RetryRefused.make({
        submissionId: command.submissionId,
        refusal: "await-unknown-resolution",
        decisionTag: decision._tag,
        message:
          "This Submission is parked on Unknown Outcomes; resolve them through the authorized resolveUnknown path (DUR-017) instead of retrying.",
      });
    }
    if (decision._tag === "AwaitApprovalDecision") {
      return yield* RetryRefused.make({
        submissionId: command.submissionId,
        refusal: "await-approval-decision",
        decisionTag: decision._tag,
        message:
          "The lane is durably waiting for approval decisions; decide them through resolveApproval instead of retrying.",
      });
    }
    yield* Effect.logInfo("DurableAgentRuntime.retry executed an operator re-drive").pipe(
      Effect.annotateLogs({
        submissionId: command.submissionId,
        threadId: submission.threadId,
        author: command.author,
        reason: command.reason,
        decision: decision._tag,
      }),
    );

    const disposition = yield* Effect.scoped(
      executeRecoveryDecision(snapshot, evidence, decision, read.records, read),
    );

    yield* wake.notify(submission.threadId);

    return RecoveryReport.make({
      submissionId: command.submissionId,
      threadId: submission.threadId,
      decision,
      disposition,
    });
  });

  /** The documented operator liveness nudge: a droppable wake hint for one lane. */
  const wakeImpl = Effect.fn("DurableAgentRuntime.wake")(function* (
    threadId: ThreadId,
  ): Effect.fn.Return<void, OperationDenied> {
    yield* operationAuthorizer.authorize(
      OperationAuthorizationRequest.make({ operation: "wake", threadId }),
    );
    yield* wake.notify(threadId);
  });

  /**
   * Scan-based DUR-017/OPS-001 obligation report — never a daemon: one ledger scan folded into
   * aged, severity-classified rows. Ages come from timestamps that already exist: `readyAt`/
   * `createdAt` for queued and running work, `suspendedAt` for durable suspensions, and the
   * oldest unresolved canonical `ToolCallUnknown` record for DUR-017 blocks (OPS-002).
   */
  const scanObligationsImpl = Effect.fn("DurableAgentRuntime.scanObligations")(function* (
    thresholds: ObligationThresholds,
  ): Effect.fn.Return<ObligationReport, DurableObligationFailure> {
    yield* operationAuthorizer.authorize(
      OperationAuthorizationRequest.make({ operation: "scanObligations" }),
    );
    const nonterminal = yield* Stream.runCollect(ledger.scanNonterminal);
    const nowMillis = yield* Clock.currentTimeMillis;
    const generatedAt = yield* nowUtc;
    const entries: Array<ObligationEntry> = [];

    for (const entry of nonterminal) {
      const snapshot = yield* ledger.loadRecoverySnapshot(
        RecoverySnapshotRequest.make({ submissionId: entry.submissionId }),
      );

      const submission = snapshot.submission;

      let blockedOn: ObligationBlockedOn;
      let since: DateTime.Utc = submission.readyAt ?? submission.createdAt;

      switch (submission.state) {
        case "unknown": {
          blockedOn = "unknown";

          const records = (yield* readAllTolerant(submission.threadId, [submission.submissionId]))
            .records;

          const runId = runIdForSubmission(submission.submissionId);

          const resolvedIds = new Set(
            records.flatMap(({ record }) =>
              record.payload._tag === "ToolCallSettled" && record.payload.runId === runId
                ? [record.payload.toolCallId]
                : [],
            ),
          );

          let earliest: DateTime.Utc | undefined;

          for (const envelope of records) {
            const payload = envelope.record.payload;

            if (payload._tag !== "ToolCallUnknown" || payload.runId !== runId) continue;
            if (resolvedIds.has(payload.toolCallId)) continue;
            const recordedAt = envelope.record.createdAt;

            if (
              earliest === undefined ||
              DateTime.toEpochMillis(recordedAt) < DateTime.toEpochMillis(earliest)
            ) {
              earliest = recordedAt;
            }
          }
          since = earliest ?? snapshot.suspension?.suspendedAt ?? since;
          break;
        }
        case "suspended": {
          blockedOn =
            snapshot.suspension?.reason._tag === "WaitingForChild" ? "waitingForChild" : "approval";
          since = snapshot.suspension?.suspendedAt ?? since;
          break;
        }
        case "admitted":
        case "ready": {
          blockedOn = "ready-aged";
          break;
        }
        default: {
          blockedOn = "running-aged";
          break;
        }
      }
      const ageSeconds = ageSecondsSince(since, nowMillis);

      entries.push(
        ObligationEntry.make({
          submissionId: submission.submissionId,
          threadId: submission.threadId,
          state: submission.state,
          blockedOn,
          ageSeconds,
          severity: obligationSeverityOf(ageSeconds, thresholds),
        }),
      );
    }

    return ObligationReport.make({ thresholds, entries, generatedAt });
  });

  const runResolvedWorkerImpl = Effect.gen(function* () {
    // Each claimed head selects a current Binding by stable Agent ID and optional host routing.
    // Original per-operation replay contracts still govern unfinished handlers, while one worker
    // pool serves both parent and child lanes.
    const nonterminal = yield* Stream.runCollect(ledger.scanNonterminal);
    const seen = new Set<ThreadId>();

    for (const submission of nonterminal) {
      if (seen.has(submission.threadId)) continue;
      seen.add(submission.threadId);
      yield* processThreadResolvedImpl(submission.threadId);
    }
    yield* Stream.runForEach(wake.wakes, (threadId) => processThreadResolvedImpl(threadId));
  });

  const messagingRuntime = yield* makeMessagingRuntime({
    bindings: registeredBindings,
    deploymentId: config.deploymentId,
    producerId: config.producerId,
  });

  const workerRuntime = yield* makeWorkerRuntime({
    bindings: registeredBindings,
    deploymentId: config.deploymentId,
    producerId: config.producerId,
    settlementPollInterval: config.settlementPollInterval,
  }).pipe(
    Effect.provideService(WorkerInputControl, {
      status: readSubmissionStatus,
      abort,
      submit: (envelope) =>
        submit({ definition: { id: envelope.agentId, input: PersistedJson } }, envelope.input, {
          threadId: envelope.threadId,
          principal: envelope.deliveryPrincipal,
          idempotencyKey: envelope.admissionKey,
          definitions: envelope.definitions,
          ...(envelope.workerAdmission === undefined
            ? {}
            : { workerAdmission: envelope.workerAdmission }),
          ...(envelope.messageAdmission === undefined
            ? {}
            : { messageAdmission: envelope.messageAdmission }),
        }),
    }),
  );

  const updateRuntime = yield* makeAgentUpdateRuntime({
    deploymentId: config.deploymentId,
    producerId: config.producerId,
  }).pipe(Effect.provideService(WorkerRuntime, workerRuntime));

  return DurableAgentRuntime.of({
    bindingRegistryKey: yield* withCrypto(
      digestJson({
        selection: bindingSelection?.key ?? null,
        bindings: (yield* Effect.forEach(registeredBindings, (binding) =>
          withCrypto(
            digestJson({
              agentId: binding.agentId,
              agent: binding.digests.agent,
              model: binding.digests.model,
              tools: binding.digests.tools,
              replay:
                binding.digests.replay === undefined
                  ? null
                  : {
                      agent: binding.digests.replay.agent,
                      agentBehavior: binding.digests.replay.agentBehavior ?? null,
                      tools: binding.digests.replay.tools,
                    },
            }),
          ),
        ).pipe(Effect.orDie)).sort(),
      }),
    ).pipe(Effect.orDie),
    workerHost: workerRuntime.acquire,
    messagingHost: messagingRuntime.acquire,
    submitRegistered,
    settlementRecord,
    submit,
    submissionStatus,
    inspectSubmissionStatus: readSubmissionStatus,
    awaitSettlement,
    awaitProgress,
    observe,
    abort,
    resolveUnknown,
    resolveApproval,
    explain,
    explainThread,
    verify: verifyImpl,
    retry: retryImpl,
    wake: wakeImpl,
    scanObligations: scanObligationsImpl,
    processThread: processThreadImpl,
    processThreadResolved: processThreadResolvedImpl,
    processThreadHead: processThreadHeadImpl,
    runResolvedWorker: runResolvedWorkerImpl,
    runRecovery,
    recoverSubmission,
  });
});

/**
 * Durable Agent Runtime coordinator (deployment class DN; D1/D2). It coordinates the
 * SubmissionLedger, ThreadStore, and WakeScheduler ports so that once `submit` returns a
 * Receipt, the Submission settles exactly once (DUR-001/DUR-002) while every external effect
 * remains at-least-once (DUR-003) — this runtime never claims exactly-once side effects.
 *
 * - `submit(agent, input, options)` — durable admission → Thread materialization →
 *   `ThreadCreated` → readiness → Receipt, with failpoints between the steps; a retry with
 *   the same (thread, principal, idempotencyKey) resumes and returns the same Receipt.
 * - `awaitSettlement(receipt)` — authorized once before the first ledger read, for the lifetime
 *   of this wait; interrupting it detaches the caller only and never cancels accepted work.
 * - `observe(receipt, {after})` — canonical record observation from a stored offset.
 * - `abort(command)` — authorized before ledger access; durable idempotent abort intent; inactive work settles aborted through
 *   recovery, an active worker makes the command canonical before interrupting its Run (§13),
 *   settled work fails with `SettlementConflict` (DUR-012). A `joined` Submission fails with a
 *   typed `JoinedToHost` conflict carrying the host identity — it settles with its host, so the
 *   abort target is the host; aborting a `joining` Submission records the intent, honored only
 *   if the host has not consumed the input (revert-then-abort, plan §2.5).
 * - `resolveUnknown(command)` — the authorized DUR-017 resolution path for Unknown Outcomes:
 *   the durable intent is idempotent per (submission, tool call) and conflicts typed on
 *   divergence; the canonical resolution records are applied by recovery or the next Attempt,
 *   and the lane wakes once every marked call is covered.
 * - `resolveApproval(command)` — the durable approval decision path (plan §2.6): the intent is
 *   idempotent per (submission, tool call) with a typed `ApprovalConflict` on divergence; once
 *   every pending call of the suspension reason is decided the lane wakes
 *   (`suspended → input-applied`) and the next Attempt resumes the declared batch without model
 *   re-invocation, appending the canonical `ToolApprovalDecided` before honoring the decision.
 * - `processThread(agent, threadId)` — drain one lane: fenced FIFO-head claims,
 *   canonical input apply, split response/prepared/results Turn commits (plan §2.1),
 *   reconcile-then-mark for open ordinary Tool Calls (DUR-009, never an automatic replay),
 *   declared-batch resume without model re-invocation (§15), and terminalization. An active
 *   host Run claims the contiguous ready prefix of later queued Submissions at every safe Turn
 *   seam (Joining/Joined, plan §2.5): the queued input becomes canonical (`input:{sid}`) before
 *   the next model request, reattaches through the prompt-coverage rule after a crash, and the
 *   joined Submissions settle with the host outcome (DUR-002/DUR-016).
 * - `processThreadResolved(threadId)` / `runResolvedWorker` — drain or continuously process
 *   lanes using registrations owned by the runtime Layer: each stable `agentId` selects
 *   one current Binding. Unfinished operation contracts gate handler execution independently
 *   of immutable admission evidence; missing bindings release the claim with a typed refusal.
 * - `runRecovery()` — classify every nonterminal Submission with the pure `classifyRecovery` and
 *   execute repair decisions, annotating owned repair attempts with their granted epochs
 *   (DUR-013). Untouched ready input and model-resuming work are reported `deferred` for a
 *   worker claim; Submissions parked on
 *   Unknown Outcomes are reported `unknown`. The S2 binding-free Subagent executors (admission
 *   completion, start-link repair, waiting restoration, wake replay, canonical join accounting,
 *   abort propagation, orphan reservation release) run here; the settlement join itself is
 *   deferred to a claiming worker because it needs the parent Binding's result projection.
 * - `explain`/`explainThread`, `verify`, `retry`, `wake`, `scanObligations` — the P7
 *   administrative operations (plan §3) over the same two ports, identical on DN and DC.
 *   `explain` and `verify` are strictly read-only; `retry` re-drives exactly one classified
 *   repair with mandatory author/reason audit and typed refusals; `scanObligations` is the
 *   scan-based DUR-017/OPS-001 obligation surface. Every one of them (plus `observe`,
 *   `resolveUnknown`, `resolveApproval`) consults the `OperationAuthorizer` reference
 *   fail-closed — the default Layer preserves the service-possession behavior, and a
 *   host-supplied authorizer turns denials into the typed `OperationDenied`.
 */
export class DurableAgentRuntime extends Context.Service<
  DurableAgentRuntime,
  {
    /** Stable registration identity for hosts parking unavailable bindings; never an admission authority. */
    readonly bindingRegistryKey: string;
    /** Acquire an authenticated source Thread facet; its References confer no authority. */
    readonly workerHost: (request: {
      readonly sourceThreadId: ThreadId;
      readonly principal: Principal;
      /** Exact retained owner input for captured source policy; never selects the latest input. */
      readonly sourceSubmissionId?: SubmissionId;
    }) => Effect.Effect<SubagentHost["Service"], WorkerError>;
    readonly messagingHost: (request: {
      readonly sourceThreadId: ThreadId;
      readonly principal: Principal;
    }) => Effect.Effect<MessagingHost["Service"], MessagingError>;
    /** Admit the exact registered Definition instance; reject missing, ambiguous, or different definitions. */
    readonly submitRegistered: <InputSchema extends Schema.Top>(
      agent: DurableSubmitAgent<InputSchema>,
      input: InputSchema["Type"],
      options: Omit<DurableSubmitOptions, "definitions">,
    ) => Effect.Effect<
      Receipt,
      DurableSubmitFailure | BindingUnavailable,
      InputSchema["EncodingServices"]
    >;
    /** Authorized exact canonical terminal record, including the encoded output. Reject pending work. */
    readonly settlementRecord: (
      receipt: Receipt,
    ) => Effect.Effect<SubmissionSettledRecord, DurableAwaitFailure>;
    readonly submit: <InputSchema extends Schema.Top>(
      agent: DurableSubmitAgent<InputSchema>,
      input: InputSchema["Type"],
      options: DurableSubmitOptions,
    ) => Effect.Effect<Receipt, DurableSubmitFailure, InputSchema["EncodingServices"]>;
    readonly awaitSettlement: (receipt: Receipt) => Effect.Effect<Settlement, DurableAwaitFailure>;
    /** Authorized, nonblocking read. Only the durable Settlement marks work complete. */
    readonly submissionStatus: (
      receipt: Receipt,
    ) => Effect.Effect<SubmissionStatus, DurableAwaitFailure>;
    /**
     * Trusted worker inspection under the same runtime authority as processThread/recoverSubmission.
     * Caller-facing observations must use submissionStatus or awaitSettlement for authorization.
     */
    readonly inspectSubmissionStatus: (
      receipt: Receipt,
    ) => Effect.Effect<SubmissionStatus, DurableAwaitFailure>;
    /**
     * Wait for an already-committed record or one incarnation-local progress hint after
     * `afterSequence`. Canonical records remain authoritative: callers re-read after return.
     */
    readonly awaitProgress: (
      threadId: ThreadId,
      afterSequence: CanonicalSequence,
    ) => Effect.Effect<void, DurableProgressFailure>;
    readonly observe: (
      receipt: Receipt,
      options?: DurableObserveOptions,
    ) => Stream.Stream<
      CanonicalRecordEnvelope,
      ThreadStoreError | ThreadNotMaterialized | OperationDenied
    >;
    readonly abort: (command: AbortCommand) => Effect.Effect<AbortIntent, DurableAbortFailure>;
    readonly resolveUnknown: (
      command: UnknownResolutionCommand,
    ) => Effect.Effect<UnknownResolutionIntent, DurableResolveFailure | OperationDenied>;
    readonly resolveApproval: (
      command: ApprovalDecisionCommand,
    ) => Effect.Effect<ApprovalDecisionIntent, DurableApprovalFailure | OperationDenied>;
    /**
     * Read-only recovery explanation of one Submission (P7 plan §3): snapshot + tolerant
     * canonical read + the pure classifier, packaged with the decision's operator meaning and
     * predicted disposition. Performs ZERO writes — the canonical log and every ledger row are
     * byte-identical before and after.
     */
    readonly explain: (
      submissionId: SubmissionId,
    ) => Effect.Effect<RecoveryExplanation, DurableExplainFailure>;
    /** `explain` for every nonterminal lane member of one Thread, in queue order. */
    readonly explainThread: (
      threadId: ThreadId,
    ) => Effect.Effect<ReadonlyArray<RecoveryExplanation>, DurableExplainFailure>;
    /**
     * Read-only integrity verification of one Thread (P7 plan §3): Schema round-trips,
     * record-identity uniqueness, sequence contiguity, FIFO input/settlement order,
     * ledger-terminal vs canonical-settlement agreement (DUR-015), and checkpoint binding —
     * typed per-check results, never a repair. The digest-chain check reports `skipped` with
     * the honest reason: full chain recomputation needs per-batch producer identity, which the
     * ThreadStore port deliberately does not export (supply it to
     * `verifyThreadInvariants` directly; adapter-level `verifyOnOpen` is the
     * storage-side audit).
     */
    readonly verify: (threadId: ThreadId) => Effect.Effect<IntegrityReport, DurableVerifyFailure>;
    /**
     * Safe re-drive of one Submission's recovery decision with mandatory author/reason audit
     * (SEC-011): executes exactly the repair the classifier names; owned repair attempts
     * append a best-effort `RepairAnnotated` with their actual claim epoch (DUR-013). Typed `RetryRefused`
     * for settled work and for lanes owned by the resolveUnknown/resolveApproval paths.
     */
    readonly retry: (command: RetryCommand) => Effect.Effect<RecoveryReport, DurableRetryFailure>;
    /** The documented operator liveness nudge: a droppable wake hint for one lane. */
    readonly wake: (threadId: ThreadId) => Effect.Effect<void, OperationDenied>;
    /**
     * Scan-based DUR-017/OPS-001 obligation report: every nonterminal Submission with what it
     * is visibly blocked on, its age, and a threshold-classified severity. Never a daemon —
     * hosts run it periodically and own the alert loop (OPS-002).
     */
    readonly scanObligations: (
      thresholds: ObligationThresholds,
    ) => Effect.Effect<ObligationReport, DurableObligationFailure>;
    readonly processThread: <
      InputSchema extends Schema.Top,
      OutputSchema extends Schema.Top,
      Instructions,
      Tools extends Record<string, Tool.Any>,
      Provider,
      ModelProvides,
      ModelRequires,
      InstructionError = InstructionErrorOf<Instructions, InputSchema["Type"]>,
      InstructionRequirements = InstructionRequirementsOf<Instructions, InputSchema["Type"]>,
      RunDispositionValue extends
        | RunDispositionDeclaration<OutputSchema["Type"], Schema.Top>
        | undefined = undefined,
      InputPromptValue extends
        | InputPromptSource<InputSchema["Type"], unknown, unknown>
        | undefined = undefined,
      UpdatesSchema extends Schema.Top | undefined = undefined,
    >(
      agent: RuntimeBinding<
        InputSchema,
        OutputSchema,
        Instructions,
        Tools,
        Provider,
        ModelProvides,
        ModelRequires,
        InstructionError,
        InstructionRequirements,
        RunDispositionValue,
        InputPromptValue,
        UpdatesSchema
      >,
      threadId: ThreadId,
    ) => Effect.Effect<
      ReadonlyArray<Settlement>,
      DurableWorkerFailure | DurableBindingFailure,
      DurableWorkerRequirements<
        RuntimeBinding<
          InputSchema,
          OutputSchema,
          Instructions,
          Tools,
          Provider,
          ModelProvides,
          ModelRequires,
          InstructionError,
          InstructionRequirements,
          RunDispositionValue,
          InputPromptValue,
          UpdatesSchema
        >,
        InstructionRequirements
      >
    >;
    readonly processThreadResolved: (
      threadId: ThreadId,
    ) => Effect.Effect<ReadonlyArray<Settlement>, DurableWorkerFailure | DurableBindingFailure>;
    /**
     * Advance the FIFO head, closing its Attempt resources before returning. With an opted-in
     * SubmissionScheduling policy, a complete Turn may hand off to the next same-Agent input;
     * the returned Settlement identifies the Submission actually completed. Each Attempt closes
     * before the next is claimed, and deferred Runs retain their original obligations. A vacant,
     * owned, unknown, or suspended head returns None and leaves accepted work pending.
     * Ready input may join this Run through the existing Turn seams and settle with its head.
     * Interruption ends only this Attempt; ownership cleanup uses its latest renewed token.
     * A trusted host may supply `yieldAfter` to return None before the next Turn's context
     * preparation, committing any completed Turn first. This releases ownership without settling or resetting the durable
     * Run deadline. It is a cooperative scheduling deadline, not a hard interruption timeout.
     */
    readonly processThreadHead: (
      threadId: ThreadId,
      options?: { readonly yieldAfter?: DateTime.Utc },
    ) => Effect.Effect<Option.Option<Settlement>, DurableWorkerFailure | DurableBindingFailure>;
    readonly runResolvedWorker: Effect.Effect<void, DurableWorkerFailure | DurableBindingFailure>;
    /**
     * Recover each pending Thread independently. History/child failures, defects and the
     * configured timeout return one RecoveryBlocked per Thread; hosts must retain visibility
     * outside execution history and exclude those Threads from claims. Ledger scan failures,
     * owner interruption and injected crash boundaries still fail the whole sweep.
     * Optional Thread selection lets a host recover its selected dispatch lane independently
     * of old cleanup. Unselected Threads are neither read nor reported by this call.
     */
    readonly runRecovery: (
      options?: RecoverySweepOptions,
    ) => Effect.Effect<RecoverySweepResult, DurableWorkerFailure>;
    /** Apply one recovery decision; untouched ready input is deferred to its worker claim. */
    readonly recoverSubmission: (
      submissionId: SubmissionId,
    ) => Effect.Effect<RecoveryReport, DurableWorkerFailure>;
  }
>()("@effect-agent/thread/DurableAgentRuntime") {
  /**
   * Resolve typed registrations and capture their services once in the runtime's Layer Scope.
   * Every claimed head must select exactly one current registered Definition. Worker calls
   * cannot replace these registrations or their captured services. Tool authorization is required.
   */
  static layerRegistered<const Entries extends ReadonlyArray<AgentRegistration>>(
    registrations: Entries,
  ) {
    return Layer.effect(DurableAgentRuntime)(
      Effect.flatMap(compileRegistrations(registrations), make),
    );
  }

  /** Construct from precompiled registrations whose captured resources belong to the caller's Scope. */
  static layerWithBindings(bindings: ReadonlyArray<ResolvedBinding>) {
    return Layer.effect(DurableAgentRuntime)(make(bindings));
  }

  /** Captures optional context preparation; Tool authorization remains required in `R`. */
  static readonly layerWithServices: Layer.Layer<
    DurableAgentRuntime,
    never,
    | SubmissionLedger
    | ThreadStore
    | WakeScheduler
    | DurableRuntimeFailpoint
    | DurableRuntimeConfig
    | ToolReconciler
    | RunToolAuthorization
    | Crypto.Crypto
  > = DurableAgentRuntime.layerWithBindings([]);

  /** Compatible defaults: no host prompt transformation and allow-all Tool authorization. */
  static readonly layer: Layer.Layer<
    DurableAgentRuntime,
    never,
    | SubmissionLedger
    | ThreadStore
    | WakeScheduler
    | DurableRuntimeFailpoint
    | DurableRuntimeConfig
    | ToolReconciler
    | Crypto.Crypto
  > = DurableAgentRuntime.layerWithServices.pipe(
    Layer.provide([RunContextPreparationPassthrough, RunToolAuthorization.allowAll]),
  );
}
