import { type Crypto, Effect, Predicate, Schema, Stream, type DateTime } from "effect";
import { Prompt } from "effect/ai";

import { ThreadId, RunId, ToolCallId, TurnId, type SubmissionId } from "../core/Identifiers.ts";
import { type ExhaustedLimit } from "../core/RunEvent.ts";
import { RunPolicyUsage } from "../core/RunPolicyUsage.ts";
import { type Selection, type Snapshot } from "../core/ToolExposure.ts";
import type { ToolParameterRejection } from "../core/ToolResult.ts";
import { ModelCallUsage, summarizeModelUsage, type RunUsageSummary } from "../core/Usage.ts";
import type { WorkerRef } from "../core/Worker.ts";
import {
  CLEARED_TOOL_RESULT,
  COMPACTION_SUMMARY_PREFIX,
  contextWindowId,
  contextWindowMessage,
} from "../engine/Compaction.ts";
import { digestJson, type DigestError } from "./Digest.ts";
import {
  type JournalCheckpointSeed,
  type ThreadContextCheckpoint,
} from "./internal/journal-checkpoint.ts";
import {
  makeJournalMetadata,
  toolExecutionKey,
  type JournalMetadata,
} from "./internal/journal-metadata.ts";
import {
  BatchId,
  CanonicalBatch,
  CompactionCreated,
  ModelResponseRecorded,
  PersistedJson,
  RecordEnvelope,
  RecordId,
  RunCompleted,
  ToolCallSettled,
  type CanonicalRecordEnvelope,
  type CanonicalSequence,
  type DeploymentId,
  type ProducerId,
} from "./Records.ts";
import { IdempotencyKey } from "./SubmissionLedger.ts";

/** A canonical record could not be projected into Run/Prompt state. */
export class RunJournalError extends Schema.TaggedError<RunJournalError>()("RunJournalError", {
  message: Schema.String,
  cause: Schema.optionalKey(Schema.Defect()),
}) {}

const journalError = (message: string, cause?: unknown): RunJournalError =>
  cause === undefined
    ? RunJournalError.make({ message })
    : RunJournalError.make({ message, cause });

const decodeRunId = Schema.decodeSync(RunId);
const decodeTurnId = Schema.decodeSync(TurnId);
const decodeBatchId = Schema.decodeSync(BatchId);
const decodeRecordId = Schema.decodeSync(RecordId);

/**
 * Deterministic Run identity pinned per Submission (plan §Coordinator flow). Every Attempt of one
 * Submission shares this Run identity, so canonical per-Turn records from different Attempts
 * belong to one logical Run.
 */
export const runIdForSubmission = (submissionId: SubmissionId): RunId =>
  decodeRunId(`run:${submissionId}`);

/** Stable canonical clock identity shared by every Attempt of one Run. */
export const runStartedRecordId = (runId: RunId): RecordId => decodeRecordId(`run-start:${runId}`);

export const runStartedBatchId = (runId: RunId): BatchId => decodeBatchId(`run-start:${runId}`);

export const runDurationRecordId = (runId: RunId): RecordId =>
  decodeRecordId(`run-duration:${runId}`);

export const runDurationBatchId = (runId: RunId): BatchId => decodeBatchId(`run-duration:${runId}`);

/** Deterministic Turn identity: Attempt-independent for one (Run, canonical turn) pair. */
export const turnIdForRun = (runId: RunId, turn: number): TurnId =>
  decodeTurnId(`turn:${runId}:${turn}`);

/** Deterministic batch identity of one committed canonical no-tool Turn (P4 single-batch shape). */
export const turnBatchId = (runId: RunId, turn: number): BatchId =>
  decodeBatchId(`turn:${runId}:${turn}`);

/**
 * Deterministic batch identity of a tool-declaring Turn's RESPONSE commit (plan §2.1 commit 1):
 * the assistant response plus pending steering becomes canonical BEFORE approval preflight and
 * tool preparation, creating the durability §15 "resume tool scheduling" window.
 */
export const turnResponseBatchId = (runId: RunId, turn: number): BatchId =>
  decodeBatchId(`turn-response:${runId}:${turn}`);

/**
 * Deterministic batch identity of a tool-declaring Turn's RESULTS commit (plan §2.1 commit 5):
 * every `ToolCallSettled` record of the Turn, in declaration order, model-visible atomically.
 */
export const turnResultsBatchId = (runId: RunId, turn: number): BatchId =>
  decodeBatchId(`turn-results:${runId}:${turn}`);

/**
 * Deterministic per-call late-settle batch identity used by the resolution path when one
 * recovered/resolved call settles outside its Turn's results batch. Record identity
 * (`tool-settled:{runId}:{turn}:{toolCallId}`) dedupes double-settles across both paths.
 */
export const toolCallResultBatchId = (
  runId: RunId,
  turn: number,
  toolCallId: ToolCallId,
): BatchId => decodeBatchId(`turn-results:${runId}:${turn}:${toolCallId}`);

/** Deterministic batch identity of one Turn's `ToolCallPrepared` commit (plan §2.1 commit 3). */
export const turnPreparedBatchId = (runId: RunId, turn: number): BatchId =>
  decodeBatchId(`turn-prepared:${runId}:${turn}`);

/**
 * Deterministic identity of one pre-Turn compaction record (RUN-026,
 * RUN-026). Keyed by Run, Turn, and kind — the engine performs at most one
 * threshold compaction per Turn plus at most one overflow-forced summarize,
 * so a superseding Attempt that re-decides the same compaction replays the
 * batch identity instead of duplicating the record.
 */
export const compactionRecordId = (
  runId: RunId,
  turn: number,
  kind: "clear-tool-results" | "summarize" | "rollover",
): RecordId => decodeRecordId(`compaction:${runId}:${turn}:${kind}`);

/** Deterministic batch identity of one compaction append (same string as its record id). */
export const compactionBatchId = (
  runId: RunId,
  turn: number,
  kind: "clear-tool-results" | "summarize" | "rollover",
): BatchId => decodeBatchId(`compaction:${runId}:${turn}:${kind}`);

/** Deterministic canonical record identity of one Turn's `ModelResponseRecorded` record. */
export const modelResponseRecordId = (runId: RunId, turn: number): RecordId =>
  decodeRecordId(`model-response:${runId}:${turn}`);

/** Terminal Tool completion marker committed atomically with its settled Tool result. */
export const runCompletedRecordId = (runId: RunId): RecordId =>
  decodeRecordId(`run-completed:${runId}`);

/** Native source reservation locator, including the first admission of a continuing worker. */
export const workerInputRecordId = (messageId: IdempotencyKey): RecordId =>
  decodeRecordId(`worker-input:${messageId}`);

/** Source-owned first reservation; native worker identity is minted from its first message. */
export const firstWorkerInputRecordId = (worker: WorkerRef): RecordId =>
  decodeRecordId(`worker-input:${worker.threadId}`);

export const workerOriginRecordId = (threadId: ThreadId): RecordId =>
  decodeRecordId(`worker-origin:${threadId}`);

export const workerReportRecordId = (messageId: IdempotencyKey): RecordId =>
  decodeRecordId(`worker-report:${messageId}`);

export const peerMessageRecordId = (messageId: IdempotencyKey): RecordId =>
  decodeRecordId(messageId);

/** Same immutable tuple used by native update admission; callers never parse its hash. */
export const agentUpdateRecordId = Effect.fn("RunJournal.agentUpdateRecordId")(function* (
  threadId: ThreadId,
  runId: RunId,
  updateId: IdempotencyKey,
) {
  return decodeRecordId(`agent-update:${yield* digestJson([threadId, runId, updateId])}`);
});

/** Deterministic canonical record identity of one Turn's `ToolCallSettled` record. */
export const toolCallSettledRecordId = (
  runId: RunId,
  turn: number,
  toolCallId: ToolCallId,
): RecordId => decodeRecordId(`tool-settled:${runId}:${turn}:${toolCallId}`);

/** Deterministic canonical record identity of one Tool Call's `ToolCallPrepared` record. */
export const toolCallPreparedRecordId = (
  runId: RunId,
  turn: number,
  toolCallId: ToolCallId,
): RecordId => decodeRecordId(`tool-prepared:${runId}:${turn}:${toolCallId}`);

/** Deterministic batch identity of one Turn's `ToolCallUnknown` marking append. */
export const markUnknownBatchId = (submissionId: SubmissionId, turn: number): BatchId =>
  decodeBatchId(`mark-unknown:${submissionId}:${turn}`);

/** Deterministic canonical record identity of one Tool Call's `ToolCallUnknown` record. */
export const toolCallUnknownRecordId = (
  runId: RunId,
  turn: number,
  toolCallId: ToolCallId,
): RecordId => decodeRecordId(`tool-unknown:${runId}:${turn}:${toolCallId}`);

/** Deterministic batch identity of one Tool Call's resolution append (DUR-017). */
export const toolCallResolutionBatchId = (
  submissionId: SubmissionId,
  toolCallId: ToolCallId,
): BatchId => decodeBatchId(`resolve:${submissionId}:${toolCallId}`);

/** Deterministic canonical record identity of one Tool Call's `ToolCallResolved` record. */
export const toolCallResolvedRecordId = (
  runId: RunId,
  turn: number,
  toolCallId: ToolCallId,
): RecordId => decodeRecordId(`tool-resolved:${runId}:${turn}:${toolCallId}`);

/**
 * Deterministic identity of one accepted Durable Step result. The one-record batch reuses the
 * SAME string, so batch idempotency plus the epoch fence realize the durability §11
 * racing-writers rule: only the fenced winner's record commits; the loser replays it.
 * A versioned JSON tuple keeps separator characters in each identity component distinct.
 * Replay derives this key from the structured payload, including records with legacy IDs.
 */
export const toolStepSettledRecordId = (
  runId: RunId,
  toolCallId: ToolCallId,
  stepName: string,
): RecordId => decodeRecordId(JSON.stringify(["step@2", runId, toolCallId, stepName]));

/** Deterministic batch identity of one Durable Step commit (same string as its record id). */
export const toolStepSettledBatchId = (
  runId: RunId,
  toolCallId: ToolCallId,
  stepName: string,
): BatchId => decodeBatchId(toolStepSettledRecordId(runId, toolCallId, stepName));

/** Deterministic batch identity of one Turn's canonical approval-request append (plan §2.6). */
export const turnApprovalsBatchId = (runId: RunId, turn: number): BatchId =>
  decodeBatchId(`turn-approvals:${runId}:${turn}`);

/** Deterministic canonical record identity of one Tool Call's `ToolApprovalRequested` record. */
export const toolApprovalRequestRecordId = (
  runId: RunId,
  turn: number,
  toolCallId: ToolCallId,
): RecordId => decodeRecordId(`approval-request:${runId}:${turn}:${toolCallId}`);

/** Deterministic batch identity of one Tool Call's canonical approval-decision append. */
export const approvalDecisionBatchId = (
  submissionId: SubmissionId,
  toolCallId: ToolCallId,
): BatchId => decodeBatchId(`approval-decision:${submissionId}:${toolCallId}`);

/** Deterministic canonical record identity of one Tool Call's `ToolApprovalDecided` record. */
export const toolApprovalDecisionRecordId = (
  runId: RunId,
  turn: number,
  toolCallId: ToolCallId,
): RecordId => decodeRecordId(`approval-decision:${runId}:${turn}:${toolCallId}`);

/**
 * Deterministic identity of one superseded Attempt's `ModelResponseInterrupted` audit record
 * (durability §9). Keyed by the superseded epoch, so each interrupted ownership period is
 * recorded at most once; the one-record batch reuses the same string.
 */
export const modelResponseInterruptedRecordId = (runId: RunId, supersededEpoch: number): RecordId =>
  decodeRecordId(`interrupted:${runId}:${supersededEpoch}`);

/** Deterministic batch identity of one `ModelResponseInterrupted` append (same string). */
export const modelResponseInterruptedBatchId = (runId: RunId, supersededEpoch: number): BatchId =>
  decodeBatchId(`interrupted:${runId}:${supersededEpoch}`);

const decodeThreadId = Schema.decodeSync(ThreadId);
const decodeIdempotencyKey = Schema.decodeSync(IdempotencyKey);

/**
 * Deterministic canonical record identity of one parent Tool Call's `SubagentRequested` record.
 * The one-record batch reuses the same string, so batch
 * idempotency plus the parent epoch fence make the request append exactly-once-canonical.
 */
export const subagentRequestedRecordId = (runId: RunId, toolCallId: ToolCallId): RecordId =>
  decodeRecordId(`subagent-requested:${runId}:${toolCallId}`);

/** Deterministic batch identity of one `SubagentRequested` append (same string). */
export const subagentRequestedBatchId = (runId: RunId, toolCallId: ToolCallId): BatchId =>
  decodeBatchId(`subagent-requested:${runId}:${toolCallId}`);

/**
 * Deterministic canonical record identity of one parent Tool Call's `SubagentStarted` record.
 * Recovery's start-link repair appends the EXACT same record
 * under this identity, so a raced repair replays instead of duplicating (SUB-016/SUB-017).
 */
export const subagentStartedRecordId = (runId: RunId, toolCallId: ToolCallId): RecordId =>
  decodeRecordId(`subagent-started:${runId}:${toolCallId}`);

/** Deterministic batch identity of one `SubagentStarted` append (same string). */
export const subagentStartedBatchId = (runId: RunId, toolCallId: ToolCallId): BatchId =>
  decodeBatchId(`subagent-started:${runId}:${toolCallId}`);

/**
 * Deterministic batch identity of one parent Tool Call's atomic settlement join: the
 * `SubagentJoined` record plus the parent's `ToolCallSettled` record (its existing
 * `tool-settled:{runId}:{turn}:{toolCallId}` identity) commit as ONE canonical batch (SUB-019).
 */
export const subagentJoinBatchId = (runId: RunId, toolCallId: ToolCallId): BatchId =>
  decodeBatchId(`subagent-join:${runId}:${toolCallId}`);

/** Deterministic canonical record identity of one parent Tool Call's `SubagentJoined` record. */
export const subagentJoinedRecordId = (runId: RunId, toolCallId: ToolCallId): RecordId =>
  decodeRecordId(`subagent-joined:${runId}:${toolCallId}`);

/**
 * Deterministic identity of one child Thread's `SubagentLineageRecorded` record.
 * Its own single-record batch reuses the same string so the generic
 * `thread-created:{cid}` batch identity is never contradicted.
 */
export const subagentLineageRecordId = (threadId: ThreadId): RecordId =>
  decodeRecordId(`subagent-lineage:${threadId}`);

/** Deterministic batch identity of one `SubagentLineageRecorded` append (same string). */
export const subagentLineageBatchId = (threadId: ThreadId): BatchId =>
  decodeBatchId(`subagent-lineage:${threadId}`);

/**
 * Deterministic intended child Thread identity: the
 * parent Submission and Tool Call pair addresses exactly one child Thread, so a replayed
 * establishment converges on the one existing child (SUB-016).
 */
export const childThreadIdFor = (
  parentSubmissionId: SubmissionId,
  toolCallId: ToolCallId,
): ThreadId => decodeThreadId(`subagent:${parentSubmissionId}:${toolCallId}`);

/**
 * Deterministic child admission idempotency key: scoped to
 * the parent Run and Tool Call identity, so duplicate admission attempts resolve through the
 * ledger's idempotency contract to one child Receipt (SUB-016, SUB-031). The ledger key is
 * bounded (256); coordinator-minted Run and Tool Call identities stay far below that bound.
 */
export const childIdempotencyKeyFor = (
  parentRunId: RunId,
  toolCallId: ToolCallId,
): IdempotencyKey => decodeIdempotencyKey(`subagent:${parentRunId}:${toolCallId}`);

const decodePersistedPrompt = (
  messages: PersistedJson,
): Effect.Effect<Prompt.Prompt, RunJournalError> =>
  Schema.decodeUnknownEffect(Prompt.Prompt)(messages).pipe(
    Effect.mapError((cause) =>
      journalError("Canonical messages are not Schema-encoded Prompt messages", cause),
    ),
  );

// Canonical payloads are immutable. Weak keys let retained storage rows own the lifetime
// while repeated projections of an advancing tail reuse their validated Prompt values.
const decodedMessages = new WeakMap<object, Prompt.Prompt>();

const decodePromptMessages = (messages: PersistedJson) =>
  Effect.suspend(() => {
    if (!Predicate.isObject(messages)) return decodePersistedPrompt(messages);
    const cached = decodedMessages.get(messages);

    return cached === undefined
      ? decodePersistedPrompt(messages).pipe(
          Effect.tap((prompt) =>
            Effect.sync(() => {
              decodedMessages.set(messages, prompt);
            }),
          ),
        )
      : Effect.succeed(cached);
  });

interface PendingSettledTool {
  readonly record: ToolCallSettled;
  /** RUN-026: a `clear-tool-results` compaction covers this record's sequence. */
  readonly cleared: boolean;
}

const toolMessageFromSettled = (
  settled: ReadonlyArray<PendingSettledTool>,
): Effect.Effect<Prompt.Message, RunJournalError> =>
  Effect.try({
    try: () =>
      Prompt.makeMessage("tool", {
        content: settled.map(({ record, cleared }) =>
          Prompt.makePart("tool-result", {
            id: record.toolCallId,
            name: record.toolName,
            result: cleared ? CLEARED_TOOL_RESULT : record.result,
            isFailure: record.isFailure,
            providerExecuted: false,
          }),
        ),
      }),
    catch: (cause) => journalError("Unable to rebuild Tool message from ToolCallSettled", cause),
  });

/**
 * Pure canonical projection of one Run's durable execution state.
 *
 * Prompt reconstruction contract (D8):
 *
 * - `ModelResponseRecorded.messages` carries the Schema-encoded Prompt messages the Turn appended
 *   to the model-visible prompt — for the Run's FIRST committed Turn that includes the evaluated
 *   instruction and user-input messages, for later Turns only the assistant response messages.
 *   Tool messages are excluded from `messages`.
 * - `ToolCallSettled` records (committed in the same per-Turn batch, in declaration order)
 *   deterministically rebuild the Turn's single Tool message.
 * - `UserInputRecorded` records input, with a Submission identity only for durable admission. Its
 *   Prompt-visible form (instructions + user message) becomes canonical inside the owning Run's
 *   first `ModelResponseRecorded`. The projection consumes it only for Run correlation.
 * - Immediate retained history uses `ModelCompleted.messages` for the successful Run's exact
 *   native Prompt suffix, including any input examples. It has no resumable Turn state.
 */
/** Cumulative committed usage of the projected Run (RUN-023 resume re-seed). */
export interface RunJournalUsage {
  readonly modelCalls: number;
  /** Known accounting gaps retained across Attempts without changing numeric usage totals. */
  readonly unobservedModelCalls?: number | undefined;
  readonly inputTokens: number;
  readonly outputTokens: number;
  readonly lastInputTokens: number;
  readonly lastOutputTokens: number;
  /** Cumulative persisted spend of the projected Run's committed calls (RUN-023). */
  readonly costMicrousd: number;
  /** Canonical per-call detail used for settlement aggregation and recovery. */
  readonly modelUsage: ReadonlyArray<ModelCallUsage>;
  /** Detailed usage of retired records, grouped without retaining per-call payloads. */
  readonly summarizedModelUsage?: RunUsageSummary | undefined;
}

export interface RunJournalProjection {
  readonly toolSelection?: Selection | undefined;
  readonly policyUsage: RunPolicyUsage;
  /** Canonical projection for the requested Run; may end at its resumable Tool declaration. */
  readonly prompt: Prompt.Prompt;
  /** Prior-Run history with model-only unknown results closing incomplete application calls. */
  readonly historyBefore: Prompt.Prompt;
  /** Number of canonical Turns already committed for the projected Run. */
  readonly committedTurns: number;
  /** Summed per-call usage of the projected Run's committed responses; zeros for records predating usage capture. */
  readonly usage: RunJournalUsage;
  /** Latest committed context window identity, retained across ownership changes. */
  readonly contextWindowId?: string | undefined;
  /** Canonical evaluated instructions and initial input for this Run, independent of the view. */
  readonly protectedContext?: Prompt.Prompt | undefined;
  /** Last successful singleton Tool awaiting possible context-control interpretation by the engine. */
  readonly pendingContextToolCallId?: string | undefined;
}

interface ProjectedResponseUsage {
  readonly modelCalls: number;
  readonly inputTokens: number;
  readonly outputTokens: number;
  readonly costMicrousd: number;
  readonly modelUsage: ReadonlyArray<ModelCallUsage>;
}

const projectedResponseUsage = (
  response: ModelResponseRecorded,
): Effect.Effect<ProjectedResponseUsage, RunJournalError> =>
  Effect.gen(function* () {
    const calls = response.modelUsage;

    if (calls === undefined) {
      return {
        modelCalls: 1,
        inputTokens: response.inputTokens ?? 0,
        outputTokens: response.outputTokens ?? 0,
        costMicrousd: response.costMicrousd ?? 0,
        modelUsage: [],
      };
    }
    if (calls.length === 0) {
      return yield* journalError("A canonical modelUsage list must not be empty");
    }

    const summary = yield* summarizeModelUsage(calls).pipe(
      Effect.mapError((cause) =>
        journalError("Canonical model usage exceeds accounting bounds", cause),
      ),
    );

    if (
      (response.inputTokens !== undefined && response.inputTokens !== summary.inputTokens.total) ||
      (response.outputTokens !== undefined &&
        response.outputTokens !== summary.outputTokens.total) ||
      (response.costMicrousd !== undefined && response.costMicrousd !== summary.costMicrousd)
    ) {
      return yield* journalError("Canonical detailed and aggregate model usage disagree");
    }

    return {
      modelCalls: summary.modelCalls,
      inputTokens: summary.inputTokens.total,
      outputTokens: summary.outputTokens.total,
      costMicrousd: summary.costMicrousd,
      modelUsage: calls,
    };
  });

const addProjectedUsage = (
  field: string,
  left: number,
  right: number,
): Effect.Effect<number, RunJournalError> =>
  Schema.decodeEffect(Schema.Natural)(left + right).pipe(
    Effect.mapError((cause) =>
      journalError(`Canonical projected usage exceeds safe-integer bounds at ${field}`, cause),
    ),
  );

interface FoldState {
  readonly all: Array<Prompt.Message>;
  readonly before: Array<Prompt.Message>;
  readonly pendingTools: Array<PendingSettledTool>;
  readonly pendingToolsForRun: boolean;
  readonly committedTurns: number;
}

const decodeToolCallId = Schema.decodeSync(ToolCallId);

const declaredApplicationToolCallIds = (prompt: Prompt.Prompt): ReadonlyArray<string> => {
  const ids: Array<string> = [];

  for (const message of prompt.content) {
    if (message.role !== "assistant") continue;
    for (const part of message.content) {
      if (part.type === "tool-call" && !part.providerExecuted) ids.push(part.id);
    }
  }

  return ids;
};

/**
 * Phase 5 audit tags that are prompt-transparent: they carry durability evidence (preparation,
 * unknown marking, resolution, Step results, approvals, interruption) but contribute nothing to
 * the model-visible Prompt, and — unlike the P4 tags — they do NOT split a contiguous
 * `ToolCallSettled` group into separate Tool messages, so a late-settled call's audit records
 * cannot change the replayed prompt shape.
 *
 * The four S2 Subagent lifecycle tags are prompt-transparent for the same reason (spec §5/§11):
 * the parent prompt never carries child transcript or establishment evidence — the joined child
 * result reaches the model exclusively through the paired `ToolCallSettled` record, and the
 * child-log lineage record is not model input.
 */
const PROMPT_TRANSPARENT_TAGS: ReadonlySet<string> = new Set([
  "RunPolicyUsageReserved",
  "RunStarted",
  "RunDurationExhausted",
  "ToolCallPrepared",
  "ToolCallUnknown",
  "ToolCallResolved",
  "ToolStepSettled",
  "ToolApprovalRequested",
  "ToolApprovalDecided",
  "ModelResponseInterrupted",
  "ModelCallAborted",
  "SubagentRequested",
  "SubagentStarted",
  "SubagentJoined",
  "SubagentLineageRecorded",
  "WorkerInputRequested",
  "WorkerOriginRecorded",
  "WorkerInputCompleted",
  "WorkerReportPrepared",
  "AgentUpdateEmitted",
  "WorkerReportRefused",
  "PeerMessagePrepared",
  "SubtreeBudgetReserved",
]);

/**
 * Pure projection: rebuild one Run's resume state from canonical records (DUR-015). Canonical
 * order is authoritative; the fold projects each `ModelResponseRecorded` Turn and the
 * owning Run's resumable incomplete Tool Turn. It flushes each contiguous group of valid `ToolCallSettled` records into one Tool message,
 * exactly mirroring the per-Turn commit shape produced by `turnCanonicalBatch` (no-tool Turns) and
 * by the
 * `turnResponseBatch`/`turnResultsBatch` split (tool-declaring Turns). The Phase 5 audit tags
 * are skipped transparently, so split-batch commits replay to the same prompt as P4 single-batch
 * commits.
 *
 * An incomplete application Tool turn remains visible while projecting its owning Run so active
 * recovery can resume the declared batch. It is not a valid model-visible Turn boundary for a
 * later Run until model-only unknown results close its missing calls. Those explanatory results
 * are never canonical settlements or evidence for compaction, recovery or accounting. Real
 * results replace them at the original declaration, including results appended after another Run.
 * Prior user intent and assistant text remain visible; prior system instructions do not.
 * Each Run retains the history preceding its start and its own continuation. Other Runs'
 * subsequent Turns cannot replace its input. Compaction covers only its creator's Run view;
 * a projection without an owner retains interleaved exchanges from the complete Thread history.
 */
/** @internal Lightweight canonical boundaries collected without retaining record payloads. */
export interface JournalBoundary {
  readonly sequence: CanonicalSequence;
  readonly tag: "ModelResponseRecorded" | "ToolCallSettled";
  readonly promptLength: number;
  /** A declaration without all settled results requires terminal-prior-Run proof for coverage. */
  readonly incomplete?: true | undefined;
  /** The Run terminated after its last response and differs from the projection's owner. */
  readonly terminalPriorRun?: true | undefined;
}

/**
 * Reconstruct a fixed canonical prefix from a re-readable stream. The caller must keep the same
 * records visible on every traversal. The first collects compaction and settlement metadata;
 * rollovers additionally validate covered Tool batches before rebuilding Prompt and usage. Metadata and the
 * live Prompt remain resident; covered historical message/tool payloads do not. An uncompacted Prompt still grows
 * with its conversation, so hosts must configure an appropriate context compaction policy.
 * Prepared metadata must describe exactly this stream and seed through the same fixed tail;
 * it skips only the metadata scan, never covered-Tool validation or the canonical fold.
 * @internal
 */
export const projectRunJournalStream = Effect.fn("RunJournal.projectRunJournalStream")(function* <
  E,
  R,
>(
  records: Stream.Stream<CanonicalRecordEnvelope, E, R>,
  ownerRunId: RunId | undefined,
  onBoundary?: (boundary: JournalBoundary) => void,
  seed?: JournalCheckpointSeed,
  preparedMetadata?: JournalMetadata,
  priorContext?: ThreadContextCheckpoint,
): Effect.fn.Return<RunJournalProjection, RunJournalError | E, R> {
  if (seed !== undefined && seed.runId !== ownerRunId)
    return yield* journalError("Recovery checkpoint belongs to another Run");
  if (seed !== undefined && priorContext !== undefined)
    return yield* journalError("Run recovery and prior Thread context cannot seed the same replay");

  const historical =
    priorContext === undefined ? [] : (yield* decodePromptMessages(priorContext.prompt)).content;

  let state: FoldState = {
    all: [...historical],
    before: [...historical],
    pendingTools: [],
    pendingToolsForRun: false,
    committedTurns: seed?.committedTurns ?? 0,
  };

  // RUN-026 pre-scan: valid compactions retire only their creator's Run view. A bound
  // stays below its own sequence and cannot split a visible response from its settled results.
  // Pruning and rollovers may cover complete owner-Run batches; a summarize record carries
  // its summary. Invalid records leave full history authoritative. A wider containing view
  // replaces earlier coverage, with equal bounds preferring the later record.
  // One span per settled record, paired with its declaring response the same
  // way the fold pairs them: a settled belongs to the most recent
  // ModelResponseRecorded of its Run. A bound inside (response, settled)
  // would orphan the tool message from its declaring response. Orphaned
  // settleds (filtered later by the fold) still contribute spans —
  // over-invalidating is the fail-safe direction.
  if (
    preparedMetadata !== undefined &&
    (preparedMetadata.ownerRunId !== ownerRunId || preparedMetadata.seed !== seed)
  )
    return yield* journalError("Prepared journal metadata belongs to another replay");

  let metadata = preparedMetadata;

  if (metadata === undefined) {
    const collected = makeJournalMetadata(ownerRunId, seed);

    yield* Stream.runForEach(records, (envelope) => Effect.sync(() => collected.add(envelope)));
    metadata = collected.snapshot();
  }

  const {
    firstSequenceByRun,
    lastResponseSequenceByRun,
    terminalSequenceByRun,
    settledSpans,
    toolExecutionEvidence,
    settledToolCallRecordIds,
    settledById,
  } = metadata;

  const declarationByResultSequence = new Map(settledSpans.map(({ from, to }) => [to, from]));

  const isInRunView = (
    sequence: number,
    payload: { readonly _tag: string; readonly runId?: RunId | undefined },
    runId: RunId | undefined,
  ): boolean => {
    if (runId === undefined || payload.runId === undefined || payload.runId === runId) return true;
    const first = firstSequenceByRun.get(runId) ?? Number.POSITIVE_INFINITY;

    return (
      sequence < first ||
      (payload._tag === "ToolCallSettled" &&
        (declarationByResultSequence.get(sequence) ?? Number.POSITIVE_INFINITY) < first)
    );
  };

  const compactions = metadata.compactions.filter(({ sequence, payload }) =>
    isInRunView(sequence, payload, ownerRunId),
  );

  if (priorContext !== undefined && compactions.length > 0)
    return yield* journalError("New compaction requires the complete canonical context mapping");

  const recordsForRun = records.pipe(
    Stream.filter(({ sequence, record: { payload } }) =>
      isInRunView(sequence, payload, ownerRunId),
    ),
  );

  const isCovered = (envelope: CanonicalRecordEnvelope, compaction: CompactionCreated): boolean =>
    envelope.sequence <= compaction.coversThrough &&
    isInRunView(envelope.sequence, envelope.record.payload, compaction.runId);

  const settledCoverage = compactions.reduce(
    (through, { payload }) =>
      payload.kind !== "summarize" ? Math.max(through, payload.coversThrough) : through,
    0,
  );

  // Terminality changes only prompt coverage; it never settles or resolves the Tool Call.
  // Compare against the compaction's Run and sequence, independent of the replay's owner.
  const isTerminalPriorRun = (
    candidateRunId: RunId,
    compactionRunId: RunId | undefined,
    beforeSequence: number,
  ): boolean => {
    const terminal = terminalSequenceByRun.get(candidateRunId);

    return (
      candidateRunId !== compactionRunId &&
      terminal !== undefined &&
      terminal < beforeSequence &&
      terminal > (lastResponseSequenceByRun.get(candidateRunId) ?? 0)
    );
  };

  const incompleteResponseSequences: Array<{ readonly sequence: number; readonly runId: RunId }> =
    [];

  let ownerPrefixSequence = seed?.firstSequence ?? Number.POSITIVE_INFINITY;

  let protectedContext: Prompt.Prompt | undefined =
    seed?.protectedContext === undefined
      ? undefined
      : yield* decodePromptMessages(seed.protectedContext);

  if (settledCoverage > 0) {
    yield* Stream.runForEach(recordsForRun, (envelope) =>
      Effect.gen(function* () {
        const payload = envelope.record.payload;

        if (payload._tag !== "ModelResponseRecorded" || envelope.sequence > settledCoverage) return;
        const messages = yield* decodePromptMessages(payload.messages);
        const declared = declaredApplicationToolCallIds(messages);

        for (const id of declared) {
          const callId = yield* Schema.decodeEffect(ToolCallId)(id).pipe(
            Effect.mapError((cause) =>
              journalError("Failed to decode a declared Tool Call ID", cause),
            ),
          );

          if (
            !settledToolCallRecordIds.has(
              toolCallSettledRecordId(payload.runId, payload.turn, callId),
            )
          ) {
            incompleteResponseSequences.push({ sequence: envelope.sequence, runId: payload.runId });
            break;
          }
        }
        if (
          payload.runId === ownerRunId &&
          payload.turn === 1 &&
          payload.runScopedPrefixLength !== undefined
        ) {
          ownerPrefixSequence = envelope.sequence;
          protectedContext = Prompt.fromMessages(
            messages.content.slice(0, payload.runScopedPrefixLength),
          );
        }
      }),
    );
  }

  const boundIsValid = (payload: CompactionCreated, ownSequence: number): boolean => {
    const { runId, coversThrough } = payload;

    if (coversThrough <= 0 || coversThrough >= ownSequence) return false;
    if (seed !== undefined && ownSequence === seed.compaction.sequence)
      return (
        seed.compaction.record.payload._tag === "CompactionCreated" &&
        Schema.toEquivalence(CompactionCreated)(payload, seed.compaction.record.payload)
      );
    const ownerFirst = firstSequenceByRun.get(runId);

    if (payload.kind === "summarize" && ownerFirst !== undefined && coversThrough >= ownerFirst)
      return false;
    if (
      payload.kind !== "summarize" &&
      incompleteResponseSequences.some(
        (response) =>
          response.sequence <= coversThrough &&
          isInRunView(
            response.sequence,
            { _tag: "ModelResponseRecorded", runId: response.runId },
            runId,
          ) &&
          !isTerminalPriorRun(response.runId, runId, ownSequence),
      )
    )
      return false;
    for (const span of settledSpans) {
      if (
        span.from <= coversThrough &&
        coversThrough < span.to &&
        isInRunView(span.from, { _tag: "ModelResponseRecorded", runId: span.runId }, runId)
      )
        return false;
    }

    return true;
  };

  type CompactionView = (typeof compactions)[number];

  let replacements: ReadonlyArray<CompactionView> = [];
  let clearings: ReadonlyArray<CompactionView> = [];

  const retainCompaction = (views: ReadonlyArray<CompactionView>, next: CompactionView) => {
    // Independent Run views overlap without containing one another. Retire an overlay only
    // when the replacement actually contains its view, not merely a larger sequence number.
    if (
      views.some(
        (prior) =>
          prior.payload.coversThrough > next.payload.coversThrough &&
          isInRunView(next.sequence, next.payload, prior.payload.runId),
      )
    )
      return views;

    return [
      ...views.filter(
        (prior) =>
          next.payload.coversThrough < prior.payload.coversThrough ||
          !isInRunView(prior.sequence, prior.payload, next.payload.runId),
      ),
      next,
    ];
  };

  let latestWindowId: string | undefined = seed?.contextWindowId ?? priorContext?.contextWindowId;
  let latestWindowSequence = seed?.throughSequence ?? -1;
  let rolloverCoveredThrough = 0;

  for (const { payload, sequence } of compactions) {
    if (!boundIsValid(payload, sequence)) continue;
    if (payload.kind === "rollover" && sequence > latestWindowSequence) {
      latestWindowId = contextWindowId(payload.runId, payload.turn);
      latestWindowSequence = sequence;
    }
    if (payload.kind === "rollover")
      rolloverCoveredThrough = Math.max(rolloverCoveredThrough, payload.coversThrough);
    if (payload.kind === "summarize" || payload.kind === "rollover") {
      if (payload.kind === "summarize" && payload.summary === undefined) continue;
      replacements = retainCompaction(replacements, { payload, sequence });
    } else clearings = retainCompaction(clearings, { payload, sequence });
  }
  let summaryEmitted = false;

  const retainedPrefix = replacements.some(
    ({ payload }) =>
      payload.kind === "rollover" &&
      payload.runId === ownerRunId &&
      ownerPrefixSequence <= payload.coversThrough,
  )
    ? (protectedContext?.content ?? [])
    : [];

  const replacementLength = retainedPrefix.length + replacements.length;

  if (seed?.frontier !== undefined)
    onBoundary?.({ ...seed.frontier, promptLength: replacementLength });

  const emitSummary = () => {
    if (summaryEmitted || replacements.length === 0) return;
    summaryEmitted = true;
    state.all.push(...retainedPrefix);
    for (const { payload: replacement } of replacements) {
      const message =
        replacement.kind === "rollover"
          ? contextWindowMessage(
              contextWindowId(replacement.runId, replacement.turn),
              replacement.handoff,
            )
          : Prompt.makeMessage("user", {
              content: [
                Prompt.makePart("text", {
                  text: `${COMPACTION_SUMMARY_PREFIX}${replacement.summary}`,
                }),
              ],
            });

      state.all.push(message);
      if (replacement.kind !== "rollover" || replacement.runId !== ownerRunId)
        state.before.push(message);
    }
  };

  const modelUsage: Array<ModelCallUsage> = [];
  let unobservedModelCalls = seed?.unobservedModelCalls ?? 0;

  const usage = {
    modelCalls: seed?.modelCalls ?? 0,
    inputTokens: seed?.inputTokens ?? 0,
    outputTokens: seed?.outputTokens ?? 0,
    lastInputTokens: seed?.lastInputTokens ?? 0,
    lastOutputTokens: seed?.lastOutputTokens ?? 0,
    costMicrousd: seed?.costMicrousd ?? 0,
    modelUsage,
    ...(seed === undefined ? {} : { summarizedModelUsage: seed.summarizedModelUsage }),
  };

  let toolSelection = seed?.toolSelection;
  let usageTurn = seed?.committedTurns ?? 0;

  const incompleteToolTurns = new Set<string>();
  const incompleteToolCalls = new Set<string>();
  let pendingContextToolCallId: string | undefined;
  let ownerTerminated = false;

  const policyUsage = {
    committedTurns: seed?.policyUsage.committedTurns ?? 0,
    toolCalls: seed?.policyUsage.toolCalls ?? 0,
    programmaticToolCalls: seed?.policyUsage.programmaticToolCalls ?? 0,
    consecutiveToolFailures: seed?.policyUsage.consecutiveToolFailures ?? 0,
    finalizationUsed: seed?.policyUsage.finalizationUsed ?? false,
    modelRestarts: seed?.policyUsage.modelRestarts ?? 0,
  };

  const accountResponse = Effect.fn("RunJournal.accountResponse")(function* (
    envelope: CanonicalRecordEnvelope,
    payload: ModelResponseRecorded,
    messages: Prompt.Prompt,
  ) {
    const record = envelope.record;

    const declared = declaredApplicationToolCallIds(messages);
    const declaredRecordIds: Array<RecordId> = [];

    for (const id of declared) {
      const toolCallId = yield* Effect.try({
        try: () => decodeToolCallId(id),
        catch: (cause) => journalError("Failed to decode a declared Tool Call ID", cause),
      });

      declaredRecordIds.push(toolCallSettledRecordId(payload.runId, payload.turn, toolCallId));
    }
    if (declaredRecordIds.some((recordId) => !settledToolCallRecordIds.has(recordId))) {
      incompleteToolTurns.add(envelope.record.recordId);
      for (const recordId of declaredRecordIds) incompleteToolCalls.add(recordId);
    }
    if (payload.runId !== ownerRunId) return;
    if (seed !== undefined && envelope.sequence <= seed.throughSequence) return;
    if (payload.turn === 1 && payload.runScopedPrefixLength !== undefined) {
      protectedContext = Prompt.fromMessages(
        messages.content.slice(0, payload.runScopedPrefixLength),
      );
    }

    const responseUsage = yield* projectedResponseUsage(payload);

    unobservedModelCalls = yield* addProjectedUsage(
      "unobservedModelCalls",
      unobservedModelCalls,
      payload.unobservedModelCalls ?? 0,
    );

    usage.modelCalls = yield* addProjectedUsage(
      "modelCalls",
      usage.modelCalls,
      responseUsage.modelCalls,
    );
    usage.inputTokens = yield* addProjectedUsage(
      "inputTokens",
      usage.inputTokens,
      responseUsage.inputTokens,
    );
    usage.outputTokens = yield* addProjectedUsage(
      "outputTokens",
      usage.outputTokens,
      responseUsage.outputTokens,
    );
    usage.costMicrousd = yield* addProjectedUsage(
      "costMicrousd",
      usage.costMicrousd,
      responseUsage.costMicrousd,
    );
    usage.modelUsage.push(...responseUsage.modelUsage);
    if (payload.turn > usageTurn) {
      usageTurn = payload.turn;
      usage.lastInputTokens = responseUsage.inputTokens;
      usage.lastOutputTokens = responseUsage.outputTokens;
    }

    policyUsage.committedTurns = Math.max(policyUsage.committedTurns, payload.turn);

    const calls = messages.content.flatMap((message) =>
      message.role === "assistant"
        ? message.content.filter((part) => part.type === "tool-call")
        : [],
    );

    const candidate = calls.length === 1 ? calls[0] : undefined;

    const candidateResult =
      candidate === undefined
        ? undefined
        : settledById.get(`tool-settled:${ownerRunId}:${payload.turn}:${candidate.id}`);

    pendingContextToolCallId =
      candidate !== undefined &&
      !candidate.providerExecuted &&
      candidateResult?.isFailure === false &&
      candidateResult.budgetRejected !== true &&
      envelope.sequence > rolloverCoveredThrough
        ? candidate.id
        : undefined;

    policyUsage.toolCalls += calls.length;
    if (payload.toolExposure !== undefined) toolSelection = payload.toolExposure.selection;
    if (incompleteToolTurns.has(record.recordId)) return;
    for (const call of calls) {
      const result = call.providerExecuted
        ? messages.content
            .flatMap((message) => (message.role === "assistant" ? message.content : []))
            .find(
              (part) => part.type === "tool-result" && part.providerExecuted && part.id === call.id,
            )
        : settledById.get(`tool-settled:${ownerRunId}:${payload.turn}:${call.id}`);

      if (result === undefined || ("budgetRejected" in result && result.budgetRejected === true))
        continue;
      if (!("isFailure" in result)) continue;
      if (!result.isFailure && "toolSelection" in result && result.toolSelection !== undefined)
        toolSelection = result.toolSelection;
      policyUsage.consecutiveToolFailures = result.isFailure
        ? policyUsage.consecutiveToolFailures + 1
        : 0;
    }
  });

  // Slots refer to the retained Prompt itself, not an additional history payload index.
  // Only still-unseen results retain a slot; late results fill the original declaration in place.
  const historicalResults = new Map<
    string,
    {
      readonly allIndex: number;
      readonly beforeIndex: number;
      readonly parts: Array<Prompt.ToolResultPart>;
      readonly partIndex: number;
    }
  >();

  let pendingToolOrder = new Map<string, number>();

  const flushTools = Effect.fnUntraced(function* (
    current: FoldState,
  ): Effect.fn.Return<FoldState, RunJournalError> {
    if (current.pendingTools.length === 0) return current;

    // Suspension can persist an ordinary sibling before a delegated call joins. Model context
    // still uses declaration order, matching the live interpreter's completed results batch.
    const ordered = current.pendingTools.toSorted(
      (left, right) =>
        (pendingToolOrder.get(left.record.toolCallId) ?? Number.MAX_SAFE_INTEGER) -
        (pendingToolOrder.get(right.record.toolCallId) ?? Number.MAX_SAFE_INTEGER),
    );

    const toolMessage = yield* toolMessageFromSettled(ordered);

    current.all.push(toolMessage);
    if (!current.pendingToolsForRun) current.before.push(toolMessage);

    return {
      ...current,
      pendingTools: [],
      pendingToolsForRun: false,
    };
  });

  yield* Stream.runForEach(recordsForRun, (envelope) =>
    Effect.gen(function* () {
      const payload = envelope.record.payload;

      if (
        ((payload._tag === "RunCompleted" || payload._tag === "RunFailed") &&
          payload.runId === ownerRunId) ||
        (payload._tag === "SubmissionSettled" &&
          runIdForSubmission(payload.submissionId) === ownerRunId)
      )
        ownerTerminated = true;

      if (payload._tag === "RunPolicyUsageReserved" && payload.runId === ownerRunId) {
        if (seed !== undefined && envelope.sequence <= seed.throughSequence) return;
        if (
          payload.programmaticToolCalls < policyUsage.programmaticToolCalls ||
          (policyUsage.finalizationUsed && !payload.finalizationUsed)
        ) {
          return yield* journalError("Run policy reservations must be monotonic");
        }
        policyUsage.programmaticToolCalls = payload.programmaticToolCalls;
        policyUsage.finalizationUsed = payload.finalizationUsed;
      }
      if (payload._tag === "ModelCallAborted" && payload.runId === ownerRunId) {
        if (seed !== undefined && envelope.sequence <= seed.throughSequence) return;
        if (payload.restart !== policyUsage.modelRestarts + 1)
          return yield* journalError("Model restart reservations must advance once");
        policyUsage.modelRestarts = payload.restart;

        const summary = yield* summarizeModelUsage(payload.modelUsage).pipe(
          Effect.mapError((cause) =>
            journalError("Aborted model usage exceeds accounting bounds", cause),
          ),
        );

        usage.modelCalls = yield* addProjectedUsage(
          "modelCalls",
          usage.modelCalls,
          summary.modelCalls,
        );
        usage.inputTokens = yield* addProjectedUsage(
          "inputTokens",
          usage.inputTokens,
          summary.inputTokens.total,
        );
        usage.outputTokens = yield* addProjectedUsage(
          "outputTokens",
          usage.outputTokens,
          summary.outputTokens.total,
        );
        usage.costMicrousd = yield* addProjectedUsage(
          "costMicrousd",
          usage.costMicrousd,
          summary.costMicrousd,
        );
        usage.modelUsage.push(...payload.modelUsage);
        unobservedModelCalls = yield* addProjectedUsage(
          "unobservedModelCalls",
          unobservedModelCalls,
          payload.unobservedModelCalls,
        );
      }
      if (PROMPT_TRANSPARENT_TAGS.has(payload._tag)) return;
      // The compaction record governs the fold (pre-scan) and contributes no
      // message of its own; records at or below the summarize bound render as
      // the one summary message emitted at the covered/kept transition.
      if (payload._tag === "CompactionCreated") return;
      if (
        seed !== undefined &&
        envelope.sequence <= seed.throughSequence &&
        (payload._tag === "ModelResponseRecorded" || payload._tag === "ToolCallSettled")
      )
        return;
      if (replacements.some(({ payload }) => isCovered(envelope, payload))) {
        // Retiring Prompt payloads does not retire the owning Run's policy or usage accounting.
        if (payload._tag === "ModelResponseRecorded" && payload.runId === ownerRunId) {
          const messages = yield* decodePromptMessages(payload.messages);

          yield* accountResponse(envelope, payload, messages);
          state = { ...state, committedTurns: Math.max(state.committedTurns, payload.turn) };
        }
        if (payload._tag === "ModelResponseRecorded" || payload._tag === "ToolCallSettled") {
          onBoundary?.({
            sequence: envelope.sequence,
            tag: payload._tag,
            promptLength: Math.max(replacementLength, state.all.length),
            ...(isTerminalPriorRun(payload.runId, ownerRunId, Number.POSITIVE_INFINITY)
              ? { terminalPriorRun: true }
              : {}),
            ...(incompleteToolTurns.has(envelope.record.recordId) ||
            incompleteToolCalls.has(envelope.record.recordId)
              ? { incomplete: true }
              : {}),
          });
        }

        return;
      }
      emitSummary();
      if (payload._tag === "ToolCallSettled") {
        if (payload.runId !== ownerRunId) {
          const slot = historicalResults.get(envelope.record.recordId);

          if (slot === undefined)
            return yield* journalError("Historical Tool result has no matching declaration");
          const declared = slot.parts[slot.partIndex];

          if (declared?.id !== payload.toolCallId || declared.name !== payload.toolName)
            return yield* journalError("Historical Tool result differs from its declaration");
          slot.parts[slot.partIndex] = Prompt.makePart("tool-result", {
            id: payload.toolCallId,
            name: payload.toolName,
            result: clearings.some(({ payload }) => isCovered(envelope, payload))
              ? CLEARED_TOOL_RESULT
              : payload.result,
            isFailure: payload.isFailure,
            providerExecuted: false,
          });
          const message = Prompt.makeMessage("tool", { content: [...slot.parts] });

          state.all[slot.allIndex] = message;
          state.before[slot.beforeIndex] = message;
          historicalResults.delete(envelope.record.recordId);
          onBoundary?.({
            sequence: envelope.sequence,
            tag: payload._tag,
            promptLength: state.all.length,
            ...(incompleteToolCalls.has(envelope.record.recordId) ? { incomplete: true } : {}),
            ...(isTerminalPriorRun(payload.runId, ownerRunId, Number.POSITIVE_INFINITY)
              ? { terminalPriorRun: true }
              : {}),
          });

          return;
        }
        if (
          state.pendingTools.length > 0 &&
          state.pendingToolsForRun !== (payload.runId === ownerRunId)
        ) {
          state = yield* flushTools(state);
        }
        state.pendingTools.push({
          record: payload,
          cleared: clearings.some(({ payload }) => isCovered(envelope, payload)),
        });
        state = {
          ...state,
          pendingToolsForRun: payload.runId === ownerRunId,
        };
        onBoundary?.({
          sequence: envelope.sequence,
          tag: payload._tag,
          promptLength: state.all.length + 1,
          ...(isTerminalPriorRun(payload.runId, ownerRunId, Number.POSITIVE_INFINITY)
            ? { terminalPriorRun: true }
            : {}),
          ...(incompleteToolCalls.has(envelope.record.recordId) ? { incomplete: true } : {}),
        });

        return;
      }
      state = yield* flushTools(state);
      if (payload._tag === "ModelCompleted" && payload.messages !== undefined) {
        const messages = yield* decodePromptMessages(payload.messages);

        for (const message of messages.content) {
          state.all.push(message);
          if (payload.runId !== ownerRunId) state.before.push(message);
        }

        return;
      }
      if (payload._tag !== "ModelResponseRecorded") return;
      const messages = yield* decodePromptMessages(payload.messages);
      const forRun = payload.runId === ownerRunId;

      pendingToolOrder = new Map(
        declaredApplicationToolCallIds(messages).map((id, index) => [id, index]),
      );

      yield* accountResponse(envelope, payload, messages);

      const visibleMessages = forRun
        ? messages.content
        : messages.content.filter((message) => message.role !== "system");

      for (const message of visibleMessages) {
        state.all.push(message);
        if (!forRun) state.before.push(message);
      }
      if (!forRun) {
        const calls = messages.content.flatMap((message) =>
          message.role === "assistant"
            ? message.content.filter(
                (part): part is Prompt.ToolCallPart =>
                  part.type === "tool-call" && !part.providerExecuted,
              )
            : [],
        );

        if (calls.length > 0) {
          const parts = yield* Effect.forEach(calls, (call) =>
            Effect.gen(function* () {
              const callId = yield* Schema.decodeEffect(ToolCallId)(call.id).pipe(
                Effect.mapError((cause) => journalError("Invalid historical Tool Call ID", cause)),
              );

              const operation = payload.toolOperations?.find(
                (operation) => operation.toolCallId === callId && operation.toolName === call.name,
              );

              // Only the recorded execution contract can prove that dispatch required a
              // preparation. Ordinary readonly calls may execute without one.
              const notExecuted =
                operation !== undefined &&
                (operation.executionClass !== "readonly" ||
                  operation.executionKind !== "ordinary") &&
                !toolExecutionEvidence.has(
                  toolExecutionKey({
                    runId: payload.runId,
                    turn: payload.turn,
                    toolCallId: callId,
                  }),
                );

              return Prompt.makePart("tool-result", {
                id: call.id,
                name: call.name,
                result: notExecuted
                  ? {
                      _tag: "ToolUnavailable",
                      toolName: call.name,
                      execution: "not-executed",
                      message:
                        "This earlier call never reached durable preparation and was not executed.",
                    }
                  : {
                      _tag: "ToolOutcomeUnknown",
                      message:
                        "This earlier operation has no recorded outcome. It may have executed. Do not assume success or retry it; its original operation remains unresolved.",
                    },
                isFailure: true,
                providerExecuted: false,
              });
            }),
          );

          const allIndex = state.all.length;
          const beforeIndex = state.before.length;
          const message = Prompt.makeMessage("tool", { content: parts });

          state.all.push(message);
          state.before.push(message);
          for (const [partIndex, call] of calls.entries()) {
            const callId = yield* Schema.decodeEffect(ToolCallId)(call.id).pipe(
              Effect.mapError((cause) => journalError("Invalid historical Tool Call ID", cause)),
            );

            historicalResults.set(toolCallSettledRecordId(payload.runId, payload.turn, callId), {
              allIndex,
              beforeIndex,
              parts,
              partIndex,
            });
          }
        }
      }
      state = {
        ...state,
        committedTurns: forRun
          ? Math.max(state.committedTurns, payload.turn)
          : state.committedTurns,
      };
      onBoundary?.({
        sequence: envelope.sequence,
        tag: payload._tag,
        promptLength: state.all.length,
        ...(isTerminalPriorRun(payload.runId, ownerRunId, Number.POSITIVE_INFINITY)
          ? { terminalPriorRun: true }
          : {}),
        ...(incompleteToolTurns.has(envelope.record.recordId) ? { incomplete: true } : {}),
      });
    }),
  );
  emitSummary();
  state = yield* flushTools(state);

  const validatedPolicyUsage = yield* Schema.decodeEffect(RunPolicyUsage)(policyUsage).pipe(
    Effect.mapError((cause) =>
      journalError("Run policy accounting exceeds its Schema bounds", cause),
    ),
  );

  return {
    ...(toolSelection === undefined ? {} : { toolSelection }),
    policyUsage: validatedPolicyUsage,
    prompt: Prompt.fromMessages(state.all),
    historyBefore: Prompt.fromMessages(state.before),
    committedTurns: state.committedTurns,
    usage: unobservedModelCalls === 0 ? usage : { ...usage, unobservedModelCalls },
    ...(latestWindowId === undefined ? {} : { contextWindowId: latestWindowId }),
    ...(protectedContext === undefined ? {} : { protectedContext }),
    ...(ownerTerminated || pendingContextToolCallId === undefined
      ? {}
      : { pendingContextToolCallId }),
  };
});

/** Pure projection of one Run's durable recovery state from canonical records. */
export const projectRunJournal = Effect.fn("RunJournal.projectRunJournal")(
  (
    records: ReadonlyArray<CanonicalRecordEnvelope>,
    runId: RunId,
  ): Effect.Effect<RunJournalProjection, RunJournalError> =>
    projectRunJournalStream(Stream.fromIterable(records), runId),
);

/**
 * Pure valid-prompt projection from canonical records: `UserInputRecorded` +
 * `ModelResponseRecorded` + complete `ToolCallSettled` batches → the deterministic model-visible
 * Prompt (plan §Coordinator flow step 3).
 */
export const promptFromCanonicalRecords = Effect.fn("RunJournal.promptFromCanonicalRecords")(
  (
    records: ReadonlyArray<CanonicalRecordEnvelope>,
  ): Effect.Effect<Prompt.Prompt, RunJournalError> =>
    projectRunJournalStream(Stream.fromIterable(records), undefined).pipe(
      Effect.map((projection) => projection.prompt),
    ),
);

/** Everything one committed Turn contributes to its canonical batch. */
/**
 * Staged usage is validated, never repaired: clamping negatives or truncating
 * fractions would under-record canonical usage, and NaN/Infinity must fail
 * typed instead of escaping as a record-construction defect (RUN-023).
 */
const validStagedUsage = (label: string, value: number): Effect.Effect<number, RunJournalError> =>
  Number.isSafeInteger(value) && value >= 0
    ? Effect.succeed(value)
    : Effect.fail(
        journalError(`Staged ${label} must be a non-negative safe integer, got ${String(value)}`),
      );

export interface TurnCommitInput {
  readonly toolOperations?: ModelResponseRecorded["toolOperations"] | undefined;
  readonly toolParameterRejections?: ReadonlyArray<ToolParameterRejection> | undefined;
  readonly toolExposure?: Snapshot | undefined;
  readonly toolSelections?: ReadonlyMap<string, Selection> | undefined;
  readonly budgetRejectedCalls?: ReadonlySet<string>;
  readonly runId: RunId;
  /** Canonical (Run-relative, Attempt-independent) Turn number; must be positive. */
  readonly turn: number;
  readonly turnId: TurnId;
  /**
   * The Prompt messages this Turn appended to official history, in order, including the Turn's
   * Tool message when application Tools ran. Tool messages become `ToolCallSettled` records; the
   * remaining messages become the Turn's `ModelResponseRecorded.messages`.
   */
  readonly appended: ReadonlyArray<Prompt.Message>;
  readonly producerId: ProducerId;
  readonly deploymentId: DeploymentId;
  readonly createdAt: DateTime.Utc;
  /** Leading instruction/wake messages that stay canonical but are hidden from later Runs. */
  readonly runScopedPrefixLength?: number | undefined;
  /** Terminal output committed atomically with this Turn's final canonical batch. */
  readonly runCompletion?:
    | {
        readonly output: PersistedJson;
        readonly runDisposition?: PersistedJson | undefined;
        readonly finishReason?: "budget-exhausted" | undefined;
        readonly exhausted?: ExhaustedLimit | undefined;
      }
    | undefined;
  /** Known missing-accounting invocations staged before this canonical response. */
  readonly unobservedModelCalls?: number | undefined;
  /** Per-call provider usage staged by the engine's `noteTurnUsage` (RUN-023). */
  readonly usage?:
    | {
        readonly inputTokens: number;
        readonly outputTokens: number;
        readonly costMicrousd?: number | undefined;
        readonly modelUsage?: ReadonlyArray<ModelCallUsage> | undefined;
      }
    | undefined;
}

const decodePersistedJson = Schema.decodeUnknownEffect(PersistedJson);
const encodePrompt = Schema.encodeEffect(Prompt.Prompt);
const decodeModelUsage = Schema.decodeUnknownEffect(Schema.Array(ModelCallUsage));

const requireCanonicalTurn = (turn: number): Effect.Effect<void, RunJournalError> =>
  !Number.isInteger(turn) || turn <= 0
    ? Effect.fail(journalError(`Canonical turn number must be a positive integer: ${turn}`))
    : Effect.void;

interface SplitTurnMessages {
  readonly promptMessages: ReadonlyArray<Prompt.Message>;
  readonly toolParts: ReadonlyArray<Prompt.ToolResultPart>;
}

const splitTurnMessages = (appended: ReadonlyArray<Prompt.Message>): SplitTurnMessages => {
  const promptMessages: Array<Prompt.Message> = [];
  const toolParts: Array<Prompt.ToolResultPart> = [];

  for (const message of appended) {
    if (message.role !== "tool") {
      promptMessages.push(message);
      continue;
    }
    for (const part of message.content) {
      if (part.type !== "tool-result") continue;
      toolParts.push(part);
    }
  }

  return { promptMessages, toolParts };
};

const modelResponseRecord = Effect.fn("RunJournal.modelResponseRecord")(function* (
  input: TurnCommitInput,
  promptMessages: ReadonlyArray<Prompt.Message>,
): Effect.fn.Return<RecordEnvelope, RunJournalError | DigestError, Crypto.Crypto> {
  if (promptMessages.length === 0) {
    return yield* journalError(`Turn ${input.turn} appended no model-visible Prompt messages`);
  }
  const runScopedPrefixLength = input.runScopedPrefixLength;

  if (
    runScopedPrefixLength !== undefined &&
    (input.turn !== 1 ||
      !Number.isSafeInteger(runScopedPrefixLength) ||
      runScopedPrefixLength <= 0 ||
      runScopedPrefixLength >= promptMessages.length ||
      promptMessages
        .slice(0, runScopedPrefixLength)
        .some((message) => message.role !== "system" && message.role !== "user"))
  ) {
    return yield* journalError(
      "Run-scoped Prompt provenance must identify a non-empty system/user prefix of Turn 1 before its assistant response",
    );
  }

  const encodedMessages = yield* encodePrompt(Prompt.fromMessages([...promptMessages])).pipe(
    Effect.mapError((cause) => journalError("Turn Prompt messages failed to encode", cause)),
  );

  const messages = yield* decodePersistedJson(encodedMessages).pipe(
    Effect.mapError((cause) =>
      journalError("Turn Prompt messages exceed canonical persistence bounds", cause),
    ),
  );

  const messagesDigest = yield* digestJson(messages);

  const modelUsage =
    input.usage?.modelUsage === undefined
      ? undefined
      : yield* decodeModelUsage(input.usage.modelUsage).pipe(
          Effect.mapError((cause) => journalError("Turn model usage failed to decode", cause)),
        );

  if (modelUsage !== undefined) {
    if (modelUsage.length === 0) {
      return yield* journalError("Turn model usage must contain at least one completed call");
    }

    const summary = yield* summarizeModelUsage(modelUsage).pipe(
      Effect.mapError((cause) => journalError("Turn model usage exceeds accounting bounds", cause)),
    );

    if (
      input.usage === undefined ||
      input.usage.inputTokens !== summary.inputTokens.total ||
      input.usage.outputTokens !== summary.outputTokens.total ||
      (input.usage.costMicrousd ?? 0) !== summary.costMicrousd
    ) {
      return yield* journalError("Turn detailed and aggregate model usage disagree");
    }
  }

  return RecordEnvelope.make({
    recordId: modelResponseRecordId(input.runId, input.turn),
    family: "thread",
    schemaVersion: 1,
    createdAt: input.createdAt,
    deploymentId: input.deploymentId,
    payload: ModelResponseRecorded.make({
      ...(input.toolOperations === undefined ? {} : { toolOperations: input.toolOperations }),
      ...(input.toolParameterRejections === undefined || input.toolParameterRejections.length === 0
        ? {}
        : { toolParameterRejections: input.toolParameterRejections }),
      ...(input.toolExposure === undefined ? {} : { toolExposure: input.toolExposure }),
      runId: input.runId,
      turnId: input.turnId,
      turn: input.turn,
      messages,
      messagesDigest,
      ...(runScopedPrefixLength === undefined ? {} : { runScopedPrefixLength }),
      ...(modelUsage === undefined ? {} : { modelUsage }),
      ...(input.unobservedModelCalls === undefined || input.unobservedModelCalls === 0
        ? {}
        : {
            unobservedModelCalls: yield* validStagedUsage(
              "unobservedModelCalls",
              input.unobservedModelCalls,
            ),
          }),
      ...(input.usage === undefined
        ? {}
        : {
            inputTokens: yield* validStagedUsage("inputTokens", input.usage.inputTokens),
            outputTokens: yield* validStagedUsage("outputTokens", input.usage.outputTokens),
            // Written only when non-zero: absent re-seeds as zero, so the
            // no-estimator case stays byte-identical to pre-cost histories.
            ...(input.usage.costMicrousd === undefined || input.usage.costMicrousd === 0
              ? {}
              : {
                  costMicrousd: yield* validStagedUsage("costMicrousd", input.usage.costMicrousd),
                }),
          }),
    }),
  });
});

const toolSettledRecords = Effect.fn("RunJournal.toolSettledRecords")(function* (
  input: TurnCommitInput,
  toolParts: ReadonlyArray<Prompt.ToolResultPart>,
): Effect.fn.Return<Array<RecordEnvelope>, RunJournalError> {
  const toolRecords: Array<RecordEnvelope> = [];

  for (const part of toolParts) {
    const result = yield* decodePersistedJson(part.result).pipe(
      Effect.mapError((cause) =>
        journalError(`Tool result ${part.id} exceeds canonical persistence bounds`, cause),
      ),
    );

    const toolCallId = yield* Effect.try({
      try: () => decodeToolCallId(part.id),
      catch: (cause) => journalError(`Invalid Tool Call ID ${part.id}`, cause),
    });

    toolRecords.push(
      RecordEnvelope.make({
        recordId: toolCallSettledRecordId(input.runId, input.turn, toolCallId),
        family: "thread",
        schemaVersion: 1,
        createdAt: input.createdAt,
        deploymentId: input.deploymentId,
        payload: ToolCallSettled.make({
          ...(input.toolSelections?.get(part.id) === undefined
            ? {}
            : { toolSelection: input.toolSelections.get(part.id) }),
          runId: input.runId,
          toolCallId,
          toolName: part.name,
          result,
          isFailure: part.isFailure,
          ...(input.budgetRejectedCalls?.has(part.id) === true ? { budgetRejected: true } : {}),
        }),
      }),
    );
  }

  return toolRecords;
});

/** Integrity of the original validated terminal values; never a current-code projection. */
export const runCompletionDigest = (
  completion: Pick<
    RunCompleted,
    "runId" | "output" | "runDisposition" | "finishReason" | "exhausted"
  >,
) =>
  digestJson({
    runId: completion.runId,
    output: completion.output,
    runDisposition: completion.runDisposition ?? null,
    finishReason: completion.finishReason ?? null,
    exhausted: completion.exhausted ?? null,
  });

const runCompletionRecord = Effect.fn("RunJournal.runCompletionRecord")(function* (
  input: TurnCommitInput,
) {
  if (input.runCompletion === undefined) return undefined;
  const completion = { runId: input.runId, ...input.runCompletion };

  return RecordEnvelope.make({
    recordId: runCompletedRecordId(input.runId),
    family: "thread",
    schemaVersion: 1,
    createdAt: input.createdAt,
    deploymentId: input.deploymentId,
    payload: RunCompleted.make({
      ...completion,
      resultDigest: yield* runCompletionDigest(completion),
    }),
  });
});

/**
 * Pure per-Turn canonical batch builder (TurnCompleted seam fold, D6/D8): one
 * `ModelResponseRecorded` record plus one `ToolCallSettled` record per terminal Tool result, all
 * under the WP0-style deterministic identities, committed as ONE atomic batch. The same input
 * always yields byte-identical content, so an in-Attempt append retry is an honest batch replay.
 *
 * Phase 5 keeps this shape for Turns that declare no application Tool calls; their terminal
 * `RunCompleted` marker joins the response in this same atomic batch. Tool-declaring Turns split
 * into `turnResponseBatch` + `turnResultsBatch`.
 */
export const turnCanonicalBatch = Effect.fn("RunJournal.turnCanonicalBatch")(function* (
  input: TurnCommitInput,
): Effect.fn.Return<CanonicalBatch, RunJournalError | DigestError, Crypto.Crypto> {
  yield* requireCanonicalTurn(input.turn);
  const { promptMessages, toolParts } = splitTurnMessages(input.appended);
  const modelResponse = yield* modelResponseRecord(input, promptMessages);
  const toolRecords = yield* toolSettledRecords(input, toolParts);
  const completionRecord = yield* runCompletionRecord(input);

  return CanonicalBatch.make({
    batchId: turnBatchId(input.runId, input.turn),
    producerId: input.producerId,
    records:
      completionRecord === undefined
        ? [modelResponse, ...toolRecords]
        : [modelResponse, ...toolRecords, completionRecord],
  });
});

/**
 * Commit 1 of a tool-declaring Turn: the Turn's `ModelResponseRecorded` record, including
 * provider results retained in assistant content before application Tools execute.
 * — pending steering plus the assistant response with its declared tool calls — under batch
 * identity `turn-response:{runId}:{turn}`. Committing the response before preparation creates
 * the provably-safe durability §15 window ("after model item commit, before tool preparation →
 * resume tool scheduling"): a crash there resumes the declared batch with no model re-invocation
 * and no Unknown. Tool messages in `appended` are ignored; the record identity is the same
 * `model-response:{runId}:{turn}` as the single-batch shape, so record-id assertions and the
 * prompt projection are unchanged.
 */
export const turnResponseBatch = Effect.fn("RunJournal.turnResponseBatch")(function* (
  input: TurnCommitInput,
): Effect.fn.Return<CanonicalBatch, RunJournalError | DigestError, Crypto.Crypto> {
  yield* requireCanonicalTurn(input.turn);
  const { promptMessages } = splitTurnMessages(input.appended);
  const modelResponse = yield* modelResponseRecord(input, promptMessages);

  return CanonicalBatch.make({
    batchId: turnResponseBatchId(input.runId, input.turn),
    producerId: input.producerId,
    records: [modelResponse],
  });
});

/**
 * Commit 5 of a tool-declaring Turn (plan §2.1): the Turn's `ToolCallSettled` records in
 * declaration order under batch identity `turn-results:{runId}:{turn}` — the batch becomes
 * model-visible atomically. Non-tool messages in `appended` are ignored; a Turn without any
 * terminal Tool result has no results batch and fails typed.
 */
export const turnResultsBatch = Effect.fn("RunJournal.turnResultsBatch")(function* (
  input: TurnCommitInput,
): Effect.fn.Return<CanonicalBatch, RunJournalError | DigestError, Crypto.Crypto> {
  yield* requireCanonicalTurn(input.turn);
  const { toolParts } = splitTurnMessages(input.appended);
  const toolRecords = yield* toolSettledRecords(input, toolParts);
  const first = toolRecords[0];

  if (first === undefined) {
    return yield* journalError(`Turn ${input.turn} has no terminal Tool results to commit`);
  }
  if (input.runCompletion !== undefined && toolRecords.length !== 1) {
    return yield* journalError("A terminal Tool completion requires exactly one settled result");
  }
  const completionRecord = yield* runCompletionRecord(input);

  return CanonicalBatch.make({
    batchId: turnResultsBatchId(input.runId, input.turn),
    producerId: input.producerId,
    records:
      completionRecord === undefined
        ? [first, ...toolRecords.slice(1)]
        : [first, ...toolRecords.slice(1), completionRecord],
  });
});
