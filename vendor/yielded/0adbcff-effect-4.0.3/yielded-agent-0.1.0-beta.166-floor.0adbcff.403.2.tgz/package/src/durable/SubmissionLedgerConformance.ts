import type { Crypto } from "effect";
import { Clock, DateTime, Duration, Effect, Option, Result, Schema, Stream } from "effect";
import { TestClock } from "effect/testing";

import { InputMessage, MessageAdmission } from "../capabilities/Messaging.ts";
import { AgentPolicy } from "../core/AgentPolicy.ts";
import { type ReceiptId } from "../core/Identifiers.ts";
import { AgentId, ThreadId, SubmissionId, ToolCallId, DelegationId } from "../core/Identifiers.ts";
import {
  SubagentDelegationCaps,
  SubagentGrant,
  SubagentReservationAmounts,
} from "../core/SubagentContract.ts";
import { WorkerCompletion, WorkerUpdate } from "../core/Worker.ts";
import { digestJson, type DigestError } from "./Digest.ts";
import {
  CanonicalSequence,
  DefinitionDigests,
  DeploymentId,
  Digest,
  ProducerId,
  RecordEnvelope,
  SubmissionSettled,
  SubmissionSettledRecord,
  PersistedJson,
  WorkerAdmission,
  type SettlementFailureDiagnostic,
} from "./Records.ts";
import { runIdForSubmission } from "./RunJournal.ts";
import {
  type AdmissionResult,
  AbortCommand,
  AbortIntentRequest,
  AdmissionConflict,
  AdmissionPolicyError,
  AdmissionRequest,
  ApprovalConflict,
  ApprovalDecisionCommand,
  ApprovalPendingSuspension,
  AttachChildToReservationRequest,
  BeginChildBudgetReleaseRequest,
  ChildBudgetReservationRequest,
  ChildReservationConflict,
  ChildReservationId,
  ChildSettledNotification,
  ClaimJoiningRequest,
  ClaimRequest,
  ClaimHandoff,
  IdempotencyKey,
  JoinedToHost,
  LedgerError,
  MarkInputAppliedRequest,
  MarkJoinedRequest,
  MarkReadyRequest,
  MarkUnknownRequest,
  OwnershipLost,
  OwnershipToken,
  ParentLinkage,
  Principal,
  RecoverySnapshotRequest,
  ReleaseChildBudgetRequest,
  ReleaseOwnershipRequest,
  RenewOwnershipRequest,
  ResolutionCompletedWithResult,
  ResolutionNeverHappened,
  ResolutionSafeToRetry,
  RevertJoiningRequest,
  SettlementConflict,
  Settlement,
  SettlementFinalization,
  SettlementReservation,
  SubmissionLedger,
  SubmissionLookupById,
  SubmissionLookupByKey,
  SuspendRequest,
  UnknownResolutionCommand,
  UnknownResolutionConflict,
  WaitingChild,
  WaitingForChildSuspension,
  submissionInputRecordId,
  submissionSettlementId,
  submissionSettlementRecordId,
  type SubmissionLedgerFailure,
} from "./SubmissionLedger.ts";

/** A SubmissionLedger contract invariant that an adapter under test violated. */
export class SubmissionLedgerConformanceViolation extends Schema.TaggedError<SubmissionLedgerConformanceViolation>()(
  "SubmissionLedgerConformanceViolation",
  {
    caseName: Schema.String,
    message: Schema.String,
  },
) {}

export type SubmissionLedgerConformanceFailure =
  | SubmissionLedgerFailure
  | DigestError
  | SubmissionLedgerConformanceViolation;

/**
 * One adapter-neutral SubmissionLedger contract case. Each case owns disjoint Thread
 * lanes, so a suite may run every case against one shared ledger instance or against a fresh
 * ledger per case. Cases drive lease expiry through `TestClock`, so they must run inside the
 * `@effect/vitest` test environment (`it.effect`), and they compute real content digests, so the
 * host suite must provide `Crypto.Crypto`.
 */
export interface SubmissionLedgerConformanceCase {
  readonly name: string;
  readonly run: Effect.Effect<
    void,
    SubmissionLedgerConformanceFailure,
    SubmissionLedger | Crypto.Crypto
  >;
}

const decodeThreadId = Schema.decodeSync(ThreadId);
const decodeSubmissionId = Schema.decodeSync(SubmissionId);
const decodeIdempotencyKey = Schema.decodeSync(IdempotencyKey);
const decodeSequence = Schema.decodeSync(CanonicalSequence);
const decodeToolCallId = Schema.decodeSync(ToolCallId);
const decodeChildReservationId = Schema.decodeSync(ChildReservationId);

/** A token that never owned any lane, for ownership-fencing assertions. */
const BOGUS_TOKEN = Schema.decodeSync(OwnershipToken)("ownership-ledger-conformance-bogus");

const persistedJsonEquivalent = Schema.toEquivalence(PersistedJson);
const isAdmissionConflict = Schema.is(AdmissionConflict);
const isApprovalConflict = Schema.is(ApprovalConflict);
const isChildReservationConflict = Schema.is(ChildReservationConflict);
const isJoinedToHost = Schema.is(JoinedToHost);
const isLedgerError = Schema.is(LedgerError);
const isOwnershipLost = Schema.is(OwnershipLost);
const isSettlementConflict = Schema.is(SettlementConflict);
const isUnknownResolutionConflict = Schema.is(UnknownResolutionConflict);

const CONFORMANCE_PRINCIPAL = Schema.decodeSync(Principal)("principal-ledger-conformance");
const OTHER_PRINCIPAL = Schema.decodeSync(Principal)("principal-ledger-conformance-other");
const CONFORMANCE_AGENT = Schema.decodeSync(AgentId)("agent-ledger-conformance");
const CONFORMANCE_DEPLOYMENT = Schema.decodeSync(DeploymentId)("deployment-ledger-conformance");
const CONFORMANCE_DEFINITION_DIGEST = Schema.decodeSync(Digest)("d".repeat(64));

const CONFORMANCE_DIGESTS = DefinitionDigests.make({
  agent: CONFORMANCE_DEFINITION_DIGEST,
  model: CONFORMANCE_DEFINITION_DIGEST,
  tools: CONFORMANCE_DEFINITION_DIGEST,
});

const CONFORMANCE_CREATED_AT = DateTime.toUtc(DateTime.makeUnsafe(1));
const PRODUCER_A = Schema.decodeSync(ProducerId)("producer-ledger-conformance-a");
const PRODUCER_B = Schema.decodeSync(ProducerId)("producer-ledger-conformance-b");

const sameInstant = (left: DateTime.Utc, right: DateTime.Utc): boolean =>
  DateTime.toEpochMillis(left) === DateTime.toEpochMillis(right);

const admissionRequest = Effect.fn("SubmissionLedgerConformance.admissionRequest")(function* (
  threadId: ThreadId,
  idempotencyKey: string,
  input: PersistedJson,
  parentLinkage?: ParentLinkage,
) {
  const inputDigest = yield* digestJson(input);

  return AdmissionRequest.make({
    threadId,
    principal: CONFORMANCE_PRINCIPAL,
    idempotencyKey: decodeIdempotencyKey(idempotencyKey),
    agentId: CONFORMANCE_AGENT,
    agentDigests: CONFORMANCE_DIGESTS,
    deploymentId: CONFORMANCE_DEPLOYMENT,
    inputPayload: input,
    inputDigest,
    ...(parentLinkage === undefined ? {} : { parentLinkage }),
  });
});

const admitReady = Effect.fn("SubmissionLedgerConformance.admitReady")(function* (
  threadId: ThreadId,
  idempotencyKey: string,
  input: PersistedJson,
) {
  const ledger = yield* SubmissionLedger;
  const admitted = yield* ledger.admit(yield* admissionRequest(threadId, idempotencyKey, input));

  yield* ledger.markReady(MarkReadyRequest.make({ submissionId: admitted.submissionId }));

  return admitted;
});

const claimLane = Effect.fn("SubmissionLedgerConformance.claimLane")(function* (
  threadId: ThreadId,
  producerId: ProducerId,
) {
  const ledger = yield* SubmissionLedger;

  return yield* ledger.claim(ClaimRequest.make({ threadId, producerId }));
});

const lookupById = Effect.fn("SubmissionLedgerConformance.lookupById")(function* (
  submissionId: SubmissionId,
) {
  const ledger = yield* SubmissionLedger;

  return yield* ledger.lookup(SubmissionLookupById.make({ submissionId }));
});

const recoverySnapshot = Effect.fn("SubmissionLedgerConformance.recoverySnapshot")(function* (
  submissionId: SubmissionId,
) {
  const ledger = yield* SubmissionLedger;

  return yield* ledger.loadRecoverySnapshot(RecoverySnapshotRequest.make({ submissionId }));
});

interface ReservationIdentity {
  readonly submissionId: SubmissionId;
  readonly ownershipToken: OwnershipToken;
  readonly receiptId: ReceiptId;
}

type ReservationOptions = ReservationIdentity &
  (
    | {
        readonly outcome: "completed";
        readonly result?: PersistedJson;
      }
    | {
        readonly outcome: "failed";
        readonly result: SettlementFailureDiagnostic;
      }
    | {
        readonly outcome: "aborted";
        readonly result?: never;
      }
  );

/**
 * Builds a complete, deterministic settlement reservation: the exact canonical envelope that
 * would be appended (DUR-011) plus the digest of its canonical JSON encoding. Two calls with the
 * same options produce byte-identical content, so replays are honest reservation replays.
 */
const settlementReservation = Effect.fn("SubmissionLedgerConformance.settlementReservation")(
  function* (options: ReservationOptions) {
    const settlementId = submissionSettlementId(options.submissionId);

    const payload = yield* Schema.decodeEffect(SubmissionSettledRecord)(
      SubmissionSettled.make({
        submissionId: options.submissionId,
        settlementId,
        receiptId: options.receiptId,
        outcome: options.outcome,
        ...(options.result === undefined ? {} : { result: options.result }),
      }),
    ).pipe(Effect.orDie);

    const record = RecordEnvelope.make({
      recordId: submissionSettlementRecordId(options.submissionId),
      family: "thread",
      schemaVersion: 1,
      createdAt: CONFORMANCE_CREATED_AT,
      deploymentId: CONFORMANCE_DEPLOYMENT,
      payload,
    });

    const encoded = yield* Schema.encodeEffect(RecordEnvelope)(record).pipe(Effect.orDie);
    const recordDigest = yield* digestJson(encoded);

    return SettlementReservation.make({
      submissionId: options.submissionId,
      ownershipToken: options.ownershipToken,
      settlementId,
      outcome: options.outcome,
      record,
      recordDigest,
    });
  },
);

const settleClaimed = Effect.fn("SubmissionLedgerConformance.settleClaimed")(function* (
  admitted: AdmissionResult,
  ownershipToken: OwnershipToken,
) {
  const ledger = yield* SubmissionLedger;

  const reservation = yield* settlementReservation({
    submissionId: admitted.submissionId,
    ownershipToken,
    receiptId: admitted.receiptId,
    outcome: "completed",
  });

  yield* ledger.reserveSettlement(reservation);

  return yield* ledger.finalizeSettlement(
    SettlementFinalization.make({
      submissionId: admitted.submissionId,
      settlementId: submissionSettlementId(admitted.submissionId),
    }),
  );
});

/** Advances the TestClock one millisecond past the given lease boundary. */
const advancePastLease = Effect.fn("SubmissionLedgerConformance.advancePastLease")(function* (
  leaseExpiresAt: DateTime.Utc,
) {
  const nowMillis = yield* Clock.currentTimeMillis;
  const waitMillis = Math.max(0, DateTime.toEpochMillis(leaseExpiresAt) - nowMillis) + 1;

  yield* TestClock.adjust(Duration.millis(waitMillis));
});

const conformanceCase = (
  name: string,
  build: (assert: {
    readonly ensure: (
      condition: boolean,
      message: string,
    ) => Effect.Effect<void, SubmissionLedgerConformanceViolation>;
    readonly expectFailure: <A, E, R>(
      description: string,
      effect: Effect.Effect<A, E, R>,
    ) => Effect.Effect<E, SubmissionLedgerConformanceViolation, R>;
    readonly expectSome: <A>(
      description: string,
      option: Option.Option<A>,
    ) => Effect.Effect<A, SubmissionLedgerConformanceViolation>;
  }) => Effect.Effect<void, SubmissionLedgerConformanceFailure, SubmissionLedger | Crypto.Crypto>,
): SubmissionLedgerConformanceCase => ({
  name,
  run: build({
    ensure: (condition, message) =>
      condition
        ? Effect.void
        : Effect.fail(SubmissionLedgerConformanceViolation.make({ caseName: name, message })),
    expectFailure: (description, effect) =>
      Effect.flip(effect).pipe(
        Effect.mapError(() =>
          SubmissionLedgerConformanceViolation.make({
            caseName: name,
            message: `Expected failure but the operation succeeded: ${description}`,
          }),
        ),
      ),
    expectSome: (description, option) =>
      Effect.fromOption(option, () =>
        SubmissionLedgerConformanceViolation.make({
          caseName: name,
          message: `Expected a value but found none: ${description}`,
        }),
      ),
  }).pipe(Effect.withSpan(`SubmissionLedgerConformance.${name}`)),
});

const admissionGroupRace = conformanceCase(
  "admits only one concurrent group request and retains immutable constraints",
  ({ ensure, expectFailure, expectSome }) =>
    Effect.gen(function* () {
      const ledger = yield* SubmissionLedger;

      const requests = yield* Effect.forEach(["first", "second"], (key) =>
        admissionRequest(decodeThreadId("ledger-group-race"), key, {}).pipe(
          Effect.map((request) => AdmissionRequest.make({ ...request, admissionGroup: "entity" })),
        ),
      );

      const outcomes = yield* Effect.forEach(
        requests,
        (request) => ledger.admit(request).pipe(Effect.result),
        { concurrency: 2 },
      );

      yield* ensure(
        outcomes.filter(Result.isSuccess).length === 1,
        "More than one unsettled group submission was admitted",
      );
      yield* ensure(
        outcomes.some(
          (outcome) =>
            Result.isFailure(outcome) &&
            Schema.is(AdmissionPolicyError)(outcome.failure) &&
            outcome.failure.reason === "occupied",
        ),
        "Concurrent loser was not a typed capacity wait",
      );
      for (const [index, outcome] of outcomes.entries()) {
        if (Result.isFailure(outcome)) continue;
        const request = requests[index];

        if (request === undefined) return yield* Effect.die("Missing group race request");

        const snapshot = yield* expectSome(
          "group snapshot",
          yield* lookupById(outcome.success.submissionId),
        );

        yield* ensure(
          snapshot.admissionGroup === "entity",
          "Admission constraints disappeared from the durable snapshot",
        );
        yield* ensure(
          isAdmissionConflict(
            yield* expectFailure(
              "changed retained group",
              ledger.admit(AdmissionRequest.make({ ...request, admissionGroup: "other" })),
            ),
          ),
          "Changed constraints did not produce an admission conflict",
        );
      }
    }),
);

const admissionGroupSettlement = conformanceCase(
  "retains group capacity through terminalizing and permits exact replay",
  ({ ensure, expectFailure, expectSome }) =>
    Effect.gen(function* () {
      const ledger = yield* SubmissionLedger;
      const threadId = decodeThreadId("ledger-conformance-group");

      const original = AdmissionRequest.make({
        ...(yield* admissionRequest(threadId, "group-first", { n: 1 })),
        admissionGroup: "entity-work",
      });

      const successor = AdmissionRequest.make({
        ...(yield* admissionRequest(threadId, "group-second", { n: 2 })),
        admissionGroup: "entity-work",
      });

      const first = yield* ledger.admit(original);

      yield* expectFailure("occupied group", ledger.admit(successor));
      yield* ensure(
        (yield* ledger.admit(original)).submissionId === first.submissionId,
        "Exact retry must resolve before occupied group checks",
      );
      yield* ledger.markReady(MarkReadyRequest.make({ submissionId: first.submissionId }));
      const claim = yield* expectSome("claimed group head", yield* claimLane(threadId, PRODUCER_A));

      yield* ledger.reserveSettlement(
        yield* settlementReservation({
          submissionId: first.submissionId,
          receiptId: first.receiptId,
          ownershipToken: claim.ownershipToken,
          outcome: "completed",
        }),
      );
      yield* expectFailure("terminalizing group", ledger.admit(successor));
      yield* ledger.finalizeSettlement(
        SettlementFinalization.make({
          submissionId: first.submissionId,
          settlementId: submissionSettlementId(first.submissionId),
        }),
      );
      yield* ensure(
        !(yield* ledger.admit(successor)).replayed,
        "Only canonical settlement releases group capacity",
      );
    }),
);

const admissionIdempotency = conformanceCase(
  "replays identical admissions and rejects conflicting input digests",
  ({ ensure, expectFailure, expectSome }) =>
    Effect.gen(function* () {
      const threadId = decodeThreadId("ledger-conformance-admission");
      const ledger = yield* SubmissionLedger;

      const request = yield* admissionRequest(threadId, "admission-key-1", {
        city: "Lisbon",
      });

      const first = yield* ledger.admit(request);

      yield* ensure(!first.replayed, "The first admission of a key must not report replayed");
      yield* ensure(first.state === "admitted", "A fresh admission must start in state admitted");

      const afterAdmit = yield* expectSome(
        "lookup immediately after admission",
        yield* lookupById(first.submissionId),
      );

      yield* ensure(
        afterAdmit.inputDigest === request.inputDigest && afterAdmit.state === "admitted",
        "Admission must be readable with strong consistency immediately after the write",
      );

      const replayed = yield* ledger.admit(request);

      yield* ensure(
        replayed.replayed &&
          replayed.submissionId === first.submissionId &&
          replayed.receiptId === first.receiptId &&
          replayed.queueSequence === first.queueSequence,
        "An identical admission must replay the original identities with replayed set",
      );

      const conflicting = yield* admissionRequest(threadId, "admission-key-1", {
        city: "Porto",
      });

      const conflict = yield* expectFailure(
        "an admission reusing the key with different canonical input",
        ledger.admit(conflicting),
      );

      yield* ensure(
        isAdmissionConflict(conflict) &&
          conflict.existingInputDigest === request.inputDigest &&
          conflict.attemptedInputDigest === conflicting.inputDigest,
        "A same-key admission with a different digest must fail with both digests reported",
      );

      yield* ledger.markReady(MarkReadyRequest.make({ submissionId: first.submissionId }));
      yield* ledger.markReady(MarkReadyRequest.make({ submissionId: first.submissionId }));

      const ready = yield* expectSome(
        "lookup after readiness",
        yield* lookupById(first.submissionId),
      );

      yield* ensure(
        ready.state === "ready" && ready.readyAt !== undefined,
        "markReady must be idempotent and record readiness exactly once",
      );

      const retryAfterReady = yield* ledger.admit(request);

      yield* ensure(
        retryAfterReady.replayed && retryAfterReady.receiptId === first.receiptId,
        "A client retry after readiness must return the original Receipt",
      );

      const second = yield* ledger.admit(
        yield* admissionRequest(threadId, "admission-key-2", { city: "Faro" }),
      );

      yield* ensure(
        second.submissionId !== first.submissionId && second.queueSequence !== first.queueSequence,
        "A different key on the same lane must mint fresh identities and a fresh queue sequence",
      );
    }),
);

const workerMetadata = (base: AdmissionRequest) =>
  WorkerAdmission.make({
    messageId: base.idempotencyKey,
    sourceSubmissionId: Schema.decodeSync(SubmissionId)("source-input"),
    deliveryPrincipal: base.principal,
    parameters: { prompt: "original projection parameters" },
    createdAtMillis: 1,
    origin: {
      worker: {
        schemaVersion: 1,
        threadId: base.threadId,
        targetAgentId: CONFORMANCE_AGENT,
        delegationId: Schema.decodeSync(DelegationId)("worker-research"),
      },
      source: {
        _tag: "programmatic",
        threadId: decodeThreadId("worker-source"),
        agentId: CONFORMANCE_AGENT,
      },
      targetDigests: CONFORMANCE_DIGESTS,
      policy: AgentPolicy.resolve(),
      budget: {
        caps: SubagentDelegationCaps.make({
          maxConcurrentChildren: 1,
          maxTotalChildInvocations: 2,
        }),
        allocation: SubagentReservationAmounts.make({
          turns: 12,
          toolCalls: 24,
          durationMillis: 300_000,
          inputTokens: 0,
          outputTokens: 0,
          costMicrousd: 0,
          resultBytes: 1_000,
        }),
      },
      grant: SubagentGrant.make({ maxDepth: 1, allowedToolNames: [] }),
      depth: 1,
      firstMessageId: base.idempotencyKey,
      createdAtMillis: 1,
      expiresAtMillis: 1_000_000,
    },
  });

const workerAdmissionIdentity = conformanceCase(
  "retains immutable worker admission metadata and rejects same-key changes or omission",
  ({ ensure, expectFailure, expectSome }) =>
    Effect.gen(function* () {
      const ledger = yield* SubmissionLedger;

      const base = yield* admissionRequest(
        decodeThreadId("ledger-conformance-worker"),
        "worker-message",
        { text: "first" },
      );

      const metadata = workerMetadata(base);

      const admitted = yield* ledger.admit(
        AdmissionRequest.make({ ...base, workerAdmission: metadata }),
      );

      const saved = yield* expectSome(
        "worker admission lookup",
        yield* lookupById(admitted.submissionId),
      );

      yield* ensure(
        saved.workerAdmission !== undefined &&
          Schema.toEquivalence(WorkerAdmission)(saved.workerAdmission, metadata),
        "Worker origin and per-input parameters must survive admission lookup",
      );
      yield* ensure(
        saved.parentLinkage === undefined,
        "Background work must not acquire attached-parent semantics",
      );
      const recovery = yield* recoverySnapshot(admitted.submissionId);

      yield* ensure(
        recovery.submission.workerAdmission !== undefined &&
          Schema.toEquivalence(WorkerAdmission)(recovery.submission.workerAdmission, metadata),
        "Recovery must retain the exact worker envelope",
      );

      const replayed = yield* ledger.admit(
        AdmissionRequest.make({ ...base, workerAdmission: metadata }),
      );

      yield* ensure(
        replayed.replayed && replayed.receiptId === admitted.receiptId,
        "Identical metadata must replay the original receipt",
      );
      for (const changed of [
        undefined,
        WorkerAdmission.make({ ...metadata, parameters: { prompt: "changed" } }),
        WorkerAdmission.make({
          ...metadata,
          sourceSubmissionId: Schema.decodeSync(SubmissionId)("other-source-input"),
        }),
        WorkerAdmission.make({
          ...metadata,
          origin: { ...metadata.origin, expiresAtMillis: 2_000_000 },
        }),
      ]) {
        const conflict = yield* expectFailure(
          "different or omitted worker metadata",
          ledger.admit(
            AdmissionRequest.make({
              ...base,
              ...(changed === undefined ? {} : { workerAdmission: changed }),
            }),
          ),
        );

        yield* ensure(
          isAdmissionConflict(conflict),
          "Worker metadata changes must produce AdmissionConflict even when input is unchanged",
        );
      }

      const nextKey = decodeIdempotencyKey("worker-follow-up");

      const next = AdmissionRequest.make({
        ...base,
        idempotencyKey: nextKey,
        workerAdmission: { ...metadata, messageId: nextKey, parameters: { prompt: "next" } },
      });

      const followed = yield* ledger.admit(next);

      yield* ensure(
        followed.queueSequence > admitted.queueSequence,
        "Matching worker origins must admit later inputs",
      );
      for (const changed of [
        undefined,
        WorkerAdmission.make({
          ...metadata,
          origin: { ...metadata.origin, expiresAtMillis: 3_000_000 },
        }),
      ]) {
        const conflict = yield* expectFailure(
          "worker lane origin replacement",
          ledger.admit(
            AdmissionRequest.make({
              ...base,
              idempotencyKey: decodeIdempotencyKey("worker-lane-replacement"),
              ...(changed === undefined ? {} : { workerAdmission: changed }),
            }),
          ),
        );

        yield* ensure(
          conflict._tag === "AdmissionPolicyError" && conflict.reason === "refused",
          "New keys cannot remove or replace an established worker origin",
        );
      }

      const ordinary = yield* admissionRequest(
        decodeThreadId("ledger-conformance-ordinary-lane"),
        "ordinary",
        { text: "ordinary" },
      );

      yield* ledger.admit(ordinary);

      const takeover = yield* expectFailure(
        "ordinary lane takeover",
        ledger.admit(
          AdmissionRequest.make({
            ...ordinary,
            idempotencyKey: decodeIdempotencyKey("takeover"),
            workerAdmission: {
              ...metadata,
              origin: {
                ...metadata.origin,
                worker: { ...metadata.origin.worker, threadId: ordinary.threadId },
              },
            },
          }),
        ),
      );

      yield* ensure(
        takeover._tag === "AdmissionPolicyError" && takeover.reason === "refused",
        "A worker cannot take over an ordinary lane before canonical materialization",
      );

      const racing = yield* admissionRequest(
        decodeThreadId("ledger-conformance-lane-race"),
        "ordinary-race",
        { text: "race" },
      );

      const raced = yield* Effect.forEach(
        [
          racing,
          AdmissionRequest.make({
            ...racing,
            idempotencyKey: decodeIdempotencyKey("worker-race"),
            workerAdmission: {
              ...metadata,
              origin: {
                ...metadata.origin,
                worker: { ...metadata.origin.worker, threadId: racing.threadId },
              },
            },
          }),
        ],
        (request) => ledger.admit(request).pipe(Effect.result),
        { concurrency: 2 },
      );

      yield* ensure(
        raced.filter((result) => result._tag === "Success").length === 1 &&
          raced.filter(
            (result) => result._tag === "Failure" && result.failure._tag === "AdmissionPolicyError",
          ).length === 1,
        "Concurrent ordinary/worker admissions must atomically choose exactly one lane identity",
      );
    }),
);

const messageAdmissionIdentity = conformanceCase(
  "retains authenticated peer provenance and rejects same-key changes or omission",
  ({ ensure, expectFailure, expectSome }) =>
    Effect.gen(function* () {
      const ledger = yield* SubmissionLedger;

      const base = yield* admissionRequest(
        decodeThreadId("ledger-conformance-peer"),
        "peer-message",
        { text: "hello" },
      );

      const metadata = Schema.decodeSync(MessageAdmission)({
        schemaVersion: 1,
        message: { ownerThreadId: "peer-source", messageId: "peer-message" },
        peerName: "reviewer",
        sender: { threadId: "peer-source", agentId: "peer-agent" },
        returnAddress: { threadId: "peer-source", agentId: "peer-agent" },
      });

      const admitted = yield* ledger.admit(
        AdmissionRequest.make({ ...base, messageAdmission: metadata }),
      );

      const saved = yield* expectSome(
        "peer admission lookup",
        yield* lookupById(admitted.submissionId),
      );

      yield* ensure(
        saved.messageAdmission !== undefined &&
          Schema.toEquivalence(InputMessage)(saved.messageAdmission, metadata),
        "Peer sender and return address must survive lookup without becoming application input",
      );
      const recovery = yield* recoverySnapshot(admitted.submissionId);

      yield* ensure(
        recovery.submission.messageAdmission !== undefined &&
          Schema.toEquivalence(InputMessage)(recovery.submission.messageAdmission, metadata),
        "Recovery must retain peer provenance",
      );

      const replayed = yield* ledger.admit(
        AdmissionRequest.make({ ...base, messageAdmission: metadata }),
      );

      yield* ensure(
        replayed.replayed && replayed.receiptId === admitted.receiptId,
        "Identical peer metadata must replay its receipt",
      );
      for (const changed of [
        undefined,
        MessageAdmission.make({ ...metadata, peerName: "other" }),
        MessageAdmission.make({ ...metadata, inReplyTo: metadata.message }),
      ]) {
        const conflict = yield* expectFailure(
          "different or omitted peer metadata",
          ledger.admit(
            AdmissionRequest.make({
              ...base,
              ...(changed === undefined ? {} : { messageAdmission: changed }),
            }),
          ),
        );

        yield* ensure(
          isAdmissionConflict(conflict),
          "Peer provenance changes must produce AdmissionConflict",
        );
      }
    }),
);

const workerUpdateIdentity = conformanceCase(
  "retains framework updates separately and rejects changed same-key metadata",
  ({ ensure, expectFailure, expectSome }) =>
    Effect.gen(function* () {
      const ledger = yield* SubmissionLedger;

      const base = yield* admissionRequest(
        decodeThreadId("ledger-conformance-update"),
        "update-message",
        { text: "original application input" },
      );

      const metadata = Schema.decodeSync(WorkerUpdate)({
        _tag: "WorkerUpdate",
        schemaVersion: 1,
        worker: {
          schemaVersion: 1,
          delegationId: "research",
          targetAgentId: "child",
          threadId: "child-thread",
        },
        update: {
          schemaVersion: 1,
          agentId: "child",
          threadId: "child-thread",
          runId: "child-run",
          updateId: "finding",
          sequence: 1,
          value: { finding: "partial" },
        },
      });

      const admitted = yield* ledger.admit(
        AdmissionRequest.make({ ...base, messageAdmission: metadata }),
      );

      const saved = yield* expectSome(
        "update admission lookup",
        yield* lookupById(admitted.submissionId),
      );

      yield* ensure(
        saved.messageAdmission !== undefined &&
          Schema.toEquivalence(InputMessage)(saved.messageAdmission, metadata),
        "Update identity and value must survive lookup",
      );
      yield* ensure(
        Schema.toEquivalence(PersistedJson)(saved.inputPayload, base.inputPayload),
        "Framework update must not replace application input",
      );
      const recovery = yield* recoverySnapshot(admitted.submissionId);

      yield* ensure(
        recovery.submission.messageAdmission !== undefined &&
          Schema.toEquivalence(InputMessage)(recovery.submission.messageAdmission, metadata),
        "Recovery must retain update provenance",
      );

      const replay = yield* ledger.admit(
        AdmissionRequest.make({ ...base, messageAdmission: metadata }),
      );

      yield* ensure(
        replay.replayed && replay.receiptId === admitted.receiptId,
        "Identical update retries must reuse the original receipt",
      );
      for (const changed of [
        undefined,
        WorkerUpdate.make({ ...metadata, update: { ...metadata.update, sequence: 2 } }),
        WorkerUpdate.make({
          ...metadata,
          update: { ...metadata.update, value: { finding: "changed" } },
        }),
      ]) {
        const conflict = yield* expectFailure(
          "changed update metadata",
          ledger.admit(
            AdmissionRequest.make({
              ...base,
              ...(changed === undefined ? {} : { messageAdmission: changed }),
            }),
          ),
        );

        yield* ensure(
          isAdmissionConflict(conflict),
          "Changed update identity or value must conflict",
        );
      }
    }),
);

const workerCompletionIdentity = conformanceCase(
  "retains framework completions and rejects same-key changes or omission",
  ({ ensure, expectFailure, expectSome }) =>
    Effect.gen(function* () {
      const ledger = yield* SubmissionLedger;

      const base = yield* admissionRequest(
        decodeThreadId("ledger-conformance-completion"),
        "completion-message",
        { text: "hello" },
      );

      const metadata = Schema.decodeSync(WorkerCompletion)({
        _tag: "WorkerCompletion",
        schemaVersion: 1,
        budgetExhausted: false,
        report: {
          _tag: "Settled",
          worker: {
            schemaVersion: 1,
            delegationId: "research",
            targetAgentId: "child",
            threadId: "child-thread",
          },
          receipt: {
            threadId: "child-thread",
            submissionId: "child-input",
            receiptId: "child-receipt",
            queueSequence: 1,
          },
          runId: "child-run",
          settlementId: "child-settlement",
          outcome: "completed",
          result: { answer: "done" },
        },
      });

      const admitted = yield* ledger.admit(
        AdmissionRequest.make({ ...base, messageAdmission: metadata }),
      );

      const saved = yield* expectSome(
        "completion admission lookup",
        yield* lookupById(admitted.submissionId),
      );

      yield* ensure(
        saved.messageAdmission !== undefined &&
          Schema.toEquivalence(InputMessage)(saved.messageAdmission, metadata),
        "Completion identity and projected result must survive lookup without becoming application input",
      );
      const recovery = yield* recoverySnapshot(admitted.submissionId);

      yield* ensure(
        recovery.submission.messageAdmission !== undefined &&
          Schema.toEquivalence(InputMessage)(recovery.submission.messageAdmission, metadata),
        "Recovery must retain completion provenance",
      );

      const replayed = yield* ledger.admit(
        AdmissionRequest.make({ ...base, messageAdmission: metadata }),
      );

      yield* ensure(
        replayed.replayed && replayed.receiptId === admitted.receiptId,
        "Identical completion metadata must replay its receipt",
      );
      for (const changed of [
        undefined,
        WorkerCompletion.make({ ...metadata, budgetExhausted: true }),
      ]) {
        const conflict = yield* expectFailure(
          "different or omitted completion metadata",
          ledger.admit(
            AdmissionRequest.make({
              ...base,
              ...(changed === undefined ? {} : { messageAdmission: changed }),
            }),
          ),
        );

        yield* ensure(
          isAdmissionConflict(conflict),
          "Completion metadata changes must produce AdmissionConflict",
        );
      }
    }),
);

const crossPrincipalAdmissionScoping = conformanceCase(
  "scopes idempotency keys to their principal: a second principal reusing a key mints a distinct Submission",
  ({ ensure, expectSome }) =>
    Effect.gen(function* () {
      // SEC-002 (security-operations §2): "Client idempotency keys are scoped so one principal
      // cannot discover or collide with another principal's submission." This is the COLLIDE
      // half — a second principal reusing an existing (thread, idempotency key) must not
      // replay, overwrite, or conflict with the first principal's Submission, and must not learn
      // its identity. (The DISCOVER half — scoped lookup/resolveAdmission — is covered by
      // `lookupByIdAndKey` and `resolveAdmissionAuthority`.)
      const threadId = decodeThreadId("ledger-conformance-cross-principal");
      const ledger = yield* SubmissionLedger;
      const idempotencyKey = decodeIdempotencyKey("shared-key-1");

      const mineRequest = yield* admissionRequest(threadId, "shared-key-1", {
        owner: "mine",
      });

      const mine = yield* ledger.admit(mineRequest);

      // A DIFFERENT principal admits the SAME (thread, key) with different canonical input.
      // It is neither a replay nor an AdmissionConflict: keys are principal-scoped, so this mints
      // a fresh, distinct Submission with its own identities and queue position.
      const theirsRequest = AdmissionRequest.make({
        threadId,
        principal: OTHER_PRINCIPAL,
        idempotencyKey,
        agentId: CONFORMANCE_AGENT,
        agentDigests: CONFORMANCE_DIGESTS,
        deploymentId: CONFORMANCE_DEPLOYMENT,
        inputPayload: { owner: "theirs" },
        inputDigest: yield* digestJson({ owner: "theirs" }),
      });

      const theirs = yield* ledger.admit(theirsRequest);

      yield* ensure(
        !theirs.replayed &&
          theirs.submissionId !== mine.submissionId &&
          theirs.receiptId !== mine.receiptId &&
          theirs.queueSequence !== mine.queueSequence,
        "A second principal reusing a key must mint a fresh, distinct Submission — never a replay or collision",
      );

      // The first principal's own replay is unaffected by the second principal's admission.
      const mineReplay = yield* ledger.admit(mineRequest);

      yield* ensure(
        mineReplay.replayed && mineReplay.submissionId === mine.submissionId,
        "The original principal's replay must still resolve to its own Submission after the other principal admitted",
      );

      // Each principal's scoped lookup resolves ONLY its own Submission — no cross-principal
      // discovery through the shared key.
      const mineByKey = yield* expectSome(
        "the first principal's scoped lookup",
        yield* ledger.lookup(
          SubmissionLookupByKey.make({
            threadId,
            principal: CONFORMANCE_PRINCIPAL,
            idempotencyKey,
          }),
        ),
      );

      const theirsByKey = yield* expectSome(
        "the second principal's scoped lookup",
        yield* ledger.lookup(
          SubmissionLookupByKey.make({
            threadId,
            principal: OTHER_PRINCIPAL,
            idempotencyKey,
          }),
        ),
      );

      yield* ensure(
        mineByKey.submissionId === mine.submissionId &&
          theirsByKey.submissionId === theirs.submissionId &&
          mineByKey.submissionId !== theirsByKey.submissionId,
        "Each principal's scoped lookup must resolve only its own Submission under the shared key",
      );
    }),
);

const admissionTupleBoundaries = conformanceCase(
  "preserves admission tuple boundaries when principal and key contain separators",
  ({ ensure, expectSome }) =>
    Effect.gen(function* () {
      const threadId = decodeThreadId("ledger-conformance-admission-separators");
      const ledger = yield* SubmissionLedger;
      const base = yield* admissionRequest(threadId, "r", { work: "separators" });

      const firstRequest = AdmissionRequest.make({
        ...base,
        principal: Schema.decodeSync(Principal)("p\u001fq"),
      });

      const secondRequest = AdmissionRequest.make({
        ...base,
        principal: Schema.decodeSync(Principal)("p"),
        idempotencyKey: decodeIdempotencyKey("q\u001fr"),
      });

      const first = yield* ledger.admit(firstRequest);
      const second = yield* ledger.admit(secondRequest);

      yield* ensure(
        !second.replayed &&
          second.submissionId !== first.submissionId &&
          second.receiptId !== first.receiptId &&
          second.queueSequence === first.queueSequence + 1,
        "Distinct admission tuples must allocate distinct identities and consecutive queue positions",
      );

      for (const [request, admitted] of [
        [firstRequest, first],
        [secondRequest, second],
      ] as const) {
        const key = SubmissionLookupByKey.make({
          threadId,
          principal: request.principal,
          idempotencyKey: request.idempotencyKey,
        });

        const found = yield* expectSome("the exact admission tuple", yield* ledger.lookup(key));
        const resolved = yield* ledger.resolveAdmission(key);
        const replay = yield* ledger.admit(request);

        yield* ensure(
          found.submissionId === admitted.submissionId &&
            resolved._tag === "Admitted" &&
            resolved.submission.submissionId === admitted.submissionId &&
            replay.replayed &&
            replay.submissionId === admitted.submissionId &&
            replay.receiptId === admitted.receiptId &&
            replay.queueSequence === admitted.queueSequence,
          "Lookup, authoritative resolution, and replay must preserve the exact admission tuple",
        );
      }
    }),
);

const concurrentAdmissionFifo = conformanceCase(
  "allocates distinct FIFO queue sequences under concurrent admission and claims in order",
  ({ ensure, expectSome }) =>
    Effect.gen(function* () {
      const threadId = decodeThreadId("ledger-conformance-fifo-concurrent");
      const ledger = yield* SubmissionLedger;

      const requests = [
        yield* admissionRequest(threadId, "fifo-key-0", { step: 0 }),
        yield* admissionRequest(threadId, "fifo-key-1", { step: 1 }),
        yield* admissionRequest(threadId, "fifo-key-2", { step: 2 }),
      ];

      const admitted = yield* Effect.forEach(requests, (request) => ledger.admit(request), {
        concurrency: "unbounded",
      });

      const duplicate = yield* admissionRequest(threadId, "fifo-key-dup", { step: 3 });

      const duplicated = yield* Effect.all([ledger.admit(duplicate), ledger.admit(duplicate)], {
        concurrency: "unbounded",
      });

      yield* ensure(
        duplicated[0].submissionId === duplicated[1].submissionId &&
          duplicated[0].receiptId === duplicated[1].receiptId &&
          duplicated[0].queueSequence === duplicated[1].queueSequence,
        "Concurrent duplicate admissions must resolve to one Submission and one Receipt",
      );
      yield* ensure(
        duplicated.filter((result) => !result.replayed).length === 1,
        "Exactly one of two concurrent duplicate admissions must create the Submission",
      );

      const lane = [...admitted, duplicated[0]];

      yield* ensure(
        new Set(lane.map((result) => result.queueSequence)).size === lane.length,
        "Concurrent admissions on one lane must allocate distinct queue sequences",
      );
      yield* ensure(
        new Set(lane.map((result) => result.submissionId)).size === lane.length,
        "Concurrent admissions on one lane must mint distinct Submission identities",
      );

      yield* Effect.forEach(
        lane,
        (result) => ledger.markReady(MarkReadyRequest.make({ submissionId: result.submissionId })),
        { discard: true },
      );

      const expectedOrder = [...lane].sort((a, b) => a.queueSequence - b.queueSequence);

      for (const expected of expectedOrder) {
        const claim = yield* expectSome(
          `a claim while ${expected.submissionId} heads the lane`,
          yield* claimLane(threadId, PRODUCER_A),
        );

        yield* ensure(
          claim.submissionId === expected.submissionId,
          "Claims must deliver Submissions in ascending queue-sequence order",
        );
        yield* settleClaimed(expected, claim.ownershipToken);
      }
      yield* ensure(
        Option.isNone(yield* claimLane(threadId, PRODUCER_A)),
        "A fully settled lane must produce no claim",
      );
    }),
);

const fifoHeadClaim = conformanceCase(
  "claims only the lowest unsettled head and fences the lane epoch forward",
  ({ ensure, expectSome }) =>
    Effect.gen(function* () {
      const emptyLane = decodeThreadId("ledger-conformance-empty");

      yield* ensure(
        Option.isNone(yield* claimLane(emptyLane, PRODUCER_A)),
        "Claiming a lane with no admitted work must return none",
      );

      const threadId = decodeThreadId("ledger-conformance-head");
      const first = yield* admitReady(threadId, "head-key-1", { order: 1 });
      const second = yield* admitReady(threadId, "head-key-2", { order: 2 });

      yield* ensure(
        second.queueSequence > first.queueSequence,
        "Sequential admissions must allocate increasing queue sequences",
      );

      const headClaim = yield* expectSome(
        "the first claim on the lane",
        yield* claimLane(threadId, PRODUCER_A),
      );

      yield* ensure(
        headClaim.submissionId === first.submissionId,
        "A claim must take the lowest unsettled queue sequence, never later work",
      );

      const running = yield* expectSome(
        "lookup of the claimed head",
        yield* lookupById(first.submissionId),
      );

      yield* ensure(
        running.state === "running",
        "Claiming a ready head must transition it to running with strong read visibility",
      );
      yield* ensure(
        Option.isNone(yield* claimLane(threadId, PRODUCER_B)),
        "A lane whose head lease is live under another owner must produce no claim",
      );

      yield* settleClaimed(first, headClaim.ownershipToken);

      const nextClaim = yield* expectSome(
        "the claim after the head settled",
        yield* claimLane(threadId, PRODUCER_B),
      );

      yield* ensure(
        nextClaim.submissionId === second.submissionId,
        "Settling the head must make exactly the next queue sequence claimable",
      );
      yield* ensure(
        nextClaim.producerEpoch > headClaim.producerEpoch,
        "Every successful claim must bump the Thread producer epoch",
      );
      yield* settleClaimed(second, nextClaim.ownershipToken);
      yield* ensure(
        Option.isNone(yield* claimLane(threadId, PRODUCER_A)),
        "A drained lane must produce no claim",
      );
    }),
);

const leaseExpiryReclaim = conformanceCase(
  "reclaims an expired lease with a higher epoch and fences the stale token",
  ({ ensure, expectFailure, expectSome }) =>
    Effect.gen(function* () {
      const threadId = decodeThreadId("ledger-conformance-lease");
      const ledger = yield* SubmissionLedger;
      const admitted = yield* admitReady(threadId, "lease-key-1", { work: "lease" });

      const firstClaim = yield* expectSome(
        "the initial claim",
        yield* claimLane(threadId, PRODUCER_A),
      );

      const renewal = yield* ledger.renewOwnership(
        RenewOwnershipRequest.make({
          submissionId: admitted.submissionId,
          ownershipToken: firstClaim.ownershipToken,
        }),
      );

      yield* ensure(
        DateTime.toEpochMillis(renewal.leaseExpiresAt) >=
          DateTime.toEpochMillis(firstClaim.leaseExpiresAt),
        "Renewal must never shorten the ownership lease",
      );
      const liveToken = renewal.ownershipToken;

      yield* ensure(
        Option.isNone(yield* claimLane(threadId, PRODUCER_B)),
        "A renewed live lease must keep the lane blocked for other owners",
      );

      yield* advancePastLease(renewal.leaseExpiresAt);

      const reclaim = yield* expectSome(
        "the reclaim after lease expiry",
        yield* claimLane(threadId, PRODUCER_B),
      );

      yield* ensure(
        reclaim.submissionId === admitted.submissionId &&
          reclaim.attemptId !== firstClaim.attemptId &&
          reclaim.ownershipToken !== liveToken,
        "Reclaiming an expired lease must start a fresh Attempt with a fresh token",
      );
      yield* ensure(
        reclaim.producerEpoch > firstClaim.producerEpoch,
        "Reclaiming an expired lease must bump the producer epoch past the stale Attempt",
      );

      const staleRenew = yield* expectFailure(
        "renewing with the superseded token",
        ledger.renewOwnership(
          RenewOwnershipRequest.make({
            submissionId: admitted.submissionId,
            ownershipToken: liveToken,
          }),
        ),
      );

      yield* ensure(
        isOwnershipLost(staleRenew) && staleRenew.actualEpoch === reclaim.producerEpoch,
        "A superseded token must fail renewal with the current epoch reported",
      );

      const staleRelease = yield* expectFailure(
        "releasing with the superseded token",
        ledger.releaseOwnership(
          ReleaseOwnershipRequest.make({
            submissionId: admitted.submissionId,
            ownershipToken: liveToken,
          }),
        ),
      );

      yield* ensure(isOwnershipLost(staleRelease), "A superseded token must not release the lane");

      const staleMark = yield* expectFailure(
        "marking input applied with the superseded token",
        ledger.markInputApplied(
          MarkInputAppliedRequest.make({
            submissionId: admitted.submissionId,
            ownershipToken: liveToken,
            recordId: submissionInputRecordId(admitted.submissionId),
            sequence: decodeSequence(1),
          }),
        ),
      );

      yield* ensure(
        isOwnershipLost(staleMark),
        "A superseded token must not mark canonical input applied",
      );

      const staleReservation = yield* settlementReservation({
        submissionId: admitted.submissionId,
        ownershipToken: liveToken,
        receiptId: admitted.receiptId,
        outcome: "completed",
      });

      const staleReserve = yield* expectFailure(
        "reserving a settlement with the superseded token",
        ledger.reserveSettlement(staleReservation),
      );

      yield* ensure(
        isOwnershipLost(staleReserve),
        "A superseded token must not reserve a settlement",
      );
      const afterStale = yield* recoverySnapshot(admitted.submissionId);

      yield* ensure(
        afterStale.reservation === undefined,
        "A fenced settlement reservation must leave no reservation behind",
      );

      yield* ledger.renewOwnership(
        RenewOwnershipRequest.make({
          submissionId: admitted.submissionId,
          ownershipToken: reclaim.ownershipToken,
        }),
      );

      const renewalLane = decodeThreadId("ledger-conformance-renewal");
      const renewalWork = yield* admitReady(renewalLane, "renewal-key-1", { work: "renewal" });

      const renewalClaim = yield* expectSome(
        "the claim on the renewal lane",
        yield* claimLane(renewalLane, PRODUCER_A),
      );

      yield* advancePastLease(renewalClaim.leaseExpiresAt);

      const lateRenewal = yield* ledger.renewOwnership(
        RenewOwnershipRequest.make({
          submissionId: renewalWork.submissionId,
          ownershipToken: renewalClaim.ownershipToken,
        }),
      );

      yield* ensure(
        DateTime.toEpochMillis(lateRenewal.leaseExpiresAt) >
          DateTime.toEpochMillis(renewalClaim.leaseExpiresAt),
        "Renewal after expiry must succeed and extend the lease when nobody claimed in between",
      );
    }),
);

const releaseMakesHeadClaimable = conformanceCase(
  "releases ownership gracefully so the head is immediately claimable",
  ({ ensure, expectFailure, expectSome }) =>
    Effect.gen(function* () {
      const threadId = decodeThreadId("ledger-conformance-release");
      const ledger = yield* SubmissionLedger;
      const admitted = yield* admitReady(threadId, "release-key-1", { work: "release" });

      const firstClaim = yield* expectSome(
        "the initial claim",
        yield* claimLane(threadId, PRODUCER_A),
      );

      yield* ledger.releaseOwnership(
        ReleaseOwnershipRequest.make({
          submissionId: admitted.submissionId,
          ownershipToken: firstClaim.ownershipToken,
        }),
      );

      const releasedRenew = yield* expectFailure(
        "renewing a released token",
        ledger.renewOwnership(
          RenewOwnershipRequest.make({
            submissionId: admitted.submissionId,
            ownershipToken: firstClaim.ownershipToken,
          }),
        ),
      );

      yield* ensure(
        isOwnershipLost(releasedRenew),
        "A released token must no longer renew the lease",
      );

      const reclaim = yield* expectSome(
        "the claim immediately after release",
        yield* claimLane(threadId, PRODUCER_B),
      );

      yield* ensure(
        reclaim.submissionId === admitted.submissionId &&
          reclaim.producerEpoch > firstClaim.producerEpoch,
        "A released nonterminal head must be claimable immediately with a higher epoch",
      );

      const doubleRelease = yield* expectFailure(
        "releasing with the pre-release token after a new claim",
        ledger.releaseOwnership(
          ReleaseOwnershipRequest.make({
            submissionId: admitted.submissionId,
            ownershipToken: firstClaim.ownershipToken,
          }),
        ),
      );

      yield* ensure(
        isOwnershipLost(doubleRelease),
        "A superseded token must not release the new Attempt's ownership",
      );
      yield* settleClaimed(admitted, reclaim.ownershipToken);
    }),
);

const inputAppliedIdempotency = conformanceCase(
  "marks canonical input applied idempotently under the owning token",
  ({ ensure, expectFailure, expectSome }) =>
    Effect.gen(function* () {
      const threadId = decodeThreadId("ledger-conformance-input");
      const ledger = yield* SubmissionLedger;
      const admitted = yield* admitReady(threadId, "input-key-1", { work: "input" });

      const claim = yield* expectSome(
        "the claim before input apply",
        yield* claimLane(threadId, PRODUCER_A),
      );

      const marker = MarkInputAppliedRequest.make({
        submissionId: admitted.submissionId,
        ownershipToken: claim.ownershipToken,
        recordId: submissionInputRecordId(admitted.submissionId),
        sequence: decodeSequence(2),
      });

      yield* ledger.markInputApplied(marker);

      const applied = yield* expectSome(
        "lookup after marking input applied",
        yield* lookupById(admitted.submissionId),
      );

      yield* ensure(
        applied.state === "input-applied",
        "Marking input applied must transition the Submission to input-applied",
      );

      yield* ledger.markInputApplied(marker);
      for (const conflicting of [
        MarkInputAppliedRequest.make({
          ...marker,
          recordId: submissionInputRecordId(decodeSubmissionId("different-input-marker")),
        }),
        MarkInputAppliedRequest.make({ ...marker, sequence: decodeSequence(3) }),
      ]) {
        const error = yield* expectFailure(
          "a conflicting input-applied marker",
          ledger.markInputApplied(conflicting),
        );

        yield* ensure(isLedgerError(error), "Conflicting input markers must fail as LedgerError");
      }
      const snapshot = yield* recoverySnapshot(admitted.submissionId);

      yield* ensure(
        snapshot.inputApplied !== undefined &&
          snapshot.inputApplied.recordId === marker.recordId &&
          snapshot.inputApplied.sequence === marker.sequence &&
          snapshot.submission.state === "input-applied",
        "Identical replays and rejected conflicts must retain the original input-applied marker",
      );
    }),
);

const settlementLifecycle = conformanceCase(
  "reserves and finalizes exactly one settlement with idempotent replays",
  ({ ensure, expectSome }) =>
    Effect.gen(function* () {
      const threadId = decodeThreadId("ledger-conformance-settle");
      const ledger = yield* SubmissionLedger;
      const admitted = yield* admitReady(threadId, "settle-key-1", { work: "settle" });

      const claim = yield* expectSome(
        "the claim before terminalization",
        yield* claimLane(threadId, PRODUCER_A),
      );

      const reservation = yield* settlementReservation({
        submissionId: admitted.submissionId,
        ownershipToken: claim.ownershipToken,
        receiptId: admitted.receiptId,
        outcome: "completed",
        result: { answer: 42 },
      });

      const reserved = yield* ledger.reserveSettlement(reservation);

      yield* ensure(
        !reserved.replayed &&
          reserved.settlementId === reservation.settlementId &&
          reserved.outcome === "completed" &&
          reserved.recordDigest === reservation.recordDigest,
        "The first reservation must commit the exact reserved record without replay",
      );

      const terminalizing = yield* expectSome(
        "lookup after reservation",
        yield* lookupById(admitted.submissionId),
      );

      yield* ensure(
        terminalizing.state === "terminalizing",
        "Reserving a settlement must transition the Submission to terminalizing",
      );

      const replayedReservation = yield* ledger.reserveSettlement(reservation);

      yield* ensure(
        replayedReservation.replayed &&
          replayedReservation.recordDigest === reservation.recordDigest,
        "An identical reservation must replay with the stored exact record",
      );

      const finalization = SettlementFinalization.make({
        submissionId: admitted.submissionId,
        settlementId: reservation.settlementId,
      });

      const settlement = yield* ledger.finalizeSettlement(finalization);

      yield* ensure(
        settlement.submissionId === admitted.submissionId &&
          settlement.settlementId === reservation.settlementId &&
          settlement.receiptId === admitted.receiptId &&
          settlement.outcome === "completed",
        "Finalization must return the Settlement bound to the admission Receipt",
      );

      const settled = yield* expectSome(
        "lookup after finalization",
        yield* lookupById(admitted.submissionId),
      );

      yield* ensure(
        settled.state === "settled" && settled.settledOutcome === "completed",
        "Finalization must settle the Submission with its recorded outcome",
      );

      yield* TestClock.adjust("1 second");
      const retried = yield* ledger.finalizeSettlement(finalization);

      yield* ensure(
        retried.settlementId === settlement.settlementId &&
          retried.receiptId === settlement.receiptId &&
          retried.outcome === settlement.outcome &&
          sameInstant(retried.settledAt, settlement.settledAt),
        "Retrying finalization after a lost acknowledgment must return the same Settlement",
      );
      yield* ensure(
        Option.isNone(yield* claimLane(threadId, PRODUCER_B)),
        "A settled lane with no further work must produce no claim",
      );

      const failedDiagnostic = {
        errorTag: "ConformanceFailure",
        message: "The conformance Submission failed",
      } as const;

      const failedAdmission = yield* admitReady(threadId, "settle-key-2", {
        work: "fail",
      });

      const failedClaim = yield* expectSome(
        "the claim before failed terminalization",
        yield* claimLane(threadId, PRODUCER_A),
      );

      const failedReservation = yield* settlementReservation({
        submissionId: failedAdmission.submissionId,
        ownershipToken: failedClaim.ownershipToken,
        receiptId: failedAdmission.receiptId,
        outcome: "failed",
        result: failedDiagnostic,
      });

      yield* ledger.reserveSettlement(failedReservation);

      const failedSettlement = yield* ledger.finalizeSettlement(
        SettlementFinalization.make({
          submissionId: failedAdmission.submissionId,
          settlementId: failedReservation.settlementId,
        }),
      );

      yield* ensure(
        failedSettlement.outcome === "failed" &&
          failedSettlement.failure?.errorTag === failedDiagnostic.errorTag &&
          failedSettlement.failure.message === failedDiagnostic.message,
        "A failed finalization must return the exact bounded canonical diagnostic",
      );
      yield* TestClock.adjust("1 second");

      const replayedFailedSettlement = yield* ledger.finalizeSettlement(
        SettlementFinalization.make({
          submissionId: failedAdmission.submissionId,
          settlementId: failedReservation.settlementId,
        }),
      );

      yield* ensure(
        replayedFailedSettlement.failure?.errorTag === failedDiagnostic.errorTag &&
          replayedFailedSettlement.failure.message === failedDiagnostic.message &&
          sameInstant(replayedFailedSettlement.settledAt, failedSettlement.settledAt),
        "A replayed failed finalization must preserve its diagnostic and original settledAt",
      );
    }),
);

const settlementConflicts = conformanceCase(
  "rejects conflicting settlement reservations and finalizations",
  ({ ensure, expectFailure, expectSome }) =>
    Effect.gen(function* () {
      const threadId = decodeThreadId("ledger-conformance-settle-conflict");
      const ledger = yield* SubmissionLedger;
      const admitted = yield* admitReady(threadId, "conflict-key-1", { work: "conflict" });

      const claim = yield* expectSome(
        "the claim before terminalization",
        yield* claimLane(threadId, PRODUCER_A),
      );

      const reservation = yield* settlementReservation({
        submissionId: admitted.submissionId,
        ownershipToken: claim.ownershipToken,
        receiptId: admitted.receiptId,
        outcome: "completed",
        result: { attempt: 1 },
      });

      yield* ledger.reserveSettlement(reservation);

      const conflictingOutcome = yield* settlementReservation({
        submissionId: admitted.submissionId,
        ownershipToken: claim.ownershipToken,
        receiptId: admitted.receiptId,
        outcome: "failed",
        result: {
          errorTag: "ConformanceFailure",
          message: "The conflicting conformance reservation failed",
        },
      });

      const outcomeConflict = yield* expectFailure(
        "reserving a different outcome for the same Submission",
        ledger.reserveSettlement(conflictingOutcome),
      );

      yield* ensure(
        isSettlementConflict(outcomeConflict) && outcomeConflict.existingOutcome === "completed",
        "A second reservation with a different outcome must conflict with the recorded outcome",
      );

      const conflictingContent = yield* settlementReservation({
        submissionId: admitted.submissionId,
        ownershipToken: claim.ownershipToken,
        receiptId: admitted.receiptId,
        outcome: "completed",
        result: { attempt: 2 },
      });

      const contentConflict = yield* expectFailure(
        "reserving the same outcome with different canonical content",
        ledger.reserveSettlement(conflictingContent),
      );

      yield* ensure(
        isSettlementConflict(contentConflict) && contentConflict.existingOutcome === "completed",
        "A second reservation with different content must conflict even when outcomes match",
      );

      const wrongFinalization = yield* expectFailure(
        "finalizing with a settlement identity that was never reserved",
        ledger.finalizeSettlement(
          SettlementFinalization.make({
            submissionId: admitted.submissionId,
            settlementId: submissionSettlementId(
              decodeSubmissionId(`${admitted.submissionId}-other`),
            ),
          }),
        ),
      );

      yield* ensure(
        isSettlementConflict(wrongFinalization) &&
          wrongFinalization.existingOutcome === "completed",
        "Finalization disagreeing with the reserved settlement must conflict",
      );

      const settlement = yield* ledger.finalizeSettlement(
        SettlementFinalization.make({
          submissionId: admitted.submissionId,
          settlementId: reservation.settlementId,
        }),
      );

      yield* ensure(
        settlement.outcome === "completed",
        "The originally reserved outcome must remain the one that settles",
      );
    }),
);

const abortIdempotency = conformanceCase(
  "records abort intent idempotently and refuses to abort settled work",
  ({ ensure, expectFailure, expectSome }) =>
    Effect.gen(function* () {
      const threadId = decodeThreadId("ledger-conformance-abort");
      const ledger = yield* SubmissionLedger;

      const admitted = yield* ledger.admit(
        yield* admissionRequest(threadId, "abort-key-1", { work: "abort" }),
      );

      const readRequest = AbortIntentRequest.make({ submissionId: admitted.submissionId });

      yield* ensure(
        (yield* ledger.readAbortIntent(readRequest)) === undefined,
        "An admitted Submission without an abort intent must return undefined",
      );

      const intent = yield* ledger.requestAbort(
        AbortCommand.make({
          submissionId: admitted.submissionId,
          author: "conformance-operator",
          reason: "first abort request",
        }),
      );

      yield* TestClock.adjust("1 second");

      const repeated = yield* ledger.requestAbort(
        AbortCommand.make({
          submissionId: admitted.submissionId,
          author: "conformance-operator",
          reason: "second abort request",
        }),
      );

      yield* ensure(
        repeated.reason === intent.reason &&
          repeated.author === intent.author &&
          sameInstant(repeated.requestedAt, intent.requestedAt),
        "Repeating an abort command must return the recorded intent unchanged",
      );
      const snapshot = yield* recoverySnapshot(admitted.submissionId);
      const narrow = yield* ledger.readAbortIntent(readRequest);

      yield* ensure(
        snapshot.abortIntent !== undefined && snapshot.abortIntent.reason === intent.reason,
        "The recovery snapshot must expose the recorded abort intent",
      );
      yield* ensure(
        narrow !== undefined &&
          narrow.submissionId === intent.submissionId &&
          narrow.author === intent.author &&
          narrow.reason === intent.reason &&
          sameInstant(narrow.requestedAt, intent.requestedAt) &&
          narrow.canonicalRecordId === snapshot.abortIntent?.canonicalRecordId,
        "The narrow read must preserve the recorded intent and canonical proof",
      );

      const unknown = yield* expectFailure(
        "reading an unknown Submission's abort intent",
        ledger.readAbortIntent(
          AbortIntentRequest.make({ submissionId: decodeSubmissionId("unknown-abort-target") }),
        ),
      );

      yield* ensure(unknown._tag === "LedgerError", "Unknown abort targets must fail typed");

      const settledLane = decodeThreadId("ledger-conformance-abort-settled");
      const settledWork = yield* admitReady(settledLane, "abort-key-2", { work: "settled" });

      const claim = yield* expectSome(
        "the claim on the settled lane",
        yield* claimLane(settledLane, PRODUCER_A),
      );

      yield* settleClaimed(settledWork, claim.ownershipToken);

      const terminalAbort = yield* expectFailure(
        "aborting a settled Submission",
        ledger.requestAbort(
          AbortCommand.make({
            submissionId: settledWork.submissionId,
            author: "conformance-operator",
            reason: "too late",
          }),
        ),
      );

      yield* ensure(
        isSettlementConflict(terminalAbort) && terminalAbort.existingOutcome === "completed",
        "Abort must never rewrite a terminal outcome",
      );
    }),
);

const scanNonterminalWorklist = conformanceCase(
  "scans exactly the unsettled work in lane order",
  ({ ensure, expectSome }) =>
    Effect.gen(function* () {
      const laneA = decodeThreadId("ledger-conformance-scan-a");
      const laneB = decodeThreadId("ledger-conformance-scan-b");
      const ledger = yield* SubmissionLedger;

      const first = yield* admitReady(laneA, "scan-key-1", { step: 1 });
      const second = yield* admitReady(laneA, "scan-key-2", { step: 2 });
      const third = yield* admitReady(laneA, "scan-key-3", { step: 3 });
      const settledElsewhere = yield* admitReady(laneB, "scan-key-4", { step: 4 });

      const firstClaim = yield* expectSome(
        "the claim on the first head",
        yield* claimLane(laneA, PRODUCER_A),
      );

      yield* settleClaimed(first, firstClaim.ownershipToken);
      yield* expectSome("the claim on the second head", yield* claimLane(laneA, PRODUCER_A));

      const otherClaim = yield* expectSome(
        "the claim on the other lane",
        yield* claimLane(laneB, PRODUCER_A),
      );

      yield* settleClaimed(settledElsewhere, otherClaim.ownershipToken);

      const scanned = yield* ledger.scanNonterminal.pipe(Stream.runCollect);

      yield* ensure(
        scanned.every((snapshot) => snapshot.state !== "settled"),
        "scanNonterminal must never emit settled Submissions",
      );

      const mine = scanned.filter(
        (snapshot) => snapshot.threadId === laneA || snapshot.threadId === laneB,
      );

      yield* ensure(
        mine.length === 2 &&
          mine.at(0)?.submissionId === second.submissionId &&
          mine.at(1)?.submissionId === third.submissionId,
        "scanNonterminal must emit exactly the unsettled Submissions in queue-sequence order",
      );
      yield* ensure(
        mine.at(0)?.state === "running" && mine.at(1)?.state === "ready",
        "scanNonterminal entries must carry the current Submission states",
      );
      yield* ensure(
        mine.at(0)?.receiptId === second.receiptId &&
          mine.at(1)?.receiptId === third.receiptId &&
          mine.every(
            (entry) =>
              entry.principal === CONFORMANCE_PRINCIPAL &&
              !("inputPayload" in entry) &&
              !("workerAdmission" in entry) &&
              !("messageAdmission" in entry),
          ),
        "The worklist retains receipt and principal identity without execution payloads",
      );
      const start = scanned.findIndex((snapshot) => snapshot.submissionId === second.submissionId);

      yield* ensure(
        start >= 0 && scanned.at(start + 1)?.submissionId === third.submissionId,
        "One lane's unsettled Submissions must be contiguous in (thread, sequence) order",
      );
    }),
);

const lookupByIdAndKey = conformanceCase(
  "looks up submissions by identity and scoped idempotency key with strong reads",
  ({ ensure, expectSome }) =>
    Effect.gen(function* () {
      const threadId = decodeThreadId("ledger-conformance-lookup");
      const ledger = yield* SubmissionLedger;
      const request = yield* admissionRequest(threadId, "lookup-key-1", { city: "Kyoto" });
      const admitted = yield* ledger.admit(request);

      const byId = yield* expectSome(
        "lookup by Submission identity",
        yield* lookupById(admitted.submissionId),
      );

      yield* ensure(
        byId.submissionId === admitted.submissionId &&
          byId.threadId === threadId &&
          byId.queueSequence === admitted.queueSequence &&
          byId.principal === request.principal &&
          byId.idempotencyKey === request.idempotencyKey &&
          byId.agentId === request.agentId &&
          byId.deploymentId === request.deploymentId &&
          byId.inputDigest === request.inputDigest &&
          byId.receiptId === admitted.receiptId &&
          byId.state === "admitted" &&
          byId.settledOutcome === undefined &&
          byId.readyAt === undefined,
        "Lookup by identity must return the full admission snapshot",
      );

      const byKey = yield* expectSome(
        "lookup by scoped idempotency key",
        yield* ledger.lookup(
          SubmissionLookupByKey.make({
            threadId,
            principal: request.principal,
            idempotencyKey: request.idempotencyKey,
          }),
        ),
      );

      yield* ensure(
        byKey.submissionId === admitted.submissionId,
        "Lookup by key must resolve to the same Submission as lookup by identity",
      );

      yield* ensure(
        Option.isNone(
          yield* lookupById(decodeSubmissionId("submission-ledger-conformance-missing")),
        ),
        "Lookup of an unknown Submission identity must return none",
      );
      yield* ensure(
        Option.isNone(
          yield* ledger.lookup(
            SubmissionLookupByKey.make({
              threadId,
              principal: request.principal,
              idempotencyKey: decodeIdempotencyKey("lookup-key-missing"),
            }),
          ),
        ),
        "Lookup of an unknown idempotency key must return none",
      );
      yield* ensure(
        Option.isNone(
          yield* ledger.lookup(
            SubmissionLookupByKey.make({
              threadId,
              principal: OTHER_PRINCIPAL,
              idempotencyKey: request.idempotencyKey,
            }),
          ),
        ),
        "Idempotency keys must be scoped to their principal",
      );

      yield* ledger.markReady(MarkReadyRequest.make({ submissionId: admitted.submissionId }));

      const readyByKey = yield* expectSome(
        "lookup by key after readiness",
        yield* ledger.lookup(
          SubmissionLookupByKey.make({
            threadId,
            principal: request.principal,
            idempotencyKey: request.idempotencyKey,
          }),
        ),
      );

      yield* ensure(
        readyByKey.state === "ready" && readyByKey.readyAt !== undefined,
        "Lookups must observe prior writes with strong consistency",
      );
    }),
);

const recoverySnapshotConsistency = conformanceCase(
  "loads a strongly consistent recovery snapshot without exposing the live token",
  ({ ensure, expectSome }) =>
    Effect.gen(function* () {
      const threadId = decodeThreadId("ledger-conformance-recovery");
      const ledger = yield* SubmissionLedger;
      const admitted = yield* admitReady(threadId, "recovery-key-1", { work: "recovery" });

      const initial = yield* recoverySnapshot(admitted.submissionId);

      yield* ensure(
        initial.submission.state === "ready" &&
          initial.ownership === undefined &&
          initial.inputApplied === undefined &&
          initial.reservation === undefined &&
          initial.abortIntent === undefined,
        "A ready, unclaimed Submission must have no ownership, marker, reservation, or intent",
      );

      const claim = yield* expectSome(
        "the claim before snapshotting",
        yield* claimLane(threadId, PRODUCER_A),
      );

      const owned = yield* recoverySnapshot(admitted.submissionId);

      yield* ensure(
        owned.ownership !== undefined &&
          owned.ownership.attemptId === claim.attemptId &&
          owned.ownership.producerEpoch === claim.producerEpoch &&
          owned.ownership.ownerProducerId === PRODUCER_A &&
          sameInstant(owned.ownership.leaseExpiresAt, claim.leaseExpiresAt),
        "The recovery snapshot must expose the live Attempt's identity, owner, epoch, and lease",
      );

      const marker = MarkInputAppliedRequest.make({
        submissionId: admitted.submissionId,
        ownershipToken: claim.ownershipToken,
        recordId: submissionInputRecordId(admitted.submissionId),
        sequence: decodeSequence(3),
      });

      yield* ledger.markInputApplied(marker);
      yield* ledger.requestAbort(
        AbortCommand.make({
          submissionId: admitted.submissionId,
          author: "conformance-operator",
          reason: "abort during recovery case",
        }),
      );

      const reservation = yield* settlementReservation({
        submissionId: admitted.submissionId,
        ownershipToken: claim.ownershipToken,
        receiptId: admitted.receiptId,
        outcome: "aborted",
      });

      yield* ledger.reserveSettlement(reservation);

      const reserved = yield* recoverySnapshot(admitted.submissionId);

      yield* ensure(
        reserved.inputApplied !== undefined &&
          reserved.inputApplied.recordId === marker.recordId &&
          reserved.inputApplied.sequence === marker.sequence,
        "The recovery snapshot must expose the applied-input marker",
      );
      yield* ensure(
        reserved.abortIntent !== undefined &&
          reserved.abortIntent.reason === "abort during recovery case",
        "The recovery snapshot must expose the abort intent",
      );
      yield* ensure(
        reserved.reservation !== undefined &&
          !reserved.reservation.finalized &&
          reserved.reservation.settlementId === reservation.settlementId &&
          reserved.reservation.outcome === "aborted" &&
          reserved.reservation.recordDigest === reservation.recordDigest,
        "The recovery snapshot must expose the unfinalized reservation with its exact record",
      );

      yield* ledger.finalizeSettlement(
        SettlementFinalization.make({
          submissionId: admitted.submissionId,
          settlementId: reservation.settlementId,
        }),
      );
      const settled = yield* recoverySnapshot(admitted.submissionId);

      yield* ensure(
        settled.submission.state === "settled" &&
          settled.submission.settledOutcome === "aborted" &&
          settled.reservation !== undefined &&
          settled.reservation.finalized,
        "After finalization the snapshot must show the settled state and finalized reservation",
      );
    }),
);

const joiningPrefixClaim = conformanceCase(
  "claims a contiguous joining prefix and stops at a gap",
  ({ ensure, expectFailure, expectSome }) =>
    Effect.gen(function* () {
      const threadId = decodeThreadId("ledger-conformance-joining-prefix");
      const ledger = yield* SubmissionLedger;

      const host = yield* admitReady(threadId, "join-prefix-host", { work: "host" });
      const second = yield* admitReady(threadId, "join-prefix-2", { queued: 2 });
      const third = yield* admitReady(threadId, "join-prefix-3", { queued: 3 });

      // Admitted but never marked ready: the gap that breaks the contiguous prefix.
      const fourth = yield* ledger.admit(
        yield* admissionRequest(threadId, "join-prefix-4", { queued: 4 }),
      );

      const fifth = yield* admitReady(threadId, "join-prefix-5", { queued: 5 });

      const hostClaim = yield* expectSome("the host claim", yield* claimLane(threadId, PRODUCER_A));

      yield* ensure(
        hostClaim.submissionId === host.submissionId,
        "The host must head the lane before joining later work",
      );

      const foreign = yield* expectFailure(
        "claiming joining work without owning the host lane",
        ledger.claimJoining(
          ClaimJoiningRequest.make({
            threadId,
            hostSubmissionId: host.submissionId,
            ownershipToken: BOGUS_TOKEN,
            maxCount: 8,
          }),
        ),
      );

      yield* ensure(
        isOwnershipLost(foreign),
        "claimJoining must be fenced by the host's ownership token",
      );

      const first = yield* ledger.claimJoining(
        ClaimJoiningRequest.make({
          threadId,
          hostSubmissionId: host.submissionId,
          ownershipToken: hostClaim.ownershipToken,
          maxCount: 1,
        }),
      );

      yield* ensure(
        first.length === 1 &&
          first[0].submissionId === second.submissionId &&
          first[0].queueSequence === second.queueSequence &&
          persistedJsonEquivalent(first[0].inputPayload, { queued: 2 }),
        "maxCount must bound the claim to exactly the next queued Submission with its input",
      );

      const rest = yield* ledger.claimJoining(
        ClaimJoiningRequest.make({
          threadId,
          hostSubmissionId: host.submissionId,
          ownershipToken: hostClaim.ownershipToken,
          maxCount: 8,
        }),
      );

      yield* ensure(
        rest.length === 1 && rest[0].submissionId === third.submissionId,
        "A repeated claim must skip already-joining rows and stop at the admitted gap",
      );

      const blocked = yield* ledger.claimJoining(
        ClaimJoiningRequest.make({
          threadId,
          hostSubmissionId: host.submissionId,
          ownershipToken: hostClaim.ownershipToken,
          maxCount: 8,
        }),
      );

      yield* ensure(
        blocked.length === 0,
        "An admitted-not-ready row must break the contiguous prefix and hide later ready work",
      );

      const secondState = yield* expectSome(
        "lookup of a claimed joining Submission",
        yield* lookupById(second.submissionId),
      );

      const fourthState = yield* expectSome(
        "lookup of the gap Submission",
        yield* lookupById(fourth.submissionId),
      );

      const fifthState = yield* expectSome(
        "lookup of the ready Submission after the gap",
        yield* lookupById(fifth.submissionId),
      );

      yield* ensure(
        secondState.state === "joining" &&
          fourthState.state === "admitted" &&
          fifthState.state === "ready",
        "Claiming must transition exactly the claimed prefix to joining",
      );

      const hostSnapshot = yield* recoverySnapshot(host.submissionId);

      yield* ensure(
        hostSnapshot.joins.length === 2 &&
          hostSnapshot.joins[0].submissionId === second.submissionId &&
          hostSnapshot.joins[0].state === "joining" &&
          hostSnapshot.joins[0].hostSubmissionId === host.submissionId &&
          hostSnapshot.joins[1].submissionId === third.submissionId,
        "The host recovery snapshot must expose the claimed prefix in queue order",
      );
      const joinedSide = yield* recoverySnapshot(second.submissionId);

      yield* ensure(
        joinedSide.hostSubmissionId === host.submissionId,
        "A joining Submission's recovery snapshot must expose its host linkage",
      );

      yield* ledger.markReady(MarkReadyRequest.make({ submissionId: fourth.submissionId }));

      const afterGap = yield* ledger.claimJoining(
        ClaimJoiningRequest.make({
          threadId,
          hostSubmissionId: host.submissionId,
          ownershipToken: hostClaim.ownershipToken,
          maxCount: 8,
        }),
      );

      yield* ensure(
        afterGap.length === 2 &&
          afterGap[0].submissionId === fourth.submissionId &&
          afterGap[1].submissionId === fifth.submissionId,
        "Once the gap closes, the claim must extend past already-claimed rows in queue order",
      );
    }),
);

const revertJoiningReturnsToReady = conformanceCase(
  "revertJoining returns exactly the pre-append claims to ready",
  ({ ensure, expectSome }) =>
    Effect.gen(function* () {
      const threadId = decodeThreadId("ledger-conformance-revert-joining");
      const ledger = yield* SubmissionLedger;

      const host = yield* admitReady(threadId, "revert-host", { work: "host" });
      const second = yield* admitReady(threadId, "revert-2", { queued: 2 });
      const third = yield* admitReady(threadId, "revert-3", { queued: 3 });
      const hostClaim = yield* expectSome("the host claim", yield* claimLane(threadId, PRODUCER_A));

      const claims = yield* ledger.claimJoining(
        ClaimJoiningRequest.make({
          threadId,
          hostSubmissionId: host.submissionId,
          ownershipToken: hostClaim.ownershipToken,
          maxCount: 8,
        }),
      );

      yield* ensure(claims.length === 2, "Both queued Submissions must join the host's prefix");

      // third's canonical input is appended; second's never is.
      yield* ledger.markJoined(
        MarkJoinedRequest.make({
          submissionId: third.submissionId,
          ownershipToken: hostClaim.ownershipToken,
          recordId: submissionInputRecordId(third.submissionId),
          sequence: decodeSequence(7),
        }),
      );

      yield* ledger.revertJoining(RevertJoiningRequest.make({ submissionId: second.submissionId }));

      const reverted = yield* expectSome(
        "lookup after revert",
        yield* lookupById(second.submissionId),
      );

      yield* ensure(
        reverted.state === "ready",
        "Reverting a pre-append joining Submission must return it to ready",
      );
      const revertedSnapshot = yield* recoverySnapshot(second.submissionId);

      yield* ensure(
        revertedSnapshot.hostSubmissionId === undefined,
        "Reverting must clear the host linkage",
      );
      const hostSnapshot = yield* recoverySnapshot(host.submissionId);

      yield* ensure(
        hostSnapshot.joins.length === 1 &&
          hostSnapshot.joins[0].submissionId === third.submissionId &&
          hostSnapshot.joins[0].state === "joined",
        "The reverted Submission must leave the host's join view",
      );

      yield* ledger.revertJoining(RevertJoiningRequest.make({ submissionId: second.submissionId }));

      const stillReady = yield* expectSome(
        "lookup after repeating the revert",
        yield* lookupById(second.submissionId),
      );

      yield* ensure(stillReady.state === "ready", "Repeating revertJoining must be a no-op");

      // A post-append joined Submission must NOT revert (DUR-016: it reattaches instead).
      yield* ledger.revertJoining(RevertJoiningRequest.make({ submissionId: third.submissionId }));

      const joined = yield* expectSome(
        "lookup of the joined Submission after an attempted revert",
        yield* lookupById(third.submissionId),
      );

      yield* ensure(
        joined.state === "joined",
        "revertJoining must be a no-op for an already-joined Submission",
      );

      const reclaimed = yield* ledger.claimJoining(
        ClaimJoiningRequest.make({
          threadId,
          hostSubmissionId: host.submissionId,
          ownershipToken: hostClaim.ownershipToken,
          maxCount: 8,
        }),
      );

      yield* ensure(
        reclaimed.length === 1 && reclaimed[0].submissionId === second.submissionId,
        "A reverted Submission must be claimable again exactly once",
      );
    }),
);

const markJoinedIdempotency = conformanceCase(
  "markJoined is idempotent and repairable from history",
  ({ ensure, expectFailure, expectSome }) =>
    Effect.gen(function* () {
      const threadId = decodeThreadId("ledger-conformance-mark-joined");
      const ledger = yield* SubmissionLedger;

      const host = yield* admitReady(threadId, "mark-joined-host", { work: "host" });
      const second = yield* admitReady(threadId, "mark-joined-2", { queued: 2 });
      const third = yield* admitReady(threadId, "mark-joined-3", { queued: 3 });
      const hostClaim = yield* expectSome("the host claim", yield* claimLane(threadId, PRODUCER_A));

      yield* ledger.claimJoining(
        ClaimJoiningRequest.make({
          threadId,
          hostSubmissionId: host.submissionId,
          ownershipToken: hostClaim.ownershipToken,
          maxCount: 8,
        }),
      );

      const marker = MarkJoinedRequest.make({
        submissionId: second.submissionId,
        ownershipToken: hostClaim.ownershipToken,
        recordId: submissionInputRecordId(second.submissionId),
        sequence: decodeSequence(4),
      });

      yield* ledger.markJoined(marker);

      const joined = yield* expectSome(
        "lookup after marking joined",
        yield* lookupById(second.submissionId),
      );

      yield* ensure(
        joined.state === "joined",
        "Marking the canonical input position must transition joining to joined",
      );

      yield* ledger.markJoined(marker);
      const snapshot = yield* recoverySnapshot(second.submissionId);

      yield* ensure(
        snapshot.submission.state === "joined" &&
          snapshot.hostSubmissionId === host.submissionId &&
          snapshot.inputApplied !== undefined &&
          snapshot.inputApplied.recordId === marker.recordId &&
          snapshot.inputApplied.sequence === marker.sequence,
        "Repeating the identical join marker must be a no-op with the marker retained",
      );

      const divergent = yield* expectFailure(
        "re-marking with a different canonical position",
        ledger.markJoined(
          MarkJoinedRequest.make({
            submissionId: second.submissionId,
            ownershipToken: hostClaim.ownershipToken,
            recordId: marker.recordId,
            sequence: decodeSequence(5),
          }),
        ),
      );

      yield* ensure(
        !isOwnershipLost(divergent),
        "A divergent join marker must fail as a ledger integrity error, not ownership loss",
      );

      const stale = yield* expectFailure(
        "marking joined without owning the host lane",
        ledger.markJoined(
          MarkJoinedRequest.make({
            submissionId: third.submissionId,
            ownershipToken: BOGUS_TOKEN,
            recordId: submissionInputRecordId(third.submissionId),
            sequence: decodeSequence(6),
          }),
        ),
      );

      yield* ensure(isOwnershipLost(stale), "markJoined must be fenced by the host's ownership");

      // Repairable from history: the host Attempt dies and a later host Attempt repairs the
      // lost marker under its fresh ownership token (DUR-016).
      yield* ledger.releaseOwnership(
        ReleaseOwnershipRequest.make({
          submissionId: host.submissionId,
          ownershipToken: hostClaim.ownershipToken,
        }),
      );

      const reclaim = yield* expectSome(
        "the host reclaim after release",
        yield* claimLane(threadId, PRODUCER_B),
      );

      yield* ensure(
        reclaim.submissionId === host.submissionId &&
          reclaim.producerEpoch > hostClaim.producerEpoch,
        "The host must be reclaimable while its joined work is pending",
      );

      const superseded = yield* expectFailure(
        "repairing the marker with the superseded host token",
        ledger.markJoined(
          MarkJoinedRequest.make({
            submissionId: third.submissionId,
            ownershipToken: hostClaim.ownershipToken,
            recordId: submissionInputRecordId(third.submissionId),
            sequence: decodeSequence(6),
          }),
        ),
      );

      yield* ensure(
        isOwnershipLost(superseded),
        "A superseded host token must not repair a join marker",
      );
      yield* ledger.markJoined(
        MarkJoinedRequest.make({
          submissionId: third.submissionId,
          ownershipToken: reclaim.ownershipToken,
          recordId: submissionInputRecordId(third.submissionId),
          sequence: decodeSequence(6),
        }),
      );

      const repaired = yield* expectSome(
        "lookup after the repair",
        yield* lookupById(third.submissionId),
      );

      yield* ensure(
        repaired.state === "joined",
        "A later host Attempt must repair the lost join marker from history",
      );
    }),
);

const claimNeverGrantsBlockedHead = conformanceCase(
  "claim never grants a suspended, unknown, joining, or joined head",
  ({ ensure, expectFailure, expectSome }) =>
    Effect.gen(function* () {
      const ledger = yield* SubmissionLedger;

      // joining head: the host settled while a claimed-but-unappended join was pending.
      const joiningLane = decodeThreadId("ledger-conformance-head-joining");
      const joiningHost = yield* admitReady(joiningLane, "head-joining-host", { work: "host" });
      const joiningSub = yield* admitReady(joiningLane, "head-joining-2", { queued: 2 });

      yield* admitReady(joiningLane, "head-joining-3", { queued: 3 });

      const joiningHostClaim = yield* expectSome(
        "the joining lane's host claim",
        yield* claimLane(joiningLane, PRODUCER_A),
      );

      yield* ledger.claimJoining(
        ClaimJoiningRequest.make({
          threadId: joiningLane,
          hostSubmissionId: joiningHost.submissionId,
          ownershipToken: joiningHostClaim.ownershipToken,
          maxCount: 1,
        }),
      );
      yield* settleClaimed(joiningHost, joiningHostClaim.ownershipToken);
      yield* ensure(
        Option.isNone(yield* claimLane(joiningLane, PRODUCER_B)),
        "A joining head must block the lane; later ready work is never skipped past it",
      );
      yield* ledger.revertJoining(
        RevertJoiningRequest.make({ submissionId: joiningSub.submissionId }),
      );

      const afterRevert = yield* expectSome(
        "the claim after reverting the joining head",
        yield* claimLane(joiningLane, PRODUCER_B),
      );

      yield* ensure(
        afterRevert.submissionId === joiningSub.submissionId,
        "Reverting the joining head must make it claimable in FIFO order",
      );

      // joined head: the host settled between its finalization and the joined settlement.
      const joinedLane = decodeThreadId("ledger-conformance-head-joined");
      const joinedHost = yield* admitReady(joinedLane, "head-joined-host", { work: "host" });
      const joinedSub = yield* admitReady(joinedLane, "head-joined-2", { queued: 2 });

      const joinedHostClaim = yield* expectSome(
        "the joined lane's host claim",
        yield* claimLane(joinedLane, PRODUCER_A),
      );

      yield* ledger.claimJoining(
        ClaimJoiningRequest.make({
          threadId: joinedLane,
          hostSubmissionId: joinedHost.submissionId,
          ownershipToken: joinedHostClaim.ownershipToken,
          maxCount: 1,
        }),
      );
      yield* ledger.markJoined(
        MarkJoinedRequest.make({
          submissionId: joinedSub.submissionId,
          ownershipToken: joinedHostClaim.ownershipToken,
          recordId: submissionInputRecordId(joinedSub.submissionId),
          sequence: decodeSequence(3),
        }),
      );

      const joinedAbort = yield* expectFailure(
        "aborting a joined Submission",
        ledger.requestAbort(
          AbortCommand.make({
            submissionId: joinedSub.submissionId,
            author: "conformance-operator",
            reason: "joined abort target",
          }),
        ),
      );

      yield* ensure(
        isJoinedToHost(joinedAbort) && joinedAbort.hostSubmissionId === joinedHost.submissionId,
        "Abort of a joined Submission must fail with the host linkage — the abort target is the host",
      );
      yield* settleClaimed(joinedHost, joinedHostClaim.ownershipToken);
      yield* ensure(
        Option.isNone(yield* claimLane(joinedLane, PRODUCER_B)),
        "A joined head must block the lane; it settles with the host, never with a worker claim",
      );

      // suspended head: durable approval waiting consumes no worker permit.
      const suspendedLane = decodeThreadId("ledger-conformance-head-suspended");

      const suspendedHost = yield* admitReady(suspendedLane, "head-suspended-host", {
        work: "host",
      });

      const suspendedClaim = yield* expectSome(
        "the suspended lane's claim",
        yield* claimLane(suspendedLane, PRODUCER_A),
      );

      const gatedCall = decodeToolCallId("call-head-suspended");

      const suspendOutcome = yield* ledger.suspend(
        SuspendRequest.make({
          submissionId: suspendedHost.submissionId,
          ownershipToken: suspendedClaim.ownershipToken,
          reason: ApprovalPendingSuspension.make({ toolCallIds: [gatedCall] }),
        }),
      );

      yield* ensure(suspendOutcome === "suspended", "An undecided approval must suspend durably");
      yield* ensure(
        Option.isNone(yield* claimLane(suspendedLane, PRODUCER_B)),
        "A suspended head must produce no claim",
      );
      yield* ledger.recordApprovalDecision(
        ApprovalDecisionCommand.make({
          submissionId: suspendedHost.submissionId,
          toolCallId: gatedCall,
          decision: "approved",
          resolver: "conformance-approver",
          reason: "unblock the suspended head",
        }),
      );

      const wokenClaim = yield* expectSome(
        "the claim after the covering decision",
        yield* claimLane(suspendedLane, PRODUCER_B),
      );

      yield* ensure(
        wokenClaim.submissionId === suspendedHost.submissionId &&
          wokenClaim.producerEpoch > suspendedClaim.producerEpoch,
        "A covering decision must wake the lane for a fresh fenced Attempt",
      );

      // unknown head: the DUR-017 blocked lane outlives lease expiry.
      const unknownLane = decodeThreadId("ledger-conformance-head-unknown");
      const unknownHost = yield* admitReady(unknownLane, "head-unknown-host", { work: "host" });

      const unknownClaim = yield* expectSome(
        "the unknown lane's claim",
        yield* claimLane(unknownLane, PRODUCER_A),
      );

      const unknownCall = decodeToolCallId("call-head-unknown");

      yield* ledger.markUnknown(
        MarkUnknownRequest.make({
          submissionId: unknownHost.submissionId,
          toolCallIds: [unknownCall],
          reason: "an ordinary call may have executed",
        }),
      );
      yield* advancePastLease(unknownClaim.leaseExpiresAt);
      yield* ensure(
        Option.isNone(yield* claimLane(unknownLane, PRODUCER_B)),
        "An unknown head must stay blocked even after the stale lease expires",
      );
      yield* ledger.recordUnknownResolution(
        UnknownResolutionCommand.make({
          submissionId: unknownHost.submissionId,
          toolCallId: unknownCall,
          author: "conformance-operator",
          reason: "supplier store shows no effect",
          resolution: ResolutionNeverHappened.make(),
        }),
      );

      const reopened = yield* expectSome(
        "the claim after the covering resolution",
        yield* claimLane(unknownLane, PRODUCER_B),
      );

      yield* ensure(
        reopened.submissionId === unknownHost.submissionId,
        "A covering resolution must reopen the blocked lane",
      );
    }),
);

const approvalDecisionIdempotency = conformanceCase(
  "approval decisions are idempotent and conflict on divergence",
  ({ ensure, expectFailure, expectSome }) =>
    Effect.gen(function* () {
      const threadId = decodeThreadId("ledger-conformance-approval");
      const ledger = yield* SubmissionLedger;
      const admitted = yield* admitReady(threadId, "approval-key-1", { work: "approve" });

      const claim = yield* expectSome(
        "the claim before decisions",
        yield* claimLane(threadId, PRODUCER_A),
      );

      const callA = decodeToolCallId("call-approval-a");
      const callB = decodeToolCallId("call-approval-b");

      const first = yield* ledger.recordApprovalDecision(
        ApprovalDecisionCommand.make({
          submissionId: admitted.submissionId,
          toolCallId: callA,
          decision: "approved",
          resolver: "conformance-approver",
          reason: "policy allows the booking",
        }),
      );

      yield* ensure(
        first.decision === "approved" && first.toolCallId === callA,
        "The first decision must record the intent",
      );

      yield* TestClock.adjust("1 second");

      const replayed = yield* ledger.recordApprovalDecision(
        ApprovalDecisionCommand.make({
          submissionId: admitted.submissionId,
          toolCallId: callA,
          decision: "approved",
          resolver: "conformance-approver-second",
          reason: "a different reason text",
        }),
      );

      yield* ensure(
        replayed.reason === first.reason &&
          replayed.resolver === first.resolver &&
          sameInstant(replayed.decidedAt, first.decidedAt),
        "Repeating the same decision must replay the recorded intent unchanged",
      );

      const conflict = yield* expectFailure(
        "re-deciding the same call divergently",
        ledger.recordApprovalDecision(
          ApprovalDecisionCommand.make({
            submissionId: admitted.submissionId,
            toolCallId: callA,
            decision: "denied",
            resolver: "conformance-approver",
            reason: "changed my mind",
          }),
        ),
      );

      yield* ensure(
        isApprovalConflict(conflict) &&
          conflict.toolCallId === callA &&
          conflict.existingDecision === "approved",
        "A divergent re-decision must conflict with the recorded decision",
      );

      yield* ledger.recordApprovalDecision(
        ApprovalDecisionCommand.make({
          submissionId: admitted.submissionId,
          toolCallId: callB,
          decision: "denied",
          resolver: "conformance-approver",
          reason: "policy denies the cancellation",
        }),
      );
      const snapshot = yield* recoverySnapshot(admitted.submissionId);

      yield* ensure(
        snapshot.approvalDecisions.length === 2 &&
          snapshot.approvalDecisions.some(
            (intent) => intent.toolCallId === callA && intent.decision === "approved",
          ) &&
          snapshot.approvalDecisions.some(
            (intent) => intent.toolCallId === callB && intent.decision === "denied",
          ),
        "The recovery snapshot must expose every recorded decision intent",
      );

      yield* settleClaimed(admitted, claim.ownershipToken);

      const late = yield* expectFailure(
        "deciding an approval for a settled Submission",
        ledger.recordApprovalDecision(
          ApprovalDecisionCommand.make({
            submissionId: admitted.submissionId,
            toolCallId: decodeToolCallId("call-approval-late"),
            decision: "approved",
            resolver: "conformance-approver",
            reason: "too late",
          }),
        ),
      );

      yield* ensure(
        isSettlementConflict(late) && late.existingOutcome === "completed",
        "A decision must never land on a settled Submission",
      );
    }),
);

const unknownAbortClaim = conformanceCase(
  "a durable abort makes an unknown head claimable without resolving or replaying its calls",
  ({ ensure, expectFailure, expectSome }) =>
    Effect.gen(function* () {
      const ledger = yield* SubmissionLedger;

      for (const abortFirst of [false, true]) {
        const threadId = decodeThreadId(`ledger-conformance-unknown-abort-${abortFirst}`);
        const head = yield* admitReady(threadId, "head", { work: "uncertain" });

        const original = yield* expectSome(
          "original claim",
          yield* claimLane(threadId, PRODUCER_A),
        );

        const follower = yield* admitReady(threadId, "follower", { work: "later" });

        const command = AbortCommand.make({
          submissionId: head.submissionId,
          author: "first-operator",
          reason: "stop without asserting external rollback",
        });

        if (abortFirst) yield* ledger.requestAbort(command);
        yield* ledger.markUnknown(
          MarkUnknownRequest.make({
            submissionId: head.submissionId,
            toolCallIds: [decodeToolCallId("uncertain-one"), decodeToolCallId("uncertain-two")],
            reason: "external replies were lost",
          }),
        );
        if (abortFirst) {
          yield* ensure(
            Option.isNone(yield* claimLane(threadId, PRODUCER_B)),
            "Abort must not bypass a still-live ownership lease",
          );
        }
        yield* advancePastLease(original.leaseExpiresAt);
        if (!abortFirst) {
          const later = yield* expectSome(
            "runnable follower behind unknown work",
            yield* claimLane(threadId, PRODUCER_B),
          );

          yield* ensure(
            later.submissionId === follower.submissionId,
            "Unknown work must preserve the queue order of runnable followers",
          );
          yield* ledger.releaseOwnership(
            ReleaseOwnershipRequest.make({
              submissionId: later.submissionId,
              ownershipToken: later.ownershipToken,
            }),
          );
        }
        const intent = yield* ledger.requestAbort(command);

        const duplicate = yield* ledger.requestAbort(
          AbortCommand.make({
            ...command,
            author: "later-operator",
            reason: "lost acknowledgement retry",
          }),
        );

        yield* ensure(
          duplicate.author === intent.author &&
            duplicate.reason === intent.reason &&
            sameInstant(duplicate.requestedAt, intent.requestedAt),
          "The first abort audit must win",
        );

        const reclaimed = yield* expectSome(
          "unknown head with durable abort",
          yield* claimLane(threadId, PRODUCER_B),
        );

        yield* ensure(
          reclaimed.submissionId === head.submissionId &&
            reclaimed.producerEpoch > original.producerEpoch,
          "Abort must claim the head with a fresh fence, never skip to its follower",
        );
        const snapshot = yield* recoverySnapshot(head.submissionId);

        yield* ensure(
          snapshot.submission.state === "unknown" && snapshot.unknownResolutions.length === 0,
          "Claiming for abort must not erase uncertainty or manufacture tool resolutions",
        );

        const stale = yield* expectFailure(
          "stale owner",
          ledger.reserveSettlement(
            yield* settlementReservation({
              ...head,
              ownershipToken: original.ownershipToken,
              outcome: "completed",
            }),
          ),
        );

        yield* ensure(isOwnershipLost(stale), "The original owner must remain fenced");

        const reservation = yield* settlementReservation({
          ...head,
          ownershipToken: reclaimed.ownershipToken,
          outcome: "aborted",
        });

        yield* ledger.reserveSettlement(reservation);
        yield* ledger.requestAbort(command);
        const settled = yield* ledger.finalizeSettlement(SettlementFinalization.make(reservation));

        yield* ensure(
          settled.outcome === "aborted",
          "The abort reservation must survive a duplicate command",
        );
        const late = yield* expectFailure("abort after settlement", ledger.requestAbort(command));

        yield* ensure(
          isSettlementConflict(late) && late.existingOutcome === "aborted",
          "A terminal outcome must not change",
        );
        const next = yield* expectSome("follower claim", yield* claimLane(threadId, PRODUCER_B));

        yield* ensure(
          next.submissionId === follower.submissionId,
          "Settlement must release the follower",
        );
      }
    }),
);

const unknownResolutionLifecycle = conformanceCase(
  "unknown resolutions reopen the lane only when no open call remains",
  ({ ensure, expectFailure, expectSome }) =>
    Effect.gen(function* () {
      const threadId = decodeThreadId("ledger-conformance-unknown");
      const ledger = yield* SubmissionLedger;
      const admitted = yield* admitReady(threadId, "unknown-key-1", { work: "unknown" });

      const claim = yield* expectSome(
        "the claim before the unknown marking",
        yield* claimLane(threadId, PRODUCER_A),
      );

      const call1 = decodeToolCallId("call-unknown-1");
      const call2 = decodeToolCallId("call-unknown-2");
      const call3 = decodeToolCallId("call-unknown-3");

      const marking = MarkUnknownRequest.make({
        submissionId: admitted.submissionId,
        toolCallIds: [call1, call2],
        reason: "the worker died during two supplier calls",
      });

      yield* ledger.markUnknown(marking);
      yield* ledger.markUnknown(marking);

      const marked = yield* expectSome(
        "lookup after marking unknown",
        yield* lookupById(admitted.submissionId),
      );

      yield* ensure(
        marked.state === "unknown",
        "Marking unknown must be idempotent and block the lane",
      );

      yield* advancePastLease(claim.leaseExpiresAt);
      yield* ensure(
        Option.isNone(yield* claimLane(threadId, PRODUCER_B)),
        "An unknown lane must consume no worker permit",
      );

      const first = yield* ledger.recordUnknownResolution(
        UnknownResolutionCommand.make({
          submissionId: admitted.submissionId,
          toolCallId: call1,
          author: "conformance-operator",
          reason: "supplier store shows no booking",
          resolution: ResolutionNeverHappened.make(),
        }),
      );

      const partiallyResolved = yield* expectSome(
        "lookup after a partial resolution",
        yield* lookupById(admitted.submissionId),
      );

      yield* ensure(
        partiallyResolved.state === "unknown" &&
          Option.isNone(yield* claimLane(threadId, PRODUCER_B)),
        "A partial resolution must keep the lane blocked while calls remain open",
      );

      yield* TestClock.adjust("1 second");

      const divergent = yield* expectFailure(
        "re-resolving the same call divergently",
        ledger.recordUnknownResolution(
          UnknownResolutionCommand.make({
            submissionId: admitted.submissionId,
            toolCallId: call1,
            author: "conformance-operator",
            reason: "changed my mind",
            resolution: ResolutionSafeToRetry.make(),
          }),
        ),
      );

      yield* ensure(
        isUnknownResolutionConflict(divergent) && divergent.toolCallId === call1,
        "A divergent re-resolution must conflict",
      );

      const replayed = yield* ledger.recordUnknownResolution(
        UnknownResolutionCommand.make({
          submissionId: admitted.submissionId,
          toolCallId: call1,
          author: "conformance-operator-second",
          reason: "a different reason text",
          resolution: ResolutionNeverHappened.make(),
        }),
      );

      yield* ensure(
        sameInstant(replayed.resolvedAt, first.resolvedAt) && replayed.reason === first.reason,
        "Repeating the same resolution must replay the recorded intent unchanged",
      );

      // A later marking extends the open set; the lane must not reopen until it is covered too.
      yield* ledger.markUnknown(
        MarkUnknownRequest.make({
          submissionId: admitted.submissionId,
          toolCallIds: [call3],
          reason: "a second wave of uncertainty",
        }),
      );
      yield* ledger.recordUnknownResolution(
        UnknownResolutionCommand.make({
          submissionId: admitted.submissionId,
          toolCallId: call2,
          author: "conformance-operator",
          reason: "supplier confirmed the booking",
          resolution: ResolutionCompletedWithResult.make({
            result: { bookingRef: "booking-1" },
            isFailure: false,
          }),
        }),
      );

      const stillBlocked = yield* expectSome(
        "lookup while the extended set stays open",
        yield* lookupById(admitted.submissionId),
      );

      yield* ensure(
        stillBlocked.state === "unknown" && Option.isNone(yield* claimLane(threadId, PRODUCER_B)),
        "The lane must stay blocked while any marked call lacks a resolution",
      );

      yield* ledger.recordUnknownResolution(
        UnknownResolutionCommand.make({
          submissionId: admitted.submissionId,
          toolCallId: call3,
          author: "conformance-operator",
          reason: "idempotency key covers a repeat",
          resolution: ResolutionSafeToRetry.make(),
        }),
      );

      const reopenedState = yield* expectSome(
        "lookup after the covering resolution",
        yield* lookupById(admitted.submissionId),
      );

      yield* ensure(
        reopenedState.state === "input-applied",
        "Covering every marked call must reopen the lane as input-applied",
      );
      const snapshot = yield* recoverySnapshot(admitted.submissionId);

      yield* ensure(
        snapshot.unknownResolutions.length === 3,
        "The recovery snapshot must expose every recorded resolution intent",
      );

      const reclaim = yield* expectSome(
        "the claim after the lane reopened",
        yield* claimLane(threadId, PRODUCER_B),
      );

      yield* ensure(
        reclaim.submissionId === admitted.submissionId &&
          reclaim.producerEpoch > claim.producerEpoch,
        "The reopened lane must grant a fresh fenced Attempt",
      );

      yield* settleClaimed(admitted, reclaim.ownershipToken);

      const late = yield* expectFailure(
        "resolving an unknown call for a settled Submission",
        ledger.recordUnknownResolution(
          UnknownResolutionCommand.make({
            submissionId: admitted.submissionId,
            toolCallId: decodeToolCallId("call-unknown-late"),
            author: "conformance-operator",
            reason: "too late",
            resolution: ResolutionNeverHappened.make(),
          }),
        ),
      );

      yield* ensure(
        isSettlementConflict(late),
        "A resolution must never land on a settled Submission",
      );
    }),
);

const suspendResumesImmediatelyWhenDecided = conformanceCase(
  "suspend with an already-present decision resumes immediately",
  ({ ensure, expectFailure, expectSome }) =>
    Effect.gen(function* () {
      const threadId = decodeThreadId("ledger-conformance-suspend");
      const ledger = yield* SubmissionLedger;
      const admitted = yield* admitReady(threadId, "suspend-key-1", { work: "suspend" });

      const claim = yield* expectSome(
        "the claim before suspension",
        yield* claimLane(threadId, PRODUCER_A),
      );

      const callA = decodeToolCallId("call-suspend-a");
      const callB = decodeToolCallId("call-suspend-b");

      const foreign = yield* expectFailure(
        "suspending without owning the lane",
        ledger.suspend(
          SuspendRequest.make({
            submissionId: admitted.submissionId,
            ownershipToken: BOGUS_TOKEN,
            reason: ApprovalPendingSuspension.make({ toolCallIds: [callA] }),
          }),
        ),
      );

      yield* ensure(isOwnershipLost(foreign), "suspend must be fenced by the owning token");

      // The decision raced ahead of the suspend transaction (plan §2.6).
      yield* ledger.recordApprovalDecision(
        ApprovalDecisionCommand.make({
          submissionId: admitted.submissionId,
          toolCallId: callA,
          decision: "approved",
          resolver: "conformance-approver",
          reason: "decided before the suspend committed",
        }),
      );

      const immediate = yield* ledger.suspend(
        SuspendRequest.make({
          submissionId: admitted.submissionId,
          ownershipToken: claim.ownershipToken,
          reason: ApprovalPendingSuspension.make({ toolCallIds: [callA] }),
        }),
      );

      yield* ensure(
        immediate === "resume-immediately",
        "A fully-decided suspension reason must resume immediately",
      );

      const notSuspended = yield* expectSome(
        "lookup after the immediate resume",
        yield* lookupById(admitted.submissionId),
      );

      yield* ensure(
        notSuspended.state === "running",
        "An immediate resume must not transition the Submission to suspended",
      );
      // The ownership period must survive an immediate resume: the caller keeps working.
      yield* ledger.renewOwnership(
        RenewOwnershipRequest.make({
          submissionId: admitted.submissionId,
          ownershipToken: claim.ownershipToken,
        }),
      );

      const suspended = yield* ledger.suspend(
        SuspendRequest.make({
          submissionId: admitted.submissionId,
          ownershipToken: claim.ownershipToken,
          reason: ApprovalPendingSuspension.make({ toolCallIds: [callA, callB] }),
        }),
      );

      yield* ensure(
        suspended === "suspended",
        "An undecided call in the reason must suspend durably",
      );

      const suspendedState = yield* expectSome(
        "lookup after the suspension",
        yield* lookupById(admitted.submissionId),
      );

      yield* ensure(suspendedState.state === "suspended", "The suspension must be durable");
      const suspendedSnapshot = yield* recoverySnapshot(admitted.submissionId);

      yield* ensure(
        suspendedSnapshot.suspension !== undefined &&
          suspendedSnapshot.suspension.reason._tag === "ApprovalPending" &&
          suspendedSnapshot.suspension.reason.toolCallIds.length === 2 &&
          suspendedSnapshot.approvalDecisions.length === 1,
        "The recovery snapshot must expose the suspension reason and prior decisions",
      );

      const ended = yield* expectFailure(
        "renewing after the suspension ended the ownership period",
        ledger.renewOwnership(
          RenewOwnershipRequest.make({
            submissionId: admitted.submissionId,
            ownershipToken: claim.ownershipToken,
          }),
        ),
      );

      yield* ensure(
        isOwnershipLost(ended),
        "Suspension must end the ownership period without settling",
      );

      yield* ledger.recordApprovalDecision(
        ApprovalDecisionCommand.make({
          submissionId: admitted.submissionId,
          toolCallId: callB,
          decision: "denied",
          resolver: "conformance-approver",
          reason: "the covering decision",
        }),
      );

      const woken = yield* expectSome(
        "lookup after the covering decision",
        yield* lookupById(admitted.submissionId),
      );

      yield* ensure(
        woken.state === "input-applied",
        "The covering decision must wake the suspended lane",
      );
      const wokenSnapshot = yield* recoverySnapshot(admitted.submissionId);

      yield* ensure(
        wokenSnapshot.suspension === undefined,
        "Waking must clear the durable suspension",
      );

      const reclaim = yield* expectSome(
        "the claim after waking",
        yield* claimLane(threadId, PRODUCER_B),
      );

      yield* settleClaimed(admitted, reclaim.ownershipToken);

      const terminal = yield* expectFailure(
        "suspending a settled Submission",
        ledger.suspend(
          SuspendRequest.make({
            submissionId: admitted.submissionId,
            ownershipToken: reclaim.ownershipToken,
            reason: ApprovalPendingSuspension.make({ toolCallIds: [callA] }),
          }),
        ),
      );

      yield* ensure(
        isSettlementConflict(terminal) && terminal.existingOutcome === "completed",
        "Suspension must never land on a settled Submission",
      );
    }),
);

const joinedSettlementLinkageAuthority = conformanceCase(
  "a joined Submission's settlement reservation is authorized by host linkage",
  ({ ensure, expectFailure, expectSome }) =>
    Effect.gen(function* () {
      const threadId = decodeThreadId("ledger-conformance-joined-settlement");
      const ledger = yield* SubmissionLedger;

      const host = yield* admitReady(threadId, "joined-settle-host", { work: "host" });
      const queued = yield* admitReady(threadId, "joined-settle-2", { queued: 2 });
      const hostClaim = yield* expectSome("the host claim", yield* claimLane(threadId, PRODUCER_A));

      const claims = yield* ledger.claimJoining(
        ClaimJoiningRequest.make({
          threadId,
          hostSubmissionId: host.submissionId,
          ownershipToken: hostClaim.ownershipToken,
          maxCount: 1,
        }),
      );

      yield* ensure(
        claims.length === 1 && claims[0]?.submissionId === queued.submissionId,
        "The queued Submission must join the host's contiguous prefix",
      );

      // A merely-`joining` Submission is still revertible: its reservation stays fenced by
      // lane ownership like any other row.
      const joiningReservation = yield* settlementReservation({
        submissionId: queued.submissionId,
        ownershipToken: BOGUS_TOKEN,
        receiptId: queued.receiptId,
        outcome: "completed",
      });

      const fenced = yield* expectFailure(
        "reserving a joining Submission's settlement without lane ownership",
        ledger.reserveSettlement(joiningReservation),
      );

      yield* ensure(
        isOwnershipLost(fenced),
        "A joining Submission's settlement reservation must stay ownership-fenced",
      );

      yield* ledger.markJoined(
        MarkJoinedRequest.make({
          submissionId: queued.submissionId,
          ownershipToken: hostClaim.ownershipToken,
          recordId: submissionInputRecordId(queued.submissionId),
          sequence: decodeSequence(7),
        }),
      );

      // A `joined` lane is never worker-claimable, so no ownership token can exist for it:
      // the recorded host linkage authorizes the reservation and the presented token is not
      // consulted (plan §2.5 — the coordinator's joined-settlement loop and the
      // SettleJoinedWithHost recovery executor both rely on this).
      const joinedReservation = yield* settlementReservation({
        submissionId: queued.submissionId,
        ownershipToken: BOGUS_TOKEN,
        receiptId: queued.receiptId,
        outcome: "completed",
      });

      yield* ledger.reserveSettlement(joinedReservation);

      const settlement = yield* ledger.finalizeSettlement(
        SettlementFinalization.make({
          submissionId: queued.submissionId,
          settlementId: submissionSettlementId(queued.submissionId),
        }),
      );

      yield* ensure(
        settlement.outcome === "completed",
        "The joined settlement must finalize with the reserved outcome",
      );

      const settled = yield* expectSome(
        "lookup after the joined settlement",
        yield* lookupById(queued.submissionId),
      );

      yield* ensure(
        settled.state === "settled" && settled.settledOutcome === "completed",
        "The joined Submission must settle terminally",
      );
    }),
);

const childReservationIdempotency = conformanceCase(
  "replays an identical child reservation and rejects a divergent allocation digest",
  ({ ensure, expectFailure, expectSome }) =>
    Effect.gen(function* () {
      const threadId = decodeThreadId("ledger-conformance-child-reserve");
      const ledger = yield* SubmissionLedger;
      const parent = yield* admitReady(threadId, "child-reserve-parent", { work: "parent" });
      const claim = yield* expectSome("the parent claim", yield* claimLane(threadId, PRODUCER_A));

      const allocation = { turns: 4, toolCalls: 8 };
      const allocationDigest = yield* digestJson(allocation);

      const requestFields = {
        reservationId: decodeChildReservationId("child-reservation:run-reserve:call-1"),
        parentSubmissionId: parent.submissionId,
        parentToolCallId: decodeToolCallId("call-child-reserve"),
        ownershipToken: claim.ownershipToken,
        allocation,
        allocationDigest,
      };

      const request = ChildBudgetReservationRequest.make(requestFields);
      const first = yield* ledger.reserveChildBudget(request);

      yield* ensure(
        !first.replayed &&
          first.reservation.status === "reserved" &&
          first.reservation.allocationDigest === allocationDigest &&
          first.reservation.childSubmissionId === undefined &&
          persistedJsonEquivalent(first.reservation.allocation, allocation),
        "The first reservation must create a reserved row carrying the exact allocation",
      );

      yield* TestClock.adjust("1 second");

      const replayed = yield* ledger.reserveChildBudget(
        ChildBudgetReservationRequest.make({
          ...requestFields,
          allocation: { toolCalls: 8, turns: 4 },
        }),
      );

      yield* ensure(
        replayed.replayed &&
          replayed.reservation.status === "reserved" &&
          persistedJsonEquivalent(replayed.reservation.allocation, allocation) &&
          sameInstant(replayed.reservation.reservedAt, first.reservation.reservedAt),
        "An identical reservation must replay the stored row unchanged",
      );

      const divergentAllocation = { turns: 64, toolCalls: 8 };

      const divergent = yield* expectFailure(
        "a divergent allocation for the same reservation id",
        ledger.reserveChildBudget(
          ChildBudgetReservationRequest.make({
            ...requestFields,
            allocation: divergentAllocation,
            allocationDigest: yield* digestJson(divergentAllocation),
          }),
        ),
      );

      yield* ensure(
        isChildReservationConflict(divergent) && divergent.status === "reserved",
        "A divergent allocation must conflict with the recorded reservation",
      );

      const secondId = yield* expectFailure(
        "a second reservation id for the same parent Tool Call",
        ledger.reserveChildBudget(
          ChildBudgetReservationRequest.make({
            ...requestFields,
            reservationId: decodeChildReservationId("child-reservation:run-reserve:call-1-other"),
          }),
        ),
      );

      yield* ensure(
        isChildReservationConflict(secondId),
        "One parent Tool Call must never own two reservations",
      );

      const snapshot = yield* recoverySnapshot(parent.submissionId);

      yield* ensure(
        snapshot.childReservations.length === 1 &&
          snapshot.childReservations[0].reservationId === request.reservationId &&
          snapshot.childReservations[0].status === "reserved" &&
          snapshot.childAttachments.length === 0,
        "The parent recovery snapshot must expose the reservation before any attachment",
      );
    }),
);

const childReservationFencing = conformanceCase(
  "a stale parent token cannot transition a child reservation",
  ({ ensure, expectFailure, expectSome }) =>
    Effect.gen(function* () {
      const threadId = decodeThreadId("ledger-conformance-child-fence");
      const childLane = decodeThreadId("ledger-conformance-child-fence-child");
      const ledger = yield* SubmissionLedger;
      const parent = yield* admitReady(threadId, "child-fence-parent", { work: "parent" });
      const child = yield* admitReady(childLane, "child-fence-child", { work: "child" });

      const firstClaim = yield* expectSome(
        "the first parent claim",
        yield* claimLane(threadId, PRODUCER_A),
      );

      const allocation = { turns: 2 };
      const allocationDigest = yield* digestJson(allocation);

      const requestFields = {
        reservationId: decodeChildReservationId("child-reservation:run-fence:call-1"),
        parentSubmissionId: parent.submissionId,
        parentToolCallId: decodeToolCallId("call-child-fence"),
        ownershipToken: BOGUS_TOKEN,
        allocation,
        allocationDigest,
      };

      const request = ChildBudgetReservationRequest.make(requestFields);

      const foreign = yield* expectFailure(
        "creating a reservation without owning the parent lane",
        ledger.reserveChildBudget(request),
      );

      yield* ensure(
        isOwnershipLost(foreign),
        "Reservation creation must be fenced by the parent's live ownership token",
      );
      const afterForeign = yield* recoverySnapshot(parent.submissionId);

      yield* ensure(
        afterForeign.childReservations.length === 0,
        "A fenced reservation attempt must leave no row behind",
      );

      yield* ledger.reserveChildBudget(
        ChildBudgetReservationRequest.make({
          ...requestFields,
          ownershipToken: firstClaim.ownershipToken,
        }),
      );

      // The parent Attempt ends and a replacement claims the lane: the old token is fenced.
      yield* ledger.releaseOwnership(
        ReleaseOwnershipRequest.make({
          submissionId: parent.submissionId,
          ownershipToken: firstClaim.ownershipToken,
        }),
      );

      const reclaim = yield* expectSome(
        "the replacement parent claim",
        yield* claimLane(threadId, PRODUCER_B),
      );

      yield* ensure(
        reclaim.producerEpoch > firstClaim.producerEpoch,
        "The replacement claim must fence the stale parent Attempt",
      );

      const staleAttach = yield* expectFailure(
        "attaching a child with the superseded parent token",
        ledger.attachChildToReservation(
          AttachChildToReservationRequest.make({
            reservationId: request.reservationId,
            ownershipToken: firstClaim.ownershipToken,
            childSubmissionId: child.submissionId,
          }),
        ),
      );

      yield* ensure(
        isOwnershipLost(staleAttach),
        "A superseded parent token must not attach a child",
      );

      const staleCreate = yield* expectFailure(
        "creating a second-call reservation with the superseded parent token",
        ledger.reserveChildBudget(
          ChildBudgetReservationRequest.make({
            ...requestFields,
            reservationId: decodeChildReservationId("child-reservation:run-fence:call-2"),
            parentToolCallId: decodeToolCallId("call-child-fence-second"),
            ownershipToken: firstClaim.ownershipToken,
          }),
        ),
      );

      yield* ensure(
        isOwnershipLost(staleCreate),
        "A superseded parent token must not create new reservation state",
      );

      // An identical replay creates nothing, so it short-circuits before the fence exactly
      // like reserveSettlement: a recovering caller reads the recorded row.
      const staleReplay = yield* ledger.reserveChildBudget(
        ChildBudgetReservationRequest.make({
          ...requestFields,
          ownershipToken: firstClaim.ownershipToken,
        }),
      );

      yield* ensure(
        staleReplay.replayed && staleReplay.reservation.status === "reserved",
        "An identical reservation replay must return the recorded row even from a stale caller",
      );

      const attached = yield* ledger.attachChildToReservation(
        AttachChildToReservationRequest.make({
          reservationId: request.reservationId,
          ownershipToken: reclaim.ownershipToken,
          childSubmissionId: child.submissionId,
        }),
      );

      yield* ensure(
        attached.childSubmissionId === child.submissionId,
        "The live replacement token must attach the child",
      );
    }),
);

const attachChildIdempotency = conformanceCase(
  "attachChildToReservation is idempotent and rejects a divergent child",
  ({ ensure, expectFailure, expectSome }) =>
    Effect.gen(function* () {
      const threadId = decodeThreadId("ledger-conformance-child-attach");
      const childLane = decodeThreadId("ledger-conformance-child-attach-child");
      const ledger = yield* SubmissionLedger;
      const parent = yield* admitReady(threadId, "child-attach-parent", { work: "parent" });
      const child = yield* admitReady(childLane, "child-attach-child", { queued: 1 });
      const otherChild = yield* admitReady(childLane, "child-attach-other", { queued: 2 });
      const claim = yield* expectSome("the parent claim", yield* claimLane(threadId, PRODUCER_A));

      const allocation = { turns: 3 };
      const reservationId = decodeChildReservationId("child-reservation:run-attach:call-1");

      yield* ledger.reserveChildBudget(
        ChildBudgetReservationRequest.make({
          reservationId,
          parentSubmissionId: parent.submissionId,
          parentToolCallId: decodeToolCallId("call-child-attach"),
          ownershipToken: claim.ownershipToken,
          allocation,
          allocationDigest: yield* digestJson(allocation),
        }),
      );

      const unknownReservation = yield* expectFailure(
        "attaching to a reservation that was never created",
        ledger.attachChildToReservation(
          AttachChildToReservationRequest.make({
            reservationId: decodeChildReservationId("child-reservation:run-attach:missing"),
            ownershipToken: claim.ownershipToken,
            childSubmissionId: child.submissionId,
          }),
        ),
      );

      yield* ensure(
        isLedgerError(unknownReservation),
        "Attaching to an unknown reservation must fail as a ledger error",
      );

      const attached = yield* ledger.attachChildToReservation(
        AttachChildToReservationRequest.make({
          reservationId,
          ownershipToken: claim.ownershipToken,
          childSubmissionId: child.submissionId,
        }),
      );

      yield* ensure(
        attached.childSubmissionId === child.submissionId && attached.status === "reserved",
        "Attaching must record the child on the reservation row",
      );

      const replayed = yield* ledger.attachChildToReservation(
        AttachChildToReservationRequest.make({
          reservationId,
          ownershipToken: claim.ownershipToken,
          childSubmissionId: child.submissionId,
        }),
      );

      yield* ensure(
        replayed.childSubmissionId === child.submissionId,
        "Repeating the identical attachment must be a no-op",
      );

      const divergent = yield* expectFailure(
        "attaching a different child to the same reservation",
        ledger.attachChildToReservation(
          AttachChildToReservationRequest.make({
            reservationId,
            ownershipToken: claim.ownershipToken,
            childSubmissionId: otherChild.submissionId,
          }),
        ),
      );

      yield* ensure(
        isChildReservationConflict(divergent),
        "A divergent child attachment must conflict with the recorded child",
      );

      const snapshot = yield* recoverySnapshot(parent.submissionId);

      yield* ensure(
        snapshot.childAttachments.length === 1 &&
          snapshot.childAttachments[0].childSubmissionId === child.submissionId &&
          snapshot.childAttachments[0].toolCallId === decodeToolCallId("call-child-attach") &&
          snapshot.childAttachments[0].childState === "ready" &&
          snapshot.childAttachments[0].childOutcome === undefined,
        "The parent recovery snapshot must expose the attachment with the child's lane state",
      );
    }),
);

const beginReleaseFreezesAccountingOnce = conformanceCase(
  "beginRelease freezes the accounting decision exactly once",
  ({ ensure, expectFailure, expectSome }) =>
    Effect.gen(function* () {
      const threadId = decodeThreadId("ledger-conformance-child-freeze");
      const ledger = yield* SubmissionLedger;
      const parent = yield* admitReady(threadId, "child-freeze-parent", { work: "parent" });
      const claim = yield* expectSome("the parent claim", yield* claimLane(threadId, PRODUCER_A));

      const allocation = { turns: 4 };
      const reservationId = decodeChildReservationId("child-reservation:run-freeze:call-1");

      yield* ledger.reserveChildBudget(
        ChildBudgetReservationRequest.make({
          reservationId,
          parentSubmissionId: parent.submissionId,
          parentToolCallId: decodeToolCallId("call-child-freeze"),
          ownershipToken: claim.ownershipToken,
          allocation,
          allocationDigest: yield* digestJson(allocation),
        }),
      );

      const accounting = { consumed: { turns: 1 }, released: { turns: 3 } };

      const frozen = yield* ledger.beginChildBudgetRelease(
        BeginChildBudgetReleaseRequest.make({ reservationId, accounting }),
      );

      yield* ensure(
        frozen.status === "releasePending" &&
          frozen.accounting !== undefined &&
          persistedJsonEquivalent(frozen.accounting, accounting) &&
          frozen.releaseBeganAt !== undefined,
        "The first beginRelease must freeze the accounting and move to releasePending",
      );

      yield* TestClock.adjust("1 second");

      const replayed = yield* ledger.beginChildBudgetRelease(
        BeginChildBudgetReleaseRequest.make({
          reservationId,
          accounting: { released: { turns: 3 }, consumed: { turns: 1 } },
        }),
      );

      yield* ensure(
        replayed.status === "releasePending" &&
          replayed.releaseBeganAt !== undefined &&
          frozen.releaseBeganAt !== undefined &&
          sameInstant(replayed.releaseBeganAt, frozen.releaseBeganAt),
        "Replaying the identical accounting must be a no-op with the frozen decision retained",
      );

      const divergent = yield* expectFailure(
        "freezing a different accounting decision",
        ledger.beginChildBudgetRelease(
          BeginChildBudgetReleaseRequest.make({
            reservationId,
            accounting: { consumed: { turns: 4 }, released: { turns: 0 } },
          }),
        ),
      );

      yield* ensure(
        isChildReservationConflict(divergent) && divergent.status === "releasePending",
        "A divergent accounting freeze must conflict with the frozen decision",
      );

      yield* ledger.releaseChildBudget(ReleaseChildBudgetRequest.make({ reservationId }));

      const afterRelease = yield* ledger.beginChildBudgetRelease(
        BeginChildBudgetReleaseRequest.make({ reservationId, accounting }),
      );

      yield* ensure(
        afterRelease.status === "released" &&
          afterRelease.accounting !== undefined &&
          persistedJsonEquivalent(afterRelease.accounting, accounting),
        "Replaying the identical accounting after release must return the released row",
      );

      const divergentAfterRelease = yield* expectFailure(
        "freezing a different accounting decision after release",
        ledger.beginChildBudgetRelease(
          BeginChildBudgetReleaseRequest.make({
            reservationId,
            accounting: { consumed: { turns: 2 }, released: { turns: 2 } },
          }),
        ),
      );

      yield* ensure(
        isChildReservationConflict(divergentAfterRelease) &&
          divergentAfterRelease.status === "released",
        "The frozen decision must stay immutable after release",
      );
    }),
);

const releaseAppliedExactlyOnce = conformanceCase(
  "release returns unused allocation exactly once",
  ({ ensure, expectFailure, expectSome }) =>
    Effect.gen(function* () {
      const threadId = decodeThreadId("ledger-conformance-child-release");
      const ledger = yield* SubmissionLedger;
      const parent = yield* admitReady(threadId, "child-release-parent", { work: "parent" });
      const claim = yield* expectSome("the parent claim", yield* claimLane(threadId, PRODUCER_A));

      const allocation = { turns: 4 };
      const reservationId = decodeChildReservationId("child-reservation:run-release:call-1");

      yield* ledger.reserveChildBudget(
        ChildBudgetReservationRequest.make({
          reservationId,
          parentSubmissionId: parent.submissionId,
          parentToolCallId: decodeToolCallId("call-child-release"),
          ownershipToken: claim.ownershipToken,
          allocation,
          allocationDigest: yield* digestJson(allocation),
        }),
      );

      const early = yield* expectFailure(
        "releasing before the accounting decision is frozen",
        ledger.releaseChildBudget(ReleaseChildBudgetRequest.make({ reservationId })),
      );

      yield* ensure(
        isChildReservationConflict(early) && early.status === "reserved",
        "Release must never skip the releasePending freeze",
      );

      yield* ledger.beginChildBudgetRelease(
        BeginChildBudgetReleaseRequest.make({
          reservationId,
          accounting: { consumed: {}, released: { turns: 4 } },
        }),
      );

      const released = yield* ledger.releaseChildBudget(
        ReleaseChildBudgetRequest.make({ reservationId }),
      );

      yield* ensure(
        released.status === "released" && released.releasedAt !== undefined,
        "Release must transition releasePending to released",
      );

      yield* TestClock.adjust("1 second");

      const replayed = yield* ledger.releaseChildBudget(
        ReleaseChildBudgetRequest.make({ reservationId }),
      );

      yield* ensure(
        replayed.status === "released" &&
          replayed.releasedAt !== undefined &&
          released.releasedAt !== undefined &&
          sameInstant(replayed.releasedAt, released.releasedAt),
        "Replaying the release must return the stored row unchanged — never applied twice",
      );

      const snapshot = yield* recoverySnapshot(parent.submissionId);

      yield* ensure(
        snapshot.childReservations.length === 1 &&
          snapshot.childReservations[0].status === "released",
        "The recovery snapshot must expose the released reservation",
      );
    }),
);

const recordChildSettledWake = conformanceCase(
  "recordChildSettled accepts canonical terminalizing prefixes and wakes only when all are covered",
  ({ ensure, expectFailure, expectSome }) =>
    Effect.gen(function* () {
      const parentLane = decodeThreadId("ledger-conformance-child-wake");
      const childLaneA = decodeThreadId("ledger-conformance-child-wake-a");
      const childLaneB = decodeThreadId("ledger-conformance-child-wake-b");
      const ledger = yield* SubmissionLedger;

      const parent = yield* admitReady(parentLane, "child-wake-parent", { work: "parent" });
      const childA = yield* admitReady(childLaneA, "child-wake-a", { child: "a" });
      const childB = yield* admitReady(childLaneB, "child-wake-b", { child: "b" });

      const parentClaim = yield* expectSome(
        "the parent claim",
        yield* claimLane(parentLane, PRODUCER_A),
      );

      const suspended = yield* ledger.suspend(
        SuspendRequest.make({
          submissionId: parent.submissionId,
          ownershipToken: parentClaim.ownershipToken,
          reason: WaitingForChildSuspension.make({
            children: [
              WaitingChild.make({
                toolCallId: decodeToolCallId("call-wake-a"),
                childSubmissionId: childA.submissionId,
              }),
              WaitingChild.make({
                toolCallId: decodeToolCallId("call-wake-b"),
                childSubmissionId: childB.submissionId,
              }),
            ],
          }),
        }),
      );

      yield* ensure(
        suspended === "suspended",
        "Unsettled children must suspend the parent durably",
      );

      const ended = yield* expectFailure(
        "renewing after the waitingForChild suspension ended the ownership period",
        ledger.renewOwnership(
          RenewOwnershipRequest.make({
            submissionId: parent.submissionId,
            ownershipToken: parentClaim.ownershipToken,
          }),
        ),
      );

      yield* ensure(
        isOwnershipLost(ended),
        "waitingForChild must end the ownership period without settling (SUB-030)",
      );
      yield* ensure(
        Option.isNone(yield* claimLane(parentLane, PRODUCER_B)),
        "A waitingForChild head must produce no claim and consume no worker permit",
      );

      const childClaimA = yield* expectSome(
        "the first child claim",
        yield* claimLane(childLaneA, PRODUCER_A),
      );

      const childReservationA = yield* settlementReservation({
        submissionId: childA.submissionId,
        ownershipToken: childClaimA.ownershipToken,
        receiptId: childA.receiptId,
        outcome: "completed",
      });

      yield* ledger.reserveSettlement(childReservationA);

      const partial = yield* ledger.recordChildSettled(
        ChildSettledNotification.make({
          parentSubmissionId: parent.submissionId,
          childSubmissionId: childA.submissionId,
        }),
      );

      yield* ensure(
        partial === "still-waiting",
        "A settlement notification must not wake the parent while a listed child is unsettled",
      );
      yield* ledger.finalizeSettlement(
        SettlementFinalization.make({
          submissionId: childA.submissionId,
          settlementId: childReservationA.settlementId,
        }),
      );

      const stillSuspended = yield* expectSome(
        "lookup while one child is outstanding",
        yield* lookupById(parent.submissionId),
      );

      yield* ensure(
        stillSuspended.state === "suspended" &&
          Option.isNone(yield* claimLane(parentLane, PRODUCER_B)),
        "The parent lane must stay suspended until every listed child settled",
      );

      const childClaimB = yield* expectSome(
        "the second child claim",
        yield* claimLane(childLaneB, PRODUCER_A),
      );

      const childReservationB = yield* settlementReservation({
        submissionId: childB.submissionId,
        ownershipToken: childClaimB.ownershipToken,
        receiptId: childB.receiptId,
        outcome: "completed",
      });

      yield* ledger.reserveSettlement(childReservationB);

      const woken = yield* ledger.recordChildSettled(
        ChildSettledNotification.make({
          parentSubmissionId: parent.submissionId,
          childSubmissionId: childB.submissionId,
        }),
      );

      yield* ensure(
        woken === "woken",
        "The covering canonical settlement prefix must wake the parent before child finalization",
      );
      yield* ledger.finalizeSettlement(
        SettlementFinalization.make({
          submissionId: childB.submissionId,
          settlementId: childReservationB.settlementId,
        }),
      );

      const awake = yield* expectSome(
        "lookup after the covering settlement",
        yield* lookupById(parent.submissionId),
      );

      yield* ensure(
        awake.state === "input-applied",
        "The woken parent must transition suspended(WaitingForChild) to input-applied",
      );
      const wokenSnapshot = yield* recoverySnapshot(parent.submissionId);

      yield* ensure(
        wokenSnapshot.suspension === undefined,
        "Waking must clear the durable suspension",
      );

      const replayedNotification = yield* ledger.recordChildSettled(
        ChildSettledNotification.make({
          parentSubmissionId: parent.submissionId,
          childSubmissionId: childA.submissionId,
        }),
      );

      yield* ensure(
        replayedNotification === "not-waiting",
        "Replaying a notification after the wake must be an idempotent no-op",
      );

      const reclaim = yield* expectSome(
        "the parent claim after waking",
        yield* claimLane(parentLane, PRODUCER_B),
      );

      yield* ensure(
        reclaim.submissionId === parent.submissionId &&
          reclaim.producerEpoch > parentClaim.producerEpoch,
        "The woken lane must grant a fresh fenced Attempt",
      );
      yield* settleClaimed(parent, reclaim.ownershipToken);

      const afterSettlement = yield* ledger.recordChildSettled(
        ChildSettledNotification.make({
          parentSubmissionId: parent.submissionId,
          childSubmissionId: childB.submissionId,
        }),
      );

      yield* ensure(
        afterSettlement === "not-waiting",
        "A notification for a settled parent must answer not-waiting",
      );
    }),
);

const suspendResumesImmediatelyForSettledChildren = conformanceCase(
  "suspend returns resume-immediately when children already settled",
  ({ ensure, expectSome }) =>
    Effect.gen(function* () {
      const parentLane = decodeThreadId("ledger-conformance-child-raced");
      const childLaneA = decodeThreadId("ledger-conformance-child-raced-a");
      const childLaneB = decodeThreadId("ledger-conformance-child-raced-b");
      const ledger = yield* SubmissionLedger;

      // The child settles BEFORE the parent's suspend transaction commits (spec §12 step 10
      // race): the suspend must observe the settlement and resume immediately.
      const settledChild = yield* admitReady(childLaneA, "child-raced-a", { child: "a" });

      const settledClaim = yield* expectSome(
        "the settled child's claim",
        yield* claimLane(childLaneA, PRODUCER_A),
      );

      yield* settleClaimed(settledChild, settledClaim.ownershipToken);
      const pendingChild = yield* admitReady(childLaneB, "child-raced-b", { child: "b" });

      const parent = yield* admitReady(parentLane, "child-raced-parent", { work: "parent" });

      const parentClaim = yield* expectSome(
        "the parent claim",
        yield* claimLane(parentLane, PRODUCER_A),
      );

      const immediate = yield* ledger.suspend(
        SuspendRequest.make({
          submissionId: parent.submissionId,
          ownershipToken: parentClaim.ownershipToken,
          reason: WaitingForChildSuspension.make({
            children: [
              WaitingChild.make({
                toolCallId: decodeToolCallId("call-raced-a"),
                childSubmissionId: settledChild.submissionId,
              }),
            ],
          }),
        }),
      );

      yield* ensure(
        immediate === "resume-immediately",
        "A suspend listing only settled children must resume immediately",
      );

      const stillRunning = yield* expectSome(
        "lookup after the immediate resume",
        yield* lookupById(parent.submissionId),
      );

      yield* ensure(
        stillRunning.state === "running",
        "An immediate resume must not transition the parent to suspended",
      );
      // The ownership period must survive an immediate resume: the caller keeps working.
      yield* ledger.renewOwnership(
        RenewOwnershipRequest.make({
          submissionId: parent.submissionId,
          ownershipToken: parentClaim.ownershipToken,
        }),
      );

      const suspended = yield* ledger.suspend(
        SuspendRequest.make({
          submissionId: parent.submissionId,
          ownershipToken: parentClaim.ownershipToken,
          reason: WaitingForChildSuspension.make({
            children: [
              WaitingChild.make({
                toolCallId: decodeToolCallId("call-raced-a"),
                childSubmissionId: settledChild.submissionId,
              }),
              WaitingChild.make({
                toolCallId: decodeToolCallId("call-raced-b"),
                childSubmissionId: pendingChild.submissionId,
              }),
            ],
          }),
        }),
      );

      yield* ensure(
        suspended === "suspended",
        "One unsettled listed child must suspend the parent durably",
      );
      const snapshot = yield* recoverySnapshot(parent.submissionId);

      yield* ensure(
        snapshot.suspension !== undefined &&
          snapshot.suspension.reason._tag === "WaitingForChild" &&
          snapshot.suspension.reason.children.length === 2,
        "The recovery snapshot must expose the WaitingForChild reason with its children",
      );
    }),
);

const admissionParentLinkage = conformanceCase(
  "admit records and replays parent linkage",
  ({ ensure, expectFailure, expectSome }) =>
    Effect.gen(function* () {
      const parentLane = decodeThreadId("ledger-conformance-linkage");
      const childLane = decodeThreadId("ledger-conformance-linkage-child");
      const ledger = yield* SubmissionLedger;
      const parent = yield* admitReady(parentLane, "linkage-parent", { work: "parent" });

      const linkage = ParentLinkage.make({
        parentSubmissionId: parent.submissionId,
        parentToolCallId: decodeToolCallId("call-linkage"),
      });

      const request = yield* admissionRequest(
        childLane,
        "linkage-child-key",
        { task: "research" },
        linkage,
      );

      const admitted = yield* ledger.admit(request);

      yield* ensure(!admitted.replayed, "The first linked admission must create the child");

      const byId = yield* expectSome(
        "lookup of the linked child",
        yield* lookupById(admitted.submissionId),
      );

      yield* ensure(
        byId.parentLinkage !== undefined &&
          byId.parentLinkage.parentSubmissionId === parent.submissionId &&
          byId.parentLinkage.parentToolCallId === linkage.parentToolCallId,
        "The child snapshot must expose its immutable parent linkage",
      );
      const childSnapshot = yield* recoverySnapshot(admitted.submissionId);

      yield* ensure(
        childSnapshot.parentLinkage !== undefined &&
          childSnapshot.parentLinkage.parentSubmissionId === parent.submissionId,
        "The child recovery snapshot must expose its parent linkage",
      );

      const replayed = yield* ledger.admit(request);

      yield* ensure(
        replayed.replayed &&
          replayed.submissionId === admitted.submissionId &&
          replayed.receiptId === admitted.receiptId,
        "An identical linked admission must replay the original identities (SUB-016)",
      );

      const divergentLinkage = yield* expectFailure(
        "replaying the admission with a different parent Tool Call",
        ledger.admit(
          yield* admissionRequest(
            childLane,
            "linkage-child-key",
            { task: "research" },
            ParentLinkage.make({
              parentSubmissionId: parent.submissionId,
              parentToolCallId: decodeToolCallId("call-linkage-other"),
            }),
          ),
        ),
      );

      yield* ensure(
        isAdmissionConflict(divergentLinkage),
        "A divergent parent linkage must conflict even when the input digest matches",
      );

      const droppedLinkage = yield* expectFailure(
        "replaying the admission without its parent linkage",
        ledger.admit(yield* admissionRequest(childLane, "linkage-child-key", { task: "research" })),
      );

      yield* ensure(
        isAdmissionConflict(droppedLinkage),
        "Dropping the recorded linkage on replay must conflict",
      );

      const plain = yield* ledger.admit(
        yield* admissionRequest(childLane, "linkage-plain-key", { task: "plain" }),
      );

      const addedLinkage = yield* expectFailure(
        "replaying an unlinked admission with a parent linkage",
        ledger.admit(
          yield* admissionRequest(childLane, "linkage-plain-key", { task: "plain" }, linkage),
        ),
      );

      yield* ensure(
        isAdmissionConflict(addedLinkage),
        "Adding a linkage to an unlinked admission on replay must conflict",
      );

      const plainSnapshot = yield* expectSome(
        "lookup of the unlinked Submission",
        yield* lookupById(plain.submissionId),
      );

      yield* ensure(
        plainSnapshot.parentLinkage === undefined,
        "An unlinked Submission must expose no parent linkage",
      );
    }),
);

const resolveAdmissionAuthority = conformanceCase(
  "resolveAdmission distinguishes notAdmitted from admitted authoritatively",
  ({ ensure, expectSome }) =>
    Effect.gen(function* () {
      const threadId = decodeThreadId("ledger-conformance-resolve");
      const ledger = yield* SubmissionLedger;

      const key = SubmissionLookupByKey.make({
        threadId,
        principal: CONFORMANCE_PRINCIPAL,
        idempotencyKey: decodeIdempotencyKey("resolve-key-1"),
      });

      const before = yield* ledger.resolveAdmission(key);

      yield* ensure(
        before._tag === "NotAdmitted",
        "The authoritative store must prove absence before admission (SUB-031)",
      );

      const admitted = yield* ledger.admit(
        yield* admissionRequest(threadId, "resolve-key-1", { work: "resolve" }),
      );

      const after = yield* ledger.resolveAdmission(key);

      yield* ensure(
        after._tag === "Admitted" &&
          after.submission.submissionId === admitted.submissionId &&
          after.submission.receiptId === admitted.receiptId &&
          after.submission.state === "admitted",
        "An admitted key must resolve to the full authoritative snapshot",
      );

      const foreign = yield* ledger.resolveAdmission(
        SubmissionLookupByKey.make({
          threadId,
          principal: OTHER_PRINCIPAL,
          idempotencyKey: decodeIdempotencyKey("resolve-key-1"),
        }),
      );

      yield* ensure(
        foreign._tag === "NotAdmitted",
        "Admission resolution must stay scoped to the requesting principal",
      );

      yield* ledger.markReady(MarkReadyRequest.make({ submissionId: admitted.submissionId }));

      const claim = yield* expectSome(
        "the claim before terminal resolution",
        yield* claimLane(threadId, PRODUCER_A),
      );

      yield* settleClaimed(admitted, claim.ownershipToken);
      const settled = yield* ledger.resolveAdmission(key);

      yield* ensure(
        settled._tag === "Admitted" &&
          settled.submission.state === "settled" &&
          settled.submission.settledOutcome === "completed",
        "A settled Submission still resolves as admitted — terminality never becomes absence",
      );
    }),
);

const queuedAbortSettlementAuthority = conformanceCase(
  "reserveSettlement authorizes an aborted, unowned queued settlement by its durable intent",
  ({ ensure, expectFailure }) =>
    Effect.gen(function* () {
      // P7 §7(c): an aborted, never-claimed, still-queued `ready` Submission has no live
      // ownership to fence against, so its durable abort intent authorizes exactly its
      // ABORTED settlement — recovery settles it without waiting for it to head the lane.
      // The authorization is outcome- and state-narrow and stays fail-closed otherwise.
      const threadId = decodeThreadId("ledger-conformance-queued-abort");
      const ledger = yield* SubmissionLedger;

      const head = yield* admitReady(threadId, "queued-abort-head", { work: "head" });
      const second = yield* admitReady(threadId, "queued-abort-2", { queued: 2 });
      const third = yield* admitReady(threadId, "queued-abort-3", { queued: 3 });

      yield* ledger.requestAbort(
        AbortCommand.make({
          submissionId: second.submissionId,
          author: "operator",
          reason: "cancelled while queued",
        }),
      );

      // Fail-closed control: a queued row WITHOUT an abort intent never accepts an unowned
      // reservation, aborted or not.
      const unaborted = yield* expectFailure(
        "reserving an aborted settlement for a queued row without an abort intent",
        settlementReservation({
          submissionId: third.submissionId,
          ownershipToken: BOGUS_TOKEN,
          receiptId: third.receiptId,
          outcome: "aborted",
        }).pipe(Effect.flatMap((reservation) => ledger.reserveSettlement(reservation))),
      );

      yield* ensure(
        isOwnershipLost(unaborted),
        "A queued reservation without a durable abort intent must stay fenced (OwnershipLost)",
      );

      // Fail-closed control: the durable intent authorizes ONLY the aborted outcome.
      const wrongOutcome = yield* expectFailure(
        "reserving a completed settlement for the aborted queued row",
        settlementReservation({
          submissionId: second.submissionId,
          ownershipToken: BOGUS_TOKEN,
          receiptId: second.receiptId,
          outcome: "completed",
          result: { fabricated: true },
        }).pipe(Effect.flatMap((reservation) => ledger.reserveSettlement(reservation))),
      );

      yield* ensure(
        isOwnershipLost(wrongOutcome),
        "An abort intent must never authorize a non-aborted settlement outcome",
      );

      const reservation = yield* settlementReservation({
        submissionId: second.submissionId,
        ownershipToken: BOGUS_TOKEN,
        receiptId: second.receiptId,
        outcome: "aborted",
      });

      const reserved = yield* ledger.reserveSettlement(reservation);

      yield* ensure(
        reserved.replayed === false && reserved.outcome === "aborted",
        "The abort intent must authorize the aborted reservation without lane ownership",
      );
      // The crash replay (`terminalizing` + committed reservation) is equally authorized.
      const replayed = yield* ledger.reserveSettlement(reservation);

      yield* ensure(
        replayed.replayed === true,
        "Replaying the identical aborted reservation must short-circuit idempotently",
      );
      yield* ledger.finalizeSettlement(
        SettlementFinalization.make({
          submissionId: second.submissionId,
          settlementId: submissionSettlementId(second.submissionId),
        }),
      );

      const settled = yield* recoverySnapshot(second.submissionId);

      yield* ensure(
        settled.submission.state === "settled" && settled.submission.settledOutcome === "aborted",
        "The aborted queued Submission must settle while the head is still unsettled",
      );
      const headState = yield* recoverySnapshot(head.submissionId);

      yield* ensure(
        headState.submission.state === "ready",
        "Settling the aborted queued row must not disturb the unclaimed head",
      );
    }),
);

const abortedSettledRowIsNotAJoiningGap = conformanceCase(
  "claimJoining treats an aborted-settled row as a non-gap",
  ({ ensure, expectSome }) =>
    Effect.gen(function* () {
      // P7 §7(c): an aborted-settled row is a CLOSED obligation — the contiguous joining
      // prefix walks over it so later ready work still joins the host (the pre-P7 rule
      // treated every settled row as a conservative gap).
      const threadId = decodeThreadId("ledger-conformance-aborted-non-gap");
      const ledger = yield* SubmissionLedger;

      const host = yield* admitReady(threadId, "aborted-gap-host", { work: "host" });
      const second = yield* admitReady(threadId, "aborted-gap-2", { queued: 2 });
      const third = yield* admitReady(threadId, "aborted-gap-3", { queued: 3 });

      yield* ledger.requestAbort(
        AbortCommand.make({
          submissionId: second.submissionId,
          author: "operator",
          reason: "cancelled while queued",
        }),
      );

      const reservation = yield* settlementReservation({
        submissionId: second.submissionId,
        ownershipToken: BOGUS_TOKEN,
        receiptId: second.receiptId,
        outcome: "aborted",
      });

      yield* ledger.reserveSettlement(reservation);
      yield* ledger.finalizeSettlement(
        SettlementFinalization.make({
          submissionId: second.submissionId,
          settlementId: submissionSettlementId(second.submissionId),
        }),
      );

      const hostClaim = yield* expectSome("the host claim", yield* claimLane(threadId, PRODUCER_A));

      yield* ensure(
        hostClaim.submissionId === host.submissionId,
        "The host must head the lane (the aborted-settled row is out of the queue)",
      );

      const claims = yield* ledger.claimJoining(
        ClaimJoiningRequest.make({
          threadId,
          hostSubmissionId: host.submissionId,
          ownershipToken: hostClaim.ownershipToken,
          maxCount: 8,
        }),
      );

      yield* ensure(
        claims.length === 1 && claims[0].submissionId === third.submissionId,
        "The joining prefix must skip the aborted-settled row and claim the later ready work",
      );
      const settled = yield* recoverySnapshot(second.submissionId);

      yield* ensure(
        settled.submission.state === "settled" && settled.submission.settledOutcome === "aborted",
        "Walking the prefix must never disturb the aborted-settled row",
      );
    }),
);

const assignmentSettlement = conformanceCase(
  "seals terminal assignments atomically while waiting and unapplied corrections remain steerable",
  ({ ensure, expectSome, expectFailure }) =>
    Effect.gen(function* () {
      const ledger = yield* SubmissionLedger;

      if (ledger.inspectWorker === undefined) return;

      // Each row isolates one ownership rule. The same cases run on every native adapter.
      const cases = [
        {
          name: "completed",
          outcome: "completed",
          disposition: "completed",
          terminal: "completed",
        },
        { name: "waiting", outcome: "completed", disposition: "waiting", terminal: undefined },
        { name: "failure", outcome: "failed", queued: true, terminal: "failed" },
        {
          name: "failure-joining",
          outcome: "failed",
          queued: true,
          joining: true,
          terminal: "failed",
        },
        { name: "exhaustion", outcome: "completed", exhausted: true, terminal: "failed" },
        { name: "active-abort", outcome: "aborted", terminal: "cancelled" },
        { name: "queued-abort", outcome: "aborted", noRun: true, terminal: undefined },
        {
          name: "reusable",
          outcome: "completed",
          disposition: "completed",
          reusable: true,
          terminal: undefined,
        },
        {
          name: "late-correction",
          outcome: "completed",
          disposition: "completed",
          queued: true,
          terminal: undefined,
        },
        {
          name: "applied-correction",
          outcome: "completed",
          disposition: "completed",
          queued: true,
          joined: true,
          terminal: "completed",
        },
      ] as const;

      for (const scenario of cases) {
        const threadId = decodeThreadId(`assignment-${scenario.name}`);
        const base = yield* admissionRequest(threadId, "first", { text: "first" });
        const metadata = workerMetadata(base);

        const workerAdmission = WorkerAdmission.make({
          ...metadata,
          origin: {
            ...metadata.origin,
            ...("reusable" in scenario ? {} : { lifecycle: "assignment" as const }),
          },
        });

        const request = AdmissionRequest.make({ ...base, workerAdmission });

        const first = yield* ledger.admit(request);

        yield* ledger.markReady(MarkReadyRequest.make({ submissionId: first.submissionId }));
        const claim = yield* expectSome("assignment claim", yield* claimLane(threadId, PRODUCER_A));
        const runId = runIdForSubmission(first.submissionId);

        const payload = yield* Schema.decodeEffect(SubmissionSettledRecord)(
          SubmissionSettled.make({
            submissionId: first.submissionId,
            settlementId: submissionSettlementId(first.submissionId),
            receiptId: first.receiptId,
            outcome: scenario.outcome,
            ...("noRun" in scenario ? {} : { runId }),
            ...(scenario.outcome === "aborted"
              ? {}
              : {
                  result:
                    scenario.outcome === "failed"
                      ? { errorTag: "TestFailure", message: "Failed task" }
                      : { answer: "done" },
                }),
            ...("disposition" in scenario ? { runDisposition: scenario.disposition } : {}),
            ...("exhausted" in scenario
              ? { finishReason: "budget-exhausted" as const, exhausted: "turns" as const }
              : {}),
          }),
        ).pipe(Effect.orDie);

        const record = RecordEnvelope.make({
          recordId: submissionSettlementRecordId(first.submissionId),
          family: "thread",
          schemaVersion: 1,
          createdAt: CONFORMANCE_CREATED_AT,
          deploymentId: CONFORMANCE_DEPLOYMENT,
          payload,
        });

        let queued: AdmissionResult | undefined;

        if ("queued" in scenario) {
          const next = yield* admissionRequest(threadId, "correction", { text: "correction" });

          queued = yield* ledger.admit(
            AdmissionRequest.make({
              ...next,
              workerAdmission: { ...workerAdmission, messageId: next.idempotencyKey },
            }),
          );
          yield* ledger.markReady(MarkReadyRequest.make({ submissionId: queued.submissionId }));
          if ("joined" in scenario || "joining" in scenario) {
            yield* ledger.claimJoining(
              ClaimJoiningRequest.make({
                threadId,
                hostSubmissionId: first.submissionId,
                ownershipToken: claim.ownershipToken,
                maxCount: 1,
              }),
            );
          }
          if ("joined" in scenario) {
            yield* ledger.markJoined(
              MarkJoinedRequest.make({
                submissionId: queued.submissionId,
                ownershipToken: claim.ownershipToken,
                recordId: submissionInputRecordId(queued.submissionId),
                sequence: Schema.decodeSync(CanonicalSequence)(2),
              }),
            );
          }
        }
        yield* ledger.reserveSettlement(
          SettlementReservation.make({
            submissionId: first.submissionId,
            ownershipToken: claim.ownershipToken,
            settlementId: payload.settlementId,
            outcome: scenario.outcome,
            record,
            recordDigest: yield* digestJson(
              yield* Schema.encodeEffect(RecordEnvelope)(record).pipe(Effect.orDie),
            ),
          }),
        );

        const finalization = SettlementFinalization.make({
          submissionId: first.submissionId,
          settlementId: payload.settlementId,
        });

        const settled = yield* ledger.finalizeSettlement(finalization);

        yield* ensure(
          Schema.toEquivalence(Settlement)(settled, yield* ledger.finalizeSettlement(finalization)),
          "Finalization replay must preserve its exact outcome",
        );
        const control = yield* ledger.inspectWorker(threadId);

        yield* ensure(
          control.terminal === scenario.terminal &&
            control.stopped === (scenario.terminal !== undefined),
          `Wrong assignment state for ${scenario.name}`,
        );
        yield* ensure(
          (yield* ledger.admit(request)).receiptId === first.receiptId,
          "A seal must preserve same-command receipt replay",
        );
        const next = yield* admissionRequest(threadId, "later", { text: "later" });

        const later = AdmissionRequest.make({
          ...next,
          workerAdmission: { ...workerAdmission, messageId: next.idempotencyKey },
        });

        if (scenario.terminal !== undefined) {
          const refusal = yield* expectFailure("terminal admission", ledger.admit(later));

          yield* ensure(
            Schema.is(AdmissionPolicyError)(refusal) && refusal.code === "worker-stopped",
            "New instructions cannot reopen a terminal assignment",
          );
        } else {
          yield* ledger.admit(later);
        }
        if (queued !== undefined) {
          if ("joining" in scenario)
            yield* ledger.revertJoining(
              RevertJoiningRequest.make({ submissionId: queued.submissionId }),
            );
          const state = yield* recoverySnapshot(queued.submissionId);

          yield* ensure(
            (state.abortIntent !== undefined) === (scenario.outcome === "failed"),
            "Failure aborts queued inputs; completion never cancels an accepted correction or joined member",
          );
        }
        if (scenario.terminal !== undefined && ledger.stopWorker !== undefined) {
          yield* ledger.stopWorker({ threadId, author: CONFORMANCE_PRINCIPAL });
          yield* ensure(
            (yield* ledger.inspectWorker(threadId)).terminal === scenario.terminal,
            "Explicit stop cannot replace an assignment's first terminal outcome",
          );
        }
      }
    }),
);

// Native turn-boundary yielding retained the active FIFO head:
// https://github.com/yielded-dev/agent/commit/2259fc05eec3bfac2a92a8d055953f3482e54735
const cooperativeHandoff = conformanceCase(
  "hands off complete Turns without bypassing ownership, ordering, cancellation or approval",
  ({ ensure, expectSome }) =>
    Effect.gen(function* () {
      const ledger = yield* SubmissionLedger;

      for (const scenario of [
        "ready",
        "live",
        "stale",
        "abort",
        "approval",
        "gap",
        "ready-prefix",
        "unapplied",
        "foreign",
      ] as const) {
        const threadId = decodeThreadId(`ledger-handoff-${scenario}`);
        const first = yield* admitReady(threadId, "first", { work: "old" });
        const claim = yield* expectSome("original claim", yield* claimLane(threadId, PRODUCER_A));

        if (scenario !== "unapplied")
          yield* ledger.markInputApplied(
            MarkInputAppliedRequest.make({
              submissionId: first.submissionId,
              ownershipToken: claim.ownershipToken,
              recordId: submissionInputRecordId(first.submissionId),
              sequence: decodeSequence(1),
            }),
          );
        if (scenario === "gap")
          yield* ledger.admit(yield* admissionRequest(threadId, "gap", { work: "not-ready" }));
        if (scenario === "ready-prefix") yield* admitReady(threadId, "prefix", { work: "earlier" });
        const next = yield* admitReady(threadId, "next", { work: "human" });

        const handoff = ClaimHandoff.make({
          producerEpoch: claim.producerEpoch,
          deferredSubmissionIds: [first.submissionId],
          submissionId: scenario === "foreign" ? decodeSubmissionId("foreign") : next.submissionId,
        });

        if (scenario === "approval") {
          yield* ledger.suspend(
            SuspendRequest.make({
              submissionId: first.submissionId,
              ownershipToken: claim.ownershipToken,
              reason: ApprovalPendingSuspension.make({
                toolCallIds: [decodeToolCallId("purchase")],
              }),
            }),
          );
        } else if (scenario !== "live") {
          yield* ledger.releaseOwnership(
            ReleaseOwnershipRequest.make({
              submissionId: first.submissionId,
              ownershipToken: claim.ownershipToken,
            }),
          );
        }
        if (scenario === "abort")
          yield* ledger.requestAbort(
            AbortCommand.make({
              submissionId: first.submissionId,
              author: "human",
              reason: "stop",
            }),
          );
        if (scenario === "stale") {
          const intervening = yield* expectSome(
            "intervening claim",
            yield* claimLane(threadId, PRODUCER_B),
          );

          yield* ledger.releaseOwnership(
            ReleaseOwnershipRequest.make({
              submissionId: first.submissionId,
              ownershipToken: intervening.ownershipToken,
            }),
          );
        }

        const selected = yield* ledger.claim(
          ClaimRequest.make({ threadId, producerId: PRODUCER_B, handoff }),
        );

        if (scenario !== "ready") {
          yield* ensure(Option.isNone(selected), `Handoff must preserve the ${scenario} boundary`);
          continue;
        }
        const nextClaim = yield* expectSome("ordered handoff claim", selected);

        yield* ensure(
          nextClaim.submissionId === next.submissionId &&
            nextClaim.producerEpoch > claim.producerEpoch,
          "Handoff must claim the next Submission with a new epoch",
        );
        yield* settleClaimed(next, nextClaim.ownershipToken);

        const resumed = yield* expectSome(
          "original Run resumes",
          yield* claimLane(threadId, PRODUCER_A),
        );

        yield* ensure(
          resumed.submissionId === first.submissionId,
          "The deferred Submission must retain its original obligation",
        );
        yield* ensure(
          (yield* recoverySnapshot(first.submissionId)).submission.receiptId === first.receiptId &&
            (yield* recoverySnapshot(next.submissionId)).submission.receiptId === next.receiptId,
          "Handoff must preserve both receipt identities",
        );
      }
    }),
);

/**
 * The shared, adapter-parameterized SubmissionLedger contract suite (STORE-010). Every durable
 * ledger adapter test suite must execute each case against its own ledger provisioning, inside
 * the `@effect/vitest` test environment (TestClock) and with `Crypto.Crypto` provided.
 */
export const submissionLedgerConformanceCases: ReadonlyArray<SubmissionLedgerConformanceCase> = [
  admissionIdempotency,
  workerAdmissionIdentity,
  assignmentSettlement,
  messageAdmissionIdentity,
  workerCompletionIdentity,
  workerUpdateIdentity,
  admissionGroupRace,
  admissionGroupSettlement,
  crossPrincipalAdmissionScoping,
  admissionTupleBoundaries,
  concurrentAdmissionFifo,
  fifoHeadClaim,
  cooperativeHandoff,
  leaseExpiryReclaim,
  releaseMakesHeadClaimable,
  inputAppliedIdempotency,
  settlementLifecycle,
  settlementConflicts,
  abortIdempotency,
  scanNonterminalWorklist,
  lookupByIdAndKey,
  recoverySnapshotConsistency,
  joiningPrefixClaim,
  revertJoiningReturnsToReady,
  markJoinedIdempotency,
  claimNeverGrantsBlockedHead,
  approvalDecisionIdempotency,
  unknownResolutionLifecycle,
  unknownAbortClaim,
  suspendResumesImmediatelyWhenDecided,
  joinedSettlementLinkageAuthority,
  childReservationIdempotency,
  childReservationFencing,
  attachChildIdempotency,
  beginReleaseFreezesAccountingOnce,
  releaseAppliedExactlyOnce,
  recordChildSettledWake,
  suspendResumesImmediatelyForSettledChildren,
  admissionParentLinkage,
  resolveAdmissionAuthority,
  queuedAbortSettlementAuthority,
  abortedSettledRowIsNotAJoiningGap,
];
